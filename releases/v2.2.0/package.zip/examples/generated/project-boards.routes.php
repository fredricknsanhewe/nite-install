<?php
use App\Controllers\ProjectBoardController;

// Auto-registered from routes/generated/project-boards.php.
// Public routes.
$r->get('/project-boards', [ProjectBoardController::class, 'list']);
$r->get('/project-boards/{slug}', [ProjectBoardController::class, 'show']);

// Admin routes.
// View permission: admin.project_boards.view
// Manage permission: admin.project_boards.manage
$r->get('/admin/project-boards', [ProjectBoardController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.project_boards.view'));
$r->post('/admin/project-boards', [ProjectBoardController::class, 'create'])->middleware($auth)->middleware($perm('admin.project_boards.manage'));
$r->get('/admin/project-boards/{id}', [ProjectBoardController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.project_boards.view'));
$r->put('/admin/project-boards/{id}', [ProjectBoardController::class, 'update'])->middleware($auth)->middleware($perm('admin.project_boards.manage'));
$r->patch('/admin/project-boards/{id}', [ProjectBoardController::class, 'update'])->middleware($auth)->middleware($perm('admin.project_boards.manage'));
$r->delete('/admin/project-boards/{id}', [ProjectBoardController::class, 'delete'])->middleware($auth)->middleware($perm('admin.project_boards.manage'));