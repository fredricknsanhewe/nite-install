<?php
use App\Controllers\SupportTicketController;

// Auto-registered from routes/generated/support-tickets.php.
// Public routes.
$r->get('/support-tickets', [SupportTicketController::class, 'list']);
$r->get('/support-tickets/{slug}', [SupportTicketController::class, 'show']);

// Admin routes.
// View permission: admin.support_tickets.view
// Manage permission: admin.support_tickets.manage
$r->get('/admin/support-tickets', [SupportTicketController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.support_tickets.view'));
$r->post('/admin/support-tickets', [SupportTicketController::class, 'create'])->middleware($auth)->middleware($perm('admin.support_tickets.manage'));
$r->get('/admin/support-tickets/{id}', [SupportTicketController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.support_tickets.view'));
$r->put('/admin/support-tickets/{id}', [SupportTicketController::class, 'update'])->middleware($auth)->middleware($perm('admin.support_tickets.manage'));
$r->patch('/admin/support-tickets/{id}', [SupportTicketController::class, 'update'])->middleware($auth)->middleware($perm('admin.support_tickets.manage'));
$r->delete('/admin/support-tickets/{id}', [SupportTicketController::class, 'delete'])->middleware($auth)->middleware($perm('admin.support_tickets.manage'));