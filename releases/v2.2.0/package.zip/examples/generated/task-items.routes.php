<?php
use App\Controllers\TaskItemController;

// Auto-registered from routes/generated/task-items.php.
// Public routes.
$r->get('/task-items', [TaskItemController::class, 'list']);
$r->get('/task-items/{slug}', [TaskItemController::class, 'show']);

// Admin routes.
// View permission: admin.task_items.view
// Manage permission: admin.task_items.manage
$r->get('/admin/task-items', [TaskItemController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.task_items.view'));
$r->post('/admin/task-items', [TaskItemController::class, 'create'])->middleware($auth)->middleware($perm('admin.task_items.manage'));
$r->get('/admin/task-items/{id}', [TaskItemController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.task_items.view'));
$r->put('/admin/task-items/{id}', [TaskItemController::class, 'update'])->middleware($auth)->middleware($perm('admin.task_items.manage'));
$r->patch('/admin/task-items/{id}', [TaskItemController::class, 'update'])->middleware($auth)->middleware($perm('admin.task_items.manage'));
$r->delete('/admin/task-items/{id}', [TaskItemController::class, 'delete'])->middleware($auth)->middleware($perm('admin.task_items.manage'));