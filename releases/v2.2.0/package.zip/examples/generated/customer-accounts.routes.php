<?php
use App\Controllers\CustomerAccountController;

// Auto-registered from routes/generated/customer-accounts.php.
// Public routes.
$r->get('/customer-accounts', [CustomerAccountController::class, 'list']);
$r->get('/customer-accounts/{slug}', [CustomerAccountController::class, 'show']);

// Admin routes.
// View permission: admin.customer_accounts.view
// Manage permission: admin.customer_accounts.manage
$r->get('/admin/customer-accounts', [CustomerAccountController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.customer_accounts.view'));
$r->post('/admin/customer-accounts', [CustomerAccountController::class, 'create'])->middleware($auth)->middleware($perm('admin.customer_accounts.manage'));
$r->get('/admin/customer-accounts/{id}', [CustomerAccountController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.customer_accounts.view'));
$r->put('/admin/customer-accounts/{id}', [CustomerAccountController::class, 'update'])->middleware($auth)->middleware($perm('admin.customer_accounts.manage'));
$r->patch('/admin/customer-accounts/{id}', [CustomerAccountController::class, 'update'])->middleware($auth)->middleware($perm('admin.customer_accounts.manage'));
$r->delete('/admin/customer-accounts/{id}', [CustomerAccountController::class, 'delete'])->middleware($auth)->middleware($perm('admin.customer_accounts.manage'));