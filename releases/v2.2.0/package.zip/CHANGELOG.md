# Changelog

## 2.2.0 - 2026-07-22

### Added

- Flysystem-backed media storage adapters for local, FTP/FTPS, S3-compatible, and HTTP storage.
- User permission-group assignment in the administration interface and `group_ids` on admin user updates.
- Configurable administration favicon through `NITE_ADMIN_FAVICON_URL`.
- Release metadata repair migration and first-release upgrade compatibility guidance.

### Changed

- New installations explicitly use the modern password-policy profile.
- Existing installations with no `NITE_PASSWORD_POLICY_PROFILE` retain compatible eight-character password defaults until they opt in.
- All release packages now include this changelog and `UPGRADE.md`.

### Compatibility

- Legacy role endpoints are retained through Nite 2.x and return `Deprecation: true` headers.
- The RBAC matrix response stays compatible with the installation's pre-2.1 or 2.1+ profile. Set `NITE_RBAC_MATRIX_FORMAT=legacy` or `groups` to choose explicitly.
- The migration ledger repair changes version metadata only; it does not alter application data or schema.

## Historical tag note

Early repository tags and embedded application versions were not always aligned. `v2.2.0` establishes the release/version convention: the tag, release package, and `App::VERSION` must match exactly.
