<?php
namespace App\Http\Middleware;

use App\Http\Request;
use App\Http\Response;
use App\Services\RbacService;

final class PermissionMiddleware
{
    public static function require(string|array $permissionCodeOrCodes): callable
    {
        $codes = is_array($permissionCodeOrCodes)
            ? array_values(array_map('strval', $permissionCodeOrCodes))
            : [(string)$permissionCodeOrCodes];

        return function (Request $request, callable $next) use ($codes): Response {
            $request->attributes['required_permissions'] = $codes;
            $userId = (string)($request->user['id'] ?? '');
            $role = (string)($request->user['role'] ?? '');
            if ($userId === '') {
                return Response::json(['error' => 'Unauthorized'], 401);
            }

            $rbac = new RbacService();
            if (!$rbac->hasAnyPermission($userId, $role, $codes)) {
                return Response::json([
                    'error' => 'Forbidden',
                    'required_permissions' => $codes,
                ], 403);
            }

            return $next($request);
        };
    }
}
