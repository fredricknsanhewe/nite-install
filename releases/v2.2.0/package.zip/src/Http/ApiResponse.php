<?php
namespace App\Http;

use App\Config\Env;

final class ApiResponse
{
    /**
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function success(
        mixed $data = [],
        string $message = 'Request completed successfully',
        int $status = 200,
        array $meta = [],
        array $headers = []
    ): Response {
        return Response::api(self::envelope('success', $status, $message, $data, null, $meta), $status, $headers);
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function error(
        string $message = 'Request failed',
        array|string|null $errors = null,
        int $status = 400,
        array $meta = [],
        array $headers = []
    ): Response {
        return Response::api(
            self::envelope('error', $status, $message, null, self::normalizeErrors($errors), $meta),
            $status,
            $headers
        );
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function validationError(
        array|string|null $errors = null,
        string $message = 'Validation failed',
        array $meta = [],
        array $headers = []
    ): Response {
        if (trim($message) === '' || $message === 'Validation failed') {
            $message = self::validationMessage($errors) ?? 'Validation failed';
        }

        return self::error($message, $errors, 422, $meta, $headers);
    }

    /**
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function exception(
        \Throwable $exception,
        string $fallbackMessage = 'Request failed',
        int $status = 500,
        array $meta = [],
        array $headers = []
    ): Response {
        error_log(sprintf(
            '%s: %s in %s:%d',
            $exception::class,
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine()
        ));

        if (!self::exposeErrorDetails()) {
            return self::error($fallbackMessage, null, $status, $meta, $headers);
        }

        return self::error(
            $fallbackMessage . ': ' . $exception->getMessage(),
            [
                'detail' => $exception->getMessage(),
                'exception' => $exception::class,
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
            ],
            $status,
            $meta,
            $headers
        );
    }

    /**
     * @return array<string, mixed>
     */
    public static function normalize(mixed $payload, int $status = 200): array
    {
        if (is_array($payload) && self::isEnvelope($payload)) {
            return self::sanitizeEnvelope($payload, $status);
        }

        $meta = [];
        if (is_array($payload) && isset($payload['meta']) && is_array($payload['meta'])) {
            $meta = $payload['meta'];
        }

        $message = is_array($payload) && is_string($payload['message'] ?? null)
            ? trim((string)$payload['message'])
            : '';

        if (is_array($payload) && array_key_exists('error_code', $payload)) {
            $meta['error_code'] = $payload['error_code'];
        }

        if ($status >= 400 || (is_array($payload) && (array_key_exists('error', $payload) || array_key_exists('errors', $payload)))) {
            if (is_array($payload) && array_key_exists('allowed_methods', $payload)) {
                $meta['allowed_methods'] = $payload['allowed_methods'];
            }
            if (is_array($payload) && array_key_exists('required_permissions', $payload)) {
                $meta['required_permissions'] = $payload['required_permissions'];
            }

            $message = $message !== ''
                ? $message
                : (is_array($payload) && is_string($payload['error'] ?? null)
                    ? (string)$payload['error']
                    : self::defaultErrorMessage($status));

            $errors = null;
            if (is_array($payload) && array_key_exists('errors', $payload)) {
                $errors = self::normalizeErrors($payload['errors']);
            } elseif (is_array($payload) && array_key_exists('detail', $payload) && $payload['detail'] !== null) {
                $errors = self::normalizeErrors(['detail' => $payload['detail']]);
            }

            return self::envelope('error', $status, $message, null, $errors, $meta);
        }

        $data = is_array($payload) && array_key_exists('data', $payload)
            ? $payload['data']
            : $payload;

        if (is_array($payload) && array_key_exists('allowed_methods', $payload)) {
            $meta['allowed_methods'] = $payload['allowed_methods'];
        }

        return self::envelope(
            'success',
            $status,
            $message !== '' ? $message : self::defaultSuccessMessage($status),
            $data,
            null,
            $meta
        );
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @return array<string, mixed>|null
     */
    private static function normalizeErrors(array|string|null $errors): ?array
    {
        if ($errors === null) {
            return null;
        }

        if (is_string($errors)) {
            $trimmed = trim($errors);
            return $trimmed === '' ? null : ['detail' => $trimmed];
        }

        return $errors === [] ? [] : $errors;
    }

    /**
     * @param array<string, mixed>|string|null $errors
     */
    private static function validationMessage(array|string|null $errors): ?string
    {
        $parts = self::flattenErrorParts($errors);
        if ($parts === []) {
            return null;
        }

        return implode(' ', array_slice($parts, 0, 4));
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @return array<int, string>
     */
    private static function flattenErrorParts(array|string|null $errors, string $prefix = ''): array
    {
        if ($errors === null) {
            return [];
        }

        if (is_string($errors)) {
            $text = trim($errors);
            return $text === '' ? [] : [$prefix !== '' ? self::labelize($prefix) . ': ' . $text : $text];
        }

        $parts = [];
        foreach ($errors as $field => $value) {
            $path = $prefix !== '' ? $prefix . '.' . (string)$field : (string)$field;
            if (is_array($value)) {
                if (array_is_list($value)) {
                    $messages = array_values(array_filter(array_map(
                        static fn (mixed $item): string => trim(is_scalar($item) ? (string)$item : (json_encode($item, JSON_UNESCAPED_SLASHES) ?: '')),
                        $value
                    )));
                    if ($messages !== []) {
                        $parts[] = self::labelize($path) . ': ' . implode(' ', $messages);
                    }
                    continue;
                }

                array_push($parts, ...self::flattenErrorParts($value, $path));
                continue;
            }

            if ($value !== null && trim((string)$value) !== '') {
                $parts[] = self::labelize($path) . ': ' . (string)$value;
            }
        }

        return $parts;
    }

    private static function labelize(string $field): string
    {
        $label = preg_replace('/[_\-.]+/', ' ', $field) ?: $field;
        return ucwords(trim($label));
    }

    /**
     * @param array<string, mixed> $payload
     */
    private static function isEnvelope(array $payload): bool
    {
        $required = ['status', 'code', 'message', 'data', 'errors', 'meta'];
        foreach ($required as $key) {
            if (!array_key_exists($key, $payload)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private static function sanitizeEnvelope(array $payload, int $status): array
    {
        $state = strtolower(trim((string)($payload['status'] ?? 'success')));
        $state = $state === 'error' || $status >= 400 ? 'error' : 'success';
        $message = trim((string)($payload['message'] ?? ''));
        $meta = is_array($payload['meta'] ?? null) ? $payload['meta'] : [];
        $errors = self::normalizeErrors($payload['errors'] ?? null);
        $data = $payload['data'] ?? null;

        if ($state === 'error') {
            $data = null;
            $errors = $errors ?? [];
            if ($message === '') {
                $message = self::defaultErrorMessage($status);
            }
        } else {
            $errors = null;
            if ($message === '') {
                $message = self::defaultSuccessMessage($status);
            }
        }

        return self::envelope($state, $status, $message, $data, $errors, $meta);
    }

    /**
     * @param array<string, mixed>|null $errors
     * @param array<string, mixed> $meta
     * @return array<string, mixed>
     */
    private static function envelope(string $status, int $code, string $message, mixed $data, ?array $errors, array $meta): array
    {
        return [
            'status' => $status,
            'code' => $code,
            'message' => $message,
            'data' => $status === 'success' ? $data : null,
            'errors' => $status === 'error' ? self::jsonObject($errors ?? []) : null,
            'meta' => self::jsonObject($meta),
        ];
    }

    private static function defaultSuccessMessage(int $status): string
    {
        return match ($status) {
            201 => 'Created successfully',
            202 => 'Request accepted',
            default => 'Request completed successfully',
        };
    }

    private static function defaultErrorMessage(int $status): string
    {
        return match ($status) {
            400 => 'Bad request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not found',
            405 => 'Method not allowed',
            422 => 'Validation failed',
            500 => 'Internal server error',
            default => 'Request failed',
        };
    }

    private static function exposeErrorDetails(): bool
    {
        return Env::bool('APP_DEBUG', false);
    }

    /**
     * @param array<string, mixed> $value
     */
    private static function jsonObject(array $value): array|\stdClass
    {
        return $value === [] ? (object)[] : $value;
    }
}
