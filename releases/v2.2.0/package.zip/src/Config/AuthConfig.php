<?php
namespace App\Config;

final class AuthConfig
{
    public static function passwordMinLength(): int
    {
        return max(8, Env::int('AUTH_PASSWORD_MIN_LENGTH', self::usesModernPasswordPolicy() ? 12 : 8));
    }

    public static function requireUppercase(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_UPPERCASE', self::usesModernPasswordPolicy());
    }

    public static function requireLowercase(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_LOWERCASE', self::usesModernPasswordPolicy());
    }

    public static function requireNumber(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_NUMBER', self::usesModernPasswordPolicy());
    }

    public static function requireSymbol(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_SYMBOL', self::usesModernPasswordPolicy());
    }

    public static function bcryptCost(): int
    {
        return max(10, min(15, Env::int('AUTH_BCRYPT_COST', 12)));
    }

    public static function throttleEnabled(): bool
    {
        return Env::bool('AUTH_LOGIN_THROTTLE_ENABLED', true);
    }

    public static function maxLoginAttempts(): int
    {
        return max(1, Env::int('AUTH_LOGIN_MAX_ATTEMPTS', 5));
    }

    public static function loginDecaySeconds(): int
    {
        return max(60, Env::int('AUTH_LOGIN_DECAY_SECONDS', 900));
    }

    public static function lockoutSeconds(): int
    {
        return max(60, Env::int('AUTH_LOGIN_LOCKOUT_SECONDS', 900));
    }

    public static function tokenIssuer(): ?string
    {
        $value = trim((string)Env::get('AUTH_TOKEN_ISSUER', ''));
        return $value !== '' ? $value : null;
    }

    public static function tokenAudience(): ?string
    {
        $value = trim((string)Env::get('AUTH_TOKEN_AUDIENCE', ''));
        return $value !== '' ? $value : null;
    }

    /**
     * @return array<string, string>
     */
    public static function jwtValidationOptions(): array
    {
        $options = [];
        $issuer = self::tokenIssuer();
        if ($issuer !== null) {
            $options['issuer'] = $issuer;
        }

        $audience = self::tokenAudience();
        if ($audience !== null) {
            $options['audience'] = $audience;
        }

        return $options;
    }

    public static function jwtSecret(): string
    {
        return (string)Env::get('JWT_SECRET', 'unsafe-default');
    }

    public static function jwtSecretIsWeak(): bool
    {
        $secret = trim(self::jwtSecret());
        if ($secret === '') {
            return true;
        }

        if (in_array(strtolower($secret), ['change-me', 'unsafe-default', 'secret', 'password'], true)) {
            return true;
        }

        return strlen($secret) < 32;
    }

    /**
     * Existing installations without a profile retain their original password
     * rules. New installations select the stronger profile in .env.example.
     */
    private static function usesModernPasswordPolicy(): bool
    {
        return strtolower(trim((string)Env::get('NITE_PASSWORD_POLICY_PROFILE', 'legacy'))) === 'modern';
    }
}
