<?php
namespace App\Config;

use App\Support\GeneratedResourceRegistry;

final class PermissionCatalog
{
    /**
     * @return array<int, array<string, mixed>>
     */
    public static function definitions(): array
    {
        static $definitions = null;
        if ($definitions !== null) {
            return $definitions;
        }

        $definitions = [
            self::def('module.framework_catalog.access', 'Framework Catalog', 'Access the Nite framework catalog and starter examples.', 'navigation', 'Navigation', 'framework_catalog', 'Framework Catalog', 'access', 'Access', 90, Roles::all()),
            self::def('module.member_dashboard.access', 'Member Dashboard', 'Access the authenticated member dashboard.', 'navigation', 'Navigation', 'member_dashboard', 'Member Dashboard', 'access', 'Access', 100, [Roles::MEMBER, Roles::TRAINER, Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('module.admin_dashboard.access', 'Admin Dashboard', 'Access the administrative dashboard.', 'navigation', 'Navigation', 'admin_dashboard', 'Admin Dashboard', 'access', 'Access', 110, [Roles::TRAINER, Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),

            self::def('profile.me.view', 'View Own Profile', 'Read the authenticated user profile.', 'account', 'Account', 'profile', 'Profile', 'view', 'View', 200, Roles::all()),
            self::def('profile.me.manage', 'Manage Own Profile', 'Update the authenticated user profile.', 'account', 'Account', 'profile', 'Profile', 'manage', 'Manage', 210, Roles::all()),

            self::def('framework.examples.view', 'View Framework Examples', 'Browse Nite module examples and starter entities.', 'framework', 'Framework', 'examples', 'Examples', 'view', 'View', 250, Roles::all()),
            self::def('framework.examples.manage', 'Manage Framework Examples', 'Create and update module example entities and timeline entries.', 'framework', 'Framework', 'examples', 'Examples', 'manage', 'Manage', 260, [Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('framework.examples.sensitive.manage', 'Manage Sensitive Examples', 'Manage payments, trust, subscriptions, recruitment, and analytics example data.', 'framework', 'Framework', 'examples_sensitive', 'Sensitive Examples', 'manage', 'Manage', 270, [Roles::ADMIN]),

            self::def('courses.catalog.view', 'View Course Catalog', 'View the public and authenticated course catalog.', 'lms', 'eLearning', 'courses', 'Courses', 'view', 'View', 300, Roles::all()),
            self::def('courses.enroll', 'Enroll In Courses', 'Enroll in available starter course examples.', 'lms', 'eLearning', 'courses', 'Courses', 'enroll', 'Enroll', 310, [Roles::MEMBER, Roles::TRAINER, Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('courses.progress.manage', 'Manage Own Course Progress', 'Update own learning progress records.', 'lms', 'eLearning', 'course_progress', 'Course Progress', 'manage', 'Manage', 320, [Roles::MEMBER, Roles::TRAINER, Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('events.view', 'View Trainings And Events', 'View training and event listings.', 'public_site', 'Public Site', 'events', 'Events', 'view', 'View', 330, Roles::all()),
            self::def('events.register', 'Register For Events', 'Register for published training events.', 'public_site', 'Public Site', 'events', 'Events', 'register', 'Register', 340, Roles::all()),
            self::def('contact.create', 'Send Contact Messages', 'Submit contact or support messages.', 'public_site', 'Public Site', 'contact', 'Contact', 'create', 'Create', 350, Roles::all()),

            self::def('admin.users.view', 'View Users', 'View users in the admin console.', 'administration', 'Administration', 'users', 'Users', 'view', 'View', 400, [Roles::SUPPORT, Roles::ADMIN]),
            self::def('admin.users.manage', 'Manage Users', 'Create, update, and delete users.', 'administration', 'Administration', 'users', 'Users', 'manage', 'Manage', 410, [Roles::ADMIN]),
            self::def('admin.rbac.view', 'View RBAC', 'Read group and permission matrices.', 'administration', 'Administration', 'rbac', 'RBAC', 'view', 'View', 420, [Roles::ADMIN]),
            self::def('admin.rbac.manage', 'Manage RBAC', 'Update group and user permission rules.', 'administration', 'Administration', 'rbac', 'RBAC', 'manage', 'Manage', 430, [Roles::ADMIN]),
            self::def('admin.security.manage', 'Manage Security Policy', 'Update password complexity, reset, age, and history policy.', 'administration', 'Administration', 'security', 'Security Policy', 'manage', 'Manage', 435, [Roles::ADMIN]),
            self::def('admin.site_settings.view', 'View Site Settings', 'View global site and navigation settings.', 'administration', 'Administration', 'site_settings', 'Site Settings', 'view', 'View', 440, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.site_settings.manage', 'Manage Site Settings', 'Update global site and navigation settings.', 'administration', 'Administration', 'site_settings', 'Site Settings', 'manage', 'Manage', 441, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.pages.view', 'View Pages', 'View public website page content in the admin console.', 'administration', 'Administration', 'pages', 'Pages', 'view', 'View', 450, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.pages.manage', 'Manage Pages', 'Manage public website page content.', 'administration', 'Administration', 'pages', 'Pages', 'manage', 'Manage', 451, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.news.view', 'View News', 'View news, announcements, and notices in the admin console.', 'administration', 'Administration', 'news', 'News', 'view', 'View', 460, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.news.manage', 'Manage News', 'Manage news, announcements, and notices.', 'administration', 'Administration', 'news', 'News', 'manage', 'Manage', 461, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.events.view', 'View Events', 'View trainings, calendars, and registrations in the admin console.', 'administration', 'Administration', 'events', 'Events', 'view', 'View', 470, [Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.events.manage', 'Manage Events', 'Manage trainings, calendars, and registrations.', 'administration', 'Administration', 'events', 'Events', 'manage', 'Manage', 471, [Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.resources.view', 'View Resources', 'View publications, manuals, and repository content in the admin console.', 'administration', 'Administration', 'resources', 'Resources', 'view', 'View', 480, [Roles::EDITOR, Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.resources.manage', 'Manage Resources', 'Manage publications, manuals, and repository content.', 'administration', 'Administration', 'resources', 'Resources', 'manage', 'Manage', 481, [Roles::EDITOR, Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.gallery.view', 'View Gallery', 'View gallery albums and media items in the admin console.', 'administration', 'Administration', 'gallery', 'Gallery', 'view', 'View', 490, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.gallery.manage', 'Manage Gallery', 'Manage gallery albums and media items.', 'administration', 'Administration', 'gallery', 'Gallery', 'manage', 'Manage', 491, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.media.view', 'View Media Library', 'View media assets, versions, and history.', 'administration', 'Administration', 'media', 'Media Library', 'view', 'View', 500, [Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('admin.media.manage', 'Manage Media Library', 'Upload, replace, delete, restore, and manage reusable media assets.', 'administration', 'Administration', 'media', 'Media Library', 'manage', 'Manage', 505, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.contacts.view', 'View Contact Messages', 'View website contact and helpdesk messages.', 'administration', 'Administration', 'contacts', 'Contacts', 'view', 'View', 510, [Roles::SUPPORT, Roles::ADMIN]),
            self::def('admin.contacts.manage', 'Manage Contact Messages', 'Update contact message status and assignments.', 'administration', 'Administration', 'contacts', 'Contacts', 'manage', 'Manage', 520, [Roles::SUPPORT, Roles::ADMIN]),
            self::def('admin.courses.view', 'View Courses', 'View courses, modules, and enrollments in the admin console.', 'administration', 'Administration', 'courses', 'Courses', 'view', 'View', 530, [Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.courses.manage', 'Manage Courses', 'Manage courses, modules, and enrollments.', 'administration', 'Administration', 'courses', 'Courses', 'manage', 'Manage', 531, [Roles::TRAINER, Roles::ADMIN]),
            self::def('admin.sample_records.view', 'View Sample Records', 'Read the example CRUD module and its archive history.', 'administration', 'Administration', 'sample_records', 'Sample Records', 'view', 'View', 535, [Roles::EDITOR, Roles::SUPPORT, Roles::ADMIN]),
            self::def('admin.sample_records.manage', 'Manage Sample Records', 'Create, update, archive-delete, and restore sample records.', 'administration', 'Administration', 'sample_records', 'Sample Records', 'manage', 'Manage', 537, [Roles::EDITOR, Roles::ADMIN]),
            self::def('admin.audit_logs.view', 'View Audit Logs', 'Read system audit log entries.', 'administration', 'Administration', 'audit_logs', 'Audit Logs', 'view', 'View', 540, [Roles::ADMIN]),
            self::def('admin.audit_logs.restore', 'Restore Archived Data', 'Restore a prior record snapshot from the recovery audit log.', 'administration', 'Administration', 'audit_logs', 'Audit Logs', 'restore', 'Restore', 541, [Roles::ADMIN]),
        ];

        foreach (GeneratedResourceRegistry::permissionDefinitions() as $definition) {
            $definitions[] = $definition;
        }

        usort($definitions, static function (array $left, array $right): int {
            return [(int)($left['sort_order'] ?? 0), (string)($left['code'] ?? '')]
                <=> [(int)($right['sort_order'] ?? 0), (string)($right['code'] ?? '')];
        });

        return $definitions;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public static function indexed(): array
    {
        static $indexed = null;
        if ($indexed !== null) {
            return $indexed;
        }

        $indexed = [];
        foreach (self::definitions() as $definition) {
            $indexed[(string)$definition['code']] = $definition;
        }

        return $indexed;
    }

    public static function isGrantedByDefault(string $role, string $permissionCode): bool
    {
        $definition = self::indexed()[$permissionCode] ?? null;
        if ($definition === null) {
            return false;
        }

        return in_array($role, $definition['default_roles'], true);
    }

    /**
     * @return array<int, string>
     */
    public static function codes(): array
    {
        return array_values(array_map(
            static fn (array $definition): string => (string)$definition['code'],
            self::definitions()
        ));
    }

    /**
     * @param array<int, string> $defaultRoles
     * @return array<string, mixed>
     */
    private static function def(
        string $code,
        string $title,
        string $description,
        string $sectionCode,
        string $sectionTitle,
        string $moduleCode,
        string $moduleTitle,
        string $actionCode,
        string $actionTitle,
        int $sortOrder,
        array $defaultRoles
    ): array {
        return [
            'code' => $code,
            'title' => $title,
            'description' => $description,
            'section_code' => $sectionCode,
            'section_title' => $sectionTitle,
            'module_code' => $moduleCode,
            'module_title' => $moduleTitle,
            'action_code' => $actionCode,
            'action_title' => $actionTitle,
            'sort_order' => $sortOrder,
            'default_roles' => array_values($defaultRoles),
        ];
    }
}
