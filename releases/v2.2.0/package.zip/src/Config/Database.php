<?php
namespace App\Config;

use PDO;
use PDOException;

final class Database
{
    private static ?PDO $connection = null;

    public static function driver(): string
    {
        $driver = strtolower(trim((string)Env::get('DB_DRIVER', 'pgsql')));
        return $driver === '' ? 'pgsql' : $driver;
    }

    public static function schemaPath(?string $driver = null): string
    {
        $selectedDriver = strtolower(trim((string)($driver ?? self::driver())));
        $schemaFile = $selectedDriver === 'mysql' ? 'schema.mysql.sql' : 'schema.sql';
        return dirname(__DIR__, 2) . '/database/' . $schemaFile;
    }

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $driver = self::driver();
        if (!in_array($driver, ['pgsql', 'mysql'], true)) {
            throw new PDOException('Unsupported DB driver: ' . $driver . '. Supported drivers: pgsql, mysql.');
        }

        $host = trim((string)Env::get('DB_HOST', '127.0.0.1'));
        $port = trim((string)Env::get('DB_PORT', $driver === 'mysql' ? '3306' : '5432'));
        $name = trim((string)Env::get('DB_NAME', 'nite'));
        $user = trim((string)Env::get('DB_USER', $driver === 'mysql' ? 'root' : 'postgres'));
        $password = (string)Env::get('DB_PASSWORD', '');

        $dsn = $driver === 'mysql'
            ? sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $host, $port, $name)
            : sprintf('pgsql:host=%s;port=%s;dbname=%s', $host, $port, $name);

        self::$connection = new PDO($dsn, $user, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => $driver === 'mysql',
            PDO::ATTR_TIMEOUT => max(1, (int)Env::get('DB_TIMEOUT_SECONDS', '5')),
        ]);
        self::$connection->exec($driver === 'mysql' ? "SET time_zone = '+00:00'" : "SET TIME ZONE 'UTC'");

        return self::$connection;
    }
}
