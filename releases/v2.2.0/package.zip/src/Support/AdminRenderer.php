<?php
namespace App\Support;

use App\Config\Env;

final class AdminRenderer
{
    /**
     * @param array<int, array<string, mixed>> $routes
     */
    public static function render(array $routes, ?string $selection = null): string
    {
        $context = self::adminContext($selection);
        $payload = [
            'summary' => ApiExplorerCatalog::summary(),
            'resources' => self::adminResources($routes),
            'routes' => array_values($routes),
            'context' => $context,
            'admin_base_path' => '/admin',
            'api_base_path' => '/api/v1',
            'app_name' => trim((string)Env::get('APP_NAME', 'Nite')) ?: 'Nite',
            'generated_at' => gmdate('c'),
        ];
        $siteUrl = htmlspecialchars(
            trim((string)Env::get('FRONTEND_URL', '/')) ?: '/',
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
        $adminTitle = htmlspecialchars(
            trim((string)Env::get('ADMIN_TITLE', 'Nite Administration')) ?: 'Nite Administration',
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
        $adminFaviconUrl = htmlspecialchars(
            trim((string)Env::get('NITE_ADMIN_FAVICON_URL', '')),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
        $adminFaviconLink = $adminFaviconUrl === ''
            ? ''
            : "\n    <link rel=\"icon\" href=\"{$adminFaviconUrl}\">";

        $encoded = json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if (!is_string($encoded)) {
            $encoded = '{}';
        }

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$adminTitle}</title>
    {$adminFaviconLink}
    <style>
        :root {
            color-scheme: light;
            --header-bg: #417690;
            --header-text: #ffffff;
            --brand: #f5dd5d;
            --crumb-bg: #79aec8;
            --module-header: #79aec8;
            --module-header-text: #ffffff;
            --link: #2b6f91;
            --link-active: #205067;
            --body-bg: #ffffff;
            --panel-bg: #ffffff;
            --row-alt: #f8f8f8;
            --selected: #ffffcc;
            --line: #e5e5e5;
            --text: #333333;
            --muted: #666666;
            --button: #79aec8;
            --button-hover: #609ab6;
            --danger: #ba2121;
            --success: #44b78b;
            --radius: 4px;
            --font: "Segoe UI", Tahoma, Arial, sans-serif;
        }

        body[data-theme="midnight"] {
            color-scheme: dark;
            --header-bg: #6577a6;
            --header-text: #f4f6ff;
            --brand: #ffff75;
            --crumb-bg: #45506e;
            --module-header: #6577a6;
            --module-header-text: #ffffff;
            --link: #80deea;
            --link-active: #b3f5ff;
            --body-bg: #282a36;
            --panel-bg: #343647;
            --row-alt: #3b3d50;
            --selected: #4a4c30;
            --line: #4b4d62;
            --text: #eeeeee;
            --muted: #c8c8d2;
            --button: #6577a6;
            --button-hover: #7386b8;
            --danger: #ff6b6b;
            --success: #69f0ae;
        }

        body[data-theme="graphite"] {
            --header-bg: #333333;
            --brand: #f4d35e;
            --crumb-bg: #555555;
            --module-header: #666666;
            --link: #1f6f8b;
            --button: #666666;
            --button-hover: #505050;
        }

        body[data-theme="forest"] {
            --header-bg: #315b4d;
            --brand: #e5f77d;
            --crumb-bg: #5f8c78;
            --module-header: #5f8c78;
            --link: #216b58;
            --button: #5f8c78;
            --button-hover: #4a7664;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--body-bg);
            color: var(--text);
            font: 14px/1.45 var(--font);
        }

        a {
            color: var(--link);
            text-decoration: none;
        }

        a:hover {
            color: var(--link-active);
            text-decoration: underline;
        }

        button, input, select, textarea {
            font: inherit;
        }

        .admin-header {
            min-height: 68px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            padding: 0 44px;
            background: var(--header-bg);
            color: var(--header-text);
        }

        .brand {
            color: var(--brand);
            font-size: 25px;
            font-weight: 300;
            letter-spacing: 0;
            white-space: nowrap;
        }

        .user-tools {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
            flex-wrap: wrap;
            color: var(--header-text);
            font-size: 12px;
            text-transform: uppercase;
        }

        .user-tools strong {
            letter-spacing: .08em;
        }

        .user-tools a,
        .user-tools button,
        .user-tools select {
            color: var(--header-text);
            background: transparent;
            border: 0;
            border-bottom: 1px solid rgba(255, 255, 255, .55);
            padding: 1px 0;
            text-transform: uppercase;
            cursor: pointer;
        }

        .user-tools select {
            max-width: 110px;
            text-transform: none;
        }

        .breadcrumbs {
            min-height: 42px;
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 0 44px;
            background: var(--crumb-bg);
            color: #ffffff;
            font-size: 14px;
        }

        .breadcrumbs a {
            color: #ffffff;
            font-weight: 600;
        }

        .main {
            display: grid;
            grid-template-columns: 330px minmax(0, 1fr);
            min-height: calc(100vh - 110px);
        }

        .sidebar {
            border-right: 1px solid var(--line);
            background: color-mix(in srgb, var(--panel-bg) 95%, var(--module-header));
            min-height: 100%;
        }

        .sidebar-toggle {
            display: none;
        }

        .sidebar-search {
            padding: 8px 22px 7px;
            border-bottom: 1px solid var(--line);
        }

        .sidebar-search input {
            width: 100%;
            height: 29px;
            border: 1px solid #cccccc;
            border-radius: 0;
            padding: 3px 7px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .app-group {
            margin: 22px 22px 0;
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .app-group h2 {
            margin: 0;
            padding: 9px 11px;
            background: var(--module-header);
            color: var(--module-header-text);
            font-size: 12px;
            line-height: 1.2;
            letter-spacing: .06em;
            text-transform: uppercase;
        }

        .model-row {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto auto;
            align-items: center;
            min-height: 38px;
            border-top: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .model-row:nth-child(odd) {
            background: var(--row-alt);
        }

        .model-row.is-current {
            background: var(--selected);
        }

        .model-row a {
            padding: 9px 11px;
            font-weight: 600;
        }

        .row-action {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 9px 8px;
            font-size: 13px;
            white-space: nowrap;
        }

        .row-action::before {
            color: var(--success);
            font-weight: 800;
        }

        .row-action.add::before {
            content: "+";
        }

        .row-action.change::before {
            content: ">";
            color: #f0a33a;
        }

        .content {
            padding: 28px 44px 54px;
            min-width: 0;
        }

        .page-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            margin-bottom: 22px;
        }

        h1 {
            margin: 0 0 8px;
            color: var(--text);
            font-size: 24px;
            font-weight: 300;
        }

        .object-title {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
        }

        .muted {
            color: var(--muted);
        }

        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            min-height: 30px;
            padding: 6px 13px;
            border: 0;
            border-radius: 15px;
            background: #888888;
            color: #ffffff;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            cursor: pointer;
        }

        .button:hover {
            color: #ffffff;
            text-decoration: none;
            background: #777777;
        }

        .button.primary {
            border-radius: var(--radius);
            background: var(--button);
            text-transform: none;
            font-size: 14px;
            min-height: 36px;
        }

        .button.primary:hover {
            background: var(--button-hover);
        }

        .button.danger {
            background: var(--danger);
        }

        .button.flat {
            border-radius: var(--radius);
            background: transparent;
            color: var(--link);
            text-transform: none;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 345px;
            gap: 52px;
            align-items: start;
            max-width: 1220px;
        }

        .module {
            margin-bottom: 28px;
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .module h2,
        .fieldset h2,
        .filter-panel h2,
        .recent h2 {
            margin: 0;
            padding: 10px 12px;
            background: var(--module-header);
            color: var(--module-header-text);
            font-size: 13px;
            letter-spacing: .06em;
            text-transform: uppercase;
        }

        .module table {
            width: 100%;
            border-collapse: collapse;
        }

        .module th,
        .module td {
            border-top: 1px solid var(--line);
            padding: 9px 11px;
            text-align: left;
            vertical-align: middle;
        }

        .module th {
            width: 45%;
            font-weight: 600;
        }

        .module td.actions {
            width: 1%;
            white-space: nowrap;
            text-align: right;
        }

        .recent {
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .recent h2 {
            background: transparent;
            color: var(--text);
            padding: 18px 20px;
            border-bottom: 1px solid var(--line);
            font-size: 20px;
            letter-spacing: 0;
            text-transform: none;
        }

        .recent h3 {
            margin: 0;
            padding: 14px 20px 10px;
            font-size: 14px;
        }

        .recent-list {
            list-style: none;
            margin: 0;
            padding: 0 20px 20px;
        }

        .recent-list li {
            margin: 0 0 12px;
            display: grid;
            grid-template-columns: 18px minmax(0, 1fr);
            gap: 8px;
        }

        .recent-kind {
            display: block;
            color: var(--muted);
            font-size: 12px;
        }

        .changelist-tools {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            gap: 18px;
            align-items: center;
            margin-bottom: 12px;
        }

        .searchbar {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 0;
        }

        .searchbar input {
            width: min(420px, 100%);
            height: 32px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 5px 8px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .actions-bar {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin: 0 0 14px;
            color: var(--muted);
        }

        .actions-bar select {
            min-width: 210px;
            height: 32px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            background: var(--panel-bg);
            color: var(--text);
        }

        .list-layout {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 250px;
            gap: 24px;
            align-items: start;
        }

        .result-table-wrap {
            overflow: auto;
            border-top: 1px solid var(--line);
            border-bottom: 1px solid var(--line);
        }

        .result-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 720px;
        }

        .result-table th,
        .result-table td {
            padding: 9px 10px;
            border-bottom: 1px solid var(--line);
            text-align: left;
            vertical-align: middle;
            white-space: nowrap;
        }

        .result-table th {
            background: var(--row-alt);
            color: var(--muted);
            font-size: 11px;
            text-transform: uppercase;
        }

        .result-table th button {
            border: 0;
            padding: 0;
            background: transparent;
            color: inherit;
            font: inherit;
            text-transform: inherit;
            cursor: pointer;
        }

        .result-table tr:nth-child(even) td {
            background: var(--row-alt);
        }

        .result-table tr.is-selected td {
            background: var(--selected);
        }

        .object-link {
            font-weight: 600;
        }

        .thumb {
            width: 52px;
            height: 38px;
            object-fit: cover;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--row-alt);
        }

        .bool {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            color: #ffffff;
            font-size: 12px;
            font-weight: 800;
        }

        .bool.true {
            background: #70bf2b;
        }

        .bool.false {
            background: #ba2121;
        }

        .filter-panel {
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .object-tools {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 8px;
        }

        .paginator {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin: 12px 0 0;
            color: var(--muted);
        }

        .paginator button,
        .permission-toolbar button {
            min-height: 30px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            background: var(--panel-bg);
            color: var(--text);
            cursor: pointer;
        }

        .paginator button[disabled] {
            opacity: .45;
            cursor: default;
        }

        .permission-toolbar {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin: 0 0 14px;
        }

        .permission-toolbar input,
        .permission-toolbar select {
            min-height: 30px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            background: var(--panel-bg);
            color: var(--text);
        }

        .permission-toolbar input {
            min-width: 220px;
            padding: 0 8px;
        }

        .permission-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 0 0 12px;
        }

        .permission-chip,
        .permission-kind {
            display: inline-flex;
            align-items: center;
            min-height: 22px;
            padding: 2px 8px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: #f8f8f8;
            color: var(--muted);
            font-size: 12px;
            white-space: nowrap;
        }

        [data-theme="midnight"] .permission-chip,
        [data-theme="midnight"] .permission-kind,
        [data-theme="graphite"] .permission-chip,
        [data-theme="graphite"] .permission-kind {
            background: #1f2937;
        }

        .permission-table select {
            min-width: 104px;
            height: 30px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            background: var(--panel-bg);
            color: var(--text);
        }

        .permission-table .effective {
            text-align: center;
        }

        .permission-table .role-cell {
            min-width: 120px;
        }

        .permission-table .role-default {
            margin-top: 4px;
            color: var(--muted);
            font-size: 11px;
            text-align: center;
        }

        .permission-table .permission-description {
            max-width: 360px;
            margin-top: 3px;
        }

        .permission-table tr.is-hidden {
            display: none;
        }

        .filter-panel h2 {
            background: transparent;
            color: var(--text);
            border-bottom: 1px solid var(--line);
            text-transform: none;
            letter-spacing: 0;
        }

        .filter-body {
            padding: 12px;
        }

        .filter-field {
            margin-bottom: 14px;
        }

        .filter-field label {
            display: block;
            margin-bottom: 4px;
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
        }

        .filter-field input,
        .filter-field select {
            width: 100%;
            height: 32px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 5px 7px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .form-layout {
            max-width: 1100px;
        }

        .fieldset {
            margin: 0 0 28px;
            border: 0;
            border-top: 1px solid var(--line);
            padding: 0;
        }

        .fieldset h2 {
            margin: 18px 0 0;
        }

        .form-row {
            display: grid;
            grid-template-columns: 220px minmax(0, 1fr);
            gap: 18px;
            align-items: start;
            padding: 12px 0;
            border-bottom: 1px solid var(--line);
        }

        .form-row label {
            padding-top: 7px;
            font-weight: 700;
        }

        .form-row.required label::after {
            content: " *";
            color: var(--danger);
        }

        .field-control input:not([type="checkbox"]):not([type="radio"]),
        .field-control select,
        .field-control textarea {
            width: min(520px, 100%);
            min-height: 34px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 6px 8px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .field-control textarea {
            min-height: 108px;
            resize: vertical;
            font-family: Consolas, "Courier New", monospace;
        }

        .help {
            margin-top: 5px;
            color: var(--muted);
            font-size: 12px;
        }

        .readonly-value {
            padding-top: 7px;
            color: var(--muted);
            word-break: break-word;
        }

        .upload-row {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 8px;
        }

        .image-preview {
            display: block;
            width: 145px;
            height: 92px;
            margin-top: 8px;
            object-fit: cover;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--row-alt);
        }

        .media-picker-backdrop {
            position: fixed;
            inset: 0;
            z-index: 90;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: rgba(0, 0, 0, 0.45);
        }

        .media-picker {
            width: min(980px, 96vw);
            max-height: 88vh;
            overflow: auto;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--panel-bg);
            box-shadow: 0 18px 48px rgba(0, 0, 0, 0.28);
        }

        .media-picker-head,
        .media-picker-tools {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 14px 16px;
            border-bottom: 1px solid var(--line);
        }

        .media-picker-tools {
            flex-wrap: wrap;
        }

        .media-picker-tools input,
        .media-picker-tools select {
            width: auto;
            min-width: 180px;
        }

        .media-picker-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 12px;
            padding: 16px;
        }

        .media-picker-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-height: 188px;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 8px;
            background: var(--row-alt);
            text-align: left;
            cursor: pointer;
        }

        .media-picker-item:hover {
            border-color: var(--link);
        }

        .media-picker-thumb {
            width: 100%;
            aspect-ratio: 4 / 3;
            object-fit: cover;
            border-radius: var(--radius);
            background: var(--panel-bg);
        }

        .media-picker-file {
            display: grid;
            place-items: center;
            width: 100%;
            aspect-ratio: 4 / 3;
            border-radius: var(--radius);
            background: var(--panel-bg);
            color: var(--muted);
            font-weight: 700;
        }

        .media-picker-name {
            font-weight: 600;
            overflow-wrap: anywhere;
        }

        .media-picker-meta {
            color: var(--muted);
            font-size: 12px;
        }

        .submit-row {
            position: sticky;
            bottom: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 18px;
            padding: 14px 18px;
            border: 1px solid var(--line);
            background: color-mix(in srgb, var(--panel-bg) 94%, var(--body-bg));
            z-index: 20;
        }

        .submit-row .delete-link {
            margin-left: auto;
        }

        .message-list {
            margin: 0 0 18px;
            padding: 0;
            list-style: none;
        }

        .message-list li {
            padding: 10px 12px;
            border: 1px solid var(--line);
            background: var(--row-alt);
        }

        .message-list li.success {
            border-color: color-mix(in srgb, var(--success) 40%, var(--line));
            color: var(--success);
        }

        .message-list li.error {
            border-color: color-mix(in srgb, var(--danger) 40%, var(--line));
            color: var(--danger);
        }

        .sidebar-toggle {
            display: none;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            min-height: 40px;
            margin: 10px 20px 0;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 8px 12px;
            background: var(--panel-bg);
            color: var(--link);
            font-weight: 700;
            cursor: pointer;
        }

        .login-panel {
            max-width: 440px;
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .login-panel h2 {
            margin: 0;
            padding: 10px 12px;
            background: var(--module-header);
            color: var(--module-header-text);
            font-size: 13px;
            text-transform: uppercase;
        }

        .login-panel form {
            padding: 18px;
        }

        .login-panel label {
            display: block;
            margin: 0 0 5px;
            font-weight: 700;
        }

        .login-panel input {
            width: 100%;
            height: 36px;
            margin-bottom: 12px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 6px 8px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .hidden {
            display: none !important;
        }

        body.is-locked .sidebar {
            display: none;
        }

        body.is-locked .sidebar-toggle {
            display: none !important;
        }

        body.is-locked .main {
            grid-template-columns: 1fr;
        }

        body.is-locked .content {
            max-width: 560px;
            width: 100%;
            margin: 0 auto;
        }

        .related-control {
            display: grid;
            grid-template-columns: minmax(180px, 1fr) minmax(120px, 180px) auto auto;
            gap: 8px;
            align-items: center;
            max-width: 620px;
        }

        .related-control input[type="search"] {
            width: 100%;
            min-height: 34px;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 6px 8px;
            background: var(--panel-bg);
            color: var(--text);
        }

        .related-control select {
            width: 100%;
        }

        .related-control .button {
            min-height: 34px;
            border-radius: var(--radius);
            text-transform: none;
        }

        .inline-panels {
            display: grid;
            gap: 18px;
            margin-top: 22px;
        }

        .inline-panel {
            border: 1px solid var(--line);
            background: var(--panel-bg);
        }

        .inline-panel h2 {
            margin: 0;
            padding: 10px 12px;
            background: var(--module-header);
            color: var(--module-header-text);
            font-size: 13px;
            text-transform: uppercase;
        }

        .inline-panel-body {
            padding: 14px;
        }

        .inline-panel textarea {
            width: 100%;
            min-height: 120px;
            margin: 8px 0;
        }

        .member-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 8px 18px;
            margin-top: 12px;
        }

        .member-option {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            padding: 8px;
            border: 1px solid var(--line);
            background: var(--row-alt);
        }

        .history-details summary {
            cursor: pointer;
            color: var(--link);
        }

        @media (max-width: 980px) {
            .admin-header {
                padding: 14px 20px;
                align-items: flex-start;
                flex-direction: column;
            }

            .breadcrumbs {
                padding: 0 20px;
            }

            .main {
                grid-template-columns: 1fr;
            }

            body.has-admin-session .sidebar-toggle {
                display: inline-flex;
            }

            body.sidebar-collapsed .sidebar {
                display: none;
            }

            .sidebar {
                max-height: 42vh;
                border-right: 0;
                border-bottom: 1px solid var(--line);
            }

            .content {
                padding: 22px 20px 44px;
            }

            .dashboard-grid,
            .list-layout {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
                gap: 6px;
            }

            .page-top,
            .changelist-tools {
                grid-template-columns: 1fr;
                flex-direction: column;
            }
        }
    </style>
</head>
<body data-theme="classic">
    <header class="admin-header">
        <a class="brand" href="/admin">{$adminTitle}</a>
        <nav class="user-tools" aria-label="Admin account tools">
            <span id="welcomeText">Welcome, guest.</span>
            <a href="{$siteUrl}" target="_blank" rel="noopener">View site</a>
            <button id="changePasswordButton" type="button">Change password</button>
            <button id="logoutButton" type="button" class="hidden">Log out</button>
            <select id="themeSelect" aria-label="Theme">
                <option value="classic">Classic</option>
                <option value="midnight">Midnight</option>
                <option value="graphite">Graphite</option>
                <option value="forest">Forest</option>
            </select>
        </nav>
    </header>
    <nav class="breadcrumbs" id="breadcrumbs" aria-label="Breadcrumbs"></nav>
    <button class="sidebar-toggle" id="sidebarToggle" type="button" aria-controls="sidebarGroups" aria-expanded="true">Hide navigation</button>
    <main class="main">
        <aside class="sidebar" aria-label="Admin navigation">
            <div class="sidebar-search">
                <input id="modelFilter" type="search" placeholder="Start typing to filter..." autocomplete="off">
            </div>
            <div id="sidebarGroups"></div>
        </aside>
        <section class="content">
            <ul class="message-list" id="messageList"></ul>
            <div id="app"></div>
        </section>
    </main>
    <script id="adminPayload" type="application/json">{$encoded}</script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.25/dist/sweetalert2.all.min.js" crossorigin="anonymous"></script>
    <script>
        (function () {
            'use strict';

            const payload = JSON.parse(document.getElementById('adminPayload').textContent || '{}');
            const resources = Array.isArray(payload.resources) ? payload.resources : [];
            const routes = Array.isArray(payload.routes) ? payload.routes : [];
            const adminBase = String(payload.admin_base_path || '/admin');
            const tokenKey = 'nite_admin_token';
            const sessionKey = 'nite_admin_session';
            const themeKey = 'nite_admin_theme';
            const recentKey = 'nite_admin_recent_actions';
            const app = document.getElementById('app');
            const sidebarGroups = document.getElementById('sidebarGroups');
            const modelFilter = document.getElementById('modelFilter');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const breadcrumbs = document.getElementById('breadcrumbs');
            const messages = document.getElementById('messageList');
            const welcomeText = document.getElementById('welcomeText');
            const themeSelect = document.getElementById('themeSelect');
            const logoutButton = document.getElementById('logoutButton');
            const state = {
                view: 'dashboard',
                resourceKey: null,
                objectId: null,
                rows: [],
                object: null,
                filters: {},
                selected: new Set(),
                search: '',
                intendedContext: null,
                page: 1,
                pageSize: 25,
                serverPaged: false,
                hasNextPage: false,
                totalRows: null,
                ordering: '',
                sessionValidated: false,
            };

            const byKey = new Map(resources.map((resource) => [String(resource.key || ''), resource]));
            const relationCache = new Map();
            const rbacRoles = ['member', 'trainer', 'editor', 'support', 'admin'];

            function escapeHtml(value) {
                return String(value ?? '').replace(/[&<>"']/g, function (char) {
                    return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[char] || char;
                });
            }

            function labelize(value) {
                return String(value || '')
                    .replace(/[_-]+/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .replace(/\b\w/g, (part) => part.toUpperCase());
            }

            function pluralLabel(resource) {
                return String(resource.label || resource.key || 'Objects');
            }

            function singularLabel(resource) {
                return String(resource.item_type || pluralLabel(resource).replace(/s$/i, '') || 'Object');
            }

            function resourceUrl(resource, suffix = '') {
                const path = String(resource.admin_surface_path || (adminBase + '?resource=' + encodeURIComponent(String(resource.key || ''))));
                return suffix ? path.replace(/\/$/, '') + suffix : path;
            }

            function resourceDefaultView(resource) {
                const key = String(resource && resource.key ? resource.key : '');
                if (key === 'rbac_matrix') {
                    return 'rbacMatrix';
                }
                if (key === 'password_policy') {
                    return 'passwordPolicy';
                }
                return 'list';
            }

            function routeFor(resource, method, mode) {
                const list = Array.isArray(resource.routes) ? resource.routes : [];
                const upper = String(method || 'GET').toUpperCase();
                return list.find((route) => {
                    const routeMethod = String(route.method || '').toUpperCase();
                    const path = String(route.path || '');
                    const request = route.request && typeof route.request === 'object' ? route.request : {};
                    const pathParams = Array.isArray(request.path_params) ? request.path_params : [];
                    if (routeMethod !== upper || !path.startsWith('/api/v1/admin/') || !routeAllowed(route)) {
                        return false;
                    }
                    if (mode === 'list') {
                        return pathParams.length === 0 && !path.includes('/history') && !path.includes('/versions');
                    }
                    if (mode === 'detail') {
                        return pathParams.length > 0 && /\/\{[^}]+\}$/.test(path) && !path.includes('/history') && !path.includes('/versions') && !path.includes('/members') && !path.includes('/permissions');
                    }
                    if (mode === 'create') {
                        return pathParams.length === 0;
                    }
                    return true;
                }) || null;
            }

            function routePathParams(route) {
                const request = route && route.request && typeof route.request === 'object' ? route.request : {};
                return Array.isArray(request.path_params) ? request.path_params : [];
            }

            function historyRouteFor(resource) {
                const list = Array.isArray(resource.routes) ? resource.routes : [];
                return list.find((route) => {
                    const path = String(route.path || '');
                    return String(route.method || '').toUpperCase() === 'GET'
                        && routeAllowed(route)
                        && path.includes('/history')
                        && routePathParams(route).length > 0;
                }) || null;
            }

            function restoreHistoryRouteFor(resource) {
                const list = Array.isArray(resource.routes) ? resource.routes : [];
                return list.find((route) => {
                    const path = String(route.path || '');
                    return String(route.method || '').toUpperCase() === 'POST'
                        && routeAllowed(route)
                        && path.includes('/history/')
                        && path.endsWith('/restore');
                }) || null;
            }

            function relatedRoutesFor(resource) {
                const detail = routeFor(resource, 'GET', 'detail');
                if (!detail) {
                    return [];
                }
                const prefix = String(detail.path || '').replace(/\/\{[^}]+\}$/, '/{id}/');
                const key = String(resource.key || '');
                return (Array.isArray(resource.routes) ? resource.routes : []).filter((route) => {
                    const path = String(route.path || '');
                    return String(route.method || '').toUpperCase() === 'GET'
                        && routeAllowed(route)
                        && key !== 'rbac_groups'
                        && path.startsWith(prefix)
                        && !path.includes('/history')
                        && !path.includes('/permissions')
                        && !path.includes('/members');
                });
            }

            function createRelatedRouteFor(resource, relatedRoute) {
                const path = String(relatedRoute && relatedRoute.path ? relatedRoute.path : '');
                return (Array.isArray(resource.routes) ? resource.routes : []).find((route) => {
                    return String(route.method || '').toUpperCase() === 'POST'
                        && routeAllowed(route)
                        && String(route.path || '') === path;
                }) || null;
            }

            function routeBodyFields(resource, mode) {
                const isAdd = mode === 'add';
                const route = routeFor(resource, isAdd ? 'POST' : 'PUT', isAdd ? 'create' : 'detail');
                const request = route && route.request && typeof route.request === 'object' ? route.request : {};
                return Array.isArray(request.body) ? request.body : [];
            }

            function allResourceFields(resource) {
                return Array.isArray(resource.fields) ? resource.fields : [];
            }

            function mergeFieldMetadata(field, resource) {
                const name = String(field.name || '');
                const base = allResourceFields(resource).find((candidate) => String(candidate.name || '') === name) || {};
                return Object.assign({}, base, field);
            }

            function relationResource(relation) {
                const key = String(relation && relation.resource_key ? relation.resource_key : '');
                return key ? byKey.get(key) || null : null;
            }

            function relationDisplayName(row, relation) {
                const labelFields = Array.isArray(relation && relation.label_fields) ? relation.label_fields : [];
                const parts = [];
                for (const field of labelFields) {
                    if (row && row[field] !== undefined && row[field] !== null && String(row[field]).trim() !== '') {
                        parts.push(String(row[field]));
                    }
                    if (parts.length >= 2) {
                        break;
                    }
                }
                if (parts.length > 0) {
                    return parts.join(' - ');
                }
                const resource = relationResource(relation) || {};
                return displayName(row || {}, resource);
            }

            function relationValue(row, relation) {
                const field = String(relation && relation.value_field ? relation.value_field : 'id');
                return row && row[field] !== undefined && row[field] !== null ? String(row[field]) : '';
            }

            function buildPath(route, objectId) {
                let path = String(route && route.path ? route.path : '');
                if (objectId) {
                    path = path.replace(/\{[^}]+\}/g, encodeURIComponent(String(objectId)));
                }
                return path;
            }

            function canAdd(resource) {
                return routeFor(resource, 'POST', 'create') !== null;
            }

            function canDelete(resource) {
                return routeFor(resource, 'DELETE', 'detail') !== null;
            }

            function supportsServerPaging(resource) {
                const optionNames = (Array.isArray(resource.query_options) ? resource.query_options : [])
                    .map((option) => String(option.name || ''));
                return optionNames.includes('limit') && optionNames.includes('offset');
            }

            function isReadOnlyResource(resource) {
                return !canAdd(resource) && !routeFor(resource, 'PUT', 'detail') && !routeFor(resource, 'PATCH', 'detail') && !canDelete(resource);
            }

            function roleLabel(role) {
                return labelize(role);
            }

            function currentSession() {
                try {
                    const raw = localStorage.getItem(sessionKey);
                    return raw ? JSON.parse(raw) : null;
                } catch (error) {
                    return null;
                }
            }

            function normalizePermissions(values) {
                return Array.isArray(values)
                    ? values.map((value) => String(value || '').trim()).filter((value) => value !== '')
                    : [];
            }

            function currentUserPermissions() {
                const session = currentSession();
                return normalizePermissions(session && session.user ? session.user.permissions : []);
            }

            function canUsePermission(permission) {
                const code = String(permission || '').trim();
                if (code === '') {
                    return true;
                }
                return currentUserPermissions().includes(code);
            }

            function hasAdminSession() {
                const session = currentSession();
                return state.sessionValidated && isSignedIn() && Boolean(session && session.user);
            }

            function isMobileLayout() {
                return window.matchMedia('(max-width: 980px)').matches;
            }

            function updateSidebarToggleLabel() {
                const collapsed = document.body.classList.contains('sidebar-collapsed');
                sidebarToggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
                sidebarToggle.textContent = collapsed ? 'Show navigation' : 'Hide navigation';
            }

            function setSidebarCollapsed(collapsed, touched = true) {
                document.body.classList.toggle('sidebar-collapsed', Boolean(collapsed));
                if (touched) {
                    document.body.classList.add('sidebar-touched');
                }
                updateSidebarToggleLabel();
            }

            function syncSidebarChrome() {
                const enabled = hasAdminSession() && !document.body.classList.contains('is-locked');
                document.body.classList.toggle('has-admin-session', enabled);
                if (!enabled || !isMobileLayout()) {
                    document.body.classList.remove('sidebar-collapsed');
                    updateSidebarToggleLabel();
                    return;
                }
                if (!document.body.classList.contains('sidebar-touched')) {
                    document.body.classList.add('sidebar-collapsed');
                }
                updateSidebarToggleLabel();
            }

            function routeAllowed(route) {
                if (!hasAdminSession()) {
                    return false;
                }
                const required = normalizePermissions(route && route.permissions ? route.permissions : []);
                if (required.length === 0) {
                    return true;
                }
                const allowed = currentUserPermissions();
                return required.some((permission) => allowed.includes(permission));
            }

            function resourceAllowed(resource) {
                const list = Array.isArray(resource && resource.routes) ? resource.routes : [];
                return list.some(routeAllowed);
            }

            function visibleResources() {
                return resources.filter(resourceAllowed);
            }

            function cookieValue(name) {
                return document.cookie
                    .split(';')
                    .map((part) => part.trim())
                    .filter((part) => part.startsWith(name + '='))
                    .map((part) => decodeURIComponent(part.slice(name.length + 1)))[0] || '';
            }

            function token() {
                return localStorage.getItem(tokenKey) || cookieValue('nite_admin_token') || '';
            }

            function isSignedIn() {
                return token() !== '';
            }

            function setLocked(locked) {
                document.body.classList.toggle('is-locked', locked);
                modelFilter.disabled = locked;
                if (locked) {
                    sidebarGroups.innerHTML = '';
                }
                syncSidebarChrome();
            }

            function clearSession() {
                state.sessionValidated = false;
                localStorage.removeItem(tokenKey);
                localStorage.removeItem(sessionKey);
                localStorage.removeItem('nite_explorer_token');
                localStorage.removeItem('nite_explorer_session');
                document.cookie = 'nite_admin_token=; Path=/; Max-Age=0; SameSite=Lax';
            }

            function saveSession(user, bearerToken) {
                if (bearerToken) {
                    localStorage.setItem(tokenKey, bearerToken);
                    localStorage.setItem('nite_explorer_token', bearerToken);
                    document.cookie = 'nite_admin_token=' + encodeURIComponent(bearerToken) + '; Path=/; SameSite=Lax';
                }
                const payload = {user: user || {}, saved_at: new Date().toISOString()};
                localStorage.setItem(sessionKey, JSON.stringify(payload));
                localStorage.setItem('nite_explorer_session', JSON.stringify(payload));
                state.sessionValidated = true;
            }

            function updateAccountChrome() {
                const session = currentSession();
                if (session && session.user) {
                    const user = session.user;
                    const name = String(user.name || user.email || 'user');
                    welcomeText.innerHTML = 'Welcome, <strong>' + escapeHtml(name) + '</strong>.';
                    logoutButton.classList.remove('hidden');
                    syncSidebarChrome();
                    return;
                }
                welcomeText.textContent = 'Welcome, guest.';
                logoutButton.classList.add('hidden');
                syncSidebarChrome();
            }

            function currentUserRequiresPasswordChange() {
                const session = currentSession();
                const user = session && session.user ? session.user : {};
                return Boolean(user && user.password_change_required);
            }

            function flash(message, type = 'success') {
                messages.innerHTML = '<li class="' + escapeHtml(type) + '">' + escapeHtml(message) + '</li>';
                notify(message, type);
                if (type === 'success') {
                    window.setTimeout(function () {
                        if (messages.textContent === message) {
                            messages.innerHTML = '';
                        }
                    }, 4000);
                }
            }

            function cssVar(name, fallback) {
                const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
                return value || fallback;
            }

            function hasSweetAlert() {
                return Boolean(window.Swal && typeof window.Swal.fire === 'function');
            }

            function sweetAlertBaseOptions() {
                return {
                    background: cssVar('--panel-bg', '#ffffff'),
                    color: cssVar('--text', '#1f2937'),
                    confirmButtonColor: cssVar('--link', '#0a4d33'),
                    cancelButtonColor: '#6b7280',
                    heightAuto: false
                };
            }

            function notify(message, type = 'success') {
                if (!hasSweetAlert()) {
                    return;
                }
                const normalized = type === 'error' ? 'error' : 'success';
                const base = sweetAlertBaseOptions();
                if (normalized === 'error') {
                    window.Swal.fire(Object.assign({}, base, {
                        icon: 'error',
                        title: 'Action needed',
                        text: String(message || 'Something went wrong.'),
                        confirmButtonText: 'OK'
                    }));
                    return;
                }
                window.Swal.fire(Object.assign({}, base, {
                    toast: true,
                    position: 'top-end',
                    icon: normalized,
                    title: String(message || 'Done.'),
                    showConfirmButton: false,
                    timer: 3200,
                    timerProgressBar: true
                }));
            }

            async function confirmAction(message, options = {}) {
                if (hasSweetAlert()) {
                    const result = await window.Swal.fire(Object.assign({}, sweetAlertBaseOptions(), {
                        icon: options.icon || 'warning',
                        title: options.title || 'Please confirm',
                        text: String(message || ''),
                        showCancelButton: true,
                        confirmButtonText: options.confirmButtonText || 'Continue',
                        cancelButtonText: options.cancelButtonText || 'Cancel',
                        confirmButtonColor: options.confirmButtonColor || cssVar('--danger', '#9f1d1d'),
                        reverseButtons: true,
                        focusCancel: true
                    }));
                    return Boolean(result && result.isConfirmed);
                }
                return window.confirm(String(message || 'Continue?'));
            }

            function groupedResources() {
                const term = String(modelFilter.value || '').trim().toLowerCase();
                const groups = new Map();
                for (const resource of visibleResources()) {
                    const label = pluralLabel(resource);
                    const key = String(resource.key || '');
                    const group = String(resource.group || 'application');
                    const haystack = [label, key, group, String(resource.table || '')].join(' ').toLowerCase();
                    if (term !== '' && !haystack.includes(term)) {
                        continue;
                    }
                    if (!groups.has(group)) {
                        groups.set(group, []);
                    }
                    groups.get(group).push(resource);
                }
                return Array.from(groups.entries()).sort((left, right) => left[0].localeCompare(right[0]));
            }

            function renderSidebar() {
                if (!hasAdminSession()) {
                    sidebarGroups.innerHTML = '';
                    syncSidebarChrome();
                    return;
                }
                sidebarGroups.innerHTML = groupedResources().map(([group, groupResources]) => {
                    const rows = groupResources
                        .sort((left, right) => pluralLabel(left).localeCompare(pluralLabel(right)))
                        .map((resource) => {
                            const key = String(resource.key || '');
                            const view = resourceDefaultView(resource);
                            const current = key === state.resourceKey ? ' is-current' : '';
                            const add = canAdd(resource)
                                ? '<a class="row-action add" href="' + escapeHtml(resourceUrl(resource, '/add')) + '" data-admin-link data-view="add" data-resource="' + escapeHtml(key) + '">Add</a>'
                                : '<span></span>';
                            return '<div class="model-row' + current + '">' +
                                '<a href="' + escapeHtml(resourceUrl(resource)) + '" data-admin-link data-view="' + escapeHtml(view) + '" data-resource="' + escapeHtml(key) + '">' + escapeHtml(pluralLabel(resource)) + '</a>' +
                                add +
                                '<a class="row-action change" href="' + escapeHtml(resourceUrl(resource)) + '" data-admin-link data-view="' + escapeHtml(view) + '" data-resource="' + escapeHtml(key) + '">Change</a>' +
                            '</div>';
                        })
                        .join('');
                    return '<section class="app-group"><h2>' + escapeHtml(labelize(group)) + '</h2>' + rows + '</section>';
                }).join('');
                syncSidebarChrome();
            }

            function setBreadcrumb(items) {
                const home = hasAdminSession()
                    ? '<a href="' + adminBase + '" data-admin-link data-view="dashboard">Home</a>'
                    : '<span>Home</span>';
                const html = [home]
                    .concat(items.map((item) => item.href
                        ? '<span>&rsaquo;</span><a href="' + escapeHtml(item.href) + '" data-admin-link ' + (item.resource ? 'data-resource="' + escapeHtml(item.resource) + '"' : '') + ' ' + (item.view ? 'data-view="' + escapeHtml(item.view) + '"' : '') + '>' + escapeHtml(item.label) + '</a>'
                        : '<span>&rsaquo;</span><span>' + escapeHtml(item.label) + '</span>'))
                    .join('');
                breadcrumbs.innerHTML = html;
            }

            function renderDashboard() {
                if (!hasAdminSession()) {
                    renderLogin('Log in to access Nite administration.', function () {
                        bootAdmin();
                    });
                    return;
                }
                state.view = 'dashboard';
                state.resourceKey = null;
                state.objectId = null;
                renderSidebar();
                setBreadcrumb([]);
                const modules = groupedResources().map(([group, groupResources]) => {
                    const rows = groupResources
                        .sort((left, right) => pluralLabel(left).localeCompare(pluralLabel(right)))
                        .map((resource) => {
                            const key = String(resource.key || '');
                            const view = resourceDefaultView(resource);
                            const add = canAdd(resource)
                                ? '<td class="actions"><a class="row-action add" href="' + escapeHtml(resourceUrl(resource, '/add')) + '" data-admin-link data-view="add" data-resource="' + escapeHtml(key) + '">Add</a></td>'
                                : '<td class="actions"></td>';
                            return '<tr>' +
                                '<th><a href="' + escapeHtml(resourceUrl(resource)) + '" data-admin-link data-view="' + escapeHtml(view) + '" data-resource="' + escapeHtml(key) + '">' + escapeHtml(pluralLabel(resource)) + '</a></th>' +
                                add +
                                '<td class="actions"><a class="row-action change" href="' + escapeHtml(resourceUrl(resource)) + '" data-admin-link data-view="' + escapeHtml(view) + '" data-resource="' + escapeHtml(key) + '">Change</a></td>' +
                            '</tr>';
                        }).join('');
                    return '<section class="module"><h2>' + escapeHtml(labelize(group)) + '</h2><table><tbody>' + rows + '</tbody></table></section>';
                }).join('');
                app.innerHTML = '<div class="page-top"><div><h1>Site administration</h1></div></div>' +
                    '<div class="dashboard-grid"><div>' + modules + '</div>' + renderRecentActions() + '</div>';
            }

            function recentActions() {
                try {
                    const rows = JSON.parse(localStorage.getItem(recentKey) || '[]');
                    return Array.isArray(rows) ? rows.slice(0, 12) : [];
                } catch (error) {
                    return [];
                }
            }

            function rememberAction(action, resource, object) {
                const rows = recentActions();
                rows.unshift({
                    action: action,
                    resource: pluralLabel(resource),
                    object: displayName(object || {}, resource),
                    at: new Date().toISOString(),
                });
                localStorage.setItem(recentKey, JSON.stringify(rows.slice(0, 20)));
            }

            function renderRecentActions() {
                const rows = recentActions();
                const items = rows.length > 0 ? rows.map((row) =>
                    '<li><span aria-hidden="true">' + (row.action === 'add' ? '+' : row.action === 'delete' ? '-' : '>') + '</span>' +
                    '<span><a href="#">' + escapeHtml(row.object || row.resource || 'Object') + '</a>' +
                    '<span class="recent-kind">' + escapeHtml(row.resource || 'Resource') + '</span></span></li>'
                ).join('') : '<li><span></span><span class="muted">No actions yet.</span></li>';
                return '<aside class="recent"><h2>Recent actions</h2><h3>My actions</h3><ul class="recent-list">' + items + '</ul></aside>';
            }

            function displayName(row, resource) {
                const fields = ['title', 'name', 'email', 'slug', 'label', 'subject', 'filename', 'original_filename', 'id'];
                for (const field of fields) {
                    if (row && row[field] !== undefined && row[field] !== null && String(row[field]).trim() !== '') {
                        return String(row[field]);
                    }
                }
                return singularLabel(resource);
            }

            function listColumns(resource, rows) {
                const preferred = ['label', 'title', 'name', 'email', 'slug', 'status', 'default_permission_count', 'account_status', 'type', 'mime_type', 'created_at', 'updated_at'];
                const fields = Array.isArray(resource.fields) ? resource.fields : [];
                const names = [];
                for (const name of preferred) {
                    if (fields.some((field) => String(field.name || '') === name) || rows.some((row) => row && row[name] !== undefined)) {
                        names.push(name);
                    }
                }
                for (const field of fields) {
                    const name = String(field.name || '');
                    if (name === '' || names.includes(name) || String(field.read_only || '') === 'true' || (String(resource.key || '') === 'users' && name === 'role')) {
                        continue;
                    }
                    names.push(name);
                    if (names.length >= 6) {
                        break;
                    }
                }
                if (!names.includes('id') && rows.some((row) => row && row.id !== undefined) && names.length < 6) {
                    names.push('id');
                }
                return names.slice(0, 7);
            }

            function sortedRows(rows) {
                const ordering = String(state.ordering || '');
                if (ordering === '') {
                    return rows;
                }
                const direction = ordering.startsWith('-') ? -1 : 1;
                const field = ordering.replace(/^-/, '');
                return rows.slice().sort((left, right) => {
                    const a = left && left[field] !== undefined && left[field] !== null ? left[field] : '';
                    const b = right && right[field] !== undefined && right[field] !== null ? right[field] : '';
                    if (typeof a === 'number' && typeof b === 'number') {
                        return (a - b) * direction;
                    }
                    return String(a).localeCompare(String(b), undefined, {numeric: true, sensitivity: 'base'}) * direction;
                });
            }

            function pagedRows(rows) {
                if (state.serverPaged) {
                    return rows;
                }
                const pageSize = Math.max(1, Number(state.pageSize || 25));
                const page = Math.max(1, Number(state.page || 1));
                return rows.slice((page - 1) * pageSize, page * pageSize);
            }

            function renderPaginator(total) {
                const pageSize = Math.max(1, Number(state.pageSize || 25));
                if (state.serverPaged) {
                    const knownTotal = Number(state.totalRows || 0);
                    const knownPages = knownTotal > 0 ? Math.max(1, Math.ceil(knownTotal / pageSize)) : null;
                    const nextDisabled = knownPages ? state.page >= knownPages : !state.hasNextPage;
                    return '<div class="paginator">' +
                        '<button type="button" data-page-action="prev"' + (state.page <= 1 ? ' disabled' : '') + '>&lsaquo; Previous</button>' +
                        '<span>Page ' + state.page + (knownPages ? ' of ' + knownPages : '') + '</span>' +
                        '<button type="button" data-page-action="next"' + (nextDisabled ? ' disabled' : '') + '>Next &rsaquo;</button>' +
                        '<span>' + (knownTotal > 0 ? knownTotal + ' total' : total + ' shown') + '</span>' +
                        '<select id="pageSize"><option value="10">10 per page</option><option value="25">25 per page</option><option value="50">50 per page</option><option value="100">100 per page</option></select>' +
                    '</div>';
                }
                const pages = Math.max(1, Math.ceil(total / pageSize));
                state.page = Math.min(Math.max(1, Number(state.page || 1)), pages);
                return '<div class="paginator">' +
                    '<button type="button" data-page-action="prev"' + (state.page <= 1 ? ' disabled' : '') + '>&lsaquo; Previous</button>' +
                    '<span>Page ' + state.page + ' of ' + pages + '</span>' +
                    '<button type="button" data-page-action="next"' + (state.page >= pages ? ' disabled' : '') + '>Next &rsaquo;</button>' +
                    '<span>' + total + ' total</span>' +
                    '<select id="pageSize"><option value="10">10 per page</option><option value="25">25 per page</option><option value="50">50 per page</option><option value="100">100 per page</option></select>' +
                '</div>';
            }

            function isMediaDisplayField(fieldName) {
                return /(_image_url|image|thumbnail|avatar|photo|cover|hero|featured|file_url|media_url)$/i.test(String(fieldName || ''));
            }

            function isImageLikeUrl(value) {
                return /^https?:\/\/.+\.(png|jpe?g|gif|webp|svg)(?:[?#].*)?$/i.test(String(value || '')) || /^https?:\/\//i.test(String(value || ''));
            }

            function setImagePreviewForControl(target, value) {
                const container = target.closest('.field-control') || target.parentElement;
                const preview = container ? container.querySelector('.image-preview') : null;
                if (!preview) {
                    return;
                }
                const src = String(value || '');
                if (isImageLikeUrl(src)) {
                    preview.src = src;
                    preview.classList.remove('hidden');
                    return;
                }
                preview.removeAttribute('src');
                preview.classList.add('hidden');
            }

            function formatValue(value, fieldName) {
                if (value === null || value === undefined || value === '') {
                    return '<span class="muted">-</span>';
                }
                if (typeof value === 'boolean') {
                    return '<span class="bool ' + (value ? 'true' : 'false') + '">' + (value ? '&#10003;' : '&#10005;') + '</span>';
                }
                if (typeof value === 'object') {
                    return '<code>' + escapeHtml(JSON.stringify(value)) + '</code>';
                }
                const text = String(value);
                if (isMediaDisplayField(fieldName) && isImageLikeUrl(text)) {
                    return '<img class="thumb" src="' + escapeHtml(text) + '" alt="">';
                }
                if (/(_at|date)$/i.test(fieldName) && parseStoredDate(text)) {
                    return escapeHtml(formatUserDateTime(text));
                }
                return escapeHtml(text.length > 95 ? text.slice(0, 92) + '...' : text);
            }

            function parseStoredDate(value) {
                const text = String(value || '').trim();
                if (text === '' || !/\d{1,2}:\d{2}/.test(text)) {
                    return null;
                }
                const hasTimezone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(text);
                const normalized = hasTimezone ? text : text.replace(' ', 'T') + 'Z';
                const date = new Date(normalized);
                return Number.isNaN(date.getTime()) ? null : date;
            }

            function formatUserDateTime(value) {
                const date = parseStoredDate(value);
                if (!date) {
                    return String(value || '');
                }
                return date.toLocaleString(undefined, {
                    year: 'numeric',
                    month: 'short',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZoneName: 'short'
                });
            }

            function localDateTimeInputValue(value) {
                const date = parseStoredDate(value);
                if (!date) {
                    return '';
                }
                const local = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));
                return local.toISOString().slice(0, 16);
            }

            function userDateTimeToStorage(value) {
                const text = String(value || '').trim();
                if (text === '') {
                    return '';
                }
                const date = new Date(text);
                return Number.isNaN(date.getTime()) ? text : date.toISOString();
            }

            async function apiFetch(path, options = {}) {
                const headers = new Headers(options.headers || {});
                headers.set('Accept', 'application/json');
                headers.set('X-User-Timezone', Intl.DateTimeFormat().resolvedOptions().timeZone || '');
                if (!(options.body instanceof FormData)) {
                    headers.set('Content-Type', 'application/json');
                }
                if (token()) {
                    headers.set('Authorization', 'Bearer ' + token());
                }
                const response = await fetch(path, Object.assign({}, options, {headers}));
                const text = await response.text();
                let json = {};
                try {
                    json = text ? JSON.parse(text) : {};
                } catch (error) {
                    json = {error: text || response.statusText};
                }
                if (!response.ok) {
                    const message = readableErrorMessage(json, response);
                    throw new Error(message);
                }
                return json;
            }

            function readableErrorMessage(json, response) {
                if (json && typeof json === 'object') {
                    const errors = json.errors;
                    const detailed = readableErrors(errors);
                    if (detailed) {
                        return detailed;
                    }
                    const direct = json.error || json.message;
                    if (direct) {
                        return String(direct);
                    }
                }
                return 'Request failed with HTTP ' + response.status;
            }

            function readableErrors(errors, prefix = '') {
                if (typeof errors === 'string') {
                    return errors.trim();
                }
                if (!errors || typeof errors !== 'object') {
                    return '';
                }

                const parts = [];
                Object.entries(errors).forEach(([field, value]) => {
                    const path = prefix ? prefix + '.' + field : field;
                    const label = labelize(path);
                    if (Array.isArray(value)) {
                        const messages = value
                            .map((item) => item && typeof item === 'object' ? JSON.stringify(item) : String(item || '').trim())
                            .filter((item) => item !== '');
                        if (messages.length > 0) {
                            parts.push(label + ': ' + messages.join(' '));
                        }
                    } else if (value && typeof value === 'object') {
                        const nested = readableErrors(value, path);
                        if (nested) {
                            parts.push(nested);
                        }
                    } else if (value !== undefined && value !== null && String(value).trim() !== '') {
                        parts.push(label + ': ' + String(value));
                    }
                });

                return parts.slice(0, 6).join('; ');
            }

            function queryString(params) {
                const search = new URLSearchParams();
                Object.entries(params).forEach(([key, value]) => {
                    if (value !== undefined && value !== null && String(value).trim() !== '') {
                        search.set(key, String(value));
                    }
                });
                const text = search.toString();
                return text === '' ? '' : '?' + text;
            }

            async function validateSession() {
                state.sessionValidated = false;
                if (!isSignedIn()) {
                    clearSession();
                    updateAccountChrome();
                    return false;
                }
                try {
                    const json = await apiFetch('/api/v1/me');
                    const user = json.data || {};
                    saveSession(user, token());
                    updateAccountChrome();
                    return true;
                } catch (error) {
                    clearSession();
                    updateAccountChrome();
                    return false;
                }
            }

            async function bootAdmin() {
                const context = state.intendedContext || (payload.context && payload.context.view ? payload.context : contextFromPath());
                state.intendedContext = context;
                setLocked(true);
                const ok = await validateSession();
                if (!ok) {
                    renderLogin('Log in to access Nite administration.', function () {
                        bootAdmin();
                    });
                    return;
                }
                setLocked(false);
                if (currentUserRequiresPasswordChange() && (context.view || '') !== 'changePassword') {
                    renderChangePassword(true);
                    state.intendedContext = null;
                    return;
                }
                renderSidebar();
                dispatch(context.view || 'dashboard', context.resource_key || context.resourceKey, context.object_id || context.objectId);
                state.intendedContext = null;
            }

            async function loadList(resource) {
                const route = routeFor(resource, 'GET', 'list');
                if (!route) {
                    throw new Error('No admin list route is registered for ' + pluralLabel(resource) + '.');
                }
                const params = Object.assign({}, state.filters);
                if (state.search !== '') {
                    params.q = state.search;
                }
                state.serverPaged = supportsServerPaging(resource);
                if (state.serverPaged) {
                    params.limit = Math.max(1, Number(state.pageSize || 25));
                    params.offset = (Math.max(1, Number(state.page || 1)) - 1) * Math.max(1, Number(state.pageSize || 25));
                }
                const json = await apiFetch(buildPath(route) + queryString(params));
                const rawRows = Array.isArray(json.data) ? json.data : (Array.isArray(json.data && json.data.items) ? json.data.items : []);
                const rows = rawRows.map((row) => {
                    if (row && typeof row === 'object' && !Array.isArray(row)) {
                        return row;
                    }
                    return {value: row};
                });
                state.rows = rows;
                const meta = json.meta && typeof json.meta === 'object' ? json.meta : {};
                state.totalRows = Number(meta.total || 0) > 0 ? Number(meta.total) : null;
                state.hasNextPage = rows.length >= Math.max(1, Number(state.pageSize || 25));
                return rows;
            }

            function renderFilters(resource) {
                const options = Array.isArray(resource.query_options) ? resource.query_options : [];
                if (options.length === 0) {
                    return '<aside class="filter-panel"><h2>Filter</h2><div class="filter-body"><span class="muted">No filters registered.</span></div></aside>';
                }
                const controls = options.map((field) => {
                    const name = String(field.name || '');
                    if (['q', 'limit', 'offset'].includes(name)) {
                        return '';
                    }
                    if (String(resource.key || '') === 'users' && name === 'role') {
                        return '';
                    }
                    const choices = Array.isArray(field.options) ? field.options : [];
                    const label = escapeHtml(labelize(name));
                    const value = state.filters[name] || '';
                    if (choices.length > 0) {
                        return '<div class="filter-field"><label for="filter_' + escapeHtml(name) + '">' + label + '</label>' +
                            '<select id="filter_' + escapeHtml(name) + '" data-filter-name="' + escapeHtml(name) + '">' +
                            '<option value="">All</option>' + choices.map((choice) => '<option value="' + escapeHtml(choice) + '"' + (String(choice) === String(value) ? ' selected' : '') + '>' + escapeHtml(labelize(choice)) + '</option>').join('') +
                            '</select></div>';
                    }
                    const type = String(field.format || field.data_type || '').includes('date') ? 'date' : 'text';
                    return '<div class="filter-field"><label for="filter_' + escapeHtml(name) + '">' + label + '</label>' +
                        '<input id="filter_' + escapeHtml(name) + '" type="' + type + '" data-filter-name="' + escapeHtml(name) + '" value="' + escapeHtml(value) + '"></div>';
                }).join('');
                return '<aside class="filter-panel"><h2>Filter</h2><div class="filter-body">' + controls +
                    '<button class="button primary" type="button" id="applyFilters">Apply</button> ' +
                    '<button class="button flat" type="button" id="clearFilters">Clear</button></div></aside>';
            }

            function renderListTable(resource, rows) {
                const columns = listColumns(resource, rows);
                if (rows.length === 0) {
                    return '<p class="muted">No ' + escapeHtml(pluralLabel(resource).toLowerCase()) + ' found.</p>';
                }
                const sorted = sortedRows(rows);
                const pageRows = pagedRows(sorted);
                const head = columns.map((name) => {
                    const active = state.ordering.replace(/^-/, '') === name;
                    const marker = active ? (state.ordering.startsWith('-') ? ' ▼' : ' ▲') : '';
                    return '<th><button type="button" data-sort-field="' + escapeHtml(name) + '">' + escapeHtml(labelize(name) + marker) + '</button></th>';
                }).join('');
                const body = pageRows.map((row) => {
                    const id = String(row.id || row.slug || row.value || row.code || '');
                    const checked = state.selected.has(id) ? ' checked' : '';
                    const selected = state.selected.has(id) ? ' is-selected' : '';
                    const link = resourceUrl(resource, '/' + encodeURIComponent(id) + '/change');
                    const cells = columns.map((name, index) => {
                        const value = formatValue(row[name], name);
                        if (index === 0 && id !== '' && !isReadOnlyResource(resource)) {
                            return '<td><a class="object-link" href="' + escapeHtml(link) + '" data-admin-link data-view="change" data-resource="' + escapeHtml(String(resource.key || '')) + '" data-object-id="' + escapeHtml(id) + '">' + value + '</a></td>';
                        }
                        return '<td>' + value + '</td>';
                    }).join('');
                    return '<tr class="' + selected + '"><td><input type="checkbox" class="row-check" data-object-id="' + escapeHtml(id) + '"' + checked + '></td>' + cells + '</tr>';
                }).join('');
                return '<div class="result-table-wrap"><table class="result-table"><thead><tr><th><input type="checkbox" id="selectAllRows"></th>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>' +
                    renderPaginator(rows.length) +
                    '<p class="muted">' + rows.length + ' ' + escapeHtml(pluralLabel(resource).toLowerCase()) + '</p>';
            }

            async function renderList(resource) {
                state.view = 'list';
                state.resourceKey = String(resource.key || '');
                state.objectId = null;
                renderSidebar();
                setBreadcrumb([{label: pluralLabel(resource)}]);
                const addButton = canAdd(resource)
                    ? '<a class="button" href="' + escapeHtml(resourceUrl(resource, '/add')) + '" data-admin-link data-view="add" data-resource="' + escapeHtml(String(resource.key || '')) + '">Add ' + escapeHtml(singularLabel(resource)) + ' +</a>'
                    : '';
                app.innerHTML = '<div class="page-top"><div><h1>Select ' + escapeHtml(pluralLabel(resource).toLowerCase()) + ' to change</h1><p class="muted">' + escapeHtml(String(resource.summary || '')) + '</p></div>' +
                    addButton + '</div>' +
                    '<p class="muted">Loading...</p>';
                try {
                    const rows = await loadList(resource);
                    const deleteOption = canDelete(resource) ? '<option value="delete">Delete selected ' + escapeHtml(pluralLabel(resource).toLowerCase()) + '</option>' : '';
                    const bulkActions = '<div class="actions-bar"><span>Action:</span><select id="bulkAction"><option value="">---------</option><option value="export">Export selected JSON</option>' + deleteOption + '</select><button class="button primary" id="runBulkAction" type="button">Go</button><span id="selectedCount">' + state.selected.size + ' selected</span></div>';
                    app.innerHTML = '<div class="page-top"><div><h1>Select ' + escapeHtml(pluralLabel(resource).toLowerCase()) + ' to change</h1><p class="muted">' + escapeHtml(String(resource.summary || '')) + '</p></div>' +
                        addButton + '</div>' +
                        '<div class="changelist-tools"><form class="searchbar" id="searchForm"><input id="listSearch" type="search" value="' + escapeHtml(state.search) + '" placeholder="Search ' + escapeHtml(pluralLabel(resource).toLowerCase()) + '"><button class="button primary" type="submit">Search</button></form></div>' +
                        bulkActions +
                        '<div class="list-layout"><div>' + renderListTable(resource, rows) + '</div>' + renderFilters(resource) + '</div>';
                    bindListEvents(resource);
                } catch (error) {
                    if (!isSignedIn()) {
                        renderLogin('Sign in to manage ' + pluralLabel(resource) + '.', function () {
                            renderList(resource);
                        });
                        return;
                    }
                    app.innerHTML = '<h1>Select ' + escapeHtml(pluralLabel(resource).toLowerCase()) + ' to change</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            function bindListEvents(resource) {
                const searchForm = document.getElementById('searchForm');
                const listSearch = document.getElementById('listSearch');
                if (searchForm) {
                    searchForm.addEventListener('submit', function (event) {
                        event.preventDefault();
                        state.search = String(listSearch.value || '').trim();
                        state.page = 1;
                        renderList(resource);
                    });
                }
                document.querySelectorAll('[data-filter-name]').forEach((control) => {
                    control.addEventListener('change', function () {
                        state.filters[control.getAttribute('data-filter-name')] = control.value;
                    });
                });
                const applyFilters = document.getElementById('applyFilters');
                if (applyFilters) {
                    applyFilters.addEventListener('click', function () {
                        renderList(resource);
                    });
                }
                const clearFilters = document.getElementById('clearFilters');
                if (clearFilters) {
                    clearFilters.addEventListener('click', function () {
                        state.filters = {};
                        state.page = 1;
                        renderList(resource);
                    });
                }
                document.querySelectorAll('[data-sort-field]').forEach((button) => {
                    button.addEventListener('click', function () {
                        const field = String(button.getAttribute('data-sort-field') || '');
                        state.ordering = state.ordering === field ? '-' + field : field;
                        renderList(resource);
                    });
                });
                document.querySelectorAll('[data-page-action]').forEach((button) => {
                    button.addEventListener('click', function () {
                        const action = String(button.getAttribute('data-page-action') || '');
                        state.page += action === 'next' ? 1 : -1;
                        renderList(resource);
                    });
                });
                const pageSize = document.getElementById('pageSize');
                if (pageSize) {
                    pageSize.value = String(state.pageSize);
                    pageSize.addEventListener('change', function () {
                        state.pageSize = Number(pageSize.value || 25);
                        state.page = 1;
                        renderList(resource);
                    });
                }
                document.querySelectorAll('.row-check').forEach((check) => {
                    check.addEventListener('change', function () {
                        const id = String(check.getAttribute('data-object-id') || '');
                        if (check.checked) {
                            state.selected.add(id);
                        } else {
                            state.selected.delete(id);
                        }
                        const count = document.getElementById('selectedCount');
                        if (count) {
                            count.textContent = state.selected.size + ' selected';
                        }
                        check.closest('tr').classList.toggle('is-selected', check.checked);
                    });
                });
                const selectAll = document.getElementById('selectAllRows');
                if (selectAll) {
                    selectAll.addEventListener('change', function () {
                        document.querySelectorAll('.row-check').forEach((check) => {
                            check.checked = selectAll.checked;
                            check.dispatchEvent(new Event('change'));
                        });
                    });
                }
                const bulk = document.getElementById('runBulkAction');
                if (bulk) {
                    bulk.addEventListener('click', function () {
                        runBulkAction(resource);
                    });
                }
            }

            async function runBulkAction(resource) {
                const action = String((document.getElementById('bulkAction') || {}).value || '');
                if (action === '' || state.selected.size === 0) {
                    return;
                }
                if (action === 'export') {
                    const selectedRows = state.rows.filter((row) => state.selected.has(String(row.id || row.slug || row.value || '')));
                    const blob = new Blob([JSON.stringify(selectedRows, null, 2)], {type: 'application/json'});
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = String(resource.key || 'records') + '-selection.json';
                    document.body.appendChild(link);
                    link.click();
                    link.remove();
                    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
                    rememberAction('change', resource, {name: selectedRows.length + ' exported'});
                    return;
                }
                if (action !== 'delete') {
                    return;
                }
                if (!(await confirmAction('Delete ' + state.selected.size + ' selected ' + pluralLabel(resource).toLowerCase() + '?', {
                    title: 'Delete selected records',
                    confirmButtonText: 'Delete'
                }))) {
                    return;
                }
                const route = routeFor(resource, 'DELETE', 'detail');
                if (!route) {
                    flash('No delete route is registered for this section.', 'error');
                    return;
                }
                try {
                    for (const id of Array.from(state.selected)) {
                        await apiFetch(buildPath(route, id), {method: 'DELETE'});
                    }
                    rememberAction('delete', resource, {name: state.selected.size + ' selected'});
                    state.selected.clear();
                    flash('Selected records deleted.');
                    renderList(resource);
                } catch (error) {
                    flash(error.message, 'error');
                }
            }

            function formFields(resource, mode) {
                const routeFields = routeBodyFields(resource, mode);
                const fields = routeFields.length > 0 ? routeFields : (mode === 'add' ? resource.create_fields : resource.update_fields);
                const usable = Array.isArray(fields) && fields.length > 0 ? fields : allResourceFields(resource);
                return usable
                    .map((field) => mergeFieldMetadata(field, resource))
                    .filter((field) => !field.read_only && !field.write_only && !(String(resource.key || '') === 'users' && ['role', 'group_ids'].includes(String(field.name || ''))));
            }

            function isMultipleRelationField(field) {
                const name = String(field.name || '');
                return name.endsWith('_ids') || name.endsWith('[]') || Array.isArray(field.default);
            }

            function relationInput(field, value) {
                const name = String(field.name || '');
                const relation = field.relation || {};
                const related = relationResource(relation);
                const required = field.required_on_create || field.required_on_update ? ' required' : '';
                const multiple = isMultipleRelationField(field);
                const values = Array.isArray(value) ? value.map(String) : (value === undefined || value === null || value === '' ? [] : [String(value)]);
                const current = escapeHtml(values.join(','));
                const viewLink = related ? '<a class="button flat" href="' + escapeHtml(resourceUrl(related)) + '" data-admin-link data-view="list" data-resource="' + escapeHtml(String(related.key || '')) + '">View</a>' : '';
                const addLink = related ? '<a class="button flat" href="' + escapeHtml(resourceUrl(related, '/add')) + '" data-admin-link data-view="add" data-resource="' + escapeHtml(String(related.key || '')) + '">Add</a>' : '';
                return '<div class="related-control">' +
                    '<select name="' + escapeHtml(name) + '" data-relation-for="' + escapeHtml(name) + '" data-relation-value="' + current + '" ' + (multiple ? 'multiple ' : '') + required + '>' +
                    (multiple ? '' : '<option value="">---------</option>') +
                    values.map((item) => '<option value="' + escapeHtml(item) + '" selected>' + escapeHtml(item) + '</option>').join('') +
                    '</select><input type="search" data-relation-search-for="' + escapeHtml(name) + '" placeholder="Search">' + viewLink + addLink + '</div>';
            }

            function fieldInput(field, value) {
                const name = String(field.name || '');
                const type = String(field.data_type || 'string');
                const format = String(field.format || '');
                let choices = Array.isArray(field.options) ? field.options : [];
                if (choices.length === 0 && name === 'role') {
                    choices = rbacRoles;
                }
                if (choices.length === 0 && name === 'account_status') {
                    choices = ['active', 'inactive', 'suspended'];
                }
                if (choices.length === 0 && name === 'access_scope') {
                    choices = ['public', 'authenticated', 'roles', 'users', 'private'];
                }
                const required = field.required_on_create || field.required_on_update ? ' required' : '';
                const safeValue = value === undefined || value === null ? '' : value;
                const media = field.media_upload && typeof field.media_upload === 'object';
                if (field.relation && typeof field.relation === 'object') {
                    return relationInput(field, safeValue);
                }
                if (media) {
                    const control = '<input type="text" name="' + escapeHtml(name) + '" value="' + escapeHtml(safeValue) + '"' + required + '>';
                    const preview = isImageLikeUrl(safeValue) ? '<img class="image-preview" src="' + escapeHtml(safeValue) + '" alt="">' : '<img class="image-preview hidden" alt="">';
                    return control + '<div class="upload-row"><input type="file" data-upload-for="' + escapeHtml(name) + '"><button class="button primary" type="button" data-upload-button="' + escapeHtml(name) + '">Upload</button><button class="button flat" type="button" data-media-pick-button="' + escapeHtml(name) + '">Pick existing</button></div>' + preview;
                }
                if (name === 'allowed_roles') {
                    const values = Array.isArray(safeValue) ? safeValue.map(String) : [];
                    return '<select name="' + escapeHtml(name) + '" multiple>' +
                        rbacRoles.map((role) => '<option value="' + escapeHtml(role) + '"' + (values.includes(role) ? ' selected' : '') + '>' + escapeHtml(roleLabel(role)) + '</option>').join('') +
                        '</select>';
                }
                if (choices.length > 0) {
                    return '<select name="' + escapeHtml(name) + '"' + required + '><option value="">---------</option>' +
                        choices.map((choice) => '<option value="' + escapeHtml(choice) + '"' + (String(choice) === String(safeValue) ? ' selected' : '') + '>' + escapeHtml(labelize(choice)) + '</option>').join('') +
                        '</select>';
                }
                if (type === 'boolean') {
                    return '<input type="checkbox" name="' + escapeHtml(name) + '" value="1"' + (safeValue === true || safeValue === 1 || safeValue === '1' ? ' checked' : '') + '>';
                }
                if (type === 'object' || format === 'json') {
                    const json = typeof safeValue === 'object' ? JSON.stringify(safeValue, null, 2) : String(safeValue || '{}');
                    return '<textarea name="' + escapeHtml(name) + '" spellcheck="false">' + escapeHtml(json) + '</textarea>';
                }
                if (format === 'date-time') {
                    const normalized = localDateTimeInputValue(safeValue);
                    return '<input type="datetime-local" name="' + escapeHtml(name) + '" value="' + escapeHtml(normalized) + '"' + required + '>';
                }
                if (format === 'date') {
                    const normalized = safeValue ? String(safeValue).slice(0, 10) : '';
                    return '<input type="date" name="' + escapeHtml(name) + '" value="' + escapeHtml(normalized) + '"' + required + '>';
                }
                if (type === 'integer' || type === 'number') {
                    return '<input type="number" name="' + escapeHtml(name) + '" value="' + escapeHtml(safeValue) + '"' + required + '>';
                }
                if (/email/i.test(name)) {
                    return '<input type="email" name="' + escapeHtml(name) + '" value="' + escapeHtml(safeValue) + '"' + required + '>';
                }
                if (/password/i.test(name)) {
                    return '<input type="password" name="' + escapeHtml(name) + '" value="" autocomplete="new-password"' + required + '>';
                }
                const control = '<input type="text" name="' + escapeHtml(name) + '" value="' + escapeHtml(safeValue) + '"' + required + '>';
                return control;
            }

            function renderFormRows(resource, mode, object) {
                const fields = formFields(resource, mode);
                return fields.map((field) => {
                    const name = String(field.name || '');
                    const required = field.required_on_create || field.required_on_update ? ' required' : '';
                    const help = field.description ? '<div class="help">' + escapeHtml(field.description) + '</div>' : '';
                    return '<div class="form-row' + required + '"><label for="field_' + escapeHtml(name) + '">' + escapeHtml(labelize(name)) + ':</label>' +
                        '<div class="field-control">' + fieldInput(field, object ? object[name] : undefined) + help + '</div></div>';
                }).join('');
            }

            function userGroupAssignmentFieldset(resource, mode) {
                if (String(resource && resource.key || '') !== 'users' || mode === 'add') {
                    return '';
                }
                return '<fieldset class="fieldset" id="userGroupAssignment" aria-live="polite">' +
                    '<h2>Permission groups</h2><p class="muted">Loading groups...</p></fieldset>';
            }

            async function hydrateUserGroupAssignment(form, user) {
                const target = form ? form.querySelector('#userGroupAssignment') : null;
                if (!target) {
                    return;
                }
                if (!canUsePermission('admin.rbac.manage')) {
                    target.innerHTML = '<h2>Permission groups</h2><p class="muted">You need RBAC management permission to change this user\'s groups.</p>';
                    return;
                }
                if (!canUsePermission('admin.rbac.view')) {
                    target.innerHTML = '<h2>Permission groups</h2><p class="muted">You need RBAC view permission to load available groups.</p>';
                    return;
                }

                try {
                    const json = await apiFetch('/api/v1/admin/rbac/groups?limit=200');
                    const groups = Array.isArray(json.data) ? json.data : [];
                    const selected = new Set((Array.isArray(user && user.groups) ? user.groups : [])
                        .map((group) => String(group && group.id || ''))
                        .filter((id) => id !== ''));
                    const rows = groups.map((group) => {
                        const id = String(group && group.id || '');
                        const name = String(group && (group.name || group.code) || id);
                        const status = group && group.is_active === false ? ' <span class="muted">(inactive)</span>' : '';
                        return '<label class="member-option" data-user-group-name="' + escapeHtml(name.toLowerCase()) + '">' +
                            '<input type="checkbox" data-user-group-id value="' + escapeHtml(id) + '"' + (selected.has(id) ? ' checked' : '') + '>' +
                            '<span><strong>' + escapeHtml(name) + '</strong>' + status + '<br><span class="muted">' + escapeHtml(String(group && group.description || 'Permission group')) + '</span></span>' +
                        '</label>';
                    }).join('');
                    target.innerHTML = '<h2>Permission groups</h2><p class="muted">Select the groups for this user, then save. This replaces the current group selection.</p>' +
                        '<input type="search" data-user-group-search placeholder="Filter groups">' +
                        '<div class="member-grid">' + (rows || '<p class="muted">No permission groups are available.</p>') + '</div>';
                    target.dataset.ready = 'true';
                    const search = target.querySelector('[data-user-group-search]');
                    if (search) {
                        search.addEventListener('input', function () {
                            const term = String(search.value || '').trim().toLowerCase();
                            target.querySelectorAll('[data-user-group-name]').forEach((item) => {
                                item.classList.toggle('hidden', term !== '' && !String(item.getAttribute('data-user-group-name') || '').includes(term));
                            });
                        });
                    }
                } catch (error) {
                    target.innerHTML = '<h2>Permission groups</h2><p class="muted">Could not load groups: ' + escapeHtml(error.message) + '</p>';
                }
            }

            async function relationRows(relation, searchTerm = '') {
                const listPath = String(relation && relation.list_path ? relation.list_path : '');
                if (listPath === '') {
                    return [];
                }
                const params = {};
                if (searchTerm !== '' && relation.search_param) {
                    params[relation.search_param] = searchTerm;
                }
                if (relation.limit_param) {
                    params[relation.limit_param] = '50';
                }
                const cacheKey = listPath + '?' + JSON.stringify(params);
                if (relationCache.has(cacheKey)) {
                    return relationCache.get(cacheKey);
                }
                const json = await apiFetch(listPath + queryString(params));
                const rows = Array.isArray(json.data) ? json.data : (Array.isArray(json.data && json.data.items) ? json.data.items : []);
                relationCache.set(cacheKey, rows);
                return rows;
            }

            function populateRelationSelect(select, relation, rows) {
                const selectedValues = String(select.getAttribute('data-relation-value') || '')
                    .split(',')
                    .map((item) => item.trim())
                    .filter((item) => item !== '');
                const selected = new Set(selectedValues);
                const options = [];
                if (!select.multiple) {
                    options.push('<option value="">---------</option>');
                }
                for (const row of rows) {
                    const value = relationValue(row, relation);
                    if (value === '') {
                        continue;
                    }
                    const label = relationDisplayName(row, relation);
                    options.push('<option value="' + escapeHtml(value) + '"' + (selected.has(value) ? ' selected' : '') + '>' + escapeHtml(label) + '</option>');
                    selected.delete(value);
                }
                for (const leftover of selected) {
                    options.unshift('<option value="' + escapeHtml(leftover) + '" selected>' + escapeHtml(leftover) + '</option>');
                }
                select.innerHTML = options.join('');
            }

            async function hydrateRelationPickers(resource, mode) {
                const fields = formFields(resource, mode);
                const byName = new Map(fields.map((field) => [String(field.name || ''), field]));
                const controls = Array.from(document.querySelectorAll('[data-relation-for]'));
                await Promise.all(controls.map(async (select) => {
                    const field = byName.get(String(select.getAttribute('data-relation-for') || ''));
                    if (!field || !field.relation) {
                        return;
                    }
                    try {
                        populateRelationSelect(select, field.relation, await relationRows(field.relation));
                    } catch (error) {
                        select.innerHTML = '<option value="">' + escapeHtml(error.message) + '</option>';
                    }
                }));

                document.querySelectorAll('[data-relation-search-for]').forEach((input) => {
                    let timer = 0;
                    input.addEventListener('input', function () {
                        window.clearTimeout(timer);
                        timer = window.setTimeout(async function () {
                            const fieldName = String(input.getAttribute('data-relation-search-for') || '');
                            const field = byName.get(fieldName);
                            const select = document.querySelector('[data-relation-for="' + CSS.escape(fieldName) + '"]');
                            if (!field || !field.relation || !select) {
                                return;
                            }
                            try {
                                populateRelationSelect(select, field.relation, await relationRows(field.relation, String(input.value || '').trim()));
                            } catch (error) {
                                flash(error.message, 'error');
                            }
                        }, 250);
                    });
                });
            }

            function permissionStateSelect(name, value, disabled = false) {
                const current = String(value || 'inherit');
                return '<select name="' + escapeHtml(name) + '"' + (disabled ? ' disabled' : '') + '>' +
                    '<option value="inherit"' + (current === 'inherit' || current === '' ? ' selected' : '') + '>Inherit</option>' +
                    '<option value="allow"' + (current === 'allow' ? ' selected' : '') + '>Allow</option>' +
                    '<option value="deny"' + (current === 'deny' ? ' selected' : '') + '>Deny</option>' +
                '</select>';
            }

            function permissionAccessKind(row) {
                const kind = String(row && row.access_kind ? row.access_kind : '').trim().toLowerCase();
                if (kind === 'visibility' || kind === 'action') {
                    return kind;
                }
                const action = String(row && row.action_code ? row.action_code : '').trim().toLowerCase();
                return ['access', 'view', 'read', 'list', 'browse'].includes(action) ? 'visibility' : 'action';
            }

            function permissionAccessLabel(row) {
                return permissionAccessKind(row) === 'visibility' ? 'Can see' : 'Can do';
            }

            function permissionModuleLabel(row) {
                return String(row && (row.module_title || row.group_label || row.group || row.module_code) ? (row.module_title || row.group_label || row.group || row.module_code) : 'General');
            }

            function permissionRowAttributes(row) {
                const haystack = [
                    row && row.title,
                    row && row.code,
                    row && row.description,
                    row && row.section_title,
                    row && row.module_title,
                    row && row.action_title,
                    permissionAccessLabel(row)
                ].join(' ').toLowerCase();
                return ' data-permission-row data-permission-kind="' + escapeHtml(permissionAccessKind(row)) + '" data-permission-module="' + escapeHtml(permissionModuleLabel(row)) + '" data-permission-search="' + escapeHtml(haystack) + '"';
            }

            function permissionNameCell(row) {
                const code = String(row && row.code ? row.code : '');
                const description = String(row && row.description ? row.description : '');
                const desc = description === '' ? '' : '<div class="muted permission-description">' + escapeHtml(description) + '</div>';
                return '<td><strong>' + escapeHtml(String(row && (row.title || row.label) ? (row.title || row.label) : code)) + '</strong> ' +
                    '<span class="permission-kind">' + escapeHtml(permissionAccessLabel(row)) + '</span>' +
                    '<div class="muted">' + escapeHtml(code) + '</div>' + desc + '</td>';
            }

            function permissionFilterControls(rows) {
                const modules = Array.from(new Set(rows.map(permissionModuleLabel).filter((value) => value !== ''))).sort((left, right) => left.localeCompare(right));
                return '<input id="permissionSearch" type="search" placeholder="Filter permissions">' +
                    '<select id="permissionKindFilter" aria-label="Filter permission type">' +
                        '<option value="">All access</option><option value="visibility">Can see</option><option value="action">Can do</option>' +
                    '</select>' +
                    '<select id="permissionModuleFilter" aria-label="Filter module"><option value="">All modules</option>' +
                        modules.map((module) => '<option value="' + escapeHtml(module) + '">' + escapeHtml(module) + '</option>').join('') +
                    '</select>' +
                    '<span class="muted" id="permissionVisibleCount"></span>';
            }

            function permissionSummary(rows) {
                const visible = rows.filter((row) => permissionAccessKind(row) === 'visibility').length;
                const action = rows.length - visible;
                return '<div class="permission-summary">' +
                    '<span class="permission-chip">Total ' + rows.length + '</span>' +
                    '<span class="permission-chip">Can see ' + visible + '</span>' +
                    '<span class="permission-chip">Can do ' + action + '</span>' +
                '</div>';
            }

            function bindPermissionFilters() {
                const search = document.getElementById('permissionSearch');
                const kind = document.getElementById('permissionKindFilter');
                const module = document.getElementById('permissionModuleFilter');
                const visibleCount = document.getElementById('permissionVisibleCount');
                const rows = Array.from(document.querySelectorAll('[data-permission-row]'));
                const apply = function () {
                    const term = String(search ? search.value : '').trim().toLowerCase();
                    const kindValue = String(kind ? kind.value : '');
                    const moduleValue = String(module ? module.value : '');
                    let visible = 0;
                    rows.forEach((row) => {
                        const matchesTerm = term === '' || String(row.getAttribute('data-permission-search') || '').includes(term);
                        const matchesKind = kindValue === '' || String(row.getAttribute('data-permission-kind') || '') === kindValue;
                        const matchesModule = moduleValue === '' || String(row.getAttribute('data-permission-module') || '') === moduleValue;
                        const show = matchesTerm && matchesKind && matchesModule;
                        row.classList.toggle('is-hidden', !show);
                        if (show) {
                            visible += 1;
                        }
                    });
                    if (visibleCount) {
                        visibleCount.textContent = visible + ' shown';
                    }
                };
                [search, kind, module].forEach((control) => {
                    if (control) {
                        control.addEventListener('input', apply);
                        control.addEventListener('change', apply);
                    }
                });
                apply();
            }

            async function renderRbacMatrix() {
                state.view = 'rbacMatrix';
                state.resourceKey = 'rbac_matrix';
                state.objectId = null;
                renderSidebar();
                setBreadcrumb([{label: 'Group Permission Matrix'}]);
                app.innerHTML = '<h1>Group permission matrix</h1><p class="muted">Loading...</p>';
                try {
                    const [groupJson, permissionJson] = await Promise.all([
                        apiFetch('/api/v1/admin/rbac/groups?limit=200'),
                        apiFetch('/api/v1/admin/rbac/permissions')
                    ]);
                    const groups = (Array.isArray(groupJson.data) ? groupJson.data : []).filter((group) => group && group.id);
                    const rows = Array.isArray(permissionJson.data) ? permissionJson.data : [];
                    const canManageRbac = canUsePermission('admin.rbac.manage');
                    if (groups.length === 0) {
                        app.innerHTML = '<div class="page-top"><div><h1>Group permission matrix</h1><p class="muted">Create groups before assigning permissions.</p></div>' +
                            '<a class="button primary" href="/admin/rbac-groups/add" data-admin-link data-view="add" data-resource="rbac_groups">Add group +</a></div>';
                        return;
                    }
                    const groupStates = new Map();
                    await Promise.all(groups.map(async (group) => {
                        const detail = await apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(String(group.id)) + '/permissions');
                        const stateMap = new Map();
                        const detailRows = Array.isArray(detail.data && detail.data.rows) ? detail.data.rows : [];
                        detailRows.forEach((row) => {
                            stateMap.set(String(row.code || ''), String(row.group_state || 'inherit'));
                        });
                        groupStates.set(String(group.id), stateMap);
                    }));
                    const body = rows.map((row) => {
                        const code = String(row.code || '');
                        const cells = groups.map((group) => {
                            const groupId = String(group.id || '');
                            const value = (groupStates.get(groupId) || new Map()).get(code) || 'inherit';
                            return '<td>' + permissionStateSelect('group[' + groupId + '][' + code + ']', value, !canManageRbac)
                                .replace('<select ', '<select data-group-permission="' + escapeHtml(groupId) + '" data-permission-code="' + escapeHtml(code) + '" ') + '</td>';
                        }).join('');
                        return '<tr' + permissionRowAttributes(row) + '>' + permissionNameCell(row) +
                            '<td>' + escapeHtml(String(row.section_title || '')) + '</td>' +
                            '<td>' + escapeHtml(permissionModuleLabel(row)) + '</td>' +
                            '<td>' + escapeHtml(String(row.action_title || row.action_code || '')) + '</td>' +
                            cells + '</tr>';
                    }).join('');
                    const heads = groups.map((group) => '<th>' + escapeHtml(String(group.name || group.code || group.id)) + '</th>').join('');
                    const saveButton = canManageRbac ? '<button class="button primary" type="button" id="savePermissionMatrix">Save group permissions</button>' : '';
                    app.innerHTML = '<div class="page-top"><div><h1>Group permission matrix</h1><p class="muted">Assign permissions through groups. Users receive access through group membership.</p></div></div>' +
                        permissionSummary(rows) +
                        '<div class="permission-toolbar">' + permissionFilterControls(rows) + saveButton + '<a class="button flat" href="/admin/rbac-groups" data-admin-link data-view="list" data-resource="rbac_groups">Groups</a><a class="button flat" href="/admin/users" data-admin-link data-view="list" data-resource="users">Users</a></div>' +
                        '<div class="result-table-wrap"><table class="result-table permission-table"><thead><tr><th>Permission</th><th>Section</th><th>Module</th><th>Action</th>' + heads + '</tr></thead><tbody>' + body + '</tbody></table></div>';
                    bindPermissionFilters();
                    const savePermissionMatrix = document.getElementById('savePermissionMatrix');
                    if (savePermissionMatrix) {
                    savePermissionMatrix.addEventListener('click', async function () {
                        try {
                            for (const group of groups) {
                                const groupId = String(group.id || '');
                                const states = {};
                                document.querySelectorAll('select[data-group-permission]').forEach((select) => {
                                    if (String(select.getAttribute('data-group-permission') || '') === groupId) {
                                        const code = String(select.getAttribute('data-permission-code') || '');
                                        if (code !== '') {
                                            states[code] = select.value;
                                        }
                                    }
                                });
                                await apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(groupId) + '/permissions', {
                                    method: 'PUT',
                                    body: JSON.stringify({states})
                                });
                            }
                            rememberAction('change', {label: 'Permission Matrix'}, {name: 'Group permissions'});
                            flash('Group permissions saved.');
                            renderRbacMatrix();
                        } catch (error) {
                            flash(error.message, 'error');
                        }
                    });
                    }
                } catch (error) {
                    app.innerHTML = '<h1>Group permission matrix</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            async function renderUserPermissions(userId) {
                state.view = 'userPermissions';
                state.resourceKey = 'users';
                state.objectId = userId;
                renderSidebar();
                setBreadcrumb([
                    {label: 'Users', href: '/admin/users', resource: 'users', view: 'list'},
                    {label: 'Permissions'}
                ]);
                app.innerHTML = '<h1>Change user permissions</h1><p class="muted">Loading...</p>';
                try {
                    const json = await apiFetch('/api/v1/admin/rbac/users/' + encodeURIComponent(String(userId)) + '/overrides');
                    const payload = json.data || {};
                    const user = payload.user || {};
                    const rows = Array.isArray(payload.rows) ? payload.rows : [];
                    const canManageRbac = canUsePermission('admin.rbac.manage');
                    const groupNames = Array.isArray(user.groups) && user.groups.length > 0
                        ? user.groups.map((group) => String(group.name || group.code || '')).filter((name) => name !== '').join(', ')
                        : 'No groups';
                    const body = rows.map((row) => {
                        const code = String(row.code || '');
                        return '<tr' + permissionRowAttributes(row) + '>' + permissionNameCell(row) +
                            '<td>' + escapeHtml(permissionModuleLabel(row)) + '</td>' +
                            '<td>' + escapeHtml(String(row.action_title || row.action_code || '')) + '</td>' +
                            '<td>' + permissionStateSelect('group_display[' + code + ']', String(row.group_state || 'inherit'), true) + '<div class="effective">' + (row.group_allowed ? '<span class="bool true">&#10003;</span>' : '<span class="bool false">&#10005;</span>') + '</div></td>' +
                            '<td>' + permissionStateSelect('user[' + code + ']', String(row.user_state || 'inherit'), !canManageRbac) + '</td>' +
                            '<td>' + (row.effective ? '<span class="bool true">&#10003;</span>' : '<span class="bool false">&#10005;</span>') + '</td></tr>';
                    }).join('');
                    const saveButton = canManageRbac ? '<button class="button primary" type="button" id="saveUserPermissions">Save user overrides</button>' : '';
                    app.innerHTML = '<div class="page-top"><div><h1>Change user permissions</h1><p class="object-title">' + escapeHtml(displayName(user, byKey.get('users') || {})) + '</p><p class="muted">Groups: ' + escapeHtml(groupNames) + '</p></div>' +
                        '<div class="object-tools"><a class="button" href="/admin/users/' + encodeURIComponent(String(userId)) + '/change" data-admin-link data-view="change" data-resource="users" data-object-id="' + escapeHtml(String(userId)) + '">Back to user</a><a class="button" href="/admin/rbac-matrix" data-admin-link data-view="rbacMatrix" data-resource="rbac_matrix">Permission matrix</a></div></div>' +
                        permissionSummary(rows) +
                        '<div class="permission-toolbar">' + permissionFilterControls(rows) + saveButton + '</div>' +
                        '<div class="result-table-wrap"><table class="result-table permission-table"><thead><tr><th>Permission</th><th>Module</th><th>Action</th><th>Group state</th><th>User override</th><th>Effective</th></tr></thead><tbody>' + body + '</tbody></table></div>';
                    bindPermissionFilters();
                    const saveUserPermissions = document.getElementById('saveUserPermissions');
                    if (saveUserPermissions) {
                    saveUserPermissions.addEventListener('click', async function () {
                        const states = {};
                        document.querySelectorAll('select[name^="user["]').forEach((select) => {
                            const match = String(select.name || '').match(/^user\[(.*)\]$/);
                            if (match) {
                                states[match[1]] = select.value;
                            }
                        });
                        try {
                            await apiFetch('/api/v1/admin/rbac/users/' + encodeURIComponent(String(userId)) + '/overrides', {
                                method: 'PUT',
                                body: JSON.stringify({states})
                            });
                            rememberAction('change', {label: 'Users'}, user);
                            flash('User permission overrides saved.');
                            renderUserPermissions(userId);
                        } catch (error) {
                            flash(error.message, 'error');
                        }
                    });
                    }
                } catch (error) {
                    app.innerHTML = '<h1>Change user permissions</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            function renderMiniTable(rows, resource) {
                const safeRows = Array.isArray(rows) ? rows : [];
                if (safeRows.length === 0) {
                    return '<p class="muted">No related records found.</p>';
                }
                const columns = listColumns(resource || {}, safeRows).slice(0, 6);
                const head = columns.map((name) => '<th>' + escapeHtml(labelize(name)) + '</th>').join('');
                const body = safeRows.slice(0, 12).map((row) => {
                    const cells = columns.map((name) => '<td>' + formatValue(row ? row[name] : null, name) + '</td>').join('');
                    return '<tr>' + cells + '</tr>';
                }).join('');
                return '<div class="result-table-wrap"><table class="result-table"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>' +
                    (safeRows.length > 12 ? '<p class="muted">Showing 12 of ' + safeRows.length + ' records.</p>' : '');
            }

            async function renderGroupMembers(groupId) {
                state.view = 'groupMembers';
                state.resourceKey = 'rbac_groups';
                state.objectId = groupId;
                renderSidebar();
                setBreadcrumb([
                    {label: 'Groups', href: '/admin/rbac-groups', resource: 'rbac_groups', view: 'list'},
                    {label: 'Members'}
                ]);
                if (!canUsePermission('admin.rbac.view')) {
                    app.innerHTML = '<h1>Group members</h1><p class="muted">You do not have permission to view RBAC groups.</p>';
                    return;
                }
                app.innerHTML = '<h1>Group members</h1><p class="muted">Loading...</p>';
                try {
                    const [memberJson, userJson] = await Promise.all([
                        apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(String(groupId)) + '/members'),
                        apiFetch('/api/v1/admin/users?limit=200')
                    ]);
                    const payload = memberJson.data || {};
                    const group = payload.group || {};
                    const members = Array.isArray(payload.members) ? payload.members : [];
                    const users = Array.isArray(userJson.data) ? userJson.data : [];
                    const selected = new Set(members.map((user) => String(user.id || '')));
                    const canManage = canUsePermission('admin.rbac.manage');
                    const rows = users.map((user) => {
                        const id = String(user.id || '');
                        return '<label class="member-option" data-member-name="' + escapeHtml(String(user.name || user.email || '').toLowerCase()) + '">' +
                            '<input type="checkbox" name="group_members" value="' + escapeHtml(id) + '"' + (selected.has(id) ? ' checked' : '') + (canManage ? '' : ' disabled') + '>' +
                            '<span><strong>' + escapeHtml(String(user.name || user.email || id)) + '</strong><br><span class="muted">' + escapeHtml(String(user.email || '')) + '</span></span>' +
                        '</label>';
                    }).join('');
                    const saveButton = canManage ? '<button class="button primary" type="button" id="saveGroupMembers">Save members</button>' : '';
                    app.innerHTML = '<div class="page-top"><div><h1>Group members</h1><p class="object-title">' + escapeHtml(displayName(group, byKey.get('rbac_groups') || {})) + '</p></div>' +
                        '<div class="object-tools"><a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(groupId)) + '/change" data-admin-link data-view="change" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(groupId)) + '">Back to group</a><a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(groupId)) + '/permissions" data-admin-link data-view="groupPermissions" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(groupId)) + '">Permissions</a></div></div>' +
                        '<div class="permission-toolbar"><input id="memberSearch" type="search" placeholder="Filter users"> ' + saveButton + '</div>' +
                        '<div class="member-grid">' + rows + '</div>';
                    const memberSearch = document.getElementById('memberSearch');
                    memberSearch.addEventListener('input', function () {
                        const term = String(memberSearch.value || '').trim().toLowerCase();
                        document.querySelectorAll('[data-member-name]').forEach((item) => {
                            item.classList.toggle('hidden', term !== '' && !String(item.getAttribute('data-member-name') || '').includes(term));
                        });
                    });
                    const saveGroupMembers = document.getElementById('saveGroupMembers');
                    if (saveGroupMembers) {
                        saveGroupMembers.addEventListener('click', async function () {
                            const userIds = Array.from(document.querySelectorAll('input[name="group_members"]:checked')).map((input) => input.value);
                            await apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(String(groupId)) + '/members', {
                                method: 'PUT',
                                body: JSON.stringify({user_ids: userIds})
                            });
                            rememberAction('change', {label: 'Groups'}, group);
                            flash('Group members saved.');
                            renderGroupMembers(groupId);
                        });
                    }
                } catch (error) {
                    app.innerHTML = '<h1>Group members</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            async function renderGroupPermissions(groupId) {
                state.view = 'groupPermissions';
                state.resourceKey = 'rbac_groups';
                state.objectId = groupId;
                renderSidebar();
                setBreadcrumb([
                    {label: 'Groups', href: '/admin/rbac-groups', resource: 'rbac_groups', view: 'list'},
                    {label: 'Permissions'}
                ]);
                if (!canUsePermission('admin.rbac.view')) {
                    app.innerHTML = '<h1>Group permissions</h1><p class="muted">You do not have permission to view RBAC groups.</p>';
                    return;
                }
                app.innerHTML = '<h1>Group permissions</h1><p class="muted">Loading...</p>';
                try {
                    const json = await apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(String(groupId)) + '/permissions');
                    const payload = json.data || {};
                    const group = payload.group || {};
                    const rows = Array.isArray(payload.rows) ? payload.rows : [];
                    const canManageRbac = canUsePermission('admin.rbac.manage');
                    const body = rows.map((row) => {
                        const code = String(row.code || '');
                        return '<tr' + permissionRowAttributes(row) + '>' + permissionNameCell(row) +
                            '<td>' + escapeHtml(permissionModuleLabel(row)) + '</td>' +
                            '<td>' + escapeHtml(String(row.action_title || row.action_code || '')) + '</td>' +
                            '<td>' + permissionStateSelect('group[' + code + ']', String(row.group_state || 'inherit'), !canManageRbac) + '</td></tr>';
                    }).join('');
                    const saveButton = canManageRbac ? '<button class="button primary" type="button" id="saveGroupPermissions">Save group permissions</button>' : '';
                    app.innerHTML = '<div class="page-top"><div><h1>Group permissions</h1><p class="object-title">' + escapeHtml(displayName(group, byKey.get('rbac_groups') || {})) + '</p><p class="muted">Group rules combine across active user groups. Direct user overrides are final.</p></div>' +
                        '<div class="object-tools"><a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(groupId)) + '/change" data-admin-link data-view="change" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(groupId)) + '">Back to group</a><a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(groupId)) + '/members" data-admin-link data-view="groupMembers" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(groupId)) + '">Members</a></div></div>' +
                        permissionSummary(rows) +
                        '<div class="permission-toolbar">' + permissionFilterControls(rows) + saveButton + '</div>' +
                        '<div class="result-table-wrap"><table class="result-table permission-table"><thead><tr><th>Permission</th><th>Module</th><th>Action</th><th>Group override</th></tr></thead><tbody>' + body + '</tbody></table></div>';
                    bindPermissionFilters();
                    const saveGroupPermissions = document.getElementById('saveGroupPermissions');
                    if (saveGroupPermissions) {
                        saveGroupPermissions.addEventListener('click', async function () {
                            const states = {};
                            document.querySelectorAll('select[name^="group["]').forEach((select) => {
                                const match = String(select.name || '').match(/^group\[(.*)\]$/);
                                if (match) {
                                    states[match[1]] = select.value;
                                }
                            });
                            await apiFetch('/api/v1/admin/rbac/groups/' + encodeURIComponent(String(groupId)) + '/permissions', {
                                method: 'PUT',
                                body: JSON.stringify({states})
                            });
                            rememberAction('change', {label: 'Groups'}, group);
                            flash('Group permissions saved.');
                            renderGroupPermissions(groupId);
                        });
                    }
                } catch (error) {
                    app.innerHTML = '<h1>Group permissions</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            async function renderObjectHistory(resource, objectId) {
                state.view = 'history';
                state.resourceKey = String(resource.key || '');
                state.objectId = objectId;
                renderSidebar();
                setBreadcrumb([
                    {label: pluralLabel(resource), href: resourceUrl(resource), resource: String(resource.key || ''), view: 'list'},
                    {label: 'History'}
                ]);
                const route = historyRouteFor(resource);
                if (!route) {
                    app.innerHTML = '<h1>History</h1><p class="muted">No history route is registered for this section.</p>';
                    return;
                }
                app.innerHTML = '<h1>History</h1><p class="muted">Loading...</p>';
                try {
                    const json = await apiFetch(buildPath(route, objectId));
                    const rows = Array.isArray(json.data) ? json.data : (Array.isArray(json.data && json.data.items) ? json.data.items : []);
                    const restoreRoute = restoreHistoryRouteFor(resource);
                    const body = rows.map((row) => {
                        const id = String(row.id || row.log_id || '');
                        const restore = restoreRoute && id !== '' ? '<button class="button flat" type="button" data-restore-log="' + escapeHtml(id) + '">Restore</button>' : '';
                        const details = '<details class="history-details"><summary>Details</summary><pre>' + escapeHtml(JSON.stringify({
                            before: row.before_json || {},
                            after: row.after_json || {},
                            diff: row.diff_json || {}
                        }, null, 2)) + '</pre></details>';
                        return '<tr><td>' + escapeHtml(String(row.action || 'change')) + '</td><td>' + escapeHtml(String(row.record_title || row.record_slug || row.record_id || '')) + '</td><td>' + escapeHtml(String(row.actor_user_id || row.actor_role || '')) + '</td><td>' + formatValue(row.created_at, 'created_at') + '</td><td>' + details + '</td><td>' + restore + '</td></tr>';
                    }).join('');
                    app.innerHTML = '<div class="page-top"><div><h1>History</h1><p class="object-title">' + escapeHtml(String(objectId || '')) + '</p></div>' +
                        '<div class="object-tools"><a class="button" href="' + escapeHtml(resourceUrl(resource, '/' + encodeURIComponent(String(objectId)) + '/change')) + '" data-admin-link data-view="change" data-resource="' + escapeHtml(String(resource.key || '')) + '" data-object-id="' + escapeHtml(String(objectId)) + '">Back to record</a></div></div>' +
                        '<div class="result-table-wrap"><table class="result-table"><thead><tr><th>Action</th><th>Record</th><th>Actor</th><th>When</th><th>Change</th><th></th></tr></thead><tbody>' + body + '</tbody></table></div>' +
                        (rows.length === 0 ? '<p class="muted">No history entries found.</p>' : '');
                    document.querySelectorAll('[data-restore-log]').forEach((button) => {
                        button.addEventListener('click', async function () {
                            if (!(await confirmAction('Restore this history entry?', {
                                title: 'Restore history entry',
                                confirmButtonText: 'Restore'
                            }))) {
                                return;
                            }
                            try {
                                const logId = String(button.getAttribute('data-restore-log') || '');
                                const restorePath = String(restoreRoute.path || '').replace(/\{[^}]+\}/, encodeURIComponent(logId));
                                await apiFetch(restorePath, {method: 'POST', body: JSON.stringify({reason: 'Restored from admin history'})});
                                rememberAction('change', resource, {id: objectId, name: 'Restored from history'});
                                flash('History entry restored.');
                                renderObjectHistory(resource, objectId);
                            } catch (error) {
                                flash(error.message, 'error');
                            }
                        });
                    });
                } catch (error) {
                    app.innerHTML = '<h1>History</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            async function renderRelatedPanels(resource, objectId) {
                const target = document.getElementById('relatedPanels');
                if (!target) {
                    return;
                }
                const routes = relatedRoutesFor(resource);
                if (routes.length === 0) {
                    target.innerHTML = '';
                    return;
                }
                target.innerHTML = '<p class="muted">Loading related records...</p>';
                const panels = [];
                for (const route of routes) {
                    const title = labelize(String(route.path || '').split('/').pop() || 'Related');
                    try {
                        const json = await apiFetch(buildPath(route, objectId));
                        const rows = Array.isArray(json.data) ? json.data : (Array.isArray(json.data && json.data.items) ? json.data.items : []);
                        const createRoute = createRelatedRouteFor(resource, route);
                        const addForm = createRoute
                            ? '<details><summary>Add related ' + escapeHtml(title.toLowerCase()) + '</summary><textarea data-related-payload="' + escapeHtml(String(route.path || '')) + '" spellcheck="false">{\\n  \\n}</textarea><button class="button primary" type="button" data-related-create="' + escapeHtml(String(route.path || '')) + '">Create</button></details>'
                            : '';
                        panels.push('<section class="inline-panel"><h2>' + escapeHtml(title) + '</h2><div class="inline-panel-body">' + renderMiniTable(rows, {}) + addForm + '</div></section>');
                    } catch (error) {
                        panels.push('<section class="inline-panel"><h2>' + escapeHtml(title) + '</h2><div class="inline-panel-body"><p class="muted">' + escapeHtml(error.message) + '</p></div></section>');
                    }
                }
                target.innerHTML = panels.join('');
                document.querySelectorAll('[data-related-create]').forEach((button) => {
                    button.addEventListener('click', async function () {
                        const path = String(button.getAttribute('data-related-create') || '');
                        const textarea = document.querySelector('[data-related-payload="' + CSS.escape(path) + '"]');
                        try {
                            const payload = JSON.parse(String(textarea ? textarea.value : '{}') || '{}');
                            await apiFetch(buildPath({path}, objectId), {
                                method: 'POST',
                                body: JSON.stringify(payload)
                            });
                            flash('Related record created.');
                            renderRelatedPanels(resource, objectId);
                        } catch (error) {
                            flash(error.message, 'error');
                        }
                    });
                });
            }

            function objectTools(resource, mode, objectId) {
                if (mode === 'add' || !objectId) {
                    return '';
                }
                const tools = [];
                if (historyRouteFor(resource)) {
                    tools.push('<a class="button" href="' + escapeHtml(resourceUrl(resource, '/' + encodeURIComponent(String(objectId)) + '/history')) + '" data-admin-link data-view="history" data-resource="' + escapeHtml(String(resource.key || '')) + '" data-object-id="' + escapeHtml(String(objectId)) + '">History</a>');
                }
                if (String(resource.key || '') === 'users') {
                    tools.push('<a class="button" href="/admin/users/' + encodeURIComponent(String(objectId)) + '/permissions" data-admin-link data-view="userPermissions" data-resource="users" data-object-id="' + escapeHtml(String(objectId)) + '">Permissions</a>');
                }
                if (String(resource.key || '') === 'rbac_groups') {
                    tools.push('<a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(objectId)) + '/members" data-admin-link data-view="groupMembers" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(objectId)) + '">Members</a>');
                    tools.push('<a class="button" href="/admin/rbac-groups/' + encodeURIComponent(String(objectId)) + '/permissions" data-admin-link data-view="groupPermissions" data-resource="rbac_groups" data-object-id="' + escapeHtml(String(objectId)) + '">Permissions</a>');
                }
                if (tools.length === 0) {
                    return '';
                }
                return '<div class="object-tools">' + tools.join('') + '</div>';
            }

            async function renderForm(resource, mode, objectId = null) {
                state.view = mode;
                state.resourceKey = String(resource.key || '');
                state.objectId = objectId;
                renderSidebar();
                const isAdd = mode === 'add';
                setBreadcrumb([
                    {label: pluralLabel(resource), href: resourceUrl(resource), resource: String(resource.key || ''), view: 'list'},
                    {label: isAdd ? 'Add' : 'Change'}
                ]);
                app.innerHTML = '<h1>' + (isAdd ? 'Add ' : 'Change ') + escapeHtml(singularLabel(resource).toLowerCase()) + '</h1><p class="muted">Loading...</p>';
                let object = {};
                if (!isAdd) {
                    try {
                        const route = routeFor(resource, 'GET', 'detail');
                        if (!route) {
                            throw new Error('No detail route is registered for this section.');
                        }
                        const json = await apiFetch(buildPath(route, objectId));
                        object = json.data || {};
                        state.object = object;
                    } catch (error) {
                        if (!isSignedIn()) {
                            renderLogin('Sign in to change this record.', function () {
                                renderForm(resource, mode, objectId);
                            });
                            return;
                        }
                        app.innerHTML = '<h1>Change ' + escapeHtml(singularLabel(resource).toLowerCase()) + '</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                        return;
                    }
                }
                app.innerHTML = '<div class="page-top"><div><h1>' + (isAdd ? 'Add ' : 'Change ') + escapeHtml(singularLabel(resource).toLowerCase()) + '</h1>' +
                    (isAdd ? '' : '<p class="object-title">' + escapeHtml(displayName(object, resource)) + '</p>') + '</div>' +
                    objectTools(resource, mode, objectId) + '</div>' +
                    '<form id="objectForm" class="form-layout"><fieldset class="fieldset"><h2>' + escapeHtml(singularLabel(resource)) + '</h2>' +
                    renderFormRows(resource, mode, object) + '</fieldset>' + userGroupAssignmentFieldset(resource, mode) + '<div class="submit-row">' +
                    '<button class="button primary" type="submit" data-save-mode="normal">Save</button>' +
                    '<button class="button primary" type="submit" data-save-mode="addAnother">Save and add another</button>' +
                    '<button class="button primary" type="submit" data-save-mode="continue">Save and continue editing</button>' +
                    (!isAdd ? '<button class="button danger delete-link" type="button" id="deleteObject">Delete</button>' : '') +
                    '</div></form>' +
                    (!isAdd ? '<div id="relatedPanels" class="inline-panels"></div>' : '');
                bindFormEvents(resource, mode, objectId);
                hydrateRelationPickers(resource, mode);
                if (!isAdd && String(resource.key || '') === 'users') {
                    hydrateUserGroupAssignment(document.getElementById('objectForm'), object);
                }
                if (!isAdd) {
                    renderRelatedPanels(resource, objectId);
                }
            }

            function collectFormPayload(form, resource, mode) {
                const data = {};
                for (const field of formFields(resource, mode)) {
                    const name = String(field.name || '');
                    const control = form.elements[name];
                    if (!control) {
                        continue;
                    }
                    if (control instanceof HTMLSelectElement && control.multiple) {
                        data[name] = Array.from(control.selectedOptions).map((option) => option.value).filter((value) => value !== '');
                        continue;
                    }
                    if (control.type === 'checkbox') {
                        data[name] = Boolean(control.checked);
                        continue;
                    }
                    let value = control.value;
                    if (value === '' && !field.required_on_create && !field.required_on_update) {
                        continue;
                    }
                    if (field.data_type === 'integer') {
                        value = value === '' ? null : parseInt(value, 10);
                    } else if (field.data_type === 'number') {
                        value = value === '' ? null : parseFloat(value);
                    } else if (field.data_type === 'object' || field.format === 'json') {
                        try {
                            value = value === '' ? {} : JSON.parse(value);
                        } catch (error) {
                            throw new Error(labelize(name) + ' must be valid JSON.');
                        }
                    } else if (field.format === 'date-time' && value !== '') {
                        value = userDateTimeToStorage(value);
                    }
                    data[name] = value;
                }
                if (String(resource && resource.key || '') === 'users') {
                    const groupAssignment = form.querySelector('#userGroupAssignment');
                    if (groupAssignment && groupAssignment.dataset.ready === 'true') {
                        data.group_ids = Array.from(groupAssignment.querySelectorAll('[data-user-group-id]:checked'))
                            .map((control) => String(control.value || ''))
                            .filter((id) => id !== '');
                    }
                }
                return data;
            }

            function bindFormEvents(resource, mode, objectId) {
                const form = document.getElementById('objectForm');
                let saveMode = 'normal';
                form.querySelectorAll('[data-save-mode]').forEach((button) => {
                    button.addEventListener('click', function () {
                        saveMode = button.getAttribute('data-save-mode') || 'normal';
                    });
                });
                form.addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const isAdd = mode === 'add';
                    const route = routeFor(resource, isAdd ? 'POST' : 'PUT', isAdd ? 'create' : 'detail');
                    if (!route) {
                        flash('No save route is registered for this section.', 'error');
                        return;
                    }
                    try {
                        const data = collectFormPayload(form, resource, mode);
                        const json = await apiFetch(buildPath(route, objectId), {
                            method: isAdd ? 'POST' : 'PUT',
                            body: JSON.stringify(data)
                        });
                        const saved = json.data || data;
                        rememberAction(isAdd ? 'add' : 'change', resource, saved);
                        flash((isAdd ? 'Added ' : 'Changed ') + displayName(saved, resource) + '.');
                        const savedId = String(saved.id || objectId || '');
                        if (saveMode === 'addAnother') {
                            navigate(resourceUrl(resource, '/add'), 'add', String(resource.key || ''));
                        } else if (saveMode === 'continue' && savedId !== '') {
                            navigate(resourceUrl(resource, '/' + encodeURIComponent(savedId) + '/change'), 'change', String(resource.key || ''), savedId);
                        } else {
                            navigate(resourceUrl(resource), 'list', String(resource.key || ''));
                        }
                    } catch (error) {
                        flash(error.message, 'error');
                    }
                });
                const deleteButton = document.getElementById('deleteObject');
                if (deleteButton) {
                    deleteButton.addEventListener('click', async function () {
                        if (!(await confirmAction('Delete this ' + singularLabel(resource).toLowerCase() + '?', {
                            title: 'Delete record',
                            confirmButtonText: 'Delete'
                        }))) {
                            return;
                        }
                        const route = routeFor(resource, 'DELETE', 'detail');
                        if (!route) {
                            flash('No delete route is registered for this section.', 'error');
                            return;
                        }
                        try {
                            await apiFetch(buildPath(route, objectId), {method: 'DELETE'});
                            rememberAction('delete', resource, state.object || {id: objectId});
                            flash('Record deleted.');
                            navigate(resourceUrl(resource), 'list', String(resource.key || ''));
                        } catch (error) {
                            flash(error.message, 'error');
                        }
                    });
                }
                form.querySelectorAll('[data-upload-button]').forEach((button) => {
                    button.addEventListener('click', function () {
                        uploadForField(resource, button.getAttribute('data-upload-button') || '');
                    });
                });
                form.querySelectorAll('[data-media-pick-button]').forEach((button) => {
                    button.addEventListener('click', function () {
                        openMediaPicker(resource, button.getAttribute('data-media-pick-button') || '');
                    });
                });
            }

            function mediaUploadConfigForField(resource, fieldName) {
                return formFields(resource, state.view).find((item) => String(item.name || '') === fieldName) || {};
            }

            function mediaPickerKindForField(fieldName) {
                return /(image|thumbnail|avatar|photo|cover|hero|featured)/i.test(String(fieldName || '')) ? 'image' : '';
            }

            function mediaLocatorForAsset(asset, media) {
                if (media.target === 'asset_id') {
                    return String(asset.id || '');
                }
                return String(asset.public_url || asset.preview_url || asset.download_url || asset.asset_url || asset.file_url || '');
            }

            function mediaAssetLabel(asset, fallback) {
                return String(asset.original_name || asset.alt_text || asset.title || fallback || 'Media');
            }

            function applyMediaLocatorToControl(target, locator, previewUrl, asset = {}) {
                if (target instanceof HTMLSelectElement) {
                    let option = Array.from(target.options).find((item) => item.value === locator) || null;
                    if (!option) {
                        option = new Option(mediaAssetLabel(asset, locator), locator, true, true);
                        target.add(option);
                    }
                    option.selected = true;
                    target.value = locator;
                    target.setAttribute('data-relation-value', locator);
                    target.dispatchEvent(new Event('change', {bubbles: true}));
                    setImagePreviewForControl(target, previewUrl || locator);
                    return;
                }

                target.value = locator;
                setImagePreviewForControl(target, previewUrl || locator);
            }

            async function openMediaPicker(resource, fieldName) {
                const target = document.querySelector('[name="' + CSS.escape(fieldName) + '"]');
                if (!target) {
                    flash('The target media field could not be found.', 'error');
                    return;
                }
                const field = mediaUploadConfigForField(resource, fieldName);
                const media = field.media_upload || {};
                const backdrop = document.createElement('div');
                backdrop.className = 'media-picker-backdrop';
                const pickerId = 'mediaPickerSearch_' + Date.now();
                backdrop.innerHTML = '<section class="media-picker" role="dialog" aria-modal="true" aria-label="Pick existing media">' +
                    '<div class="media-picker-head"><h2>Pick existing media</h2><button class="button flat" type="button" data-media-picker-close>Close</button></div>' +
                    '<div class="media-picker-tools"><input id="' + pickerId + '" type="search" placeholder="Search media"><select data-media-picker-bucket><option value="">All visible</option><option value="mine">Mine</option><option value="public">Public</option><option value="shared">Shared</option><option value="private">Private</option></select><button class="button primary" type="button" data-media-picker-search>Search</button></div>' +
                    '<div class="media-picker-grid"><p class="muted">Loading media...</p></div>' +
                    '</section>';
                document.body.appendChild(backdrop);
                const grid = backdrop.querySelector('.media-picker-grid');
                const search = backdrop.querySelector('#' + CSS.escape(pickerId));
                const bucket = backdrop.querySelector('[data-media-picker-bucket]');

                const close = () => backdrop.remove();
                backdrop.querySelector('[data-media-picker-close]').addEventListener('click', close);
                backdrop.addEventListener('click', function (event) {
                    if (event.target === backdrop) {
                        close();
                    }
                });

                const load = async () => {
                    const params = new URLSearchParams();
                    params.set('limit', '60');
                    params.set('status', 'active');
                    const kind = mediaPickerKindForField(fieldName);
                    if (kind !== '') {
                        params.set('kind', kind);
                    }
                    if (search && String(search.value || '').trim() !== '') {
                        params.set('q', String(search.value || '').trim());
                    }
                    if (bucket && String(bucket.value || '') !== '') {
                        params.set('bucket', String(bucket.value || ''));
                    }
                    grid.innerHTML = '<p class="muted">Loading media...</p>';
                    const json = await apiFetch((media.picker_endpoint || '/api/v1/media') + '?' + params.toString());
                    const rows = Array.isArray(json.data) ? json.data : [];
                    if (rows.length === 0) {
                        grid.innerHTML = '<p class="muted">No media found for this scope.</p>';
                        return;
                    }
                    grid.innerHTML = rows.map((asset, index) => {
                        const preview = String(asset.preview_url || asset.public_url || asset.download_url || '');
                        const thumb = asset.is_image && isImageLikeUrl(preview)
                            ? '<img class="media-picker-thumb" src="' + escapeHtml(preview) + '" alt="">'
                            : '<div class="media-picker-file">' + escapeHtml(String(asset.asset_kind || 'file').toUpperCase()) + '</div>';
                        return '<button class="media-picker-item" type="button" data-media-picker-index="' + index + '">' + thumb +
                            '<span class="media-picker-name">' + escapeHtml(String(asset.original_name || asset.alt_text || asset.id || 'Media')) + '</span>' +
                            '<span class="media-picker-meta">' + escapeHtml(String(asset.visibility_label || asset.access_scope || '')) + '</span>' +
                            '<span class="media-picker-meta">' + escapeHtml(String(asset.share_summary || '')) + '</span></button>';
                    }).join('');
                    grid.querySelectorAll('[data-media-picker-index]').forEach((button) => {
                        button.addEventListener('click', function () {
                            const asset = rows[Number(button.getAttribute('data-media-picker-index') || 0)] || {};
                            const locator = mediaLocatorForAsset(asset, media);
                            if (locator === '') {
                                flash('The selected media has no usable locator.', 'error');
                                return;
                            }
                            applyMediaLocatorToControl(target, locator, asset.preview_url || locator, asset);
                            close();
                            flash('Media selected.');
                        });
                    });
                };

                backdrop.querySelector('[data-media-picker-search]').addEventListener('click', load);
                search.addEventListener('keydown', function (event) {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        load();
                    }
                });
                bucket.addEventListener('change', load);
                load().catch((error) => {
                    grid.innerHTML = '<p class="muted">' + escapeHtml(error.message) + '</p>';
                });
            }

            async function uploadForField(resource, fieldName) {
                const fileInput = document.querySelector('[data-upload-for="' + CSS.escape(fieldName) + '"]');
                const target = document.querySelector('[name="' + CSS.escape(fieldName) + '"]');
                if (!fileInput || !target || !fileInput.files || fileInput.files.length === 0) {
                    flash('Choose a file first.', 'error');
                    return;
                }
                const field = mediaUploadConfigForField(resource, fieldName);
                const media = field.media_upload || {};
                const formData = new FormData();
                formData.set('file', fileInput.files[0]);
                formData.set('access_scope', media.default_access_scope || 'public');
                try {
                    const json = await apiFetch(media.endpoint || '/api/v1/admin/media', {method: 'POST', body: formData});
                    const asset = json.data || json.asset || {};
                    const locator = media.target === 'asset_id'
                        ? String(asset.id || '')
                        : String(asset.url || asset.public_url || asset.download_url || asset.asset_url || asset.file_url || '');
                    if (locator === '') {
                        throw new Error('Upload succeeded but no usable locator was returned.');
                    }
                    applyMediaLocatorToControl(target, locator, asset.preview_url || locator, asset);
                    flash('File uploaded.');
                } catch (error) {
                    flash(error.message, 'error');
                }
            }

            function renderForgotPassword() {
                setLocked(true);
                setBreadcrumb([{label: 'Password reset'}]);
                app.innerHTML = '<h1>Password reset</h1><p class="muted">Enter your account email address. If it exists, a reset code will be emailed.</p>' +
                    '<section class="login-panel"><h2>Reset password</h2><form id="forgotPasswordForm">' +
                    '<label for="forgotEmail">Email address:</label><input id="forgotEmail" name="email" type="email" value="" autocomplete="username" required>' +
                    '<button class="button primary" type="submit">Send reset code</button><button class="button flat" type="button" id="showResetCodeForm">I have a code</button><button class="button flat" type="button" id="backToLogin">Back to login</button></form></section>';
                document.getElementById('showResetCodeForm').addEventListener('click', function () {
                    const form = document.getElementById('forgotPasswordForm');
                    const emailValue = form && form.elements.email ? String(form.elements.email.value || '').trim() : '';
                    history.pushState({view: 'resetPassword'}, '', adminBase.replace(/\/$/, '') + '/reset-password' + (emailValue ? '?email=' + encodeURIComponent(emailValue) : ''));
                    renderResetPassword();
                });
                document.getElementById('backToLogin').addEventListener('click', function () {
                    renderLogin('Log in to access Nite administration.', function () {
                        bootAdmin();
                    });
                });
                document.getElementById('forgotPasswordForm').addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const form = event.currentTarget;
                    try {
                        const emailValue = String(form.elements.email.value || '').trim();
                        await apiFetch('/api/v1/auth/password/forgot', {
                            method: 'POST',
                            body: JSON.stringify({email: emailValue})
                        });
                        history.pushState({view: 'resetPassword'}, '', adminBase.replace(/\/$/, '') + '/reset-password?email=' + encodeURIComponent(emailValue));
                        renderResetPassword();
                        flash('If that email is registered, enter the 6-digit reset code sent to that address.');
                    } catch (error) {
                        flash(error.message, 'error');
                    }
                });
            }

            function renderResetPassword() {
                setLocked(true);
                setBreadcrumb([{label: 'Reset password'}]);
                const params = new URLSearchParams(window.location.search || '');
                const email = params.get('email') || '';
                const codeValue = String(params.get('code') || params.get('token') || '').replace(/\D/g, '').slice(0, 6);
                app.innerHTML = '<h1>Reset password</h1><p class="muted">Set a new password using the reset code from your email.</p>' +
                    '<section class="login-panel"><h2>New password</h2><form id="resetPasswordForm">' +
                    '<label for="resetEmail">Email address:</label><input id="resetEmail" name="email" type="email" value="' + escapeHtml(email) + '" autocomplete="username" required>' +
                    '<label for="resetCode">6-digit reset code:</label><input id="resetCode" name="code" type="text" value="' + escapeHtml(codeValue) + '" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required>' +
                    '<label for="resetPassword">New password:</label><input id="resetPassword" name="password" type="password" value="" autocomplete="new-password" required>' +
                    '<label for="resetPasswordConfirmation">Confirm password:</label><input id="resetPasswordConfirmation" name="password_confirmation" type="password" value="" autocomplete="new-password" required>' +
                    '<button class="button primary" type="submit">Reset password</button><button class="button flat" type="button" id="resetBackToLogin">Back to login</button></form></section>';
                document.getElementById('resetBackToLogin').addEventListener('click', function () {
                    history.pushState({view: 'dashboard'}, '', adminBase);
                    renderLogin('Log in to access Nite administration.', function () {
                        bootAdmin();
                    });
                });
                document.getElementById('resetCode').addEventListener('input', function (event) {
                    event.currentTarget.value = String(event.currentTarget.value || '').replace(/\D/g, '').slice(0, 6);
                });
                document.getElementById('resetPasswordForm').addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const form = event.currentTarget;
                    try {
                        const json = await apiFetch('/api/v1/auth/password/reset', {
                            method: 'POST',
                            body: JSON.stringify({
                                email: form.elements.email.value,
                                code: form.elements.code.value,
                                password: form.elements.password.value,
                                password_confirmation: form.elements.password_confirmation.value
                            })
                        });
                        const data = json.data || {};
                        if (data.token) {
                            saveSession(data.user || {}, data.token);
                            updateAccountChrome();
                        }
                        history.pushState({view: 'dashboard'}, '', adminBase);
                        flash('Password reset.');
                        bootAdmin();
                    } catch (error) {
                        flash(error.message, 'error');
                    }
                });
            }

            function renderChangePassword(required = false) {
                setLocked(Boolean(required));
                setBreadcrumb([{label: 'Change password'}]);
                const help = required ? 'Your password must be changed before you can continue.' : 'Update your account password.';
                app.innerHTML = '<h1>Change password</h1><p class="muted">' + escapeHtml(help) + '</p>' +
                    '<section class="login-panel"><h2>Password</h2><form id="changePasswordForm">' +
                    '<label for="currentPassword">Current password:</label><input id="currentPassword" name="current_password" type="password" value="" autocomplete="current-password" required>' +
                    '<label for="newPassword">New password:</label><input id="newPassword" name="password" type="password" value="" autocomplete="new-password" required>' +
                    '<label for="newPasswordConfirmation">Confirm password:</label><input id="newPasswordConfirmation" name="password_confirmation" type="password" value="" autocomplete="new-password" required>' +
                    '<button class="button primary" type="submit">Save password</button>' +
                    (required ? '' : '<button class="button flat" type="button" id="cancelPasswordChange">Cancel</button>') +
                    '</form></section>';
                const cancel = document.getElementById('cancelPasswordChange');
                if (cancel) {
                    cancel.addEventListener('click', function () {
                        renderDashboard();
                    });
                }
                document.getElementById('changePasswordForm').addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const form = event.currentTarget;
                    try {
                        const json = await apiFetch('/api/v1/auth/password/change', {
                            method: 'POST',
                            body: JSON.stringify({
                                current_password: form.elements.current_password.value,
                                password: form.elements.password.value,
                                password_confirmation: form.elements.password_confirmation.value
                            })
                        });
                        const data = json.data || {};
                        if (data.token) {
                            saveSession(data.user || {}, data.token);
                            updateAccountChrome();
                        }
                        setLocked(false);
                        flash('Password changed.');
                        bootAdmin();
                    } catch (error) {
                        flash(error.message, 'error');
                    }
                });
            }

            async function renderPasswordPolicy() {
                state.view = 'passwordPolicy';
                state.resourceKey = 'password_policy';
                state.objectId = null;
                renderSidebar();
                setBreadcrumb([{label: 'Password Policy'}]);
                app.innerHTML = '<h1>Password policy</h1><p class="muted">Loading...</p>';
                try {
                    const json = await apiFetch('/api/v1/admin/security/password-policy');
                    const policy = json.data || {};
                    const checked = (name) => policy[name] ? ' checked' : '';
                    const value = (name, fallback) => escapeHtml(policy[name] === undefined || policy[name] === null ? fallback : policy[name]);
                    app.innerHTML = '<div class="page-top"><div><h1>Password policy</h1><p class="muted">Manage password complexity, expiry, reset code lifetime, and password reuse.</p></div></div>' +
                        '<form id="passwordPolicyForm" class="form-layout"><fieldset class="fieldset"><h2>Complexity</h2>' +
                        '<div class="form-row required"><label for="policyMinLength">Minimum length:</label><div class="field-control"><input id="policyMinLength" name="min_length" type="number" min="8" max="128" value="' + value('min_length', 12) + '" required></div></div>' +
                        '<div class="form-row"><label for="policyUppercase">Require uppercase:</label><div class="field-control"><input id="policyUppercase" name="require_uppercase" type="checkbox"' + checked('require_uppercase') + '></div></div>' +
                        '<div class="form-row"><label for="policyLowercase">Require lowercase:</label><div class="field-control"><input id="policyLowercase" name="require_lowercase" type="checkbox"' + checked('require_lowercase') + '></div></div>' +
                        '<div class="form-row"><label for="policyNumber">Require number:</label><div class="field-control"><input id="policyNumber" name="require_number" type="checkbox"' + checked('require_number') + '></div></div>' +
                        '<div class="form-row"><label for="policySymbol">Require symbol:</label><div class="field-control"><input id="policySymbol" name="require_symbol" type="checkbox"' + checked('require_symbol') + '></div></div>' +
                        '</fieldset><fieldset class="fieldset"><h2>Expiry and reset</h2>' +
                        '<div class="form-row"><label for="policyMaxAge">Max age days:</label><div class="field-control"><input id="policyMaxAge" name="password_max_age_days" type="number" min="0" max="3650" value="' + value('password_max_age_days', 90) + '"><div class="help">Use 0 to disable age-based forced password changes.</div></div></div>' +
                        '<div class="form-row"><label for="policyHistory">Previous passwords blocked:</label><div class="field-control"><input id="policyHistory" name="password_history_count" type="number" min="0" max="24" value="' + value('password_history_count', 5) + '"></div></div>' +
                        '<div class="form-row"><label for="policyResetTtl">Reset code minutes:</label><div class="field-control"><input id="policyResetTtl" name="reset_token_ttl_minutes" type="number" min="5" max="1440" value="' + value('reset_token_ttl_minutes', 60) + '"></div></div>' +
                        '<div class="form-row"><label for="policyAdminReset">Force after admin reset:</label><div class="field-control"><input id="policyAdminReset" name="force_change_on_admin_reset" type="checkbox"' + checked('force_change_on_admin_reset') + '></div></div>' +
                        '<div class="form-row"><label for="policyAdminCreated">Force for admin-created users:</label><div class="field-control"><input id="policyAdminCreated" name="force_change_on_admin_created_user" type="checkbox"' + checked('force_change_on_admin_created_user') + '></div></div>' +
                        '</fieldset><div class="submit-row"><button class="button primary" type="submit">Save policy</button></div></form>';
                    document.getElementById('passwordPolicyForm').addEventListener('submit', async function (event) {
                        event.preventDefault();
                        const form = event.currentTarget;
                        try {
                            const payload = {
                                min_length: parseInt(form.elements.min_length.value, 10),
                                require_uppercase: Boolean(form.elements.require_uppercase.checked),
                                require_lowercase: Boolean(form.elements.require_lowercase.checked),
                                require_number: Boolean(form.elements.require_number.checked),
                                require_symbol: Boolean(form.elements.require_symbol.checked),
                                password_max_age_days: parseInt(form.elements.password_max_age_days.value || '0', 10),
                                password_history_count: parseInt(form.elements.password_history_count.value || '0', 10),
                                reset_token_ttl_minutes: parseInt(form.elements.reset_token_ttl_minutes.value || '60', 10),
                                force_change_on_admin_reset: Boolean(form.elements.force_change_on_admin_reset.checked),
                                force_change_on_admin_created_user: Boolean(form.elements.force_change_on_admin_created_user.checked)
                            };
                            await apiFetch('/api/v1/admin/security/password-policy/default', {
                                method: 'PUT',
                                body: JSON.stringify(payload)
                            });
                            flash('Password policy saved.');
                        } catch (error) {
                            flash(error.message, 'error');
                        }
                    });
                } catch (error) {
                    app.innerHTML = '<h1>Password policy</h1><p class="muted">' + escapeHtml(error.message) + '</p>';
                }
            }

            function renderLogin(message, onSuccess) {
                setLocked(true);
                setBreadcrumb([{label: 'Log in'}]);
                app.innerHTML = '<h1>Log in</h1><p class="muted">' + escapeHtml(message || 'Sign in to continue.') + '</p>' +
                    '<section class="login-panel"><h2>Authentication</h2><form id="loginForm">' +
                    '<label for="loginEmail">Email address:</label><input id="loginEmail" name="email" type="email" value="admin@nite.local" autocomplete="username" required>' +
                    '<label for="loginPassword">Password:</label><input id="loginPassword" name="password" type="password" value="" autocomplete="current-password" required>' +
                    '<button class="button primary" type="submit">Log in</button><button class="button flat" type="button" id="forgotPasswordButton">Forgot password</button></form></section>';
                document.getElementById('forgotPasswordButton').addEventListener('click', function () {
                    renderForgotPassword();
                });
                document.getElementById('loginForm').addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const form = event.currentTarget;
                    try {
                        const json = await apiFetch('/api/v1/auth/login', {
                            method: 'POST',
                            body: JSON.stringify({
                                email: form.elements.email.value,
                                password: form.elements.password.value
                            })
                        });
                        const data = json.data || {};
                        if (!data.token) {
                            throw new Error('Sign-in succeeded but no token was returned.');
                        }
                        saveSession(data.user || {}, data.token);
                        updateAccountChrome();
                        flash('Logged in.');
                        onSuccess();
                    } catch (error) {
                        flash(error.message, 'error');
                    }
                });
            }

            function navigate(url, view, resourceKey = null, objectId = null) {
                history.pushState({view, resourceKey, objectId}, '', url);
                dispatch(view, resourceKey, objectId);
            }

            function contextFromPath() {
                const path = window.location.pathname.replace(/\/+$/, '') || adminBase;
                if (path === adminBase) {
                    return {view: 'dashboard'};
                }
                const selection = path.startsWith(adminBase + '/') ? path.slice(adminBase.length + 1) : '';
                const parts = selection.split('/').filter(Boolean);
                const first = parts[0] || '';
                if (first === 'reset-password') {
                    return {view: 'resetPassword'};
                }
                if (first === 'change-password') {
                    return {view: 'changePassword'};
                }
                if (['password-policy', 'password_policy', 'security'].includes(first)) {
                    return {view: 'passwordPolicy', resourceKey: 'password_policy'};
                }
                if (['rbac-matrix', 'rbac_matrix', 'permission-matrix'].includes(first)) {
                    return {view: 'rbacMatrix', resourceKey: 'rbac_matrix'};
                }
                if ((first === 'users' || first === 'admin-users') && parts[1] && parts[2] === 'permissions') {
                    return {view: 'userPermissions', resourceKey: 'users', objectId: decodeURIComponent(parts[1])};
                }
                if ((first === 'rbac-groups' || first === 'rbac_groups' || first === 'groups') && parts[1] && parts[2] === 'members') {
                    return {view: 'groupMembers', resourceKey: 'rbac_groups', objectId: decodeURIComponent(parts[1])};
                }
                if ((first === 'rbac-groups' || first === 'rbac_groups' || first === 'groups') && parts[1] && parts[2] === 'permissions') {
                    return {view: 'groupPermissions', resourceKey: 'rbac_groups', objectId: decodeURIComponent(parts[1])};
                }
                const resource = resources.find((item) => {
                    const key = String(item.key || '');
                    const surface = String(item.admin_surface_path || '').replace(/^\/admin\/?/, '').split('/')[0] || '';
                    return key.replace(/_/g, '-') === first || key === first.replace(/-/g, '_') || surface === first;
                });
                if (!resource) {
                    return {view: 'dashboard'};
                }
                if (parts[1] === 'add') {
                    return {view: 'add', resourceKey: String(resource.key || '')};
                }
                if (parts[1] && parts[2] === 'change') {
                    return {view: 'change', resourceKey: String(resource.key || ''), objectId: decodeURIComponent(parts[1])};
                }
                if (parts[1] && parts[2] === 'history') {
                    return {view: 'history', resourceKey: String(resource.key || ''), objectId: decodeURIComponent(parts[1])};
                }
                return {view: 'list', resourceKey: String(resource.key || '')};
            }

            function dispatch(view, resourceKey, objectId) {
                messages.innerHTML = '';
                if (view === 'resetPassword') {
                    renderResetPassword();
                    return;
                }
                if (!hasAdminSession()) {
                    renderLogin('Log in to access Nite administration.', function () {
                        bootAdmin();
                    });
                    return;
                }
                if (view === 'dashboard') {
                    renderDashboard();
                    return;
                }
                if (view === 'changePassword') {
                    renderChangePassword();
                    return;
                }
                if (view === 'passwordPolicy') {
                    if (!canUsePermission('admin.security.manage')) {
                        renderDashboard();
                        flash('You do not have permission to access the password policy.', 'error');
                        return;
                    }
                    renderPasswordPolicy();
                    return;
                }
                if (view === 'rbacMatrix') {
                    if (!canUsePermission('admin.rbac.view')) {
                        renderDashboard();
                        flash('You do not have permission to access the permission matrix.', 'error');
                        return;
                    }
                    renderRbacMatrix();
                    return;
                }
                if (view === 'userPermissions') {
                    if (!canUsePermission('admin.rbac.view')) {
                        renderDashboard();
                        flash('You do not have permission to access user permissions.', 'error');
                        return;
                    }
                    renderUserPermissions(objectId);
                    return;
                }
                if (view === 'groupMembers') {
                    if (!canUsePermission('admin.rbac.view')) {
                        renderDashboard();
                        flash('You do not have permission to access group members.', 'error');
                        return;
                    }
                    renderGroupMembers(objectId);
                    return;
                }
                if (view === 'groupPermissions') {
                    if (!canUsePermission('admin.rbac.view')) {
                        renderDashboard();
                        flash('You do not have permission to access group permissions.', 'error');
                        return;
                    }
                    renderGroupPermissions(objectId);
                    return;
                }
                const resource = byKey.get(String(resourceKey || ''));
                if (!resource) {
                    renderDashboard();
                    return;
                }
                if (!resourceAllowed(resource)) {
                    renderDashboard();
                    flash('You do not have permission to access that admin section.', 'error');
                    return;
                }
                const nextResourceKey = String(resource.key || '');
                if (state.resourceKey !== nextResourceKey || view === 'list') {
                    state.filters = {};
                    state.search = '';
                    state.page = 1;
                    state.ordering = '';
                    state.object = null;
                    state.rows = [];
                    state.selected.clear();
                }
                if (view === 'add') {
                    renderForm(resource, 'add');
                } else if (view === 'change') {
                    renderForm(resource, 'change', objectId);
                } else if (view === 'history') {
                    renderObjectHistory(resource, objectId);
                } else {
                    renderList(resource);
                }
            }

            document.addEventListener('click', function (event) {
                const link = event.target.closest('[data-admin-link]');
                if (!link) {
                    return;
                }
                event.preventDefault();
                const view = link.getAttribute('data-view') || 'list';
                const resourceKey = link.getAttribute('data-resource');
                const objectId = link.getAttribute('data-object-id');
                if (link.closest('.sidebar') && isMobileLayout()) {
                    setSidebarCollapsed(true);
                }
                navigate(link.getAttribute('href') || adminBase, view, resourceKey, objectId);
            });

            window.addEventListener('popstate', function () {
                const context = contextFromPath();
                dispatch(context.view, context.resourceKey, context.objectId);
            });

            modelFilter.addEventListener('input', function () {
                renderSidebar();
                if (state.view === 'dashboard') {
                    renderDashboard();
                }
            });

            sidebarToggle.addEventListener('click', function () {
                setSidebarCollapsed(!document.body.classList.contains('sidebar-collapsed'));
            });

            window.addEventListener('resize', syncSidebarChrome);

            themeSelect.value = localStorage.getItem(themeKey) || 'classic';
            document.body.setAttribute('data-theme', themeSelect.value);
            themeSelect.addEventListener('change', function () {
                document.body.setAttribute('data-theme', themeSelect.value);
                localStorage.setItem(themeKey, themeSelect.value);
            });

            logoutButton.addEventListener('click', function () {
                clearSession();
                updateAccountChrome();
                state.intendedContext = {view: 'dashboard'};
                renderLogin('Log in to access Nite administration.', function () {
                    bootAdmin();
                });
            });

            document.getElementById('changePasswordButton').addEventListener('click', function () {
                history.pushState({view: 'changePassword'}, '', adminBase + '/change-password');
                renderChangePassword();
            });

            updateAccountChrome();
            bootAdmin();
        })();
    </script>
</body>
</html>
HTML;
    }

    /**
     * @param array<int, array<string, mixed>> $routes
     * @return array<int, array<string, mixed>>
     */
    private static function adminResources(array $routes): array
    {
        $resources = array_values(ApiExplorerCatalog::resources());
        $routeByPath = [];
        foreach ($routes as $route) {
            if (!is_array($route)) {
                continue;
            }
            $routeByPath[strtoupper((string)($route['method'] ?? 'GET')) . ' ' . (string)($route['path'] ?? '')] = $route;
        }

        foreach ([
            [
                'key' => 'rbac_permissions',
                'label' => 'Permissions',
                'item_type' => 'Permission',
                'summary' => 'Permission definitions used by RBAC and generated resources.',
                'path' => '/api/v1/admin/rbac/permissions',
                'fields' => [
                    self::adminField('code', 'string', 'Code'),
                    self::adminField('title', 'string', 'Title'),
                    self::adminField('module_title', 'string', 'Module'),
                    self::adminField('action_title', 'string', 'Action'),
                    self::adminField('access_kind_label', 'string', 'Access kind'),
                ],
            ],
            [
                'key' => 'rbac_groups',
                'label' => 'Groups',
                'item_type' => 'Group',
                'summary' => 'Permission groups with members and group-level rules.',
                'path' => '/api/v1/admin/rbac/groups',
                'route_paths' => [
                    'GET /api/v1/admin/rbac/groups',
                    'POST /api/v1/admin/rbac/groups',
                    'GET /api/v1/admin/rbac/groups/{id}',
                    'PUT /api/v1/admin/rbac/groups/{id}',
                    'DELETE /api/v1/admin/rbac/groups/{id}',
                    'GET /api/v1/admin/rbac/groups/{id}/members',
                    'PUT /api/v1/admin/rbac/groups/{id}/members',
                    'GET /api/v1/admin/rbac/groups/{id}/permissions',
                    'PUT /api/v1/admin/rbac/groups/{id}/permissions',
                ],
                'fields' => [
                    self::adminField('name', 'string', 'Group name.', false),
                    self::adminField('code', 'string', 'Stable group code.', false),
                    self::adminField('description', 'string', 'Internal description.', false),
                    self::adminField('is_active', 'boolean', 'Inactive groups do not affect permissions.', false),
                    self::adminField('created_at', 'string', 'Created at.'),
                ],
                'create_fields' => [
                    self::adminField('name', 'string', 'Group name.', false, true),
                    self::adminField('code', 'string', 'Stable group code. Generated from name when omitted.', false),
                    self::adminField('description', 'string', 'Internal description.', false),
                    self::adminField('is_active', 'boolean', 'Inactive groups do not affect permissions.', false),
                ],
                'update_fields' => [
                    self::adminField('name', 'string', 'Group name.', false),
                    self::adminField('code', 'string', 'Stable group code.', false),
                    self::adminField('description', 'string', 'Internal description.', false),
                    self::adminField('is_active', 'boolean', 'Inactive groups do not affect permissions.', false),
                ],
                'query_options' => [
                    self::adminField('q', 'string', 'Search groups.', false),
                    self::adminField('is_active', 'boolean', 'Filter active groups.', false, false, ['true', 'false']),
                    self::adminField('limit', 'integer', 'Maximum rows to return.', false),
                    self::adminField('offset', 'integer', 'Rows to skip.', false),
                ],
            ],
            [
                'key' => 'rbac_matrix',
                'label' => 'Group Permission Matrix',
                'item_type' => 'Permission Rule',
                'summary' => 'Group permission states for who can see each module and who can do each action.',
                'path' => '/api/v1/admin/rbac/matrix',
                'fields' => [
                    self::adminField('code', 'string', 'Code'),
                    self::adminField('title', 'string', 'Title'),
                    self::adminField('access_kind_label', 'string', 'Access kind'),
                    self::adminField('action_title', 'string', 'Action'),
                ],
            ],
            [
                'key' => 'password_policy',
                'label' => 'Password Policy',
                'item_type' => 'Password Policy',
                'summary' => 'Password complexity, reset-code expiry, and reuse controls.',
                'path' => '/api/v1/admin/security/password-policy',
                'route_paths' => [
                    'GET /api/v1/admin/security/password-policy',
                    'PUT /api/v1/admin/security/password-policy/{id}',
                ],
                'fields' => [
                    self::adminField('min_length', 'integer', 'Minimum password length.'),
                    self::adminField('password_max_age_days', 'integer', 'Days before password change is forced.'),
                    self::adminField('password_history_count', 'integer', 'Previous passwords blocked from reuse.'),
                    self::adminField('reset_token_ttl_minutes', 'integer', 'Reset code lifetime in minutes.'),
                ],
                'update_fields' => [
                    self::adminField('min_length', 'integer', 'Minimum password length.', false),
                    self::adminField('require_uppercase', 'boolean', 'Require uppercase letters.', false),
                    self::adminField('require_lowercase', 'boolean', 'Require lowercase letters.', false),
                    self::adminField('require_number', 'boolean', 'Require numbers.', false),
                    self::adminField('require_symbol', 'boolean', 'Require symbols.', false),
                    self::adminField('password_max_age_days', 'integer', 'Days before password change is forced.', false),
                    self::adminField('password_history_count', 'integer', 'Previous passwords blocked from reuse.', false),
                    self::adminField('reset_token_ttl_minutes', 'integer', 'Reset code lifetime in minutes.', false),
                    self::adminField('force_change_on_admin_reset', 'boolean', 'Force change after admin-set password.', false),
                    self::adminField('force_change_on_admin_created_user', 'boolean', 'Force change for admin-created user.', false),
                ],
            ],
        ] as $resource) {
            $routeKeys = array_values($resource['route_paths'] ?? ['GET ' . $resource['path']]);
            $resourceRoutes = array_values(array_filter(array_map(
                static fn (string $key): ?array => $routeByPath[$key] ?? null,
                $routeKeys
            )));
            if ($resourceRoutes === []) {
                continue;
            }
            $resources[] = [
                'key' => $resource['key'],
                'label' => $resource['label'],
                'group' => 'users & permissions',
                'item_type' => $resource['item_type'],
                'table' => '',
                'summary' => $resource['summary'],
                'default_data_path' => $resource['path'],
                'default_data_auth_required' => true,
                'admin_surface_path' => '/admin/' . str_replace('_', '-', $resource['key']),
                'fields' => $resource['fields'],
                'create_fields' => $resource['create_fields'] ?? [],
                'update_fields' => $resource['update_fields'] ?? [],
                'query_options' => $resource['query_options'] ?? [],
                'routes' => $resourceRoutes,
            ];
        }

        return $resources;
    }

    /**
     * @return array<string, mixed>
     */
    private static function adminField(string $name, string $type, string $description, bool $readOnly = true, bool $required = false, array $options = []): array
    {
        return [
            'name' => $name,
            'data_type' => $type,
            'format' => null,
            'nullable' => true,
            'required_on_create' => $required,
            'required_on_update' => false,
            'read_only' => $readOnly,
            'write_only' => false,
            'options' => $options,
            'description' => $description,
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private static function adminContext(?string $selection): array
    {
        $normalized = trim(str_replace('\\', '/', (string)$selection), '/');
        if ($normalized === '') {
            return ['view' => 'dashboard', 'resource_key' => null, 'object_id' => null];
        }

        $parts = array_values(array_filter(explode('/', $normalized), static fn (string $part): bool => $part !== ''));
        if (in_array(strtolower((string)($parts[0] ?? '')), ['reset-password'], true)) {
            return ['view' => 'resetPassword', 'resource_key' => null, 'object_id' => null];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['change-password'], true)) {
            return ['view' => 'changePassword', 'resource_key' => null, 'object_id' => null];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['password-policy', 'password_policy', 'security'], true)) {
            return ['view' => 'passwordPolicy', 'resource_key' => 'password_policy', 'object_id' => null];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['rbac-matrix', 'rbac_matrix', 'permission-matrix'], true)) {
            return ['view' => 'rbacMatrix', 'resource_key' => 'rbac_matrix', 'object_id' => null];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['users', 'admin-users'], true) && isset($parts[1]) && ($parts[2] ?? '') === 'permissions') {
            return ['view' => 'userPermissions', 'resource_key' => 'users', 'object_id' => rawurldecode($parts[1])];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['rbac-groups', 'rbac_groups', 'groups'], true) && isset($parts[1]) && ($parts[2] ?? '') === 'members') {
            return ['view' => 'groupMembers', 'resource_key' => 'rbac_groups', 'object_id' => rawurldecode($parts[1])];
        }
        if (in_array(strtolower((string)($parts[0] ?? '')), ['rbac-groups', 'rbac_groups', 'groups'], true) && isset($parts[1]) && ($parts[2] ?? '') === 'permissions') {
            return ['view' => 'groupPermissions', 'resource_key' => 'rbac_groups', 'object_id' => rawurldecode($parts[1])];
        }
        $resourceKey = ApiExplorerCatalog::resourceKeyForAdminSelection($parts[0] ?? '');
        if ($resourceKey === null) {
            $utilityKeys = [
                'rbac-groups' => 'rbac_groups',
                'rbac_groups' => 'rbac_groups',
                'groups' => 'rbac_groups',
                'rbac-permissions' => 'rbac_permissions',
                'rbac_permissions' => 'rbac_permissions',
                'permissions' => 'rbac_permissions',
                'rbac-matrix' => 'rbac_matrix',
                'rbac_matrix' => 'rbac_matrix',
                'permission-matrix' => 'rbac_matrix',
                'password-policy' => 'password_policy',
                'password_policy' => 'password_policy',
                'security' => 'password_policy',
            ];
            $resourceKey = $utilityKeys[strtolower((string)($parts[0] ?? ''))] ?? null;
        }
        if ($resourceKey === null) {
            return ['view' => 'dashboard', 'resource_key' => null, 'object_id' => null];
        }

        if (($parts[1] ?? '') === 'add') {
            return ['view' => 'add', 'resource_key' => $resourceKey, 'object_id' => null];
        }

        if (isset($parts[1]) && ($parts[2] ?? '') === 'change') {
            return ['view' => 'change', 'resource_key' => $resourceKey, 'object_id' => rawurldecode($parts[1])];
        }

        if (isset($parts[1]) && ($parts[2] ?? '') === 'history') {
            return ['view' => 'history', 'resource_key' => $resourceKey, 'object_id' => rawurldecode($parts[1])];
        }

        return ['view' => 'list', 'resource_key' => $resourceKey, 'object_id' => null];
    }
}
