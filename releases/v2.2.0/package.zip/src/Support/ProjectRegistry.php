<?php
namespace App\Support;

use App\Config\Env;
use App\Console\ConsoleSupport;
use RuntimeException;

final class ProjectRegistry
{
    private const DEFAULT_HOST = '127.0.0.1';
    private const DEFAULT_PORT = 8185;
    private const DEFAULT_POSTGRES_HOST_PORT = 55440;
    private const STARTING_PROJECT_PORT = 8285;
    private const STARTING_PROJECT_POSTGRES_HOST_PORT = 55441;

    public function __construct(private readonly string $rootPath)
    {
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function all(): array
    {
        $projects = [];
        if (!is_dir($this->projectsRoot())) {
            return $projects;
        }

        $directories = glob($this->projectsRoot() . '/*', GLOB_ONLYDIR) ?: [];
        foreach ($directories as $directory) {
            $project = $this->readProjectDirectory($directory);
            if ($project !== null) {
                $projects[] = $project;
            }
        }

        usort($projects, static function (array $left, array $right): int {
            return [(string)$left['slug'], (string)$left['name']] <=> [(string)$right['slug'], (string)$right['name']];
        });

        return $projects;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function find(string $slug): ?array
    {
        $normalized = $this->normalizeSlug($slug);
        if ($normalized === '') {
            return null;
        }

        return $this->readProjectDirectory($this->projectDirectory($normalized));
    }

    /**
     * @return array<string, mixed>
     */
    public function require(string $slug): array
    {
        $project = $this->find($slug);
        if ($project === null) {
            throw new RuntimeException('Project not found: ' . $slug);
        }

        $this->writeProjectRuntimeFiles($project);
        return $project;
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function create(string $name, array $options = []): array
    {
        $displayName = trim($name);
        $slug = $this->normalizeSlug((string)($options['slug'] ?? $displayName));
        if ($slug === '') {
            throw new RuntimeException('Project name or --slug must resolve to a valid project identifier.');
        }

        if ($this->find($slug) !== null) {
            throw new RuntimeException('Project already exists: ' . $slug);
        }

        $host = trim((string)($options['host'] ?? self::DEFAULT_HOST));
        $host = $host !== '' ? $host : self::DEFAULT_HOST;
        $port = isset($options['port']) ? (int)$options['port'] : $this->suggestPort();
        $this->assertValidPort($port);
        $this->assertPortAvailable($slug, $port);

        $appUrl = trim((string)($options['app-url'] ?? ('http://' . $host . ':' . $port)));
        $dbName = trim((string)($options['db-name'] ?? ('nite_' . str_replace('-', '_', $slug))));
        $mediaRoot = trim((string)($options['media-root'] ?? ('storage/projects/' . $slug . '/media')));
        $postgresHostPort = isset($options['db-port']) ? (int)$options['db-port'] : $this->suggestPostgresHostPort();
        $this->assertValidPort($postgresHostPort);
        $this->assertPostgresHostPortAvailable($slug, $postgresHostPort);
        $displayName = $displayName !== '' ? $displayName : $this->humanizeSlug($slug);

        $payload = [
            'slug' => $slug,
            'name' => $displayName,
            'host' => $host,
            'port' => $port,
            'app_url' => $appUrl,
            'created_at' => gmdate('c'),
            'env' => [
                'NITE_PROJECT' => $slug,
                'NITE_PROJECT_NAME' => $displayName,
                'APP_URL' => $appUrl,
                'DB_NAME' => $dbName,
                'MEDIA_STORAGE_ROOT' => $mediaRoot,
            ],
            'docker' => [
                'app_port' => $port,
                'postgres_host_port' => $postgresHostPort,
            ],
        ];

        $directory = $this->projectDirectory($slug);
        ConsoleSupport::ensureDirectory($directory);
        ConsoleSupport::ensureDirectory($this->rootPath . '/' . ltrim($mediaRoot, '/'));
        $encoded = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode project manifest for ' . $slug . '.');
        }

        if (file_put_contents($directory . '/project.json', $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write project manifest for ' . $slug . '.');
        }

        $project = $this->require($slug);
        $this->writeProjectRuntimeFiles($project);
        return $this->require($slug);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function bootstrapActiveFromEnvironment(): ?array
    {
        $slug = trim((string)Env::get('NITE_PROJECT', ''));
        if ($slug === '') {
            return null;
        }

        return $this->apply($slug);
    }

    /**
     * @return array<string, mixed>
     */
    public function apply(string $slug): array
    {
        $project = $this->require($slug);
        Env::apply($project['env'] ?? [], true);

        $overridePaths = $this->projectOverridePaths($project);
        if ($overridePaths !== []) {
            Env::loadOverrides($overridePaths);
        }

        return $this->require($slug);
    }

    private function projectsRoot(): string
    {
        return $this->rootPath . '/projects';
    }

    private function projectDirectory(string $slug): string
    {
        return $this->projectsRoot() . '/' . $slug;
    }

    private function normalizeSlug(string $value): string
    {
        return ConsoleSupport::kebab($value);
    }

    private function humanizeSlug(string $slug): string
    {
        return implode(' ', array_map(
            static fn (string $part): string => ucfirst(strtolower($part)),
            array_values(array_filter(explode('-', $slug), static fn (string $part): bool => $part !== ''))
        ));
    }

    /**
     * @return array<string, mixed>|null
     */
    private function readProjectDirectory(string $directory): ?array
    {
        $manifest = $directory . '/project.json';
        if (!is_file($manifest)) {
            return null;
        }

        $decoded = json_decode((string)file_get_contents($manifest), true);
        if (!is_array($decoded)) {
            throw new RuntimeException('Invalid project manifest: ' . $manifest);
        }

        return $this->normalizeProject($decoded, $directory);
    }

    /**
     * @param array<string, mixed> $project
     * @return array<string, mixed>
     */
    private function normalizeProject(array $project, string $directory): array
    {
        $slug = $this->normalizeSlug((string)($project['slug'] ?? basename($directory)));
        if ($slug === '') {
            throw new RuntimeException('Project manifest is missing a valid slug: ' . $directory . '/project.json');
        }

        $name = trim((string)($project['name'] ?? ''));
        $name = $name !== '' ? $name : $this->humanizeSlug($slug);
        $host = trim((string)($project['host'] ?? self::DEFAULT_HOST));
        $host = $host !== '' ? $host : self::DEFAULT_HOST;
        $port = (int)($project['port'] ?? self::DEFAULT_PORT);
        $this->assertValidPort($port);
        $appUrl = trim((string)($project['app_url'] ?? ('http://' . $host . ':' . $port)));
        $env = [];
        if (is_array($project['env'] ?? null)) {
            foreach ($project['env'] as $key => $value) {
                $envKey = trim((string)$key);
                if ($envKey === '') {
                    continue;
                }
                $env[$envKey] = is_scalar($value) ? (string)$value : json_encode($value, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            }
        }

        $env['NITE_PROJECT'] = $slug;
        $env['NITE_PROJECT_NAME'] = $name;
        $env['APP_URL'] = trim((string)($env['APP_URL'] ?? $appUrl));
        if ($env['APP_URL'] === '') {
            $env['APP_URL'] = $appUrl;
        }
        if (!isset($env['MEDIA_STORAGE_ROOT']) || trim((string)$env['MEDIA_STORAGE_ROOT']) === '') {
            $env['MEDIA_STORAGE_ROOT'] = 'storage/projects/' . $slug . '/media';
        }
        if (!isset($env['DB_NAME']) || trim((string)$env['DB_NAME']) === '') {
            $env['DB_NAME'] = 'nite_' . str_replace('-', '_', $slug);
        }

        $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
        $dockerAppPort = (int)($docker['app_port'] ?? $port);
        if ($dockerAppPort < 1 || $dockerAppPort > 65535) {
            $dockerAppPort = $port;
        }
        $dockerPostgresHostPort = (int)($docker['postgres_host_port'] ?? 0);
        if ($dockerPostgresHostPort < 1 || $dockerPostgresHostPort > 65535) {
            $dockerPostgresHostPort = self::STARTING_PROJECT_POSTGRES_HOST_PORT;
        }

        return [
            'slug' => $slug,
            'name' => $name,
            'host' => $host,
            'port' => $port,
            'app_url' => $appUrl,
            'env' => $env,
            'docker' => [
                'app_port' => $dockerAppPort,
                'postgres_host_port' => $dockerPostgresHostPort,
            ],
            'paths' => [
                'directory' => $directory,
                'manifest' => $directory . '/project.json',
                'env' => $directory . '/.env',
                'env_example' => $directory . '/.env.example',
                'docker_env' => $directory . '/.env.docker',
                'docker_env_example' => $directory . '/.env.docker.example',
                'dockerfile' => $directory . '/Dockerfile',
                'compose' => $directory . '/docker-compose.yml',
            ],
            'created_at' => trim((string)($project['created_at'] ?? '')),
        ];
    }

    private function suggestPort(): int
    {
        $ports = array_map(
            static fn (array $project): int => (int)($project['port'] ?? 0),
            $this->all()
        );
        $ports[] = self::DEFAULT_PORT;
        $candidate = max(self::STARTING_PROJECT_PORT, max($ports) + 1);

        while (in_array($candidate, $ports, true)) {
            $candidate += 1;
        }

        return $candidate;
    }

    private function suggestPostgresHostPort(): int
    {
        $ports = [self::DEFAULT_POSTGRES_HOST_PORT];
        foreach ($this->all() as $project) {
            $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
            $assigned = (int)($docker['postgres_host_port'] ?? 0);
            if ($assigned > 0) {
                $ports[] = $assigned;
            }
        }

        $candidate = max(self::STARTING_PROJECT_POSTGRES_HOST_PORT, max($ports) + 1);
        while (in_array($candidate, $ports, true)) {
            $candidate += 1;
        }

        return $candidate;
    }

    private function assertValidPort(int $port): void
    {
        if ($port < 1 || $port > 65535) {
            throw new RuntimeException('Port must be between 1 and 65535.');
        }
    }

    private function assertPortAvailable(string $slug, int $port): void
    {
        foreach ($this->all() as $project) {
            if ((string)($project['slug'] ?? '') === $slug) {
                continue;
            }
            if ((int)($project['port'] ?? 0) === $port) {
                throw new RuntimeException('Port ' . $port . ' is already assigned to project ' . (string)($project['slug'] ?? '') . '.');
            }
        }
    }

    private function assertPostgresHostPortAvailable(string $slug, int $port): void
    {
        if ($port === self::DEFAULT_POSTGRES_HOST_PORT) {
            throw new RuntimeException('PostgreSQL host port ' . $port . ' is reserved for the root single-project docker setup.');
        }

        foreach ($this->all() as $project) {
            if ((string)($project['slug'] ?? '') === $slug) {
                continue;
            }

            $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
            if ((int)($docker['postgres_host_port'] ?? 0) === $port) {
                throw new RuntimeException('PostgreSQL host port ' . $port . ' is already assigned to project ' . (string)($project['slug'] ?? '') . '.');
            }
        }
    }

    /**
     * @param array<string, mixed> $project
     * @return array<int, string>
     */
    private function projectOverridePaths(array $project): array
    {
        $explicit = trim((string)Env::get('NITE_PROJECT_ENV_FILE', ''));
        if ($explicit !== '') {
            $resolved = $this->resolveProjectOverridePath($explicit);
            return $resolved !== '' ? [$resolved] : [];
        }

        $dockerRuntime = Env::bool('NITE_DOCKER_RUNTIME', false);
        if ($dockerRuntime) {
            $dockerEnv = (string)($project['paths']['docker_env'] ?? '');
            if ($dockerEnv !== '' && is_file($dockerEnv)) {
                return [$dockerEnv];
            }
        }

        $projectEnv = (string)($project['paths']['env'] ?? '');
        return $projectEnv !== '' && is_file($projectEnv) ? [$projectEnv] : [];
    }

    private function resolveProjectOverridePath(string $path): string
    {
        $normalized = trim($path);
        if ($normalized === '') {
            return '';
        }

        if (preg_match('/^(?:[a-zA-Z]:[\\\\/]|\\\\\\\\|\\/)/', $normalized) === 1) {
            return is_file($normalized) ? $normalized : '';
        }

        $candidate = $this->rootPath . '/' . ltrim(str_replace('\\', '/', $normalized), '/');
        return is_file($candidate) ? $candidate : '';
    }

    /**
     * @param array<string, mixed> $project
     */
    private function writeProjectRuntimeFiles(array $project): void
    {
        $paths = is_array($project['paths'] ?? null) ? $project['paths'] : [];
        $directory = (string)($paths['directory'] ?? '');
        if ($directory === '') {
            return;
        }

        ConsoleSupport::ensureDirectory($directory);

        $hostEnvExamplePath = (string)($paths['env_example'] ?? '');
        $hostEnvPath = (string)($paths['env'] ?? '');
        $dockerEnvExamplePath = (string)($paths['docker_env_example'] ?? '');
        $dockerEnvPath = (string)($paths['docker_env'] ?? '');
        $dockerfilePath = (string)($paths['dockerfile'] ?? '');
        $composePath = (string)($paths['compose'] ?? '');

        if ($hostEnvExamplePath !== '' && !is_file($hostEnvExamplePath)) {
            file_put_contents($hostEnvExamplePath, $this->renderProjectHostEnv($project, true));
        }
        if ($hostEnvPath !== '' && !is_file($hostEnvPath)) {
            file_put_contents($hostEnvPath, $this->renderProjectHostEnv($project, false));
        }

        if ($dockerEnvExamplePath !== '' && !is_file($dockerEnvExamplePath)) {
            file_put_contents($dockerEnvExamplePath, $this->renderProjectDockerEnv($project, true));
        }
        if ($dockerEnvPath !== '' && !is_file($dockerEnvPath)) {
            file_put_contents($dockerEnvPath, $this->renderProjectDockerEnv($project, false));
        }

        if ($dockerfilePath !== '' && !is_file($dockerfilePath)) {
            file_put_contents($dockerfilePath, $this->renderProjectDockerfile($project));
        }
        if ($composePath !== '' && !is_file($composePath)) {
            file_put_contents($composePath, $this->renderProjectDockerCompose($project));
        }
    }

    /**
     * @param array<string, mixed> $project
     */
    private function renderProjectHostEnv(array $project, bool $example): string
    {
        $slug = (string)($project['slug'] ?? '');
        $name = (string)($project['name'] ?? $slug);
        $appUrl = (string)($project['app_url'] ?? ('http://127.0.0.1:' . (string)($project['port'] ?? self::DEFAULT_PORT)));
        $env = is_array($project['env'] ?? null) ? $project['env'] : [];
        $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
        $dbName = (string)($env['DB_NAME'] ?? ('nite_' . str_replace('-', '_', $slug)));
        $mediaRoot = (string)($env['MEDIA_STORAGE_ROOT'] ?? ('storage/projects/' . $slug . '/media'));
        $postgresHostPort = (int)($docker['postgres_host_port'] ?? self::STARTING_PROJECT_POSTGRES_HOST_PORT);

        $lines = [
            '# Project-specific host overrides for the shared root .env file.',
            '# Loaded automatically when you run `php nite ... --project=' . $slug . '`.',
            'NITE_PROJECT=' . $slug,
            'NITE_PROJECT_NAME=' . $name,
            'APP_URL=' . $appUrl,
            'DB_HOST=127.0.0.1',
            'DB_PORT=' . $postgresHostPort,
            'DB_NAME=' . $dbName,
            'DB_USER=postgres',
            'DB_PASSWORD=postgres',
            'NITE_SEED_DEFAULT_PASSWORD=Passw0rd!2026',
            'MEDIA_STORAGE_ROOT=' . $mediaRoot,
            'MEDIA_UPLOAD_MAX_BYTES=10485760',
            'MEDIA_UPLOAD_ALLOWED_MIME_TYPES=image/*,application/pdf,text/plain,text/csv',
            'MEDIA_UPLOAD_ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,webp,svg,pdf,txt,csv',
            'MAIL_ENABLED=false',
            'MAIL_TRANSPORT=smtp',
            'MAIL_HOST=127.0.0.1',
            'MAIL_PORT=1025',
            'MAIL_ENCRYPTION=',
            'MAIL_FROM_ADDRESS=no-reply@' . $slug . '.local',
            'MAIL_FROM_NAME=' . $name,
            'MAIL_QUEUE_MODE=database',
            'MAIL_QUEUE_BATCH_SIZE=25',
            'MAIL_QUEUE_SLEEP_SECONDS=3',
            'AUTH_PASSWORD_MIN_LENGTH=12',
            'AUTH_LOGIN_THROTTLE_ENABLED=true',
        ];

        if ($example) {
            array_splice($lines, 2, 0, '# Copy this file to .env and replace any local secrets you need.');
        }

        return implode(PHP_EOL, $lines) . PHP_EOL;
    }

    /**
     * @param array<string, mixed> $project
     */
    private function renderProjectDockerEnv(array $project, bool $example): string
    {
        $slug = (string)($project['slug'] ?? '');
        $name = (string)($project['name'] ?? $slug);
        $appPort = (int)($project['port'] ?? self::DEFAULT_PORT);
        $appUrl = 'http://127.0.0.1:' . $appPort;
        $env = is_array($project['env'] ?? null) ? $project['env'] : [];
        $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
        $dbName = (string)($env['DB_NAME'] ?? ('nite_' . str_replace('-', '_', $slug)));
        $mediaRoot = (string)($env['MEDIA_STORAGE_ROOT'] ?? ('storage/projects/' . $slug . '/media'));
        $postgresHostPort = (int)($docker['postgres_host_port'] ?? self::STARTING_PROJECT_POSTGRES_HOST_PORT);

        $lines = [
            '# Project-specific container runtime overrides.',
            'APP_ENV=local',
            'APP_DEBUG=true',
            'APP_URL=' . $appUrl,
            'NITE_PROJECT=' . $slug,
            'NITE_PROJECT_NAME=' . $name,
            'NITE_DOCKER_RUNTIME=true',
            'NITE_BROWSABLE_API=true',
            'NITE_HTML_INTERFACE_ENABLED=true',
            'JWT_SECRET=change-me',
            'AUTH_PASSWORD_MIN_LENGTH=12',
            'AUTH_PASSWORD_REQUIRE_UPPERCASE=true',
            'AUTH_PASSWORD_REQUIRE_LOWERCASE=true',
            'AUTH_PASSWORD_REQUIRE_NUMBER=true',
            'AUTH_PASSWORD_REQUIRE_SYMBOL=true',
            'AUTH_BCRYPT_COST=12',
            'AUTH_LOGIN_THROTTLE_ENABLED=true',
            'AUTH_LOGIN_MAX_ATTEMPTS=5',
            'AUTH_LOGIN_DECAY_SECONDS=900',
            'AUTH_LOGIN_LOCKOUT_SECONDS=900',
            'NITE_SEED_DEFAULT_PASSWORD=Passw0rd!2026',
            'APP_PORT=' . $appPort,
            'DB_DRIVER=pgsql',
            'DB_HOST=postgres',
            'DB_PORT=5432',
            'DB_NAME=' . $dbName,
            'DB_USER=postgres',
            'DB_PASSWORD=postgres',
            'POSTGRES_DB=' . $dbName,
            'POSTGRES_USER=postgres',
            'POSTGRES_PASSWORD=postgres',
            'POSTGRES_HOST_PORT=' . $postgresHostPort,
            'MEDIA_STORAGE_ROOT=' . $mediaRoot,
            'MEDIA_UPLOAD_MAX_BYTES=10485760',
            'MEDIA_UPLOAD_ALLOWED_MIME_TYPES=image/*,application/pdf,text/plain,text/csv',
            'MEDIA_UPLOAD_ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,webp,svg,pdf,txt,csv',
            'MAIL_ENABLED=false',
            'MAIL_TRANSPORT=smtp',
            'MAIL_HOST=mailpit',
            'MAIL_PORT=1025',
            'MAIL_ENCRYPTION=',
            'MAIL_FROM_ADDRESS=no-reply@' . $slug . '.local',
            'MAIL_FROM_NAME=' . $name,
            'MAIL_QUEUE_MODE=database',
            'MAIL_QUEUE_BATCH_SIZE=25',
            'MAIL_QUEUE_SLEEP_SECONDS=3',
        ];

        if ($example) {
            array_splice($lines, 1, 0, '# Copy this file to .env.docker before running `docker compose up --build`.');
        }

        return implode(PHP_EOL, $lines) . PHP_EOL;
    }

    /**
     * @param array<string, mixed> $project
     */
    private function renderProjectDockerfile(array $project): string
    {
        $slug = (string)($project['slug'] ?? '');
        $appPort = (int)($project['port'] ?? self::DEFAULT_PORT);

        return implode(PHP_EOL, [
            'FROM composer:2 AS vendor',
            '',
            'WORKDIR /app',
            'COPY composer.json composer.lock ./',
            'RUN composer install --no-dev --prefer-dist --no-interaction --optimize-autoloader',
            '',
            'FROM php:8.3-cli',
            '',
            'RUN docker-php-ext-install pdo pdo_pgsql pdo_mysql',
            'RUN addgroup --system nite && adduser --system --ingroup nite --home /app nite',
            '',
            'WORKDIR /app',
            '',
            'COPY --from=vendor /app/vendor /app/vendor',
            'COPY . /app',
            'RUN mkdir -p /app/storage /app/public/uploads && chown -R nite:nite /app',
            '',
            'ENV APP_PORT=' . $appPort,
            'ENV NITE_PROJECT=' . $slug,
            'ENV NITE_DOCKER_RUNTIME=true',
            'EXPOSE ' . $appPort,
            'HEALTHCHECK --interval=30s --timeout=5s --start-period=20s --retries=3 CMD php -r "exit(@file_get_contents(\'http://127.0.0.1:' . $appPort . '/api/v1/health?format=json\') !== false ? 0 : 1);"',
            '',
            'USER nite',
            'CMD ["sh", "-lc", "php nite app:serve --host=0.0.0.0 --port=${APP_PORT:-' . $appPort . '} --project=${NITE_PROJECT:-' . $slug . '}"]',
            '',
        ]);
    }

    /**
     * @param array<string, mixed> $project
     */
    private function renderProjectDockerCompose(array $project): string
    {
        $slug = (string)($project['slug'] ?? '');
        $appPort = (int)($project['port'] ?? self::DEFAULT_PORT);
        $docker = is_array($project['docker'] ?? null) ? $project['docker'] : [];
        $postgresHostPort = (int)($docker['postgres_host_port'] ?? self::STARTING_PROJECT_POSTGRES_HOST_PORT);

        return implode(PHP_EOL, [
            'services:',
            '  app:',
            '    build:',
            '      context: ../..',
            '      dockerfile: projects/' . $slug . '/Dockerfile',
            '    env_file:',
            '      - ./.env.docker',
            '    ports:',
            '      - "' . $appPort . ':' . $appPort . '"',
            '    depends_on:',
            '      - postgres',
            '      - mailpit',
            '    restart: unless-stopped',
            '',
            '  queue-worker:',
            '    build:',
            '      context: ../..',
            '      dockerfile: projects/' . $slug . '/Dockerfile',
            '    env_file:',
            '      - ./.env.docker',
            '    depends_on:',
            '      - postgres',
            '      - mailpit',
            '    command: ["sh", "-lc", "php nite queue:work --daemon --sleep=${MAIL_QUEUE_SLEEP_SECONDS:-3} --project=${NITE_PROJECT:-' . $slug . '}"]',
            '    restart: unless-stopped',
            '',
            '  postgres:',
            '    image: postgres:16',
            '    env_file:',
            '      - ./.env.docker',
            '    ports:',
            '      - "' . $postgresHostPort . ':5432"',
            '    volumes:',
            '      - ' . str_replace('-', '_', $slug) . '_postgres:/var/lib/postgresql/data',
            '    restart: unless-stopped',
            '',
            '  mailpit:',
            '    image: axllent/mailpit:latest',
            '    restart: unless-stopped',
            '',
            'volumes:',
            '  ' . str_replace('-', '_', $slug) . '_postgres:',
            '',
        ]);
    }
}
