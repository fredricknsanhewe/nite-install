<?php
namespace App\Models;

use App\Utils\UUID;

final class RbacModel extends BaseModel
{
    /**
     * @param array<int, array<string, mixed>> $definitions
     */
    public function upsertPermissions(array $definitions): void
    {
        foreach ($definitions as $definition) {
            $params = [
                ':code' => $definition['code'],
                ':title' => $definition['title'],
                ':description' => $definition['description'],
                ':section_code' => $definition['section_code'],
                ':section_title' => $definition['section_title'],
                ':module_code' => $definition['module_code'],
                ':module_title' => $definition['module_title'],
                ':action_code' => $definition['action_code'],
                ':action_title' => $definition['action_title'],
                ':sort_order' => $definition['sort_order'],
            ];

            if ($this->isMysql()) {
                $this->query(
                    <<<SQL
                        INSERT INTO permissions (
                            code, title, description, section_code, section_title,
                            module_code, module_title, action_code, action_title, sort_order
                        ) VALUES (
                            :code, :title, :description, :section_code, :section_title,
                            :module_code, :module_title, :action_code, :action_title, :sort_order
                        )
                        ON DUPLICATE KEY UPDATE
                            title = VALUES(title),
                            description = VALUES(description),
                            section_code = VALUES(section_code),
                            section_title = VALUES(section_title),
                            module_code = VALUES(module_code),
                            module_title = VALUES(module_title),
                            action_code = VALUES(action_code),
                            action_title = VALUES(action_title),
                            sort_order = VALUES(sort_order)
                    SQL,
                    $params
                );
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO permissions (
                        code, title, description, section_code, section_title,
                        module_code, module_title, action_code, action_title, sort_order
                    ) VALUES (
                        :code, :title, :description, :section_code, :section_title,
                        :module_code, :module_title, :action_code, :action_title, :sort_order
                    )
                    ON CONFLICT (code) DO UPDATE
                    SET title = EXCLUDED.title,
                        description = EXCLUDED.description,
                        section_code = EXCLUDED.section_code,
                        section_title = EXCLUDED.section_title,
                        module_code = EXCLUDED.module_code,
                        module_title = EXCLUDED.module_title,
                        action_code = EXCLUDED.action_code,
                        action_title = EXCLUDED.action_title,
                        sort_order = EXCLUDED.sort_order
                SQL,
                $params
            );
        }
    }

    public function permissionCount(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM permissions');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listPermissionRows(): array
    {
        return $this->many('SELECT * FROM permissions ORDER BY sort_order ASC, code ASC');
    }

    public function supportsGroups(): bool
    {
        return $this->rbacGroupTablesAvailable();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listGroups(array $filters = []): array
    {
        if (!$this->rbacGroupTablesAvailable()) {
            return [];
        }

        $query = $this->table('rbac_groups');
        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $query->whereLike(['code', 'name', 'description'], $q);
        }

        if (array_key_exists('is_active', $filters) && trim((string)$filters['is_active']) !== '') {
            $active = $this->boolValue($filters['is_active']);
            $query->where('is_active', $this->isPgsql() ? ($active ? 'true' : 'false') : ($active ? 1 : 0));
        }

        $limit = min(200, max(1, (int)($filters['limit'] ?? 100)));
        $offset = max(0, (int)($filters['offset'] ?? 0));
        return array_values(array_map(
            fn (array $row): array => $this->hydrateGroup($row),
            $query->orderBy('name')->limit($limit)->offset($offset)->get()
        ));
    }

    public function findGroupById(string $id): ?array
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM rbac_groups WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrateGroup($row) : null;
    }

    public function findGroupByCode(string $code): ?array
    {
        if (!$this->rbacGroupTablesAvailable()) {
            return null;
        }

        $normalized = strtolower(trim($code));
        if ($normalized === '') {
            return null;
        }

        $row = $this->one('SELECT * FROM rbac_groups WHERE LOWER(code) = :code LIMIT 1', [':code' => $normalized]);
        return $row ? $this->hydrateGroup($row) : null;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createGroup(array $data): array
    {
        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO rbac_groups (
                    id, code, name, description, is_active, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :code, :name, :description, :is_active, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':code' => strtolower(trim((string)$data['code'])),
                ':name' => trim((string)$data['name']),
                ':description' => $this->cleanString($data['description'] ?? null, true),
                ':is_active' => $this->sqlBoolean($this->boolValue($data['is_active'] ?? true)),
                ':created_by_user_id' => $this->cleanString($data['created_by_user_id'] ?? null),
                ':updated_by_user_id' => $this->cleanString($data['updated_by_user_id'] ?? null),
            ]
        );

        return (array)$this->findGroupById($id);
    }

    /**
     * @param array<string, mixed> $data
     */
    public function updateGroup(string $id, array $data): ?array
    {
        if (!$this->uuidLike($id) || $this->findGroupById($id) === null) {
            return null;
        }

        $assignments = ['updated_at = ' . $this->nowExpression()];
        $params = [':id' => $id];

        if (array_key_exists('code', $data)) {
            $assignments[] = 'code = :code';
            $params[':code'] = strtolower(trim((string)$data['code']));
        }
        if (array_key_exists('name', $data)) {
            $assignments[] = 'name = :name';
            $params[':name'] = trim((string)$data['name']);
        }
        if (array_key_exists('description', $data)) {
            $assignments[] = 'description = :description';
            $params[':description'] = $this->cleanString($data['description'] ?? null, true);
        }
        if (array_key_exists('is_active', $data)) {
            $assignments[] = 'is_active = :is_active';
            $params[':is_active'] = $this->sqlBoolean($this->boolValue($data['is_active']));
        }
        if (array_key_exists('updated_by_user_id', $data)) {
            $assignments[] = 'updated_by_user_id = :updated_by_user_id';
            $params[':updated_by_user_id'] = $this->cleanString($data['updated_by_user_id'] ?? null);
        }

        if (count($assignments) > 1) {
            $this->query('UPDATE rbac_groups SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        }

        return $this->findGroupById($id);
    }

    public function deleteGroup(string $id): bool
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($id)) {
            return false;
        }

        $this->query('DELETE FROM rbac_groups WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listGroupMembers(string $groupId): array
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($groupId)) {
            return [];
        }

        $rows = $this->many(
            <<<SQL
                SELECT u.id, u.email, u.name, u.role, u.account_status, u.profile_json, u.created_at, u.updated_at
                FROM rbac_group_members gm
                JOIN users u ON u.id = gm.user_id
                WHERE gm.group_id = :group_id
                ORDER BY u.name ASC, u.email ASC
            SQL,
            [':group_id' => $groupId]
        );

        return array_values(array_map(fn (array $row): array => $this->hydrateUserRow($row), $rows));
    }

    /**
     * @param array<int, string> $userIds
     */
    public function replaceGroupMembers(string $groupId, array $userIds): bool
    {
        if (!$this->rbacGroupTablesAvailable() || $this->findGroupById($groupId) === null) {
            return false;
        }

        $this->query('DELETE FROM rbac_group_members WHERE group_id = :group_id', [':group_id' => $groupId]);
        foreach (array_values(array_unique(array_map('strval', $userIds))) as $userId) {
            if (!$this->uuidLike($userId) || !$this->userExists($userId)) {
                continue;
            }
            $this->query(
                'INSERT INTO rbac_group_members (group_id, user_id) VALUES (:group_id, :user_id)',
                [
                    ':group_id' => $groupId,
                    ':user_id' => $userId,
                ]
            );
        }

        return true;
    }

    /**
     * Replace every permission-group membership for one user.
     *
     * @param array<int, string> $groupIds
     */
    public function replaceUserGroups(string $userId, array $groupIds): bool
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($userId) || !$this->userExists($userId)) {
            return false;
        }

        $normalizedIds = array_values(array_unique(array_filter(
            array_map('strval', $groupIds),
            fn (string $groupId): bool => $this->uuidLike($groupId) && $this->findGroupById($groupId) !== null
        )));
        if (count($normalizedIds) !== count(array_values(array_unique(array_map('strval', $groupIds))))) {
            return false;
        }

        $this->db->beginTransaction();
        try {
            $this->query('DELETE FROM rbac_group_members WHERE user_id = :user_id', [':user_id' => $userId]);
            foreach ($normalizedIds as $groupId) {
                $this->query(
                    'INSERT INTO rbac_group_members (group_id, user_id) VALUES (:group_id, :user_id)',
                    [
                        ':group_id' => $groupId,
                        ':user_id' => $userId,
                    ]
                );
            }
            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listUserGroups(string $userId): array
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($userId)) {
            return [];
        }

        $rows = $this->many(
            <<<SQL
                SELECT g.*
                FROM rbac_group_members gm
                JOIN rbac_groups g ON g.id = gm.group_id
                WHERE gm.user_id = :user_id
                ORDER BY g.name ASC
            SQL,
            [':user_id' => $userId]
        );

        return array_values(array_map(fn (array $row): array => $this->hydrateGroup($row), $rows));
    }

    /**
     * @return array<string, string>
     */
    public function listGroupRuleStates(string $groupId): array
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($groupId)) {
            return [];
        }

        $rows = $this->many(
            <<<SQL
                SELECT p.code, r.effect
                FROM rbac_group_permission_rules r
                JOIN permissions p ON p.id = r.permission_id
                WHERE r.group_id = :group_id
            SQL,
            [':group_id' => $groupId]
        );

        $states = [];
        foreach ($rows as $row) {
            $states[(string)$row['code']] = (string)$row['effect'];
        }
        return $states;
    }

    /**
     * @param array<string, string> $statesByCode
     */
    public function replaceGroupRules(string $groupId, array $statesByCode): bool
    {
        if (!$this->rbacGroupTablesAvailable() || $this->findGroupById($groupId) === null) {
            return false;
        }

        $this->query('DELETE FROM rbac_group_permission_rules WHERE group_id = :group_id', [':group_id' => $groupId]);
        if ($statesByCode === []) {
            return true;
        }

        $permissionMap = $this->permissionRowsByCodeMap(array_keys($statesByCode));
        foreach ($statesByCode as $code => $effect) {
            if (!isset($permissionMap[$code])) {
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO rbac_group_permission_rules (group_id, permission_id, effect)
                    VALUES (:group_id, :permission_id, :effect)
                SQL,
                [
                    ':group_id' => $groupId,
                    ':permission_id' => $permissionMap[$code]['id'],
                    ':effect' => $effect,
                ]
            );
        }

        return true;
    }

    /**
     * @return array<string, string>
     */
    public function listUserGroupRuleStates(string $userId): array
    {
        if (!$this->rbacGroupTablesAvailable() || !$this->uuidLike($userId)) {
            return [];
        }

        $rows = $this->many(
            <<<SQL
                SELECT p.code, r.effect
                FROM rbac_group_members gm
                JOIN rbac_groups g ON g.id = gm.group_id
                JOIN rbac_group_permission_rules r ON r.group_id = gm.group_id
                JOIN permissions p ON p.id = r.permission_id
                WHERE gm.user_id = :user_id AND g.is_active = TRUE
            SQL,
            [':user_id' => $userId]
        );

        $states = [];
        foreach ($rows as $row) {
            $code = (string)$row['code'];
            $effect = (string)$row['effect'];
            if ($effect === 'deny' || !isset($states[$code])) {
                $states[$code] = $effect;
            }
        }
        return $states;
    }

    /**
     * @return array<string, string>
     */
    public function listUserOverrideStates(string $userId): array
    {
        $rows = $this->many(
            <<<SQL
                SELECT p.code, o.effect
                FROM user_permission_overrides o
                JOIN permissions p ON p.id = o.permission_id
                WHERE o.user_id = :user_id
            SQL,
            [':user_id' => $userId]
        );

        $states = [];
        foreach ($rows as $row) {
            $states[(string)$row['code']] = (string)$row['effect'];
        }
        return $states;
    }

    /**
     * @param array<string, string> $statesByCode
     */
    public function replaceUserOverrides(string $userId, array $statesByCode): void
    {
        $this->query('DELETE FROM user_permission_overrides WHERE user_id = :user_id', [':user_id' => $userId]);
        if ($statesByCode === []) {
            return;
        }

        $permissionMap = $this->permissionRowsByCodeMap(array_keys($statesByCode));
        foreach ($statesByCode as $code => $effect) {
            if (!isset($permissionMap[$code])) {
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO user_permission_overrides (user_id, permission_id, effect)
                    VALUES (:user_id, :permission_id, :effect)
                SQL,
                [
                    ':user_id' => $userId,
                    ':permission_id' => $permissionMap[$code]['id'],
                    ':effect' => $effect,
                ]
            );
        }
    }

    private function userExists(string $userId): bool
    {
        return $this->one('SELECT id FROM users WHERE id = :id LIMIT 1', [':id' => $userId]) !== null;
    }

    /**
     * @return array<string, mixed>
     */
    private function hydrateGroup(array $row): array
    {
        $row['is_active'] = $this->boolValue($row['is_active'] ?? false);
        return $row;
    }

    /**
     * @return array<string, mixed>
     */
    private function hydrateUserRow(array $row): array
    {
        $row['profile'] = $this->decodeJson($row['profile_json'] ?? null, []);
        unset($row['profile_json']);
        return $row;
    }

    private function sqlBoolean(bool $value): string|int
    {
        return $this->isPgsql() ? ($value ? 'true' : 'false') : ($value ? 1 : 0);
    }

    private function rbacGroupTablesAvailable(): bool
    {
        static $available = null;
        if ($available !== null) {
            return $available;
        }

        try {
            if ($this->isPgsql()) {
                $row = $this->one(
                    "SELECT COUNT(*) AS total FROM information_schema.tables WHERE table_schema = current_schema() AND table_name IN ('rbac_groups', 'rbac_group_members', 'rbac_group_permission_rules')"
                );
            } else {
                $row = $this->one(
                    "SELECT COUNT(*) AS total FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('rbac_groups', 'rbac_group_members', 'rbac_group_permission_rules')"
                );
            }
            $available = (int)($row['total'] ?? 0) === 3;
        } catch (\Throwable) {
            $available = false;
        }

        return $available;
    }

    /**
     * @param array<int, string> $codes
     * @return array<string, array<string, mixed>>
     */
    private function permissionRowsByCodeMap(array $codes): array
    {
        if ($codes === []) {
            return [];
        }

        $placeholders = [];
        $params = [];
        foreach (array_values($codes) as $index => $code) {
            $key = ':code' . $index;
            $placeholders[] = $key;
            $params[$key] = $code;
        }

        $rows = $this->many(
            'SELECT id, code FROM permissions WHERE code IN (' . implode(',', $placeholders) . ')',
            $params
        );

        $map = [];
        foreach ($rows as $row) {
            $map[(string)$row['code']] = $row;
        }
        return $map;
    }
}
