<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class SupportTicketModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "status = 'published'";
        } else {
            $status = strtolower(trim((string)($filters['status'] ?? '')));
            if ($status !== '') {
                $where[] = 'status = :status';
                $params[':status'] = $this->normalizeStatus($status);
            }
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['slug', 'title', 'summary']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM support_tickets';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY updated_at DESC, created_at DESC';

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(100, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM support_tickets WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM support_tickets WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';

        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();

        $this->query(
            'INSERT INTO support_tickets (id, slug, title, summary, status, data_json) VALUES (:id, :slug, :title, :summary, :status, ' . $this->jsonParam(':data_json') . ')',
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        if ($payload === []) {
            return $this->findById($id);
        }

        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $id];
        foreach (['slug', 'title', 'summary', 'status'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }

        if (array_key_exists('data_json', $payload)) {
            $assignments[] = 'data_json = ' . $this->jsonParam(':data_json');
            $params[':data_json'] = $payload['data_json'];
        }

        $this->query('UPDATE support_tickets SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }

        $statement = $this->query('DELETE FROM support_tickets WHERE id = :id', [':id' => $id]);
        return $statement->rowCount() > 0;
    }

    public function count(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM support_tickets');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        if (array_key_exists('status', $data)) {
            $payload['status'] = $this->normalizeStatus($data['status']);
        } elseif ($create) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('data_json', $data)) {
            $payload['data_json'] = json_encode(is_array($data['data_json']) ? $data['data_json'] : [], JSON_UNESCAPED_SLASHES);
        } elseif (array_key_exists('data', $data)) {
            $payload['data_json'] = json_encode(is_array($data['data']) ? $data['data'] : [], JSON_UNESCAPED_SLASHES);
        } elseif ($create) {
            $payload['data_json'] = json_encode([], JSON_UNESCAPED_SLASHES);
        }

        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '')) {
            throw new RuntimeException('SupportTicket slug and title are required.');
        }

        return $payload;
    }

    private function normalizeStatus(mixed $value): string
    {
        $status = strtolower(trim((string)$value));
        if (!in_array($status, ['draft', 'published', 'archived'], true)) {
            return 'draft';
        }

        return $status;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        $row['data'] = $this->decodeJson($row['data_json'] ?? []);
        unset($row['data_json']);
        return $row;
    }
}