<?php
namespace App\Models;

use App\Config\Roles;
use App\Utils\UUID;
use RuntimeException;

final class MediaAssetModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['original_name', 'mime_type', 'alt_text', 'public_url']);
            $params[':q'] = '%' . $q . '%';
        }

        $status = strtolower(trim((string)($filters['status'] ?? '')));
        if ($status !== '') {
            $where[] = 'status = :status';
            $params[':status'] = $this->normalizeStatus($status);
        }

        $accessScope = strtolower(trim((string)($filters['access_scope'] ?? '')));
        if ($accessScope !== '') {
            $where[] = 'access_scope = :access_scope';
            $params[':access_scope'] = $this->normalizeAccessScope($accessScope);
        }

        $kind = strtolower(trim((string)($filters['kind'] ?? $filters['media_kind'] ?? '')));
        if ($kind !== '') {
            $mimePrefix = match ($kind) {
                'image', 'images' => 'image/',
                'video', 'videos' => 'video/',
                'audio' => 'audio/',
                'document', 'documents' => 'application/',
                default => '',
            };
            if ($mimePrefix !== '') {
                $where[] = $this->isPgsql() ? 'mime_type ILIKE :mime_type_prefix' : 'LOWER(mime_type) LIKE LOWER(:mime_type_prefix)';
                $params[':mime_type_prefix'] = $mimePrefix . '%';
            }
        }

        $mimeType = strtolower(trim((string)($filters['mime_type'] ?? '')));
        if ($mimeType !== '') {
            if (str_ends_with($mimeType, '/') || str_ends_with($mimeType, '/*')) {
                $prefix = rtrim($mimeType, '*');
                $where[] = $this->isPgsql() ? 'mime_type ILIKE :mime_type' : 'LOWER(mime_type) LIKE LOWER(:mime_type)';
                $params[':mime_type'] = $prefix . '%';
            } else {
                $where[] = 'LOWER(mime_type) = LOWER(:mime_type)';
                $params[':mime_type'] = $mimeType;
            }
        }

        $createdByUserId = trim((string)($filters['created_by_user_id'] ?? ''));
        if ($createdByUserId !== '') {
            $where[] = 'created_by_user_id = :created_by_user_id';
            $params[':created_by_user_id'] = $createdByUserId;
        }

        $limit = min(250, max(1, (int)($filters['limit'] ?? 100)));
        $offset = max(0, (int)($filters['offset'] ?? 0));
        $sql = 'SELECT * FROM media_assets';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY updated_at DESC, created_at DESC LIMIT :limit OFFSET :offset';

        $statement = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $statement->bindValue($key, $value, \PDO::PARAM_STR);
        }
        $statement->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $statement->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $statement->execute();

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $statement->fetchAll()));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM media_assets WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = $this->uuidLike((string)($data['id'] ?? '')) ? (string)$data['id'] : UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($data['created_by_user_id'] ?? $actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($data['updated_by_user_id'] ?? $actorUserId);
        $payload['created_at'] = $this->normalizeDateTime($data['created_at'] ?? null) ?: $this->normalizeDateTime(gmdate('c'));
        $payload['updated_at'] = $this->normalizeDateTime($data['updated_at'] ?? null) ?: $payload['created_at'];

        $allowedRolesJsonParam = $this->jsonParam(':allowed_roles_json');
        $allowedUserIdsJsonParam = $this->jsonParam(':allowed_user_ids_json');
        $this->query(
            <<<SQL
                INSERT INTO media_assets (
                    id, original_name, stored_name, mime_type, size_bytes, storage_path, public_url, alt_text,
                    access_scope, allowed_roles_json, allowed_user_ids_json, checksum_sha1,
                    current_version_number, version_count, status, created_by_user_id, updated_by_user_id,
                    created_at, updated_at
                ) VALUES (
                    :id, :original_name, :stored_name, :mime_type, :size_bytes, :storage_path, :public_url, :alt_text,
                    :access_scope, {$allowedRolesJsonParam}, {$allowedUserIdsJsonParam}, :checksum_sha1,
                    :current_version_number, :version_count, :status, :created_by_user_id, :updated_by_user_id,
                    :created_at, :updated_at
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [
            ':id' => $id,
            ':updated_by_user_id' => $this->cleanString($data['updated_by_user_id'] ?? $actorUserId),
        ];

        foreach ([
            'original_name',
            'stored_name',
            'mime_type',
            'size_bytes',
            'storage_path',
            'public_url',
            'alt_text',
            'access_scope',
            'checksum_sha1',
            'current_version_number',
            'version_count',
            'status',
        ] as $field) {
            if (!array_key_exists($field, $payload)) {
                continue;
            }
            $assignments[] = $field . ' = :' . $field;
            $params[':' . $field] = $payload[$field];
        }

        foreach (['allowed_roles_json', 'allowed_user_ids_json'] as $jsonField) {
            if (!array_key_exists($jsonField, $payload)) {
                continue;
            }
            $assignments[] = $jsonField . ' = ' . $this->jsonParam(':' . $jsonField);
            $params[':' . $jsonField] = $payload[$jsonField];
        }

        $this->query('UPDATE media_assets SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }

        $this->query('DELETE FROM media_assets WHERE id = :id', [':id' => $id]);
        return true;
    }

    public function restoreSnapshot(array $snapshot, ?string $actorUserId = null): array
    {
        $id = (string)($snapshot['id'] ?? '');
        if (!$this->uuidLike($id)) {
            throw new RuntimeException('The archived media asset snapshot is invalid.');
        }

        $payload = $this->normalizePayload($snapshot, true);
        $payload['id'] = $id;
        $payload['created_by_user_id'] = $this->cleanString($snapshot['created_by_user_id'] ?? null);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId) ?: $this->cleanString($snapshot['updated_by_user_id'] ?? null);
        $payload['created_at'] = $this->normalizeDateTime($snapshot['created_at'] ?? null) ?: $this->normalizeDateTime(gmdate('c'));

        if ($this->isMysql()) {
            $this->query(
                <<<SQL
                    INSERT INTO media_assets (
                        id, original_name, stored_name, mime_type, size_bytes, storage_path, public_url, alt_text,
                        access_scope, allowed_roles_json, allowed_user_ids_json, checksum_sha1,
                        current_version_number, version_count, status, created_by_user_id, updated_by_user_id,
                        created_at, updated_at
                    ) VALUES (
                        :id, :original_name, :stored_name, :mime_type, :size_bytes, :storage_path, :public_url, :alt_text,
                        :access_scope, :allowed_roles_json, :allowed_user_ids_json, :checksum_sha1,
                        :current_version_number, :version_count, :status, :created_by_user_id, :updated_by_user_id,
                        :created_at, NOW()
                    )
                    ON DUPLICATE KEY UPDATE
                        original_name = VALUES(original_name),
                        stored_name = VALUES(stored_name),
                        mime_type = VALUES(mime_type),
                        size_bytes = VALUES(size_bytes),
                        storage_path = VALUES(storage_path),
                        public_url = VALUES(public_url),
                        alt_text = VALUES(alt_text),
                        access_scope = VALUES(access_scope),
                        allowed_roles_json = VALUES(allowed_roles_json),
                        allowed_user_ids_json = VALUES(allowed_user_ids_json),
                        checksum_sha1 = VALUES(checksum_sha1),
                        current_version_number = VALUES(current_version_number),
                        version_count = VALUES(version_count),
                        status = VALUES(status),
                        created_by_user_id = VALUES(created_by_user_id),
                        updated_by_user_id = VALUES(updated_by_user_id),
                        created_at = VALUES(created_at),
                        updated_at = NOW()
                SQL,
                $payload
            );
        } else {
            $allowedRolesJsonParam = $this->jsonParam(':allowed_roles_json');
            $allowedUserIdsJsonParam = $this->jsonParam(':allowed_user_ids_json');
            $this->query(
                <<<SQL
                    INSERT INTO media_assets (
                        id, original_name, stored_name, mime_type, size_bytes, storage_path, public_url, alt_text,
                        access_scope, allowed_roles_json, allowed_user_ids_json, checksum_sha1,
                        current_version_number, version_count, status, created_by_user_id, updated_by_user_id,
                        created_at, updated_at
                    ) VALUES (
                        :id, :original_name, :stored_name, :mime_type, :size_bytes, :storage_path, :public_url, :alt_text,
                        :access_scope, {$allowedRolesJsonParam}, {$allowedUserIdsJsonParam}, :checksum_sha1,
                        :current_version_number, :version_count, :status, :created_by_user_id, :updated_by_user_id,
                        :created_at, NOW()
                    )
                    ON CONFLICT (id) DO UPDATE
                    SET original_name = EXCLUDED.original_name,
                        stored_name = EXCLUDED.stored_name,
                        mime_type = EXCLUDED.mime_type,
                        size_bytes = EXCLUDED.size_bytes,
                        storage_path = EXCLUDED.storage_path,
                        public_url = EXCLUDED.public_url,
                        alt_text = EXCLUDED.alt_text,
                        access_scope = EXCLUDED.access_scope,
                        allowed_roles_json = EXCLUDED.allowed_roles_json,
                        allowed_user_ids_json = EXCLUDED.allowed_user_ids_json,
                        checksum_sha1 = EXCLUDED.checksum_sha1,
                        current_version_number = EXCLUDED.current_version_number,
                        version_count = EXCLUDED.version_count,
                        status = EXCLUDED.status,
                        created_by_user_id = EXCLUDED.created_by_user_id,
                        updated_by_user_id = EXCLUDED.updated_by_user_id,
                        created_at = EXCLUDED.created_at,
                        updated_at = NOW()
                SQL,
                $payload
            );
        }

        return (array)$this->findById($id);
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];

        foreach ([
            'original_name',
            'stored_name',
            'mime_type',
            'storage_path',
            'public_url',
            'alt_text',
            'checksum_sha1',
        ] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        foreach (['size_bytes', 'current_version_number', 'version_count'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = max(0, (int)$data[$field]);
            }
        }

        if (array_key_exists('access_scope', $data)) {
            $payload['access_scope'] = $this->normalizeAccessScope($data['access_scope']);
        } elseif ($create) {
            $payload['access_scope'] = 'private';
        }

        if (array_key_exists('allowed_roles', $data) || array_key_exists('allowed_roles_json', $data)) {
            $payload['allowed_roles_json'] = json_encode(
                $this->normalizeAllowedRoles($data['allowed_roles'] ?? $data['allowed_roles_json'] ?? []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['allowed_roles_json'] = '[]';
        }

        if (array_key_exists('allowed_user_ids', $data) || array_key_exists('allowed_user_ids_json', $data)) {
            $payload['allowed_user_ids_json'] = json_encode(
                $this->normalizeAllowedUserIds($data['allowed_user_ids'] ?? $data['allowed_user_ids_json'] ?? []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['allowed_user_ids_json'] = '[]';
        }

        if (array_key_exists('status', $data)) {
            $payload['status'] = $this->normalizeStatus($data['status']);
        } elseif ($create) {
            $payload['status'] = 'active';
        }

        if ($create) {
            $payload['size_bytes'] = max(0, (int)($payload['size_bytes'] ?? 0));
            $payload['current_version_number'] = max(1, (int)($payload['current_version_number'] ?? 1));
            $payload['version_count'] = max($payload['current_version_number'], (int)($payload['version_count'] ?? 1));
            if (($payload['original_name'] ?? '') === '' || ($payload['stored_name'] ?? '') === '' || ($payload['mime_type'] ?? '') === '' || ($payload['storage_path'] ?? '') === '') {
                throw new RuntimeException('Media asset file metadata is incomplete.');
            }
        }

        return $payload;
    }

    /**
     * @return array<int, string>
     */
    private function normalizeAllowedRoles(mixed $value): array
    {
        $items = is_array($value) ? $value : $this->decodeJson($value, []);
        if (!is_array($items)) {
            return [];
        }

        $roles = [];
        foreach ($items as $item) {
            $role = strtolower(trim((string)$item));
            if ($role !== '' && in_array($role, Roles::all(), true)) {
                $roles[] = $role;
            }
        }

        return array_values(array_unique($roles));
    }

    /**
     * @return array<int, string>
     */
    private function normalizeAllowedUserIds(mixed $value): array
    {
        $items = is_array($value) ? $value : $this->decodeJson($value, []);
        if (!is_array($items)) {
            return [];
        }

        $userIds = [];
        foreach ($items as $item) {
            $userId = trim((string)$item);
            if ($this->uuidLike($userId)) {
                $userIds[] = $userId;
            }
        }

        return array_values(array_unique($userIds));
    }

    private function normalizeAccessScope(mixed $value): string
    {
        $scope = strtolower(trim((string)$value));
        if (!in_array($scope, ['public', 'authenticated', 'roles', 'users', 'private'], true)) {
            throw new RuntimeException('Invalid media access scope supplied.');
        }

        return $scope;
    }

    private function normalizeStatus(mixed $value): string
    {
        $status = strtolower(trim((string)$value));
        if (!in_array($status, ['active', 'archived'], true)) {
            throw new RuntimeException('Invalid media status supplied.');
        }

        return $status;
    }

    private function hydrate(array $row): array
    {
        $row = $this->normalizeRowForOutput($row);
        $row['size_bytes'] = (int)($row['size_bytes'] ?? 0);
        $row['current_version_number'] = (int)($row['current_version_number'] ?? 1);
        $row['version_count'] = (int)($row['version_count'] ?? 1);
        $row['allowed_roles'] = $this->decodeJson($row['allowed_roles_json'] ?? null, []);
        $row['allowed_user_ids'] = $this->decodeJson($row['allowed_user_ids_json'] ?? null, []);
        unset($row['allowed_roles_json'], $row['allowed_user_ids_json']);
        return $row;
    }
}
