<?php
namespace App\Models;

use App\Utils\UUID;

final class UserPasswordHistoryModel extends BaseModel
{
    /**
     * @return array<string, mixed>
     */
    public function record(string $userId, string $passwordHash, ?string $changedByUserId = null, string $source = 'user_change'): array
    {
        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO user_password_history (
                    id, user_id, password_hash, changed_by_user_id, change_source
                ) VALUES (
                    :id, :user_id, :password_hash, :changed_by_user_id, :change_source
                )
            SQL,
            [
                ':id' => $id,
                ':user_id' => $userId,
                ':password_hash' => $passwordHash,
                ':changed_by_user_id' => $this->cleanString($changedByUserId),
                ':change_source' => $this->source($source),
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        return $this->one('SELECT * FROM user_password_history WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function latestForUser(string $userId, int $limit): array
    {
        if (!$this->uuidLike($userId) || $limit < 1) {
            return [];
        }

        return $this->many(
            'SELECT * FROM user_password_history WHERE user_id = :user_id ORDER BY created_at DESC LIMIT ' . max(1, min(50, $limit)),
            [':user_id' => $userId]
        );
    }

    public function pruneForUser(string $userId, int $keep): void
    {
        if (!$this->uuidLike($userId) || $keep < 1) {
            return;
        }

        $rows = $this->latestForUser($userId, 200);
        $remove = array_slice($rows, $keep);
        foreach ($remove as $row) {
            $id = (string)($row['id'] ?? '');
            if ($this->uuidLike($id)) {
                $this->query('DELETE FROM user_password_history WHERE id = :id', [':id' => $id]);
            }
        }
    }

    private function source(string $value): string
    {
        $source = strtolower(trim($value));
        return preg_match('/^[a-z0-9_.-]{1,40}$/', $source) === 1 ? $source : 'user_change';
    }
}
