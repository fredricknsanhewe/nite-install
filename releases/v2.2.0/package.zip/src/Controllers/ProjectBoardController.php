<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\ProjectBoardService;
use RuntimeException;

final class ProjectBoardController
{
    private ProjectBoardService $projectBoards;

    public function __construct()
    {
        $this->projectBoards = new ProjectBoardService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->projectBoards->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->projectBoards->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Project Board not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->projectBoards->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->projectBoards->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Project Board not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            return Response::json(['data' => $this->projectBoards->create($request->body)], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create project board.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->projectBoards->update((string)($request->params['id'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Project Board not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update project board.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->projectBoards->delete((string)($request->params['id'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => 'Project Board not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete project board.'], 500);
        }
    }
}