<?php
namespace App\Controllers;

use App\Exceptions\AuthenticationException;
use App\Exceptions\ThrottleException;
use App\Exceptions\ValidationException;
use App\Http\ApiResponse;
use App\Http\Request;
use App\Http\Response;
use App\Services\AuthService;

final class AuthController
{
    private AuthService $auth;

    public function __construct()
    {
        $this->auth = new AuthService();
    }

    public function register(Request $request): Response
    {
        try {
            return ApiResponse::success(
                $this->auth->register($request->body, ['ip_address' => $request->ipAddress()]),
                'Created successfully',
                201
            );
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (\Throwable) {
            return ApiResponse::error('Failed to register user.', null, 500);
        }
    }

    public function login(Request $request): Response
    {
        try {
            return ApiResponse::success($this->auth->login($request->body, ['ip_address' => $request->ipAddress()]));
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (ThrottleException $e) {
            return ApiResponse::error($e->getMessage(), ['retry_after' => $e->retryAfterSeconds()], 429, [], [
                'Retry-After' => (string)$e->retryAfterSeconds(),
            ]);
        } catch (AuthenticationException $e) {
            return ApiResponse::error($e->getMessage(), null, 401);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to sign in.', null, 500);
        }
    }

    public function forgotPassword(Request $request): Response
    {
        try {
            return ApiResponse::success($this->auth->requestPasswordReset($request->body, ['ip_address' => $request->ipAddress()]));
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (\Throwable) {
            return ApiResponse::error('Failed to request password reset.', null, 500);
        }
    }

    public function resetPassword(Request $request): Response
    {
        try {
            return ApiResponse::success($this->auth->resetPassword($request->body));
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (AuthenticationException $e) {
            return ApiResponse::error($e->getMessage(), null, 401);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to reset password.', null, 500);
        }
    }

    public function changePassword(Request $request): Response
    {
        try {
            return ApiResponse::success($this->auth->changePassword((string)($request->user['id'] ?? ''), $request->body));
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (AuthenticationException $e) {
            return ApiResponse::error($e->getMessage(), null, 401);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to change password.', null, 500);
        }
    }
}
