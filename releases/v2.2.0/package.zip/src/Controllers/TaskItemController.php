<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\TaskItemService;
use RuntimeException;

final class TaskItemController
{
    private TaskItemService $taskItems;

    public function __construct()
    {
        $this->taskItems = new TaskItemService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->taskItems->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->taskItems->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Task Item not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->taskItems->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->taskItems->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Task Item not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            return Response::json(['data' => $this->taskItems->create($request->body)], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create task item.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->taskItems->update((string)($request->params['id'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Task Item not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update task item.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->taskItems->delete((string)($request->params['id'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => 'Task Item not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete task item.'], 500);
        }
    }
}