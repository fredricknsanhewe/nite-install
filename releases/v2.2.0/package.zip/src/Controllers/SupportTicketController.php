<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\SupportTicketService;
use RuntimeException;

final class SupportTicketController
{
    private SupportTicketService $supportTickets;

    public function __construct()
    {
        $this->supportTickets = new SupportTicketService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->supportTickets->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->supportTickets->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Support Ticket not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->supportTickets->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->supportTickets->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Support Ticket not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            return Response::json(['data' => $this->supportTickets->create($request->body)], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create support ticket.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->supportTickets->update((string)($request->params['id'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Support Ticket not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update support ticket.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->supportTickets->delete((string)($request->params['id'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => 'Support Ticket not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete support ticket.'], 500);
        }
    }
}