<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\CustomerAccountService;
use RuntimeException;

final class CustomerAccountController
{
    private CustomerAccountService $customerAccounts;

    public function __construct()
    {
        $this->customerAccounts = new CustomerAccountService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->customerAccounts->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->customerAccounts->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Customer Account not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->customerAccounts->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->customerAccounts->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Customer Account not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            return Response::json(['data' => $this->customerAccounts->create($request->body)], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create customer account.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->customerAccounts->update((string)($request->params['id'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Customer Account not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update customer account.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->customerAccounts->delete((string)($request->params['id'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => 'Customer Account not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete customer account.'], 500);
        }
    }
}