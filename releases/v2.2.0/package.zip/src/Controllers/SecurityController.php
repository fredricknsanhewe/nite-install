<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\PasswordPolicyService;
use RuntimeException;

final class SecurityController
{
    private PasswordPolicyService $passwordPolicy;

    public function __construct()
    {
        $this->passwordPolicy = new PasswordPolicyService();
    }

    public function passwordPolicy(Request $request): Response
    {
        return Response::json(['data' => $this->passwordPolicy->current()]);
    }

    public function updatePasswordPolicy(Request $request): Response
    {
        try {
            $record = $this->passwordPolicy->update($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $record['settings'] ?? $this->passwordPolicy->current()]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update password policy.'], 500);
        }
    }
}
