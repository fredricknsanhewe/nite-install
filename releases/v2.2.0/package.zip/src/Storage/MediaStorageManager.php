<?php
namespace App\Storage;

use App\Config\Env;
use App\Config\MediaConfig;
use Aws\S3\S3Client;
use League\Flysystem\AwsS3V3\AwsS3V3Adapter;
use League\Flysystem\Filesystem;
use League\Flysystem\Ftp\FtpAdapter;
use League\Flysystem\Ftp\FtpConnectionOptions;
use League\Flysystem\Local\LocalFilesystemAdapter;
use RuntimeException;

final class MediaStorageManager
{
    private string $rootPath;

    /**
     * @var array<string, StorageAdapterInterface>
     */
    private array $adapters = [];

    public function __construct(?string $rootPath = null)
    {
        $this->rootPath = $rootPath ?? dirname(__DIR__, 2);
    }

    /**
     * @param array<string, mixed> $file
     * @return array<string, mixed>
     */
    public function storeUpload(array $file): array
    {
        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('File upload failed.');
        }

        $tmp = trim((string)($file['tmp_name'] ?? ''));
        $originalName = trim((string)($file['name'] ?? ''));
        if ($tmp === '' || $originalName === '' || !is_file($tmp)) {
            throw new RuntimeException('Uploaded file is invalid.');
        }

        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $safeExtension = preg_match('/^[a-z0-9]{1,10}$/', $extension) === 1 ? $extension : 'bin';
        $storedName = uniqid('media_', true) . '.' . $safeExtension;
        $relativePath = $this->buildRelativePath($storedName, gmdate('c'));
        $mimeType = $this->detectMimeType($tmp, (string)($file['type'] ?? ''));
        $size = filesize($tmp);
        $sizeBytes = $size === false ? (int)($file['size'] ?? 0) : (int)$size;
        $checksum = sha1_file($tmp);

        $this->assertUploadAllowed($originalName, $safeExtension, $mimeType, $sizeBytes);

        $stream = @fopen($tmp, 'rb');
        if (!is_resource($stream)) {
            throw new RuntimeException('Failed to read the uploaded file stream.');
        }

        try {
            $this->adapter($this->activeDriver())->writeStream($relativePath, $stream);
        } finally {
            fclose($stream);
        }

        return [
            'original_name' => $originalName,
            'stored_name' => $storedName,
            'mime_type' => $mimeType,
            'size_bytes' => $sizeBytes,
            'storage_path' => $this->encodeLocator($this->activeDriver(), $relativePath),
            'checksum_sha1' => is_string($checksum) ? $checksum : null,
        ];
    }

    public function read(string $storagePath, ?string $storedName = null, mixed $createdAt = null): ?string
    {
        $resolved = $this->resolveLocation($storagePath, $storedName, $createdAt);
        if ($resolved['mode'] === 'legacy_absolute') {
            $content = @file_get_contents((string)$resolved['path']);
            return is_string($content) ? $content : null;
        }

        if (!$this->adapter((string)$resolved['driver'])->exists((string)$resolved['path'])) {
            return null;
        }

        return $this->adapter((string)$resolved['driver'])->read((string)$resolved['path']);
    }

    public function exists(string $storagePath, ?string $storedName = null, mixed $createdAt = null): bool
    {
        $resolved = $this->resolveLocation($storagePath, $storedName, $createdAt);
        if ($resolved['mode'] === 'legacy_absolute') {
            return is_file((string)$resolved['path']);
        }

        return $this->adapter((string)$resolved['driver'])->exists((string)$resolved['path']);
    }

    public function delete(mixed $storagePath): void
    {
        $target = is_string($storagePath) ? trim($storagePath) : '';
        if ($target === '') {
            return;
        }

        $resolved = $this->resolveLocation($target);
        if ($resolved['mode'] === 'legacy_absolute') {
            if (is_file((string)$resolved['path'])) {
                @unlink((string)$resolved['path']);
            }
            return;
        }

        $this->adapter((string)$resolved['driver'])->delete((string)$resolved['path']);
    }

    public function activeDriver(): string
    {
        return $this->normalizeDriver((string)Env::get('MEDIA_STORAGE_DRIVER', 'local'));
    }

    /**
     * @return array<string, mixed>
     */
    public function summary(): array
    {
        $driver = $this->activeDriver();
        $summary = [
            'driver' => $driver,
            'mode' => in_array($driver, ['ftp', 's3', 'http'], true) ? 'remote' : 'local',
        ];

        if ($driver === 'local') {
            $summary['root'] = $this->localStorageRoot();
        } elseif ($driver === 'ftp') {
            $summary['host'] = trim((string)Env::get('MEDIA_STORAGE_FTP_HOST', ''));
            $summary['root'] = trim((string)Env::get('MEDIA_STORAGE_FTP_ROOT', ''));
            $summary['ssl'] = $this->ftpSslEnabled();
        } elseif ($driver === 's3') {
            $summary['bucket'] = trim((string)Env::get('MEDIA_STORAGE_S3_BUCKET', ''));
            $summary['region'] = trim((string)Env::get('MEDIA_STORAGE_S3_REGION', ''));
            $summary['endpoint'] = trim((string)Env::get('MEDIA_STORAGE_S3_ENDPOINT', ''));
            $summary['prefix'] = $this->normalizedPrefix();
        } elseif ($driver === 'http') {
            $summary['base_url'] = trim((string)Env::get('MEDIA_STORAGE_HTTP_BASE_URL', ''));
            $summary['prefix'] = $this->normalizedPrefix();
        }

        return $summary;
    }

    public function legacyLocalAbsolutePath(string $storedName, mixed $createdAt): string
    {
        return $this->legacyStoragePath($storedName, $createdAt);
    }

    /**
     * @return array<string, mixed>
     */
    private function resolveLocation(string $storagePath, ?string $storedName = null, mixed $createdAt = null): array
    {
        $trimmed = trim($storagePath);
        if ($trimmed === '' && $storedName !== null) {
            $trimmed = $this->legacyStoragePath($storedName, $createdAt);
        }
        if ($trimmed === '') {
            throw new RuntimeException('A media storage path is required.');
        }

        if (preg_match('/^(local|ftp|ftps|s3|bucket|aws|http|https|webdav):\/\/(.+)$/i', $trimmed, $matches) === 1) {
            $driver = $this->normalizeDriver((string)$matches[1]);
            $path = ltrim((string)$matches[2], '/');
            if ($path === '') {
                throw new RuntimeException('The media storage locator is invalid.');
            }

            return [
                'mode' => 'adapter',
                'driver' => $driver,
                'path' => $path,
            ];
        }

        if ($this->isAbsolutePath($trimmed)) {
            return [
                'mode' => 'legacy_absolute',
                'driver' => 'local',
                'path' => $trimmed,
            ];
        }

        return [
            'mode' => 'adapter',
            'driver' => 'local',
            'path' => ltrim(str_replace('\\', '/', $trimmed), '/'),
        ];
    }

    private function adapter(string $driver): StorageAdapterInterface
    {
        $normalized = $this->normalizeDriver($driver);
        if (isset($this->adapters[$normalized])) {
            return $this->adapters[$normalized];
        }

        return $this->adapters[$normalized] = match ($normalized) {
            'local' => new FlysystemStorageAdapter('local', new Filesystem(
                new LocalFilesystemAdapter($this->localStorageRoot())
            )),
            'ftp' => new FlysystemStorageAdapter('ftp', new Filesystem(
                new FtpAdapter(FtpConnectionOptions::fromArray([
                    'host' => $this->requiredEnv('MEDIA_STORAGE_FTP_HOST', 'FTP storage host'),
                    'root' => trim((string)Env::get('MEDIA_STORAGE_FTP_ROOT', '')),
                    'username' => $this->requiredEnv('MEDIA_STORAGE_FTP_USERNAME', 'FTP storage username'),
                    'password' => $this->requiredEnv('MEDIA_STORAGE_FTP_PASSWORD', 'FTP storage password'),
                    'port' => max(1, (int)Env::get('MEDIA_STORAGE_FTP_PORT', '21')),
                    'ssl' => $this->ftpSslEnabled(),
                    'timeout' => max(5, (int)Env::get('MEDIA_STORAGE_FTP_TIMEOUT', '90')),
                    'passive' => Env::bool('MEDIA_STORAGE_FTP_PASSIVE', true),
                ]))
            )),
            's3' => new FlysystemStorageAdapter('s3', new Filesystem(
                new AwsS3V3Adapter(
                    new S3Client($this->s3ClientConfig()),
                    $this->requiredEnv('MEDIA_STORAGE_S3_BUCKET', 'S3 bucket'),
                    $this->normalizedPrefix()
                )
            )),
            'http' => new HttpStorageAdapter(
                $this->requiredEnv('MEDIA_STORAGE_HTTP_BASE_URL', 'HTTP storage base URL'),
                $this->optionalEnv('MEDIA_STORAGE_HTTP_USERNAME'),
                $this->optionalEnv('MEDIA_STORAGE_HTTP_PASSWORD'),
                $this->httpHeaders(),
                max(5, (int)Env::get('MEDIA_STORAGE_HTTP_TIMEOUT', '60')),
                Env::bool('MEDIA_STORAGE_HTTP_VERIFY_TLS', true)
            ),
            default => throw new RuntimeException('Unsupported media storage driver: ' . $normalized),
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function s3ClientConfig(): array
    {
        $config = [
            'version' => 'latest',
            'region' => trim((string)Env::get('MEDIA_STORAGE_S3_REGION', 'us-east-1')),
            'credentials' => [
                'key' => $this->requiredEnv('MEDIA_STORAGE_S3_KEY', 'S3 access key'),
                'secret' => $this->requiredEnv('MEDIA_STORAGE_S3_SECRET', 'S3 secret key'),
            ],
            'use_path_style_endpoint' => Env::bool('MEDIA_STORAGE_S3_PATH_STYLE', false),
        ];

        $endpoint = trim((string)Env::get('MEDIA_STORAGE_S3_ENDPOINT', ''));
        if ($endpoint !== '') {
            $config['endpoint'] = $endpoint;
        }

        return $config;
    }

    /**
     * @return array<int, string>
     */
    private function httpHeaders(): array
    {
        $raw = trim((string)Env::get('MEDIA_STORAGE_HTTP_HEADERS', ''));
        if ($raw === '') {
            return [];
        }

        return array_values(array_filter(
            array_map('trim', preg_split('/[|\\n\\r]+/', $raw) ?: []),
            static fn (string $header): bool => $header !== ''
        ));
    }

    private function localStorageRoot(): string
    {
        $configured = trim((string)Env::get('MEDIA_STORAGE_ROOT', 'storage/media'));
        $relative = trim(str_replace('\\', '/', $configured), '/');
        return $this->rootPath . '/' . ($relative === '' ? 'storage/media' : $relative);
    }

    private function normalizedPrefix(): string
    {
        return trim(str_replace('\\', '/', (string)Env::get('MEDIA_STORAGE_PREFIX', '')), '/');
    }

    private function ftpSslEnabled(): bool
    {
        return Env::bool('MEDIA_STORAGE_FTP_SSL', false) || strtolower(trim((string)Env::get('MEDIA_STORAGE_DRIVER', ''))) === 'ftps';
    }

    private function buildRelativePath(string $storedName, mixed $createdAt): string
    {
        $timestamp = strtotime((string)$createdAt);
        $relativeDir = $timestamp === false ? gmdate('Y/m') : gmdate('Y/m', $timestamp);
        $prefix = $this->normalizedPrefix();
        return $prefix === '' ? ($relativeDir . '/' . $storedName) : ($prefix . '/' . $relativeDir . '/' . $storedName);
    }

    private function legacyStoragePath(string $storedName, mixed $createdAt): string
    {
        $name = trim($storedName);
        if ($name === '') {
            return '';
        }

        $timestamp = strtotime((string)$createdAt);
        $relativeDir = $timestamp === false ? gmdate('Y/m') : gmdate('Y/m', $timestamp);
        return $this->localStorageRoot() . '/' . $relativeDir . '/' . $name;
    }

    private function detectMimeType(string $path, string $fallback): string
    {
        $detected = function_exists('mime_content_type') ? mime_content_type($path) : false;
        if (is_string($detected) && trim($detected) !== '') {
            return $detected;
        }

        $trimmedFallback = trim($fallback);
        return $trimmedFallback !== '' ? $trimmedFallback : 'application/octet-stream';
    }

    private function assertUploadAllowed(string $originalName, string $extension, string $mimeType, int $sizeBytes): void
    {
        $maxBytes = MediaConfig::uploadMaxBytes();
        if ($sizeBytes > $maxBytes) {
            throw new RuntimeException('Uploaded file exceeds the configured limit of ' . $maxBytes . ' bytes.');
        }

        $allowedExtensions = MediaConfig::allowedExtensions();
        if ($allowedExtensions !== [] && !in_array(strtolower($extension), $allowedExtensions, true)) {
            throw new RuntimeException('File extension is not allowed for ' . $originalName . '.');
        }

        $allowedMimeTypes = MediaConfig::allowedMimeTypes();
        if ($allowedMimeTypes !== [] && !$this->mimeTypeAllowed($mimeType, $allowedMimeTypes)) {
            throw new RuntimeException('File type is not allowed: ' . $mimeType . '.');
        }
    }

    /**
     * @param array<int, string> $allowedMimeTypes
     */
    private function mimeTypeAllowed(string $mimeType, array $allowedMimeTypes): bool
    {
        $normalized = strtolower(trim($mimeType));
        foreach ($allowedMimeTypes as $allowed) {
            if ($allowed === $normalized) {
                return true;
            }

            if (str_ends_with($allowed, '/*')) {
                $prefix = substr($allowed, 0, -1);
                if (str_starts_with($normalized, $prefix)) {
                    return true;
                }
            }
        }

        return false;
    }

    private function encodeLocator(string $driver, string $path): string
    {
        return $this->normalizeDriver($driver) . '://' . ltrim(str_replace('\\', '/', $path), '/');
    }

    private function normalizeDriver(string $driver): string
    {
        return match (strtolower(trim($driver))) {
            '', 'local' => 'local',
            'ftp', 'ftps' => 'ftp',
            'bucket', 'aws', 's3' => 's3',
            'http', 'https', 'webdav' => 'http',
            default => strtolower(trim($driver)),
        };
    }

    private function requiredEnv(string $key, string $label): string
    {
        $value = trim((string)Env::get($key, ''));
        if ($value === '') {
            throw new RuntimeException($label . ' is not configured.');
        }

        return $value;
    }

    private function optionalEnv(string $key): ?string
    {
        $value = trim((string)Env::get($key, ''));
        return $value === '' ? null : $value;
    }

    private function isAbsolutePath(string $path): bool
    {
        return str_starts_with($path, '/')
            || preg_match('/^[a-zA-Z]:[\\\\\\/]/', $path) === 1
            || str_starts_with($path, '\\\\');
    }
}
