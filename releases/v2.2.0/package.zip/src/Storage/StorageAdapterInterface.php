<?php
namespace App\Storage;

interface StorageAdapterInterface
{
    /**
     * @param resource $stream
     */
    public function writeStream(string $path, $stream): void;

    public function read(string $path): string;

    public function exists(string $path): bool;

    public function delete(string $path): void;
}
