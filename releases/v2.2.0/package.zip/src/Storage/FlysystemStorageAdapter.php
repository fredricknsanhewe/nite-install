<?php
namespace App\Storage;

use League\Flysystem\FilesystemException;
use League\Flysystem\FilesystemOperator;
use RuntimeException;

final class FlysystemStorageAdapter implements StorageAdapterInterface
{
    public function __construct(
        private readonly string $name,
        private readonly FilesystemOperator $filesystem
    ) {
    }

    public function writeStream(string $path, $stream): void
    {
        try {
            $this->filesystem->writeStream($path, $stream);
        } catch (FilesystemException $e) {
            throw new RuntimeException('Failed to write file to the ' . $this->name . ' storage backend: ' . $e->getMessage(), 0, $e);
        }
    }

    public function read(string $path): string
    {
        try {
            return $this->filesystem->read($path);
        } catch (FilesystemException $e) {
            throw new RuntimeException('Failed to read file from the ' . $this->name . ' storage backend: ' . $e->getMessage(), 0, $e);
        }
    }

    public function exists(string $path): bool
    {
        try {
            return $this->filesystem->fileExists($path);
        } catch (FilesystemException $e) {
            throw new RuntimeException('Failed to inspect the ' . $this->name . ' storage backend: ' . $e->getMessage(), 0, $e);
        }
    }

    public function delete(string $path): void
    {
        try {
            if ($this->filesystem->fileExists($path)) {
                $this->filesystem->delete($path);
            }
        } catch (FilesystemException $e) {
            throw new RuntimeException('Failed to delete a file from the ' . $this->name . ' storage backend: ' . $e->getMessage(), 0, $e);
        }
    }
}
