<?php
namespace App\Storage;

use RuntimeException;

final class HttpStorageAdapter implements StorageAdapterInterface
{
    /**
     * @param array<int, string> $headers
     */
    public function __construct(
        private readonly string $baseUrl,
        private readonly ?string $username,
        private readonly ?string $password,
        private readonly array $headers = [],
        private readonly int $timeout = 60,
        private readonly bool $verifyTls = true
    ) {
    }

    public function writeStream(string $path, $stream): void
    {
        if (!is_resource($stream)) {
            throw new RuntimeException('An upload stream is required for HTTP storage.');
        }

        $this->ensureParentDirectories($path);
        $streamMeta = @stream_get_meta_data($stream);
        if (is_array($streamMeta) && ($streamMeta['seekable'] ?? false)) {
            rewind($stream);
        }

        $stats = @fstat($stream);
        $size = is_array($stats) && isset($stats['size']) ? (int)$stats['size'] : 0;
        $handle = $this->createHandle('PUT', $path);
        curl_setopt($handle, CURLOPT_UPLOAD, true);
        curl_setopt($handle, CURLOPT_INFILE, $stream);
        if ($size > 0) {
            curl_setopt($handle, CURLOPT_INFILESIZE, $size);
        }

        $result = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($result === false || $status < 200 || $status >= 300) {
            throw new RuntimeException('HTTP storage upload failed for "' . $path . '" with status ' . $status . ($error !== '' ? ' (' . $error . ')' : '') . '.');
        }
    }

    public function read(string $path): string
    {
        $handle = $this->createHandle('GET', $path);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $body = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($body === false || $status < 200 || $status >= 300) {
            throw new RuntimeException('HTTP storage read failed for "' . $path . '" with status ' . $status . ($error !== '' ? ' (' . $error . ')' : '') . '.');
        }

        return (string)$body;
    }

    public function exists(string $path): bool
    {
        $handle = $this->createHandle('HEAD', $path);
        curl_setopt($handle, CURLOPT_NOBODY, true);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($result === false && $error !== '') {
            throw new RuntimeException('HTTP storage existence check failed for "' . $path . '" (' . $error . ').');
        }

        if (in_array($status, [405, 501], true)) {
            return $this->existsViaGet($path);
        }

        return $status >= 200 && $status < 300;
    }

    public function delete(string $path): void
    {
        $handle = $this->createHandle('DELETE', $path);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($result === false && $error !== '') {
            throw new RuntimeException('HTTP storage delete failed for "' . $path . '" (' . $error . ').');
        }

        if ($status !== 404 && ($status < 200 || $status >= 300)) {
            throw new RuntimeException('HTTP storage delete failed for "' . $path . '" with status ' . $status . '.');
        }
    }

    private function ensureParentDirectories(string $path): void
    {
        $directory = trim(dirname(trim($path, '/')), '.');
        if ($directory === '') {
            return;
        }

        $parts = explode('/', str_replace('\\', '/', $directory));
        $cursor = '';
        foreach ($parts as $part) {
            $segment = trim($part);
            if ($segment === '') {
                continue;
            }

            $cursor = $cursor === '' ? $segment : ($cursor . '/' . $segment);
            $handle = $this->createHandle('MKCOL', $cursor);
            curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($handle);
            $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
            $error = curl_error($handle);
            curl_close($handle);

            if ($result === false && $error !== '') {
                continue;
            }

            if (!in_array($status, [0, 200, 201, 204, 301, 302, 405], true)) {
                break;
            }
        }
    }

    private function existsViaGet(string $path): bool
    {
        $handle = $this->createHandle('GET', $path);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_RANGE, '0-0');
        $result = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($result === false && $error !== '') {
            throw new RuntimeException('HTTP storage existence fallback failed for "' . $path . '" (' . $error . ').');
        }

        return $status >= 200 && $status < 300;
    }

    private function createHandle(string $method, string $path)
    {
        $handle = curl_init($this->urlFor($path));
        if ($handle === false) {
            throw new RuntimeException('Failed to initialize the HTTP storage client.');
        }

        curl_setopt($handle, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($handle, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, $this->timeout);
        curl_setopt($handle, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, $this->verifyTls);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, $this->verifyTls ? 2 : 0);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $this->headers);
        if ($this->username !== null && $this->password !== null) {
            curl_setopt($handle, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($handle, CURLOPT_USERPWD, $this->username . ':' . $this->password);
        }

        return $handle;
    }

    private function urlFor(string $path): string
    {
        $segments = array_values(array_filter(
            explode('/', str_replace('\\', '/', trim($path))),
            static fn (string $segment): bool => $segment !== ''
        ));
        $encoded = implode('/', array_map('rawurlencode', $segments));
        return rtrim($this->baseUrl, '/') . '/' . $encoded;
    }
}
