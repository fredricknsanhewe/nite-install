<?php
namespace App\Services;

use App\Config\Env;
use App\Models\CourseModel;
use App\Models\GalleryModel;
use App\Models\NewsPostModel;
use App\Models\PageModel;
use App\Models\ResourceModel;
use App\Models\SiteSettingsModel;
use App\Models\TrainingEventModel;

final class PublicSiteService
{
    /**
     * @return array<string, mixed>
     */
    public function bootstrap(): array
    {
        $settings = new SiteSettingsModel();
        $siteSettings = $settings->all('public');
        $pages = new PageModel();
        $news = new NewsPostModel();
        $events = new TrainingEventModel();
        $resources = new ResourceModel();
        $gallery = new GalleryModel();
        $courses = new CourseModel();

        return [
            'settings' => $siteSettings,
            'site_identity' => $this->siteIdentity($siteSettings),
            'pages' => $pages->list([], false),
            'featured_news' => $news->list(['featured' => true, 'limit' => 5], false),
            'latest_news' => $news->list(['limit' => 8], false),
            'upcoming_events' => $events->list(['limit' => 8], false),
            'featured_resources' => $resources->list(['featured' => true, 'limit' => 8], false),
            'featured_courses' => $courses->listCourses(['featured' => true], false),
            'gallery_albums' => $gallery->listAlbums([], false),
            'gallery_items' => array_slice($gallery->listItems([], false), 0, 12),
        ];
    }

    /**
     * @param array<string, array<string, mixed>> $siteSettings
     * @return array<string, mixed>
     */
    private function siteIdentity(array $siteSettings): array
    {
        $global = is_array($siteSettings['global']['settings'] ?? null)
            ? $siteSettings['global']['settings']
            : [];
        $logoUrl = $this->firstString([
            $global['logo_url'] ?? null,
            $global['brand_logo_url'] ?? null,
        ]);
        $faviconUrl = $this->firstString([
            $global['favicon_url'] ?? null,
            $global['favicon_32_url'] ?? null,
            $logoUrl,
        ]);

        return [
            'title' => $this->firstString([
                $global['site_name'] ?? null,
                Env::get('APP_NAME', 'Nite'),
            ]),
            'short_name' => $this->firstString([
                $global['site_short_name'] ?? null,
                Env::get('APP_SHORT_NAME', Env::get('APP_NAME', 'Nite')),
            ]),
            'logo_url' => $logoUrl,
            'favicon_url' => $faviconUrl,
            'icons' => [
                'favicon_16' => $this->firstString([$global['favicon_16_url'] ?? null, $faviconUrl]),
                'favicon_32' => $this->firstString([$global['favicon_32_url'] ?? null, $faviconUrl]),
                'favicon_48' => $this->firstString([$global['favicon_48_url'] ?? null, $faviconUrl]),
                'apple_touch_icon' => $this->firstString([$global['apple_touch_icon_url'] ?? null, $faviconUrl]),
                'android_192' => $this->firstString([$global['android_chrome_192_url'] ?? null, $faviconUrl]),
                'android_512' => $this->firstString([$global['android_chrome_512_url'] ?? null, $faviconUrl]),
                'manifest' => $this->firstString([$global['manifest_url'] ?? null, '/site.webmanifest']),
            ],
        ];
    }

    /**
     * @param array<int, mixed> $values
     */
    private function firstString(array $values): string
    {
        foreach ($values as $value) {
            $text = trim((string)$value);
            if ($text !== '') {
                return $text;
            }
        }

        return '';
    }
}
