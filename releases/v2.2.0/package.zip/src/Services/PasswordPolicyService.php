<?php
namespace App\Services;

use App\Config\AuthConfig;
use App\Config\Env;
use App\Exceptions\ValidationException;
use App\Models\SiteSettingsModel;
use App\Models\UserPasswordHistoryModel;
use RuntimeException;

final class PasswordPolicyService
{
    private const SETTINGS_KEY = 'password_policy';

    /**
     * @return array<string, mixed>
     */
    public function current(): array
    {
        $defaults = $this->defaults();
        try {
            $record = (new SiteSettingsModel())->get(self::SETTINGS_KEY);
            $settings = is_array($record['settings'] ?? null) ? $record['settings'] : [];
            return $this->normalize($settings + $defaults);
        } catch (\Throwable) {
            return $defaults;
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(array $data, string $actorUserId = ''): array
    {
        $settings = $this->normalize($data + $this->current());
        return (new SiteSettingsModel())->upsert(self::SETTINGS_KEY, 'admin', $settings, $actorUserId);
    }

    public function assert(string $password, string $field = 'password'): void
    {
        $settings = $this->current();
        $errors = [];
        $minLength = (int)$settings['min_length'];

        if (mb_strlen($password) < $minLength) {
            $errors[] = 'Password must be at least ' . $minLength . ' characters long.';
        }
        if ((bool)$settings['require_uppercase'] && preg_match('/[A-Z]/', $password) !== 1) {
            $errors[] = 'Password must include at least one uppercase letter.';
        }
        if ((bool)$settings['require_lowercase'] && preg_match('/[a-z]/', $password) !== 1) {
            $errors[] = 'Password must include at least one lowercase letter.';
        }
        if ((bool)$settings['require_number'] && preg_match('/\d/', $password) !== 1) {
            $errors[] = 'Password must include at least one number.';
        }
        if ((bool)$settings['require_symbol'] && preg_match('/[^a-zA-Z0-9]/', $password) !== 1) {
            $errors[] = 'Password must include at least one symbol.';
        }

        if ($errors !== []) {
            throw new ValidationException([$field => $errors]);
        }
    }

    public function assertNotRecentlyUsed(string $userId, string $password, string $field = 'password'): void
    {
        $settings = $this->current();
        $historyCount = (int)$settings['password_history_count'];
        if ($historyCount < 1 || trim($userId) === '') {
            return;
        }

        $history = new UserPasswordHistoryModel();
        foreach ($history->latestForUser($userId, $historyCount) as $row) {
            if (password_verify($password, (string)($row['password_hash'] ?? ''))) {
                throw new ValidationException([$field => ['Password was used recently. Choose a different password.']]);
            }
        }
    }

    /**
     * @param array<string, mixed> $user
     * @return array{required: bool, reason: string|null}
     */
    public function changeRequirement(array $user): array
    {
        if ($this->bool($user['force_password_change'] ?? false)) {
            return ['required' => true, 'reason' => 'forced'];
        }

        $settings = $this->current();
        $maxAgeDays = (int)$settings['password_max_age_days'];
        if ($maxAgeDays < 1) {
            return ['required' => false, 'reason' => null];
        }

        $changedAt = trim((string)($user['password_changed_at'] ?? $user['created_at'] ?? ''));
        $changedTimestamp = $changedAt === '' ? false : strtotime($changedAt);
        if ($changedTimestamp === false) {
            return ['required' => true, 'reason' => 'missing_change_date'];
        }

        $expiresAt = $changedTimestamp + ($maxAgeDays * 86400);
        if ($expiresAt <= time()) {
            return ['required' => true, 'reason' => 'expired'];
        }

        return ['required' => false, 'reason' => null];
    }

    /**
     * @return array<string, mixed>
     */
    public function defaults(): array
    {
        return [
            'min_length' => AuthConfig::passwordMinLength(),
            'require_uppercase' => AuthConfig::requireUppercase(),
            'require_lowercase' => AuthConfig::requireLowercase(),
            'require_number' => AuthConfig::requireNumber(),
            'require_symbol' => AuthConfig::requireSymbol(),
            'password_max_age_days' => max(0, Env::int('AUTH_PASSWORD_MAX_AGE_DAYS', 90)),
            'password_history_count' => max(0, Env::int('AUTH_PASSWORD_HISTORY_COUNT', 5)),
            'reset_token_ttl_minutes' => max(5, Env::int('AUTH_PASSWORD_RESET_TTL_MINUTES', 60)),
            'force_change_on_admin_reset' => Env::bool('AUTH_FORCE_CHANGE_ON_ADMIN_PASSWORD_RESET', true),
            'force_change_on_admin_created_user' => Env::bool('AUTH_FORCE_CHANGE_ON_ADMIN_CREATED_USER', false),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private function normalize(array $settings): array
    {
        $minLength = max(8, min(128, (int)($settings['min_length'] ?? 12)));
        $maxAgeDays = max(0, min(3650, (int)($settings['password_max_age_days'] ?? 90)));
        $historyCount = max(0, min(24, (int)($settings['password_history_count'] ?? 5)));
        $resetTtl = max(5, min(1440, (int)($settings['reset_token_ttl_minutes'] ?? 60)));

        if ($minLength < 8) {
            throw new RuntimeException('Minimum password length must be at least 8.');
        }

        return [
            'min_length' => $minLength,
            'require_uppercase' => $this->bool($settings['require_uppercase'] ?? true),
            'require_lowercase' => $this->bool($settings['require_lowercase'] ?? true),
            'require_number' => $this->bool($settings['require_number'] ?? true),
            'require_symbol' => $this->bool($settings['require_symbol'] ?? true),
            'password_max_age_days' => $maxAgeDays,
            'password_history_count' => $historyCount,
            'reset_token_ttl_minutes' => $resetTtl,
            'force_change_on_admin_reset' => $this->bool($settings['force_change_on_admin_reset'] ?? true),
            'force_change_on_admin_created_user' => $this->bool($settings['force_change_on_admin_created_user'] ?? false),
        ];
    }

    private function bool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int)$value !== 0;
        }
        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }

        return !empty($value);
    }
}
