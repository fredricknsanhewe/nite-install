<?php
namespace App\Services;

use App\Models\CustomerAccountModel;

final class CustomerAccountService
{
    private CustomerAccountModel $customerAccounts;

    public function __construct()
    {
        $this->customerAccounts = new CustomerAccountModel();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->customerAccounts->list($filters, $admin);
    }

    public function showPublic(string $slug): ?array
    {
        return $this->customerAccounts->findBySlug($slug, false);
    }

    public function showAdmin(string $id): ?array
    {
        return $this->customerAccounts->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->customerAccounts->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->customerAccounts->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->customerAccounts->delete($id);
    }

    public function count(): int
    {
        return $this->customerAccounts->count();
    }
}