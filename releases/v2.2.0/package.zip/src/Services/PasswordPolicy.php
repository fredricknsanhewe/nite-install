<?php
namespace App\Services;

final class PasswordPolicy
{
    public static function assert(string $password, string $field = 'password'): void
    {
        (new PasswordPolicyService())->assert($password, $field);
    }
}
