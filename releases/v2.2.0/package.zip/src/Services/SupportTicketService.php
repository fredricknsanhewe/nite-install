<?php
namespace App\Services;

use App\Models\SupportTicketModel;

final class SupportTicketService
{
    private SupportTicketModel $supportTickets;

    public function __construct()
    {
        $this->supportTickets = new SupportTicketModel();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->supportTickets->list($filters, $admin);
    }

    public function showPublic(string $slug): ?array
    {
        return $this->supportTickets->findBySlug($slug, false);
    }

    public function showAdmin(string $id): ?array
    {
        return $this->supportTickets->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->supportTickets->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->supportTickets->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->supportTickets->delete($id);
    }

    public function count(): int
    {
        return $this->supportTickets->count();
    }
}