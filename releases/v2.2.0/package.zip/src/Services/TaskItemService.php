<?php
namespace App\Services;

use App\Models\TaskItemModel;

final class TaskItemService
{
    private TaskItemModel $taskItems;

    public function __construct()
    {
        $this->taskItems = new TaskItemModel();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->taskItems->list($filters, $admin);
    }

    public function showPublic(string $slug): ?array
    {
        return $this->taskItems->findBySlug($slug, false);
    }

    public function showAdmin(string $id): ?array
    {
        return $this->taskItems->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->taskItems->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->taskItems->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->taskItems->delete($id);
    }

    public function count(): int
    {
        return $this->taskItems->count();
    }
}