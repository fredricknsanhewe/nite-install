<?php
namespace App\Services;

use App\Models\ProjectBoardModel;

final class ProjectBoardService
{
    private ProjectBoardModel $projectBoards;

    public function __construct()
    {
        $this->projectBoards = new ProjectBoardModel();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->projectBoards->list($filters, $admin);
    }

    public function showPublic(string $slug): ?array
    {
        return $this->projectBoards->findBySlug($slug, false);
    }

    public function showAdmin(string $id): ?array
    {
        return $this->projectBoards->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->projectBoards->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->projectBoards->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->projectBoards->delete($id);
    }

    public function count(): int
    {
        return $this->projectBoards->count();
    }
}