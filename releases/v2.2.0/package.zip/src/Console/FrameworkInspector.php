<?php
namespace App\Console;

use App\Config\App;
use App\Config\AuthConfig;
use App\Config\Database;
use App\Config\Env;
use App\Config\MailConfig;
use App\Config\MediaConfig;
use App\Config\PermissionCatalog;
use App\Models\MailQueueModel;
use App\Storage\MediaStorageManager;
use App\Support\ApiExplorerCatalog;
use App\Support\GeneratedResourceRegistry;
use App\Support\NiteModuleCatalog;

final class FrameworkInspector
{
    private string $rootPath;
    private MigrationManager $migrations;
    private VersionManager $versions;
    private GitHubReleaseManager $releases;

    public function __construct(
        ?string $rootPath = null,
        ?MigrationManager $migrations = null,
        ?VersionManager $versions = null,
        ?GitHubReleaseManager $releases = null
    ) {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
        $this->migrations = $migrations ?? new MigrationManager($this->rootPath);
        $this->versions = $versions ?? new VersionManager($this->rootPath);
        $this->releases = $releases ?? new GitHubReleaseManager($this->rootPath);
    }

    /**
     * @return array<string, mixed>
     */
    public function about(): array
    {
        $summary = ApiExplorerCatalog::summary();
        $version = $this->versions->info();
        $generated = GeneratedResourceRegistry::manifests($this->rootPath);

        return [
            'application' => App::NAME,
            'code_version' => App::VERSION,
            'installed_version' => (string)($version['installed_version'] ?? App::VERSION),
            'installed_tag' => (string)($version['installed_tag'] ?? ('v' . App::VERSION)),
            'php_version' => PHP_VERSION,
            'php_sapi' => PHP_SAPI,
            'repository' => is_array($version['repository'] ?? null) ? $version['repository'] : $this->releases->repository(),
            'project' => $this->activeProject(),
            'storage' => (new MediaStorageManager($this->rootPath))->summary(),
            'auth' => [
                'password_min_length' => AuthConfig::passwordMinLength(),
                'throttle_enabled' => AuthConfig::throttleEnabled(),
                'token_issuer' => AuthConfig::tokenIssuer(),
                'token_audience' => AuthConfig::tokenAudience(),
            ],
            'mail' => $this->mailSummary(),
            'api' => $summary,
            'counts' => [
                'modules' => count(NiteModuleCatalog::modules()),
                'resources' => count(ApiExplorerCatalog::resources()),
                'generated_resources' => count($generated),
                'routes' => count(ApiExplorerCatalog::routeDocsMap()),
                'permissions' => count(PermissionCatalog::definitions()),
            ],
            'docs' => [
                'routes' => '/api/v1/meta/routes',
                'resources' => '/api/v1/meta/resources',
                'framework' => '/api/v1/framework',
                'modules' => '/api/v1/framework/modules',
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function activeProject(): array
    {
        $slug = trim((string)Env::get('NITE_PROJECT', ''));
        if ($slug === '') {
            return [];
        }

        return [
            'slug' => $slug,
            'name' => trim((string)Env::get('NITE_PROJECT_NAME', $slug)),
            'app_url' => trim((string)Env::get('APP_URL', '')),
        ];
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function routes(array $filters = []): array
    {
        $generatedKeys = array_fill_keys(array_keys(GeneratedResourceRegistry::manifests($this->rootPath)), true);
        $routes = [];

        foreach (array_values(ApiExplorerCatalog::routeDocsMap()) as $route) {
            if (!is_array($route)) {
                continue;
            }

            $method = strtoupper(trim((string)($route['method'] ?? 'GET')));
            $path = trim((string)($route['path'] ?? ''));
            $permissions = array_values(array_filter(
                array_map('strval', is_array($route['permissions'] ?? null) ? $route['permissions'] : []),
                static fn (string $value): bool => trim($value) !== ''
            ));
            $resourceKey = trim((string)($route['resource_key'] ?? ''));
            $item = [
                'method' => $method,
                'path' => $path,
                'summary' => trim((string)($route['summary'] ?? '')),
                'resource_key' => $resourceKey,
                'resource_label' => trim((string)($route['resource_label'] ?? $resourceKey)),
                'auth_required' => (bool)($route['auth_required'] ?? false),
                'permissions' => $permissions,
                'permission_default_roles' => array_values(array_filter(
                    array_map('strval', is_array($route['permission_default_roles'] ?? null) ? $route['permission_default_roles'] : []),
                    static fn (string $value): bool => trim($value) !== ''
                )),
                'access' => $this->routeAccess($path, (bool)($route['auth_required'] ?? false), $permissions),
                'generated' => $resourceKey !== '' && isset($generatedKeys[$resourceKey]),
            ];

            if (!$this->routeMatches($item, $filters)) {
                continue;
            }

            $routes[] = $item;
        }

        usort($routes, static function (array $left, array $right): int {
            return [$left['path'], $left['method']] <=> [$right['path'], $right['method']];
        });

        return $routes;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function resources(array $filters = []): array
    {
        $generated = array_fill_keys(array_keys(GeneratedResourceRegistry::manifests($this->rootPath)), true);
        $items = [];

        foreach (ApiExplorerCatalog::resources() as $resource) {
            if (!is_array($resource)) {
                continue;
            }

            $key = trim((string)($resource['key'] ?? ''));
            $routes = array_values(is_array($resource['routes'] ?? null) ? $resource['routes'] : []);
            $routeCount = count($routes);
            $writeCount = count(array_filter($routes, static function (array $route): bool {
                return in_array(strtoupper((string)($route['method'] ?? 'GET')), ['POST', 'PUT', 'PATCH', 'DELETE'], true);
            }));
            $item = [
                'key' => $key,
                'label' => trim((string)($resource['label'] ?? $key)),
                'group' => trim((string)($resource['group'] ?? '')),
                'item_type' => trim((string)($resource['item_type'] ?? '')),
                'table' => trim((string)($resource['table'] ?? '')),
                'summary' => trim((string)($resource['summary'] ?? '')),
                'route_count' => $routeCount,
                'write_route_count' => $writeCount,
                'field_count' => count(array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : [])),
                'default_data_path' => trim((string)($resource['default_data_path'] ?? '')),
                'default_data_auth_required' => (bool)($resource['default_data_auth_required'] ?? false),
                'generated' => $key !== '' && isset($generated[$key]),
            ];

            if (!$this->resourceMatches($item, $filters)) {
                continue;
            }

            $items[] = $item;
        }

        usort($items, static function (array $left, array $right): int {
            return [$left['group'], $left['key']] <=> [$right['group'], $right['key']];
        });

        return $items;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function modules(array $filters = []): array
    {
        $resourceMap = ApiExplorerCatalog::resources();
        $items = [];

        foreach (NiteModuleCatalog::modules() as $key => $module) {
            if (!is_array($module)) {
                continue;
            }

            $entities = array_values(array_filter(
                array_map('strval', is_array($module['entities'] ?? null) ? $module['entities'] : []),
                static fn (string $value): bool => trim($value) !== ''
            ));
            $resourceKeys = [];
            foreach ($resourceMap as $resource) {
                if (!is_array($resource)) {
                    continue;
                }

                $resourceKey = trim((string)($resource['key'] ?? ''));
                $resourceGroup = trim((string)($resource['group'] ?? ''));
                if ($resourceKey === '') {
                    continue;
                }

                if (
                    $resourceGroup === $key
                    || in_array($resourceKey, $entities, true)
                    || in_array(ConsoleSupport::singularize($resourceKey), $entities, true)
                ) {
                    $resourceKeys[] = $resourceKey;
                }
            }

            sort($resourceKeys, SORT_STRING);
            $item = [
                'key' => (string)$key,
                'title' => trim((string)($module['title'] ?? $key)),
                'summary' => trim((string)($module['summary'] ?? '')),
                'entities' => $entities,
                'entity_count' => count($entities),
                'resources' => array_values(array_unique($resourceKeys)),
                'resource_count' => count(array_unique($resourceKeys)),
            ];

            if (!$this->moduleMatches($item, $filters)) {
                continue;
            }

            $items[] = $item;
        }

        usort($items, static function (array $left, array $right): int {
            return [$left['key']] <=> [$right['key']];
        });

        return $items;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function permissions(array $filters = []): array
    {
        $generatedCodes = array_fill_keys(array_map(
            static fn (array $definition): string => (string)($definition['code'] ?? ''),
            GeneratedResourceRegistry::permissionDefinitions($this->rootPath)
        ), true);

        $items = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            if (!is_array($definition)) {
                continue;
            }

            $code = trim((string)($definition['code'] ?? ''));
            $item = [
                'code' => $code,
                'title' => trim((string)($definition['title'] ?? $code)),
                'description' => trim((string)($definition['description'] ?? '')),
                'section_code' => trim((string)($definition['section_code'] ?? '')),
                'section_title' => trim((string)($definition['section_title'] ?? '')),
                'module_code' => trim((string)($definition['module_code'] ?? '')),
                'module_title' => trim((string)($definition['module_title'] ?? '')),
                'action_code' => trim((string)($definition['action_code'] ?? '')),
                'action_title' => trim((string)($definition['action_title'] ?? '')),
                'default_roles' => array_values(array_filter(
                    array_map('strval', is_array($definition['default_roles'] ?? null) ? $definition['default_roles'] : []),
                    static fn (string $value): bool => trim($value) !== ''
                )),
                'generated' => $code !== '' && isset($generatedCodes[$code]),
            ];

            if (!$this->permissionMatches($item, $filters)) {
                continue;
            }

            $items[] = $item;
        }

        usort($items, static function (array $left, array $right): int {
            return [$left['section_code'], $left['module_code'], $left['code']] <=> [$right['section_code'], $right['module_code'], $right['code']];
        });

        return $items;
    }

    /**
     * @return array<string, mixed>
     */
    public function doctor(): array
    {
        $checks = [];
        $appEnv = $this->appEnvironment();
        $production = $this->isProductionEnvironment($appEnv);
        $debugEnabled = Env::bool('APP_DEBUG', false);
        $browsableEnabled = Env::bool('NITE_BROWSABLE_API', Env::bool('NITE_HTML_INTERFACE_ENABLED', true));

        $checks[] = $this->check(
            'runtime',
            'php',
            version_compare(PHP_VERSION, '8.1.0', '>=') ? 'ok' : 'warn',
            'PHP runtime',
            PHP_VERSION . ' (' . PHP_SAPI . ')'
        );
        $checks[] = $this->check('runtime', 'app', 'ok', 'Application version', App::VERSION);
        $checks[] = $this->check('runtime', 'app_env', 'ok', 'Application environment', $appEnv);
        $checks[] = $this->check(
            'runtime',
            'app_debug',
            $production && $debugEnabled ? 'error' : ($debugEnabled ? 'warn' : 'ok'),
            'Debug mode',
            $debugEnabled ? 'enabled' : 'disabled'
        );
        $checks[] = $this->check(
            'runtime',
            'browsable_api',
            $production && $browsableEnabled ? 'error' : 'ok',
            'Browsable API',
            $browsableEnabled ? 'enabled' : 'disabled'
        );
        $checks[] = $this->check(
            'auth',
            'jwt_secret',
            AuthConfig::jwtSecretIsWeak() ? ($production ? 'error' : 'warn') : 'ok',
            'JWT secret',
            AuthConfig::jwtSecretIsWeak() ? 'missing, placeholder, or shorter than 32 characters' : 'configured'
        );
        $checks[] = $this->check(
            'auth',
            'password_policy',
            AuthConfig::passwordMinLength() >= 10 ? 'ok' : 'warn',
            'Password policy',
            'min_length=' . AuthConfig::passwordMinLength()
        );
        $checks[] = $this->check(
            'auth',
            'login_throttle',
            AuthConfig::throttleEnabled() ? 'ok' : 'warn',
            'Login throttle',
            AuthConfig::throttleEnabled() ? 'enabled' : 'disabled'
        );
        $checks[] = $this->check(
            'media',
            'upload_max_bytes',
            MediaConfig::uploadMaxBytes() > 0 ? 'ok' : 'error',
            'Media upload max size',
            (string)MediaConfig::uploadMaxBytes()
        );
        $checks[] = $this->check(
            'media',
            'upload_allowlist',
            MediaConfig::allowedMimeTypes() !== [] || MediaConfig::allowedExtensions() !== [] ? 'ok' : 'warn',
            'Media upload allowlist',
            'mime_types=' . count(MediaConfig::allowedMimeTypes()) . ', extensions=' . count(MediaConfig::allowedExtensions())
        );
        $checks[] = $this->check(
            'mail',
            'enabled',
            MailConfig::enabled() ? 'ok' : 'warn',
            'Outbound mail',
            MailConfig::enabled() ? 'enabled' : 'disabled'
        );
        $checks[] = $this->check(
            'mail',
            'queue_mode',
            'ok',
            'Mail queue mode',
            MailConfig::queueMode()
        );
        $checks[] = $this->check(
            'mail',
            'transport',
            MailConfig::enabled() ? 'ok' : 'warn',
            'Mail transport',
            (string)(MailConfig::summary()['dsn'] ?? MailConfig::transport())
        );

        $mailSummary = MailConfig::summary();
        $fromAddress = trim((string)($mailSummary['from']['address'] ?? ''));
        $checks[] = $this->check(
            'mail',
            'from_address',
            !$this->mailRequiresFromAddress() || $fromAddress !== '' ? 'ok' : 'error',
            'Mail from address',
            $fromAddress !== '' ? $fromAddress : 'missing'
        );
        if (MailConfig::dkimEnabled()) {
            $dkim = MailConfig::dkimOptions();
            $keyPath = trim((string)($dkim['private_key_path'] ?? ''));
            $checks[] = $this->check(
                'mail',
                'dkim_key',
                $keyPath !== '' && is_file($keyPath) ? 'ok' : 'error',
                'DKIM private key',
                $keyPath !== '' ? $keyPath : 'missing'
            );
            $checks[] = $this->check(
                'mail',
                'openssl',
                extension_loaded('openssl') ? 'ok' : 'error',
                'DKIM OpenSSL support',
                extension_loaded('openssl') ? 'openssl enabled' : 'openssl extension is required for DKIM signing'
            );
        }

        $driver = Database::driver();
        $checks[] = $this->check(
            'database',
            'password',
            $production && $this->databasePasswordLooksDefault() ? 'error' : 'ok',
            'Database password',
            $this->databasePasswordLooksDefault() ? 'default or empty local credential' : 'configured'
        );
        $checks[] = $this->check('extensions', 'pdo', extension_loaded('pdo') ? 'ok' : 'error', 'PHP extension', 'pdo');
        $checks[] = $this->check(
            'extensions',
            $driver,
            extension_loaded($driver === 'mysql' ? 'pdo_mysql' : 'pdo_pgsql') ? 'ok' : 'error',
            'Database extension',
            $driver === 'mysql' ? 'pdo_mysql' : 'pdo_pgsql'
        );
        $checks[] = $this->check('extensions', 'json', extension_loaded('json') ? 'ok' : 'error', 'PHP extension', 'json');
        $checks[] = $this->check(
            'extensions',
            'curl',
            function_exists('curl_init') ? 'ok' : 'warn',
            'GitHub HTTP client',
            function_exists('curl_init') ? 'curl enabled' : 'curl missing, stream fallback will be used'
        );
        $checks[] = $this->check(
            'extensions',
            'zip',
            class_exists(\ZipArchive::class) ? 'ok' : 'error',
            'Release archive support',
            class_exists(\ZipArchive::class) ? 'ZipArchive available' : 'ZipArchive is required for install and upgrade archives'
        );

        $checks[] = $this->pathCheck('filesystem', '.env', $this->rootPath . '/.env', 'file');
        $checks[] = $this->pathCheck('filesystem', 'storage', $this->rootPath . '/storage', 'directory');
        $checks[] = $this->pathCheck('filesystem', 'public_uploads', $this->rootPath . '/public/uploads', 'directory');
        $checks[] = $this->pathCheck('filesystem', 'generated_routes', $this->rootPath . '/routes/generated', 'directory');
        $checks[] = $this->pathCheck('filesystem', 'migrations', $this->rootPath . '/database/migrations', 'directory');
        foreach ($this->storageChecks() as $check) {
            $checks[] = $check;
        }

        $repo = $this->releases->repository();
        $checks[] = $this->check(
            'release',
            'repository',
            trim((string)($repo['url'] ?? '')) !== '' ? 'ok' : 'error',
            'Public repository',
            (string)($repo['url'] ?? '')
        );

        $conflicts = $this->migrations->migrationConflicts();
        $duplicateIds = count((array)($conflicts['duplicate_ids'] ?? []));
        $duplicateNames = count((array)($conflicts['duplicate_names'] ?? []));
        $checks[] = $this->check(
            'migrations',
            'conflicts',
            ($duplicateIds + $duplicateNames) === 0 ? 'ok' : 'error',
            'Migration file conflicts',
            ($duplicateIds + $duplicateNames) === 0
                ? 'none'
                : ($duplicateIds . ' duplicate ids, ' . $duplicateNames . ' duplicate names')
        );
        foreach ($this->apiContractChecks() as $check) {
            $checks[] = $check;
        }

        try {
            Database::connection();
            $checks[] = $this->check(
                'database',
                'connection',
                'ok',
                'Database connection',
                $driver . ' ' . $this->databaseTarget()
            );

            try {
                $status = $this->migrations->status();
                $checks[] = $this->check(
                    'database',
                    'migrations',
                    'ok',
                    'Migration status',
                    count((array)($status['applied'] ?? [])) . ' applied, ' . count((array)($status['pending'] ?? [])) . ' pending'
                );
            } catch (\Throwable $e) {
                $checks[] = $this->check('database', 'migrations', 'warn', 'Migration status', $e->getMessage());
            }

            try {
                $mailQueue = new MailQueueModel();
                $counts = $mailQueue->statusCounts();
                $checks[] = $this->check(
                    'mail',
                    'queue_status',
                    'ok',
                    'Mail queue status',
                    'queued=' . (int)($counts['queued'] ?? 0)
                    . ', processing=' . (int)($counts['processing'] ?? 0)
                    . ', sent=' . (int)($counts['sent'] ?? 0)
                    . ', failed=' . (int)($counts['failed'] ?? 0)
                );
                $queueSummary = (new \App\Services\MailService())->queueSummary();
                $checks[] = $this->check(
                    'mail',
                    'queue_worker',
                    'ok',
                    'Mail queue worker',
                    'sleep=' . (int)($queueSummary['worker_sleep_seconds'] ?? 0)
                    . 's, batch=' . (int)($queueSummary['batch_size'] ?? 0)
                    . ', pending=' . (int)($queueSummary['pending'] ?? 0)
                );
            } catch (\Throwable $e) {
                $checks[] = $this->check('mail', 'queue_status', 'warn', 'Mail queue status', $e->getMessage());
            }
        } catch (\Throwable $e) {
            $checks[] = $this->check(
                'database',
                'connection',
                'error',
                'Database connection',
                $driver . ' ' . $this->databaseTarget() . ' - ' . $e->getMessage()
            );
        }

        $summary = ['ok' => 0, 'warn' => 0, 'error' => 0];
        foreach ($checks as $check) {
            $status = (string)($check['status'] ?? 'warn');
            if (!isset($summary[$status])) {
                $summary[$status] = 0;
            }
            $summary[$status]++;
        }

        return [
            'summary' => $summary,
            'counts' => [
                'modules' => count(NiteModuleCatalog::modules()),
                'resources' => count(ApiExplorerCatalog::resources()),
                'routes' => count(ApiExplorerCatalog::routeDocsMap()),
                'permissions' => count(PermissionCatalog::definitions()),
            ],
            'checks' => $checks,
        ];
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $filters
     */
    private function routeMatches(array $item, array $filters): bool
    {
        $method = strtoupper(trim((string)($filters['method'] ?? '')));
        if ($method !== '' && $item['method'] !== $method) {
            return false;
        }

        $path = trim((string)($filters['path'] ?? ''));
        if ($path !== '' && stripos((string)$item['path'], $path) === false) {
            return false;
        }

        $resource = trim((string)($filters['resource'] ?? ''));
        if ($resource !== '' && (string)$item['resource_key'] !== $resource) {
            return false;
        }

        $permission = trim((string)($filters['permission'] ?? ''));
        if (
            $permission !== ''
            && !array_filter((array)$item['permissions'], static function (string $code) use ($permission): bool {
                return stripos($code, $permission) !== false;
            })
        ) {
            return false;
        }

        $accessFilters = [];
        foreach (['public', 'auth', 'admin', 'protected'] as $key) {
            if (!empty($filters[$key])) {
                $accessFilters[$key] = true;
            }
        }

        if ($accessFilters !== []) {
            $routeAccess = (string)$item['access'];
            $matchesAccess = isset($accessFilters[$routeAccess])
                || (isset($accessFilters['protected']) && $routeAccess !== 'public');
            if (!$matchesAccess) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function storageChecks(): array
    {
        $storage = (new MediaStorageManager($this->rootPath))->summary();
        $driver = trim((string)($storage['driver'] ?? 'local'));
        $checks = [
            $this->check('storage', 'driver', 'ok', 'Media storage driver', $driver),
        ];

        if ($driver === 'local') {
            $checks[] = $this->pathCheck('storage', 'local_root', (string)($storage['root'] ?? ($this->rootPath . '/storage/media')), 'directory');
            return $checks;
        }

        if ($driver === 'ftp') {
            $checks[] = $this->check(
                'storage',
                'ftp_host',
                trim((string)($storage['host'] ?? '')) !== '' ? 'ok' : 'error',
                'FTP storage host',
                (string)($storage['host'] ?? '')
            );
            return $checks;
        }

        if ($driver === 's3') {
            $checks[] = $this->check(
                'storage',
                's3_bucket',
                trim((string)($storage['bucket'] ?? '')) !== '' ? 'ok' : 'error',
                'S3 bucket',
                (string)($storage['bucket'] ?? '')
            );
            return $checks;
        }

        if ($driver === 'http') {
            $checks[] = $this->check(
                'storage',
                'http_base_url',
                trim((string)($storage['base_url'] ?? '')) !== '' ? 'ok' : 'error',
                'HTTP storage base URL',
                (string)($storage['base_url'] ?? '')
            );
        }

        return $checks;
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $filters
     */
    private function resourceMatches(array $item, array $filters): bool
    {
        $key = trim((string)($filters['key'] ?? ''));
        if (
            $key !== ''
            && stripos((string)$item['key'], $key) === false
            && stripos((string)$item['label'], $key) === false
        ) {
            return false;
        }

        $group = trim((string)($filters['group'] ?? ''));
        if ($group !== '' && (string)$item['group'] !== $group) {
            return false;
        }

        if (!empty($filters['generated']) && !(bool)$item['generated']) {
            return false;
        }

        if (!empty($filters['built-in']) && (bool)$item['generated']) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $filters
     */
    private function moduleMatches(array $item, array $filters): bool
    {
        $module = trim((string)($filters['module'] ?? ''));
        if (
            $module !== ''
            && stripos((string)$item['key'], $module) === false
            && stripos((string)$item['title'], $module) === false
        ) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $filters
     */
    private function permissionMatches(array $item, array $filters): bool
    {
        $code = trim((string)($filters['code'] ?? ''));
        if (
            $code !== ''
            && stripos((string)$item['code'], $code) === false
            && stripos((string)$item['title'], $code) === false
        ) {
            return false;
        }

        $module = trim((string)($filters['module'] ?? ''));
        if (
            $module !== ''
            && stripos((string)$item['module_code'], $module) === false
            && stripos((string)$item['module_title'], $module) === false
        ) {
            return false;
        }

        $role = trim((string)($filters['role'] ?? ''));
        if ($role !== '' && !in_array($role, (array)$item['default_roles'], true)) {
            return false;
        }

        $section = trim((string)($filters['section'] ?? ''));
        if (
            $section !== ''
            && stripos((string)$item['section_code'], $section) === false
            && stripos((string)$item['section_title'], $section) === false
        ) {
            return false;
        }

        if (!empty($filters['generated']) && !(bool)$item['generated']) {
            return false;
        }

        return true;
    }

    /**
     * @param array<int, string> $permissions
     */
    private function routeAccess(string $path, bool $authRequired, array $permissions): string
    {
        if (
            str_starts_with($path, '/api/v1/admin')
            || in_array('module.admin_dashboard.access', $permissions, true)
            || array_filter($permissions, static fn (string $code): bool => str_starts_with($code, 'admin.')) !== []
        ) {
            return 'admin';
        }

        return $authRequired ? 'auth' : 'public';
    }

    /**
     * @return array<string, mixed>
     */
    private function check(string $group, string $name, string $status, string $label, string $detail): array
    {
        return [
            'group' => $group,
            'name' => $name,
            'status' => $status,
            'label' => $label,
            'detail' => $detail,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function pathCheck(string $group, string $name, string $path, string $expectation): array
    {
        if ($expectation === 'file') {
            if (is_file($path)) {
                return $this->check($group, $name, 'ok', 'Filesystem', $path);
            }

            $fallback = $path . '.example';
            if (str_ends_with($path, '/.env') && is_file($fallback)) {
                return $this->check($group, $name, 'warn', 'Filesystem', $path . ' missing, using .env.example fallback');
            }

            return $this->check($group, $name, 'error', 'Filesystem', $path . ' missing');
        }

        if (!is_dir($path)) {
            return $this->check($group, $name, 'warn', 'Filesystem', $path . ' missing');
        }

        if (!is_writable($path)) {
            return $this->check($group, $name, 'error', 'Filesystem', $path . ' is not writable');
        }

        return $this->check($group, $name, 'ok', 'Filesystem', $path);
    }

    private function databaseTarget(): string
    {
        $host = trim((string)Env::get('DB_HOST', '127.0.0.1'));
        $port = trim((string)Env::get('DB_PORT', Database::driver() === 'mysql' ? '3306' : '5432'));
        $name = trim((string)Env::get('DB_NAME', 'nite'));
        return $host . ':' . $port . '/' . $name;
    }

    private function appEnvironment(): string
    {
        $value = strtolower(trim((string)Env::get('APP_ENV', 'local')));
        return $value !== '' ? $value : 'local';
    }

    private function isProductionEnvironment(string $environment): bool
    {
        return in_array($environment, ['prod', 'production'], true);
    }

    private function databasePasswordLooksDefault(): bool
    {
        $password = strtolower(trim((string)Env::get('DB_PASSWORD', '')));
        return in_array($password, ['', 'postgres', 'root', 'password', 'secret'], true);
    }

    /**
     * @return array<string, mixed>
     */
    private function mailSummary(): array
    {
        $summary = MailConfig::summary();

        try {
            $queue = new MailQueueModel();
            $summary['queue_counts'] = $queue->statusCounts();
        } catch (\Throwable) {
            $summary['queue_counts'] = [];
        }

        return $summary;
    }

    private function mailRequiresFromAddress(): bool
    {
        return MailConfig::enabled();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function apiContractChecks(): array
    {
        $resources = ApiExplorerCatalog::resources();
        $routes = array_values(ApiExplorerCatalog::routeDocsMap());
        $missingItemReads = [];
        $missingCollectionReads = [];
        $collectionMutations = [];
        $metadataIssues = [];

        foreach ($resources as $resource) {
            if (!is_array($resource)) {
                continue;
            }

            $resourceKey = trim((string)($resource['key'] ?? ''));
            if ($resourceKey === '') {
                continue;
            }

            $resourceRoutes = array_values(is_array($resource['routes'] ?? null) ? $resource['routes'] : []);
            $hasItemWrite = false;
            $hasItemRead = false;
            $hasCreate = false;
            $hasCollectionRead = false;

            foreach ($resourceRoutes as $route) {
                if (!is_array($route)) {
                    continue;
                }

                $method = strtoupper(trim((string)($route['method'] ?? 'GET')));
                $pathParamCount = $this->routePathParamCount($route);
                $returnType = $this->routeReturnType($route);
                $successStatus = (int)($route['response']['success_status'] ?? 200);

                if ($method === 'GET' && $pathParamCount > 0 && !$this->isCollectionReturnType($returnType)) {
                    $hasItemRead = true;
                }
                if (in_array($method, ['PUT', 'PATCH', 'DELETE'], true) && $pathParamCount > 0) {
                    $hasItemWrite = true;
                }
                if ($method === 'POST' && $successStatus === 201) {
                    $hasCreate = true;
                }
                if ($method === 'GET' && $this->isCollectionReturnType($returnType)) {
                    $hasCollectionRead = true;
                }
            }

            if ($hasItemWrite && !$hasItemRead) {
                $missingItemReads[] = $resourceKey;
            }
            if ($hasCreate && !$hasCollectionRead) {
                $missingCollectionReads[] = $resourceKey;
            }
        }

        foreach ($routes as $route) {
            if (!is_array($route)) {
                continue;
            }

            $method = strtoupper(trim((string)($route['method'] ?? 'GET')));
            $path = trim((string)($route['path'] ?? ''));

            if (in_array($method, ['PUT', 'PATCH', 'DELETE'], true) && $this->routePathParamCount($route) === 0) {
                $collectionMutations[] = $method . ' ' . $path;
            }

            $summary = trim((string)($route['summary'] ?? ''));
            if ($summary === '') {
                $metadataIssues[] = $method . ' ' . $path . ' missing summary';
            }

            $request = is_array($route['request'] ?? null) ? $route['request'] : [];
            foreach (['path_params', 'query', 'body'] as $section) {
                foreach (array_values(is_array($request[$section] ?? null) ? $request[$section] : []) as $field) {
                    if (!is_array($field)) {
                        $metadataIssues[] = $method . ' ' . $path . ' has non-object ' . $section . ' field metadata';
                        continue;
                    }

                    $name = trim((string)($field['name'] ?? ''));
                    $dataType = trim((string)($field['data_type'] ?? ''));
                    if ($name === '' || $dataType === '') {
                        $metadataIssues[] = $method . ' ' . $path . ' has incomplete ' . $section . ' field metadata';
                    }
                }
            }
        }

        sort($missingItemReads, SORT_STRING);
        sort($missingCollectionReads, SORT_STRING);
        sort($collectionMutations, SORT_STRING);
        sort($metadataIssues, SORT_STRING);

        return [
            $this->check(
                'rest',
                'item_reads',
                $missingItemReads === [] ? 'ok' : 'error',
                'REST item read coverage',
                $missingItemReads === [] ? 'all writable resources expose an item GET route' : implode(', ', $missingItemReads)
            ),
            $this->check(
                'rest',
                'collection_reads',
                $missingCollectionReads === [] ? 'ok' : 'error',
                'REST collection read coverage',
                $missingCollectionReads === [] ? 'all creatable resources expose a collection GET route' : implode(', ', $missingCollectionReads)
            ),
            $this->check(
                'rest',
                'collection_mutations',
                $collectionMutations === [] ? 'ok' : 'error',
                'REST collection mutation routes',
                $collectionMutations === [] ? 'no PUT/PATCH/DELETE routes are registered on collection paths' : implode('; ', array_slice($collectionMutations, 0, 8))
            ),
            $this->check(
                'metadata',
                'editor_contract',
                $metadataIssues === [] ? 'ok' : 'error',
                'Editor metadata contract',
                $metadataIssues === [] ? 'route summaries and request field metadata are complete' : implode('; ', array_slice($metadataIssues, 0, 8))
            ),
        ];
    }

    private function routePathParamCount(array $route): int
    {
        return count(array_values(
            is_array($route['request']['path_params'] ?? null)
                ? $route['request']['path_params']
                : []
        ));
    }

    private function routeReturnType(array $route): string
    {
        return trim((string)($route['response']['return_type'] ?? ''));
    }

    private function isCollectionReturnType(string $returnType): bool
    {
        return $returnType !== ''
            && (
                str_ends_with($returnType, '[]')
                || str_starts_with($returnType, 'Record<')
            );
    }
}
