# Usage Modes

Nite supports three operating styles from the same codebase:

1. Single-project application mode
2. Multi-project shared framework mode
3. Public framework distribution mode

The goal is not to pick only one forever. You can build one product at the
root, run separate client or tenant projects under `projects/<slug>`, and still
publish tagged framework releases for downstream users.

## 1. Single-Project Application

Use the repository root as one application.

Host-based run:

```bash
composer install
php nite starter:list
php nite app:bootstrap "Acme Website" --starter=website-management --sample-count=120 --seed
php nite app:serve --host=0.0.0.0 --port=8185
```

Docker-based run:

```bash
copy .env.docker.example .env.docker
docker compose up --build
```

Files used in this mode:

- `.env`
- `.env.docker`
- `app.blueprint.json`
- `docs/app-blueprint.md`
- `Dockerfile`
- `docker-compose.yml`

## 2. Multi-Project Shared Framework

Use one shared framework checkout, but give each project its own manifest,
runtime port, database name, media root, host override file, and Docker files.

Create a project:

```bash
php nite app:bootstrap "Project 1" --project=project1 --starter=inventory-management --port=8286 --sample-count=240 --seed
```

Generated project runtime files:

- `projects/project1/project.json`
- `projects/project1/.env`
- `projects/project1/.env.example`
- `projects/project1/.env.docker`
- `projects/project1/.env.docker.example`
- `projects/project1/app.blueprint.json`
- `projects/project1/app-blueprint.md`
- `projects/project1/starter-samples.json`
- `projects/project1/starter-samples.md`
- `projects/project1/Dockerfile`
- `projects/project1/docker-compose.yml`

Host-based run:

```bash
php nite db:migrate --project=project1
php nite app:serve --project=project1
```

Docker-based run:

```bash
docker compose -f projects/project1/docker-compose.yml up --build
```

`projects/<slug>/.env` is for host-based `php nite ... --project=<slug>` runs.
`projects/<slug>/.env.docker` is for container-based runs.

## 3. Public Framework Distribution

Use the repository itself as the product you publish.

Typical flow:

```bash
git tag -a v2.2.0 -m "Nite v2.2.0"
git push origin v2.2.0
gh release create v2.2.0 --generate-notes
php nite app:releases --limit=5
```

When you ship framework releases, keep the other two modes working:

- root single-app setup
- generated project setup
- upgrade and downgrade paths

## Docker Layout

Root mode:

- one shared `.env.docker`
- one shared `Dockerfile`
- one shared `docker-compose.yml`

Project mode:

- one `.env.docker` per project
- one `Dockerfile` per project
- one `docker-compose.yml` per project

This separation keeps single-app development simple while allowing project
deployments to run independently on different ports and databases.
