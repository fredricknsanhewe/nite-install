# Architecture

Nite uses a compact modular backend layout:

- `public/index.php` is the route registry and HTTP entrypoint
- `nite.php` is the preferred console entrypoint for install, update, upgrade, downgrade, migrations, and scaffolding
- `src/Http` contains request, response, router, and middleware primitives
- `src/Controllers` holds HTTP handlers
- `src/Services` holds business workflows and orchestration
- `src/Models` holds database access
- `src/Support` holds framework metadata, route catalogs, and helper utilities

## Runtime

- JWT authentication with custom middleware
- RBAC with active group rules and final user overrides stored in the configured SQL database
- audit logging for request traces
- archive logging for row-level updates, deletes, and restores
- public and protected route groups under `/api/v1/*`
- file upload support through the media service
- self-describing route and resource metadata under `/api/v1/meta/*`
- browsable route index at `/api/v1/meta/routes`, with browser redirects from `/`, `/explorer`, and HTML `/api/v1` requests to that index when HTML is enabled
- REST-oriented endpoint metadata that advertises `HEAD`, `PATCH`, and `OPTIONS` alongside the concrete route handlers
- browser forms that can auto-render relation pickers and media upload helpers from schema metadata
- standalone `/admin` management UI with permission-aware sections, group RBAC, object history, related child panels, and metadata-driven forms
- public release syncing from the curated `nite-install` channel through `php nite app:install`, `app:update`, `app:upgrade`, and `app:downgrade`

## Starter Strategy

Nite is intentionally split into two types of modules:

1. Concrete starter modules
   - pages
   - news
   - resources
   - gallery
   - media
   - events
   - courses

2. Generic example modules
   - catalog
   - workflow
   - messaging
   - payments
   - subscriptions
   - trust
   - chatbot
   - analytics
   - recruitment

The generic modules are backed by reusable example-entity tables so a new team can inspect patterns for broad feature families without first building a full product.
