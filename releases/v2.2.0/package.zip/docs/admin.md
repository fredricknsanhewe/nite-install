# Nite Admin

`/admin` is the standalone management frontend for Nite apps. It is not the API explorer. It signs in through the same auth endpoints, reads the same route/resource metadata, and hides sections/actions that the logged-in user cannot access.

Set `NITE_ADMIN_ENABLED=false` to turn off the `/admin` frontend while leaving JSON APIs and other HTML helper pages available. `NITE_HTML_INTERFACE_ENABLED=false` still disables all framework HTML surfaces by default.

## What It Auto-Provides

- Application/model groups similar to Django admin.
- Changelists with search, filters, sorting, bulk export, bulk delete, and API-backed pagination when a resource supports `limit` and `offset`.
- Add/change forms generated from route body metadata.
- Relation pickers for documented foreign-key style fields.
- Media upload widgets for documented media fields.
- Date and datetime inputs for date metadata.
- Object history pages when a resource exposes `GET /api/v1/admin/.../{id}/history`.
- Restore buttons when a resource exposes a matching `POST /api/v1/admin/.../history/{logId}/restore`.
- Related child panels when a resource exposes nested admin routes such as `/api/v1/admin/courses/{id}/modules`.
- A filterable permission matrix that separates `Can see` view/access permissions from `Can do` action/manage permissions.
- Switchable built-in themes.

## RBAC

Nite evaluates permissions in this order:

1. Active group permission rules from `rbac_group_permission_rules`.
2. User permission overrides from `user_permission_overrides`.

Group rules are combined across all active groups assigned to the user. Deny wins inside the group layer, and direct user overrides remain the final precise control. Existing role values are used only once as compatibility input when the framework creates default groups for upgraded apps.

The permission matrix at `/admin/rbac-matrix` shows each permission by section, module, and action:

- `Can see`: grants visibility/read access such as admin list/detail pages.
- `Can do`: grants write or workflow actions such as create, update, delete, upload, restore, enroll, or register.
- `Inherit`: keeps the lower layer unchanged.
- `Allow`: grants the permission at that layer.
- `Deny`: removes the permission at that layer.

Built-in admin modules now expose separate `*.view` and `*.manage` permissions where read-only access is useful. For example, `admin.pages.view` can see pages in admin, while `admin.pages.manage` can create, update, or delete them.

The matrix at `/admin/rbac-matrix` is group-based. Each group is a column, and saving the matrix updates group permission states.

## Group Management

Admins with `admin.rbac.view` can view:

- `/api/v1/admin/rbac/groups`
- `/api/v1/admin/rbac/groups/{id}`
- `/api/v1/admin/rbac/groups/{id}/members`
- `/api/v1/admin/rbac/groups/{id}/permissions`

Admins with `admin.rbac.manage` can create/update/delete groups, assign members, and save group permission states.

User permission pages show the effective chain for one account: group result, user override, and final effective state.

## Generated Apps

Generated resources plug into `/admin` when their manifest exposes admin routes and permissions. For best results, generated resources should include:

- list route: `GET /api/v1/admin/<resource>`
- create route: `POST /api/v1/admin/<resource>`
- detail route: `GET /api/v1/admin/<resource>/{id}`
- update route: `PUT` or `PATCH /api/v1/admin/<resource>/{id}`
- delete route: `DELETE /api/v1/admin/<resource>/{id}`
- query metadata for `q`, filters, `limit`, and `offset`
- relation metadata for fields that should become pickers
- media metadata for fields that should upload files

Run `php nite db:migrate` after upgrading an existing app so RBAC group tables are present.
