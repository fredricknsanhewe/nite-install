# Database Guide

Nite supports both PostgreSQL and MySQL.

- `database/schema.sql` for PostgreSQL
- `database/schema.mysql.sql` for MySQL

The active runtime selects the schema family through `DB_DRIVER`.

The schema includes:

- runtime tables: users, permissions, RBAC groups, group members, group permission rules, user overrides, audit logs
- concrete starter tables: site settings, pages, news, events, registrations, resources, media, gallery, courses, modules, enrollments, progress
- generic example tables: `example_entities`, `example_entries`

## Why generic example tables exist

The generic tables let Nite demonstrate broad feature families without forcing one product schema onto every new project. A team can:

- keep them as starter playbooks
- replace one module at a time with product-specific tables
- preserve the controller and service patterns while rewriting the persistence layer

## Typical evolution path

1. Start with `example_entities` for fast exploration.
2. Choose one module family such as payments or workflow.
3. Replace that family with dedicated tables.
4. Keep the route and service contracts stable where possible.

## Existing App Upgrades

Run `php nite db:migrate` after upgrading Nite. The schema runner creates missing RBAC group tables safely:

- `rbac_groups`
- `rbac_group_members`
- `rbac_group_permission_rules`
