# App Blueprint

Generated: 2026-06-26T11:02:55+00:00

## Identity

- Name: Nite
- Mode: root
- URL: http://127.0.0.1:8185
- Preset: Standard Operations (`standard`)
- Preset summary: A stronger business baseline with content, workflow, messaging, governance, and a clean set of starter business entities.

## Focus Modules

- `content` Content: Website content management starter with pages, posts, resources, gallery, media, settings, SEO patterns, and public bootstrap responses.
- `catalog` Catalog: Reusable category, service-area, and taxonomy examples derived from the marketplace catalog patterns.
- `workflow` Workflow: Generic work-item lifecycle examples for jobs, offers, counters, ratings, favorites, milestones, and dispute-style workflow entries.
- `messaging` Messaging: Notifications, conversations, outbound queue, webhook, and integration examples inspired by WhatsApp and Messenger bridge patterns.
- `governance` Governance: Auth, users, RBAC, audit logs, and configuration controls that tie the starter together.

## Generated Resources

- `CustomerAccount` [created] Customer or client records that give the app a concrete account-level domain object. Public: `/api/v1/customer-accounts` Admin: `/api/v1/admin/customer-accounts`
- `ProjectBoard` [created] High-level projects, workspaces, or engagements used to organize operational work. Public: `/api/v1/project-boards` Admin: `/api/v1/admin/project-boards`
- `TaskItem` [created] Individual work items, follow-ups, or checklist records connected to day-to-day execution. Public: `/api/v1/task-items` Admin: `/api/v1/admin/task-items`
- `SupportTicket` [created] Issue, request, or case records for internal support and customer support flows. Public: `/api/v1/support-tickets` Admin: `/api/v1/admin/support-tickets`

## Starter Samples

- Count: 0

## Runtime

- Host env: `T:\source\nite/.env`
- Docker env: `T:\source\nite/.env.docker`
- Database: `mysql` on `127.0.0.1:3306` using database `nite`
- Storage: `local` at `storage/media`

## Commands

- `php nite starter:list`
- `php nite app:doctor`
- `php nite route:list`
- `php nite app:serve --host=127.0.0.1 --port=8185`
- `php nite db:migrate`
- `php nite db:seed`

## Notes

- Framework built-ins remain available even when this preset focuses on a smaller module subset.
- Generated resources live in src/Controllers, src/Services, src/Models, database/migrations, examples/generated, and routes/generated.
- Use OPTIONS and /api/v1/meta/routes?format=json for machine-readable route metadata.
- Docker env database values were left as-is because the bundled compose templates are PostgreSQL-first. Host runtime is fully configured for mysql.
