# Releases

Prefer the console for lifecycle work:

```bash
php install
php install --version=v2.2.0
php install --upgrade
php install --downgrade=v1.1.4
php nite app:releases --limit=10
php nite app:install --seed
php nite app:update
php nite app:upgrade 2.2.0
php nite app:downgrade 1.1.4 --force
```

The public install channel lives in:

- `https://github.com/fredricknsanhewe/nite-install`

You can override that source in `.env` with:

- `NITE_PUBLIC_REPOSITORY`
- `NITE_PUBLIC_REPOSITORY_URL`
- `NITE_PUBLIC_REPOSITORY_API`
- `NITE_PUBLIC_REPOSITORY_REF`
- `NITE_PUBLIC_REPOSITORY_RAW_URL`

It resolves versions from the public release index in `latest.json`, then downloads the matching curated package from `releases/<tag>/package.zip`.

Use `v2.2.0-beta.1` style tags for beta builds and `v2.2.0` for the stable minor release. The updater also accepts versions without the leading `v`, but `v`-prefixed tags are the cleanest convention. The tag, `App::VERSION`, and public package manifest must match exactly.

When you publish the framework, keep these three supported modes aligned:

1. root single-project application mode
2. generated multi-project mode under `projects/<slug>`
3. public release distribution mode

## Operator flow

- `php nite app:install --seed`
  Downloads the latest public release, syncs the workspace, runs migrations, and seeds starter data.
- `php nite app:update`
  Downloads the latest public release and runs migrations. Use `--accept-compatibility` when moving across a major version.
- `php nite app:upgrade 2.2.0`
  Downloads that exact public version and runs migrations.
- `php nite app:downgrade 1.9.3 --force`
  Rolls back console migrations above `1.9.3`, then downloads that public version.
- `php install`
  Downloads the latest curated install package from `nite-install`, syncs the current directory, and prepares `.env` files.
- `php install --version=v1.9.3`
  Downloads that exact curated install package.
- `php install --upgrade`
  Delegates to `php nite app:update` when the app is already installed.
- `php install --downgrade=v1.9.3`
  Delegates to `php nite app:downgrade 1.9.3` when the app is already installed.

Local safety rules:

- `.env`, `.env.docker`, `storage/`, `public/uploads/`, and `routes/generated/` are preserved during release sync.
- If the workspace is a git checkout with local changes, release sync stops unless you pass `--accept-conflicts` or `--force`.
- Backups are written under `storage/console/backups/` unless you pass `--no-backup`.

## Publish a version

1. Set `App::VERSION` in `src/Config/App.php` to the new semantic version.
2. Make sure any new console migration file has the same release version in its returned `version` field.
3. Update docs, examples, and release notes.
   Include `CHANGELOG.md` and `UPGRADE.md` whenever compatibility behavior changes.
4. Make sure root Docker files and generated project Docker files still work together.
5. Commit and push the branch.
6. Create an annotated tag:

```bash
git tag -a v2.2.0 -m "Nite v2.2.0"
git push origin v2.2.0
```

7. Publish a GitHub Release from that tag in the private `fredricknsanhewe/nite` repository.
   Use the GitHub UI, or:

```bash
gh release create v2.2.0 --generate-notes
```

8. The `publish-install-release.yml` workflow will:
   - build a curated package from the tagged private source
   - push it to `fredricknsanhewe/nite-install/releases/v2.2.0/`
   - refresh `latest.json`
   - refresh the public `install` script and README
9. Verify the console can see it:

```bash
php nite app:releases --limit=5
```

The workflow requires a repository secret named `PUBLIC_RELEASE_TOKEN` with write access to `fredricknsanhewe/nite-install`.

## Versioning rules

- Patch release: `1.2.3` -> `1.2.4`
  Use for bug fixes, docs fixes, and backward-compatible patches.
- Minor release: `1.2.3` -> `1.3.0`
  Use for backward-compatible features and new resources/routes.
- Major release: `1.2.3` -> `2.0.0`
  Use for breaking route, schema, auth, or config changes.
- Beta release: `2.0.0-beta.1` -> `2.0.0-beta.2`
  Use for public testing before the stable `2.0.0` tag.

For downgrades to work cleanly, every migration file added in a release should carry the version of the first release that shipped it.

## Release checklist

Before tagging:

- run `php nite list`
- run `php nite app:version`
- run `php nite app:doctor`
- run `php scripts/rest-audit.php`
- run `composer run test`
- run `composer audit`
- run the v0.1.0, v1.0.1, v1.1.0, v2.0.0, and v2.1.0 upgrade smoke tests against database copies
- run `php -l public/index.php`
- run `php -l nite.php`
- run `docker compose up --build` from the repository root
- run `docker compose -f projects/<slug>/docker-compose.yml up --build` for at least one generated project
- verify `README.md` and `docs/quick-start.md` examples still start with `php nite ...`
