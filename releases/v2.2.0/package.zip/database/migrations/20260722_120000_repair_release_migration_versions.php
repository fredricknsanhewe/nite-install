<?php

/*
 * Metadata-only repair for installations that received migrations with the
 * wrong first-shipped release. It changes neither application data nor schema.
 */
return [
    'name' => 'repair_release_migration_versions',
    'version' => '2.2.0',
    'up' => [
        '*' => [
            "UPDATE app_console_migrations SET version = '1.1.0' WHERE id = '20260605193000_create_rbac_groups' AND version = '1.0.1'",
            "UPDATE app_console_migrations SET version = '2.1.0' WHERE id IN ('20260611_090000_create_password_security_tables', '20260626_110253_create_customer_accounts_table', '20260626_110253_create_project_boards_table', '20260626_110253_create_support_tickets_table', '20260626_110253_create_task_items_table') AND version IN ('1.0.0', '2.0.0')",
        ],
    ],
    'down' => [],
];
