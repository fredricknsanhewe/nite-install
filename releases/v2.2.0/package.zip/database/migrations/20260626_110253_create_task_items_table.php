<?php
return [
    'name' => 'create_task_items_table',
    'version' => '2.1.0',
    'up' => [
        'pgsql' => [
            <<<'SQL'
CREATE TABLE IF NOT EXISTS task_items (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    data_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)
SQL,
            "CREATE INDEX IF NOT EXISTS idx_task_items_status_updated ON task_items (status, updated_at DESC)",
        ],
        'mysql' => [
            <<<'SQL'
CREATE TABLE IF NOT EXISTS task_items (
    id CHAR(36) PRIMARY KEY,
    slug VARCHAR(140) NOT NULL,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    data_json JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_task_items_slug (slug),
    KEY idx_task_items_status_updated (status, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        ],
    ],
    'down' => [
        'pgsql' => [
            'DROP TABLE IF EXISTS task_items CASCADE',
        ],
        'mysql' => [
            'DROP TABLE IF EXISTS task_items',
        ],
    ],
];
