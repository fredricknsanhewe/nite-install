<?php
namespace App\Config;

final class App
{
    public const NAME = 'Nite';
    public const VERSION = '0.2.0';
    public const PUBLIC_REPOSITORY = 'fredricknsanhewe/nite-install';
    public const PUBLIC_REPOSITORY_URL = 'https://github.com/fredricknsanhewe/nite-install';
    public const PUBLIC_REPOSITORY_API = 'https://api.github.com/repos/fredricknsanhewe/nite-install';
    public const PUBLIC_REPOSITORY_REF = 'main';
    public const PUBLIC_REPOSITORY_RAW_URL = 'https://raw.githubusercontent.com/fredricknsanhewe/nite-install/main';

    public static function publicRepository(): string
    {
        $value = trim((string)Env::get('NITE_PUBLIC_REPOSITORY', self::PUBLIC_REPOSITORY));
        return $value === '' ? self::PUBLIC_REPOSITORY : $value;
    }

    public static function publicRepositoryUrl(): string
    {
        $value = trim((string)Env::get('NITE_PUBLIC_REPOSITORY_URL', self::PUBLIC_REPOSITORY_URL));
        return $value === '' ? self::PUBLIC_REPOSITORY_URL : $value;
    }

    public static function publicRepositoryApi(): string
    {
        $value = trim((string)Env::get('NITE_PUBLIC_REPOSITORY_API', self::PUBLIC_REPOSITORY_API));
        return $value === '' ? self::PUBLIC_REPOSITORY_API : $value;
    }

    public static function publicRepositoryRef(): string
    {
        $value = trim((string)Env::get('NITE_PUBLIC_REPOSITORY_REF', self::PUBLIC_REPOSITORY_REF));
        return $value === '' ? self::PUBLIC_REPOSITORY_REF : $value;
    }

    public static function publicRepositoryRawUrl(): string
    {
        $value = trim((string)Env::get('NITE_PUBLIC_REPOSITORY_RAW_URL', self::PUBLIC_REPOSITORY_RAW_URL));
        if ($value !== '') {
            return rtrim($value, '/');
        }

        return 'https://raw.githubusercontent.com/' . self::publicRepository() . '/' . self::publicRepositoryRef();
    }
}
