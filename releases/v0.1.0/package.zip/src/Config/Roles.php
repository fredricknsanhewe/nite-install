<?php
namespace App\Config;

final class Roles
{
    public const MEMBER = 'member';
    public const TRAINER = 'trainer';
    public const EDITOR = 'editor';
    public const SUPPORT = 'support';
    public const ADMIN = 'admin';

    /**
     * @return array<int, string>
     */
    public static function all(): array
    {
        return [
            self::MEMBER,
            self::TRAINER,
            self::EDITOR,
            self::SUPPORT,
            self::ADMIN,
        ];
    }
}
