<?php
namespace App\Config;

final class Env
{
    private static bool $loaded = false;

    public static function load(string $path): void
    {
        self::loadFirstAvailable([$path]);
    }

    /**
     * @param array<int, string> $paths
     */
    public static function loadFirstAvailable(array $paths): void
    {
        if (self::$loaded) {
            return;
        }

        foreach ($paths as $path) {
            if (!is_string($path) || $path === '' || !is_file($path)) {
                continue;
            }
            self::loadFile($path, false);
            self::$loaded = true;
            return;
        }

        self::$loaded = true;
    }

    /**
     * @param array<int, string> $paths
     */
    public static function loadOverrides(array $paths): void
    {
        foreach ($paths as $path) {
            if (!is_string($path) || $path === '' || !is_file($path)) {
                continue;
            }
            self::loadFile($path, true);
        }
    }

    /**
     * @param array<string, scalar|null> $values
     */
    public static function apply(array $values, bool $override = true): void
    {
        foreach ($values as $key => $value) {
            $normalizedKey = trim((string)$key);
            if ($normalizedKey === '') {
                continue;
            }
            if (!$override && getenv($normalizedKey) !== false) {
                continue;
            }
            if ($value === null) {
                continue;
            }

            self::set($normalizedKey, (string)$value);
        }
    }

    private static function set(string $key, string $value): void
    {
        putenv($key . '=' . $value);
        $_ENV[$key] = $value;
        $_SERVER[$key] = $value;
    }

    private static function loadFile(string $path, bool $override): void
    {
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            [$key, $value] = array_pad(explode('=', $line, 2), 2, '');
            $key = trim($key);
            $value = trim($value);
            $value = trim($value, "\"'");
            if ($key === '' || (!$override && getenv($key) !== false)) {
                continue;
            }

            self::set($key, $value);
        }
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        $value = getenv($key);
        return $value === false ? $default : $value;
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $value = self::get($key);
        if ($value === null) {
            return $default;
        }

        return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
    }

    public static function int(string $key, int $default = 0): int
    {
        $value = self::get($key);
        if ($value === null || trim($value) === '' || !is_numeric($value)) {
            return $default;
        }

        return (int)$value;
    }
}
