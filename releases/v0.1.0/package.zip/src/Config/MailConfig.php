<?php
namespace App\Config;

use App\Config\App;
use RuntimeException;

/**
 * Centralized mail configuration for Nite.
 *
 * The framework intentionally keeps mail setup env-driven so developers and AI
 * tooling can reason about one source of truth without chasing transport logic
 * through controllers and services.
 */
final class MailConfig
{
    /**
     * Whether outbound mail is enabled for the current runtime.
     */
    public static function enabled(): bool
    {
        return Env::bool('MAIL_ENABLED', false);
    }

    /**
     * Queue mode for outbound delivery.
     *
     * Supported values:
     * - `sync`: send immediately in-process
     * - `database`: enqueue into `mail_queue` and deliver via `mail:queue:work`
     */
    public static function queueMode(): string
    {
        $mode = strtolower(trim((string)Env::get('MAIL_QUEUE_MODE', 'sync')));
        return in_array($mode, ['sync', 'database'], true) ? $mode : 'sync';
    }

    /**
     * Transport label used for summaries and queue metadata.
     */
    public static function transport(): string
    {
        if (trim((string)Env::get('MAIL_DSN', '')) !== '') {
            return 'dsn';
        }

        $transport = strtolower(trim((string)Env::get('MAIL_TRANSPORT', 'smtp')));
        return in_array($transport, ['smtp', 'sendmail', 'native', 'null'], true) ? $transport : 'smtp';
    }

    /**
     * Symfony mailer DSN string.
     *
     * Examples:
     * - smtp://user:pass@smtp.example.com:587?encryption=tls
     * - failover(smtp://primary:pass@mail1:587 smtp://backup:pass@mail2:587)
     * - roundrobin(smtp://mx1:pass@mail1:587 smtp://mx2:pass@mail2:587)
     */
    public static function dsn(): string
    {
        $raw = trim((string)Env::get('MAIL_DSN', ''));
        if ($raw !== '') {
            return $raw;
        }

        return match (self::transport()) {
            'null' => 'null://null',
            'native' => 'native://default',
            'sendmail' => 'sendmail://default',
            default => self::smtpDsn(),
        };
    }

    /**
     * Default visible From header used by all framework mail.
     *
     * @return array{address: string, name?: string}
     */
    public static function defaultFrom(): array
    {
        $address = strtolower(trim((string)Env::get('MAIL_FROM_ADDRESS', '')));
        if ($address === '' || filter_var($address, FILTER_VALIDATE_EMAIL) === false) {
            throw new RuntimeException('MAIL_FROM_ADDRESS must be configured with a valid email address when MAIL_ENABLED=true.');
        }

        $name = trim((string)Env::get('MAIL_FROM_NAME', App::NAME));
        $result = ['address' => $address];
        if ($name !== '') {
            $result['name'] = $name;
        }

        return $result;
    }

    public static function senderAddress(): ?string
    {
        $value = strtolower(trim((string)Env::get('MAIL_SENDER_ADDRESS', Env::get('MAIL_RETURN_PATH', ''))));
        return $value !== '' && filter_var($value, FILTER_VALIDATE_EMAIL) !== false ? $value : null;
    }

    /**
     * @return array<int, array{address: string, name?: string}>
     */
    public static function defaultReplyTo(): array
    {
        return self::parseAddressList((string)Env::get('MAIL_REPLY_TO', ''));
    }

    /**
     * @return array<int, array{address: string, name?: string}>
     */
    public static function adminRecipients(): array
    {
        return self::parseAddressList((string)Env::get('MAIL_ADMIN_TO', ''));
    }

    /**
     * When populated, every outbound message is redirected to these recipients.
     *
     * This is a staging/preview safety valve to prevent accidental delivery to
     * real customer addresses.
     *
     * @return array<int, array{address: string, name?: string}>
     */
    public static function overrideRecipients(): array
    {
        return self::parseAddressList((string)Env::get('MAIL_OVERRIDE_TO', ''));
    }

    public static function enforceTrustedFrom(): bool
    {
        return Env::bool('MAIL_ENFORCE_TRUSTED_FROM', true);
    }

    /**
     * @return array<int, string>
     */
    public static function allowedFromDomains(): array
    {
        $configured = self::parseCsv((string)Env::get('MAIL_ALLOWED_FROM_DOMAINS', ''));
        if ($configured !== []) {
            return $configured;
        }

        $fallback = [];
        foreach ([self::defaultFrom()['address'] ?? '', self::senderAddress() ?? ''] as $address) {
            $domain = self::domainFromEmail((string)$address);
            if ($domain !== null) {
                $fallback[] = $domain;
            }
        }

        return array_values(array_unique($fallback));
    }

    /**
     * @return array<int, string>
     */
    public static function allowedFromAddresses(): array
    {
        $configured = self::parseCsv((string)Env::get('MAIL_ALLOWED_FROM_ADDRESSES', ''));
        if ($configured !== []) {
            return $configured;
        }

        $addresses = [strtolower((string)(self::defaultFrom()['address'] ?? ''))];
        $sender = self::senderAddress();
        if ($sender !== null) {
            $addresses[] = strtolower($sender);
        }

        return array_values(array_unique(array_filter($addresses, static fn (string $value): bool => $value !== '')));
    }

    /**
     * @return array<int, string>
     */
    public static function allowedReplyToDomains(): array
    {
        return self::parseCsv((string)Env::get('MAIL_ALLOWED_REPLY_TO_DOMAINS', ''));
    }

    public static function maxAttempts(): int
    {
        return max(1, (int)Env::get('MAIL_QUEUE_MAX_ATTEMPTS', '3'));
    }

    public static function retryDelaySeconds(): int
    {
        return max(5, (int)Env::get('MAIL_QUEUE_RETRY_DELAY_SECONDS', '60'));
    }

    public static function batchSize(): int
    {
        return max(1, min(200, (int)Env::get('MAIL_QUEUE_BATCH_SIZE', '25')));
    }

    public static function workerSleepSeconds(): int
    {
        return max(1, min(300, (int)Env::get('MAIL_QUEUE_SLEEP_SECONDS', '3')));
    }

    public static function workerMaxRuntimeSeconds(): int
    {
        return max(0, (int)Env::get('MAIL_QUEUE_MAX_RUNTIME_SECONDS', '0'));
    }

    public static function contactNotificationEnabled(): bool
    {
        return Env::bool('MAIL_CONTACT_NOTIFICATION_ENABLED', false);
    }

    public static function contactAutoReplyEnabled(): bool
    {
        return Env::bool('MAIL_CONTACT_AUTO_REPLY_ENABLED', false);
    }

    public static function dkimEnabled(): bool
    {
        return trim((string)Env::get('MAIL_DKIM_DOMAIN', '')) !== ''
            && trim((string)Env::get('MAIL_DKIM_SELECTOR', '')) !== ''
            && trim((string)Env::get('MAIL_DKIM_PRIVATE_KEY_PATH', '')) !== '';
    }

    /**
     * @return array{domain: string, selector: string, private_key_path: string, passphrase: string, body_length: bool}
     */
    public static function dkimOptions(): array
    {
        return [
            'domain' => trim((string)Env::get('MAIL_DKIM_DOMAIN', '')),
            'selector' => trim((string)Env::get('MAIL_DKIM_SELECTOR', '')),
            'private_key_path' => trim((string)Env::get('MAIL_DKIM_PRIVATE_KEY_PATH', '')),
            'passphrase' => (string)Env::get('MAIL_DKIM_PASSPHRASE', ''),
            'body_length' => Env::bool('MAIL_DKIM_BODY_LENGTH', false),
        ];
    }

    /**
     * Redacted runtime summary safe for CLI/API output.
     *
     * @return array<string, mixed>
     */
    public static function summary(): array
    {
        $from = ['address' => '', 'name' => ''];
        try {
            $defaultFrom = self::defaultFrom();
            $from = [
                'address' => (string)($defaultFrom['address'] ?? ''),
                'name' => (string)($defaultFrom['name'] ?? ''),
            ];
        } catch (\Throwable) {
            // Leave the summary with blanks so doctor/about can still render.
        }

        return [
            'enabled' => self::enabled(),
            'queue_mode' => self::queueMode(),
            'transport' => self::transport(),
            'dsn' => self::maskedDsn(self::dsn()),
            'from' => $from,
            'sender_address' => self::senderAddress(),
            'reply_to_count' => count(self::defaultReplyTo()),
            'admin_recipient_count' => count(self::adminRecipients()),
            'override_recipient_count' => count(self::overrideRecipients()),
            'trusted_from_enforced' => self::enforceTrustedFrom(),
            'dkim_enabled' => self::dkimEnabled(),
            'worker_sleep_seconds' => self::workerSleepSeconds(),
            'worker_max_runtime_seconds' => self::workerMaxRuntimeSeconds(),
        ];
    }

    /**
     * @return array<int, array{address: string, name?: string}>
     */
    public static function parseAddressList(string $value): array
    {
        $items = [];
        foreach (self::splitAddressTokens($value) as $token) {
            $parsed = self::parseAddress($token);
            if ($parsed !== null) {
                $items[] = $parsed;
            }
        }

        return self::dedupeAddressList($items);
    }

    /**
     * @return array{address: string, name?: string}|null
     */
    public static function parseAddress(mixed $value): ?array
    {
        if (is_array($value)) {
            $address = strtolower(trim((string)($value['address'] ?? $value['email'] ?? '')));
            $name = trim((string)($value['name'] ?? ''));
            if ($address === '' || filter_var($address, FILTER_VALIDATE_EMAIL) === false) {
                return null;
            }

            $parsed = ['address' => $address];
            if ($name !== '') {
                $parsed['name'] = $name;
            }

            return $parsed;
        }

        $text = trim((string)$value);
        if ($text === '') {
            return null;
        }

        if (preg_match('/^\s*(.+?)\s*<([^>]+)>\s*$/', $text, $matches) === 1) {
            $address = strtolower(trim((string)($matches[2] ?? '')));
            if ($address === '' || filter_var($address, FILTER_VALIDATE_EMAIL) === false) {
                return null;
            }

            $name = trim(trim((string)($matches[1] ?? ''), "\"'"));
            $parsed = ['address' => $address];
            if ($name !== '') {
                $parsed['name'] = $name;
            }

            return $parsed;
        }

        $address = strtolower($text);
        if (filter_var($address, FILTER_VALIDATE_EMAIL) === false) {
            return null;
        }

        return ['address' => $address];
    }

    private static function smtpDsn(): string
    {
        $host = trim((string)Env::get('MAIL_HOST', '127.0.0.1'));
        $port = max(1, (int)Env::get('MAIL_PORT', '587'));
        $username = trim((string)Env::get('MAIL_USERNAME', ''));
        $password = (string)Env::get('MAIL_PASSWORD', '');
        $encryption = strtolower(trim((string)Env::get('MAIL_ENCRYPTION', 'tls')));
        $scheme = $encryption === 'ssl' ? 'smtps' : 'smtp';

        $auth = '';
        if ($username !== '') {
            $auth = rawurlencode($username);
            if ($password !== '') {
                $auth .= ':' . rawurlencode($password);
            }
            $auth .= '@';
        }

        $query = [];
        if ($encryption !== '' && $encryption !== 'ssl') {
            $query['encryption'] = $encryption;
        }

        $timeout = (int)Env::get('MAIL_TIMEOUT_SECONDS', '15');
        if ($timeout > 0) {
            $query['timeout'] = (string)$timeout;
        }

        $localDomain = trim((string)Env::get('MAIL_LOCAL_DOMAIN', ''));
        if ($localDomain !== '') {
            $query['local_domain'] = $localDomain;
        }

        $dsn = $scheme . '://' . $auth . $host . ':' . $port;
        if ($query !== []) {
            $dsn .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        }

        return $dsn;
    }

    /**
     * @return array<int, string>
     */
    private static function parseCsv(string $value): array
    {
        $items = array_map(
            static fn (string $item): string => strtolower(trim($item)),
            preg_split('/\s*,\s*/', trim($value)) ?: []
        );

        return array_values(array_unique(array_filter($items, static fn (string $item): bool => $item !== '')));
    }

    /**
     * @return array<int, string>
     */
    private static function splitAddressTokens(string $value): array
    {
        $tokens = [];
        $buffer = '';
        $depth = 0;
        $length = strlen($value);
        for ($i = 0; $i < $length; $i++) {
            $char = $value[$i];
            if ($char === '<') {
                $depth++;
            } elseif ($char === '>' && $depth > 0) {
                $depth--;
            }

            if (($char === ',' || $char === ';') && $depth === 0) {
                $trimmed = trim($buffer);
                if ($trimmed !== '') {
                    $tokens[] = $trimmed;
                }
                $buffer = '';
                continue;
            }

            $buffer .= $char;
        }

        $trimmed = trim($buffer);
        if ($trimmed !== '') {
            $tokens[] = $trimmed;
        }

        return $tokens;
    }

    /**
     * @param array<int, array{address: string, name?: string}> $items
     * @return array<int, array{address: string, name?: string}>
     */
    private static function dedupeAddressList(array $items): array
    {
        $deduped = [];
        foreach ($items as $item) {
            $key = strtolower((string)($item['address'] ?? ''));
            if ($key === '') {
                continue;
            }
            $deduped[$key] = $item;
        }

        return array_values($deduped);
    }

    private static function maskedDsn(string $dsn): string
    {
        return preg_replace('/:\/\/([^:@\/\s]+):([^@\/\s]+)@/', '://$1:***@', $dsn) ?? $dsn;
    }

    private static function domainFromEmail(string $email): ?string
    {
        $parts = explode('@', strtolower(trim($email)), 2);
        if (count($parts) !== 2 || $parts[1] === '') {
            return null;
        }

        return $parts[1];
    }
}
