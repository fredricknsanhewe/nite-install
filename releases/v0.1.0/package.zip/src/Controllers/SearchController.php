<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\CourseModel;
use App\Models\ExampleEntityModel;
use App\Models\NewsPostModel;
use App\Models\PageModel;
use App\Models\ResourceModel;
use App\Models\SampleRecordModel;

final class SearchController
{
    public function global(Request $request): Response
    {
        $q = trim((string)($request->query['q'] ?? ''));
        if ($q === '') {
            return Response::json(['data' => []]);
        }

        $pages = (new PageModel())->list(['q' => $q], true);
        $news = (new NewsPostModel())->list(['q' => $q], true);
        $resources = (new ResourceModel())->list(['q' => $q], true);
        $courses = (new CourseModel())->listCourses(['q' => $q], true);
        $sampleRecords = (new SampleRecordModel())->list(['q' => $q], true);
        $examples = (new ExampleEntityModel())->search($q);

        return Response::json([
            'data' => [
                'pages' => $pages,
                'news' => $news,
                'resources' => $resources,
                'courses' => $courses,
                'sample_records' => $sampleRecords,
                'examples' => $examples,
            ],
        ]);
    }
}
