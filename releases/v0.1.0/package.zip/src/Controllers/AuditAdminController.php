<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\SystemAuditLogModel;

final class AuditAdminController
{
    private SystemAuditLogModel $logs;

    public function __construct()
    {
        $this->logs = new SystemAuditLogModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->logs->list($request->query)]);
    }
}
