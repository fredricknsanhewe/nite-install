<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\ContactMessageService;
use RuntimeException;

final class ContactController
{
    private ContactMessageService $messages;

    public function __construct()
    {
        $this->messages = new ContactMessageService();
    }

    public function create(Request $request): Response
    {
        try {
            $message = $this->messages->create($request->body);
            return Response::json(['data' => $message], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to send contact message.'], 500);
        }
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->messages->list($request->query)]);
    }

    public function show(Request $request): Response
    {
        $message = $this->messages->findById((string)($request->params['id'] ?? ''));
        return $message ? Response::json(['data' => $message]) : Response::json(['error' => 'Message not found.'], 404);
    }

    public function update(Request $request): Response
    {
        try {
            $message = $this->messages->update((string)($request->params['id'] ?? ''), $request->body);
            return $message ? Response::json(['data' => $message]) : Response::json(['error' => 'Message not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update contact message.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->messages->delete((string)($request->params['id'] ?? ''))]]);
    }
}
