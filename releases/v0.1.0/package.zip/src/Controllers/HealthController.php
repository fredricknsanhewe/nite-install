<?php
namespace App\Controllers;

use App\Http\Request;

final class HealthController
{
    /**
     * Returning a plain array is supported and will be normalized into a standard API response.
     *
     * @return array<string, mixed>
     */
    public function __invoke(Request $request): array
    {
        return [
            'data' => [
                'status' => 'ok',
                'time' => gmdate('c'),
            ],
            'message' => 'Health check completed successfully',
        ];
    }
}
