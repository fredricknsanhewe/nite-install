<?php
namespace App\Controllers;

use App\Config\Env;
use App\Http\Request;
use App\Http\Response;
use App\Models\CourseModel;
use App\Models\NewsPostModel;
use App\Models\PageModel;
use App\Models\ResourceModel;
use App\Models\SampleRecordModel;
use App\Services\ExampleModuleService;
use App\Config\MailConfig;
use App\Storage\MediaStorageManager;
use App\Support\NiteModuleCatalog;

final class FrameworkController
{
    public function apiRoot(Request $request): Response
    {
        $projectSlug = trim((string)Env::get('NITE_PROJECT', ''));
        return Response::json([
            'data' => [
                'project' => $projectSlug === '' ? null : [
                    'slug' => $projectSlug,
                    'name' => trim((string)Env::get('NITE_PROJECT_NAME', $projectSlug)),
                    'app_url' => trim((string)Env::get('APP_URL', '')),
                ],
                'routes' => '/api/v1/meta/routes',
                'api_root' => '/api/v1',
                'health' => '/api/v1/health',
                'framework' => '/api/v1/framework',
                'resources' => '/api/v1/meta/resources',
                'modules' => '/api/v1/framework/modules',
                'search' => '/api/v1/search/global',
                'pages' => '/api/v1/pages',
                'news' => '/api/v1/news',
                'events' => '/api/v1/events',
                'resources_catalog' => '/api/v1/resources',
                'gallery' => '/api/v1/gallery',
                'courses' => '/api/v1/courses',
                'sample_records' => '/api/v1/sample-records',
                'site_bootstrap' => '/api/v1/site/bootstrap',
                'media' => '/api/v1/media/{id}',
                'storage' => (new MediaStorageManager())->summary(),
                'mail' => $this->publicMailSummary(),
            ],
        ]);
    }

    public function overview(Request $request): Response
    {
        $modules = NiteModuleCatalog::modules();
        $projectSlug = trim((string)Env::get('NITE_PROJECT', ''));
        $exampleCounts = [];
        $concreteExamples = [
            'pages' => null,
            'news_posts' => null,
            'resources' => null,
            'courses' => null,
            'sample_records' => null,
        ];
        $databaseAvailable = true;

        try {
            $exampleCounts = $this->examples()->catalog()['counts'];
            $pages = new PageModel();
            $news = new NewsPostModel();
            $resources = new ResourceModel();
            $courses = new CourseModel();
            $sampleRecords = new SampleRecordModel();
            $concreteExamples = [
                'pages' => count($pages->list([], true)),
                'news_posts' => count($news->list([], true)),
                'resources' => count($resources->list([], true)),
                'courses' => count($courses->listCourses([], true)),
                'sample_records' => $sampleRecords->count(),
            ];
        } catch (\Throwable) {
            $databaseAvailable = false;
        }

        return Response::json([
            'data' => [
                'name' => 'Nite',
                'project' => $projectSlug === '' ? null : [
                    'slug' => $projectSlug,
                    'name' => trim((string)Env::get('NITE_PROJECT_NAME', $projectSlug)),
                    'app_url' => trim((string)Env::get('APP_URL', '')),
                ],
                'tagline' => 'Custom PHP starter framework derived from proven marketplace architecture patterns.',
                'storage' => (new MediaStorageManager())->summary(),
                'mail' => $this->publicMailSummary(),
                'modules' => $modules,
                'example_counts' => $exampleCounts,
                'starter_endpoints' => [
                    'routes' => '/api/v1/meta/routes',
                    'api_root' => '/api/v1',
                    'health' => '/api/v1/health',
                    'resources' => '/api/v1/meta/resources',
                    'framework' => '/api/v1/framework',
                    'modules' => '/api/v1/framework/modules',
                    'sample_records' => '/api/v1/sample-records',
                    'sample_record_history' => '/api/v1/admin/sample-records/history',
                ],
                'database_available' => $databaseAvailable,
                'concrete_examples' => $concreteExamples,
            ],
        ]);
    }

    public function modules(Request $request): Response
    {
        return Response::json(['data' => NiteModuleCatalog::modules()]);
    }

    public function module(Request $request): Response
    {
        $moduleKey = (string)($request->params['module'] ?? '');
        $module = NiteModuleCatalog::moduleByKey($moduleKey);
        return $module ? Response::json(['data' => $module]) : Response::json(['error' => 'Module not found.'], 404);
    }

    private function examples(): ExampleModuleService
    {
        return new ExampleModuleService();
    }

    /**
     * @return array<string, mixed>
     */
    private function publicMailSummary(): array
    {
        return [
            'enabled' => MailConfig::enabled(),
            'queue_mode' => MailConfig::queueMode(),
            'dkim_enabled' => MailConfig::dkimEnabled(),
        ];
    }
}
