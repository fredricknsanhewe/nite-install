<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\SiteSettingsModel;
use App\Services\PublicSiteService;
use RuntimeException;

final class SiteController
{
    private PublicSiteService $site;
    private SiteSettingsModel $settings;

    public function __construct()
    {
        $this->site = new PublicSiteService();
        $this->settings = new SiteSettingsModel();
    }

    public function bootstrap(Request $request): Response
    {
        return Response::json(['data' => $this->site->bootstrap()]);
    }

    public function publicSettings(Request $request): Response
    {
        return Response::json(['data' => $this->settings->all('public')]);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->settings->all()]);
    }

    public function adminShow(Request $request): Response
    {
        $setting = $this->settings->get((string)($request->params['key'] ?? ''));
        return $setting ? Response::json(['data' => $setting]) : Response::json(['error' => 'Setting bucket not found.'], 404);
    }

    public function adminUpdate(Request $request): Response
    {
        try {
            $key = (string)($request->params['key'] ?? '');
            if ($key === '') {
                throw new RuntimeException('Config key is required.');
            }
            $settings = is_array($request->body['settings'] ?? null) ? $request->body['settings'] : $request->body;
            $visibility = (string)($request->body['visibility'] ?? 'admin');
            $updated = $this->settings->upsert($key, $visibility, $settings, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $updated]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update site settings.'], 500);
        }
    }
}
