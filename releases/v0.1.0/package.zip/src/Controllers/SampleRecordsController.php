<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\SampleRecordService;
use App\Support\DataChangeContext;
use RuntimeException;

final class SampleRecordsController
{
    private SampleRecordService $records;

    public function __construct()
    {
        $this->records = new SampleRecordService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->records->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->records->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Sample record not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->records->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->records->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => 'Sample record not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $result = $this->records->create(
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'sample_records'])
            );
            return Response::json([
                'data' => $result['record'],
                'meta' => [
                    'change_log_id' => $result['change_log']['id'] ?? null,
                    'action' => 'create',
                ],
            ], 201, [
                'Location' => '/api/v1/admin/sample-records/' . (string)($result['record']['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create sample record.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $result = $this->records->update(
                (string)($request->params['id'] ?? ''),
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'sample_records'])
            );
            if ($result === null) {
                return Response::json(['error' => 'Sample record not found.'], 404);
            }

            return Response::json([
                'data' => $result['record'],
                'meta' => [
                    'change_log_id' => $result['change_log']['id'] ?? null,
                    'action' => 'update',
                ],
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update sample record.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $result = $this->records->softDelete(
                (string)($request->params['id'] ?? ''),
                DataChangeContext::fromRequest($request, ['change_scope' => 'sample_records'])
            );
            if ($result === null) {
                return Response::json(['error' => 'Sample record not found.'], 404);
            }

            return Response::json([
                'data' => [
                    'deleted' => (bool)($result['deleted'] ?? false),
                    'record_id' => $result['record']['id'] ?? null,
                    'archive_log_id' => $result['change_log']['id'] ?? null,
                ],
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete sample record.'], 500);
        }
    }

    public function history(Request $request): Response
    {
        return Response::json(['data' => $this->records->history($request->query)]);
    }

    public function recordHistory(Request $request): Response
    {
        return Response::json([
            'data' => $this->records->recordHistory(
                (string)($request->params['id'] ?? ''),
                $request->query
            ),
        ]);
    }

    public function restore(Request $request): Response
    {
        try {
            $result = $this->records->restoreFromLog(
                (int)($request->params['logId'] ?? 0),
                DataChangeContext::fromRequest($request, ['change_scope' => 'sample_records'])
            );
            if ($result === null) {
                return Response::json(['error' => 'Change log entry not found.'], 404);
            }

            return Response::json([
                'data' => $result['record'],
                'meta' => [
                    'change_log_id' => $result['change_log']['id'] ?? null,
                    'restored_from_log_id' => $result['restored_from']['id'] ?? null,
                    'action' => 'restore',
                ],
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to restore sample record from history.'], 500);
        }
    }
}
