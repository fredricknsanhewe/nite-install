<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\DashboardService;

final class DashboardController
{
    private DashboardService $dashboard;

    public function __construct()
    {
        $this->dashboard = new DashboardService();
    }

    public function me(Request $request): Response
    {
        return Response::json(['data' => $this->dashboard->member((string)($request->user['id'] ?? ''))]);
    }

    public function admin(Request $request): Response
    {
        return Response::json(['data' => $this->dashboard->admin()]);
    }
}
