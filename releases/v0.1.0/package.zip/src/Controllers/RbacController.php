<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\RbacService;
use RuntimeException;

final class RbacController
{
    private RbacService $rbac;

    public function __construct()
    {
        $this->rbac = new RbacService();
    }

    public function roles(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->roles()]);
    }

    public function permissions(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->permissions()]);
    }

    public function matrix(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->matrix()]);
    }

    public function userOverrides(Request $request): Response
    {
        $payload = $this->rbac->userOverrides((string)($request->params['id'] ?? ''));
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'User not found.'], 404);
    }

    public function setRolePermissions(Request $request): Response
    {
        try {
            $states = is_array($request->body['states'] ?? null) ? $request->body['states'] : $request->body;
            return Response::json([
                'data' => $this->rbac->setRolePermissions((string)($request->params['role'] ?? ''), $states),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update role permissions.'], 500);
        }
    }

    public function setUserOverrides(Request $request): Response
    {
        try {
            $states = is_array($request->body['states'] ?? null) ? $request->body['states'] : $request->body;
            $payload = $this->rbac->setUserOverrides((string)($request->params['id'] ?? ''), $states);
            return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'User not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update user overrides.'], 500);
        }
    }
}
