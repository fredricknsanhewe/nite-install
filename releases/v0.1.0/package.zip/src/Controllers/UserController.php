<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\AuthService;

final class UserController
{
    private AuthService $auth;

    public function __construct()
    {
        $this->auth = new AuthService();
    }

    public function me(Request $request): Response
    {
        $userId = (string)($request->user['id'] ?? '');
        $user = $this->auth->me($userId);
        if ($user === null) {
            return Response::json(['error' => 'User not found.'], 404);
        }
        return Response::json(['data' => $user]);
    }
}
