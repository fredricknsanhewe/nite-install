<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\ResourceModel;
use RuntimeException;

final class ResourcesController
{
    private ResourceModel $resources;

    public function __construct()
    {
        $this->resources = new ResourceModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->resources->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $resource = $this->resources->findBySlug((string)($request->params['slug'] ?? ''), false);
        return $resource ? Response::json(['data' => $resource]) : Response::json(['error' => 'Resource not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->resources->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $resource = $this->resources->findById((string)($request->params['id'] ?? ''));
        return $resource ? Response::json(['data' => $resource]) : Response::json(['error' => 'Resource not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $resource = $this->resources->create($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $resource], 201, [
                'Location' => '/api/v1/admin/resources/' . (string)($resource['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create resource.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $resource = $this->resources->update((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $resource ? Response::json(['data' => $resource]) : Response::json(['error' => 'Resource not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update resource.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->resources->delete((string)($request->params['id'] ?? ''))]]);
    }
}
