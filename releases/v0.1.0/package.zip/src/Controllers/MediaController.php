<?php
namespace App\Controllers;

use App\Http\ApiResponse;
use App\Http\Request;
use App\Http\Response;
use App\Services\MediaService;
use App\Services\RequestUserResolver;
use App\Support\DataChangeContext;
use RuntimeException;

final class MediaController
{
    private MediaService $media;
    private RequestUserResolver $users;

    public function __construct()
    {
        $this->media = new MediaService();
        $this->users = new RequestUserResolver();
    }

    public function list(Request $request): Response
    {
        try {
            return ApiResponse::success($this->media->adminList($request->query));
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to list media assets.', null, 500);
        }
    }

    public function show(Request $request): Response
    {
        $asset = $this->media->showAdmin((string)($request->params['id'] ?? ''));
        return $asset
            ? ApiResponse::success($asset)
            : ApiResponse::error('Media asset not found.', null, 404);
    }

    public function publicShow(Request $request): Response
    {
        $result = $this->media->showAccessible(
            (string)($request->params['id'] ?? ''),
            $this->users->resolve($request)
        );

        return match ((string)($result['state'] ?? 'not_found')) {
            'ok' => ApiResponse::success($result['asset'] ?? []),
            'forbidden' => ApiResponse::error('Forbidden', null, 403),
            default => ApiResponse::error('Media asset not found.', null, 404),
        };
    }

    public function download(Request $request): Response
    {
        $result = $this->media->downloadAsset(
            (string)($request->params['id'] ?? ''),
            $this->users->resolve($request)
        );

        return match ((string)($result['state'] ?? 'not_found')) {
            'ok' => Response::file(
                (string)($result['content'] ?? ''),
                (string)($result['mime_type'] ?? 'application/octet-stream'),
                (string)($result['download_name'] ?? 'download'),
                (bool)($result['inline'] ?? true),
                200,
                [
                    'Cache-Control' => ((string)(($result['asset']['access_scope'] ?? 'private')) === 'public')
                        ? 'public, max-age=3600'
                        : 'private, no-store',
                ]
            ),
            'forbidden' => ApiResponse::error('Forbidden', null, 403),
            'storage_error' => ApiResponse::error('Failed to read the stored media file.', ['detail' => $result['message'] ?? null], 500),
            'missing_file' => ApiResponse::error('Stored media file not found on the server.', null, 404),
            default => ApiResponse::error('Media asset not found.', null, 404),
        };
    }

    public function upload(Request $request): Response
    {
        try {
            $file = $request->uploadedFile('file');
            if ($file === null) {
                return ApiResponse::error('Validation failed', ['file' => ['A file upload named "file" is required.']], 422);
            }

            $result = $this->media->upload(
                $file,
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );

            return ApiResponse::success(
                $result['asset'],
                'Created successfully',
                201,
                [
                    'version' => $result['version'] ?? null,
                    'change_log_id' => $result['change_log']['id'] ?? null,
                    'action' => 'create',
                ],
                [
                    'Location' => '/api/v1/admin/media/' . (string)($result['asset']['id'] ?? ''),
                ]
            );
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to upload media asset.', null, 500);
        }
    }

    public function uploadVersion(Request $request): Response
    {
        try {
            $file = $request->uploadedFile('file');
            if ($file === null) {
                return ApiResponse::error('Validation failed', ['file' => ['A file upload named "file" is required.']], 422);
            }

            $result = $this->media->replaceFile(
                (string)($request->params['id'] ?? ''),
                $file,
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );
            if ($result === null) {
                return ApiResponse::error('Media asset not found.', null, 404);
            }

            return ApiResponse::success($result['asset'], 'Created successfully', 201, [
                'version' => $result['version'] ?? null,
                'change_log_id' => $result['change_log']['id'] ?? null,
                'action' => 'replace',
            ], [
                'Location' => '/api/v1/admin/media/' . (string)($result['asset']['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to upload the new media version.', null, 500);
        }
    }

    public function versions(Request $request): Response
    {
        $assetId = (string)($request->params['id'] ?? '');
        if ($this->media->showAdmin($assetId) === null) {
            return ApiResponse::error('Media asset not found.', null, 404);
        }

        return ApiResponse::success($this->media->versions($assetId));
    }

    public function update(Request $request): Response
    {
        try {
            $result = $this->media->updateMetadata(
                (string)($request->params['id'] ?? ''),
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );
            if ($result === null) {
                return ApiResponse::error('Media asset not found.', null, 404);
            }

            return ApiResponse::success($result['asset'], 'Request completed successfully', 200, [
                'change_log_id' => $result['change_log']['id'] ?? null,
                'action' => 'update',
            ]);
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to update media asset.', null, 500);
        }
    }

    public function history(Request $request): Response
    {
        return ApiResponse::success($this->media->history($request->query));
    }

    public function recordHistory(Request $request): Response
    {
        return ApiResponse::success($this->media->recordHistory(
            (string)($request->params['id'] ?? ''),
            $request->query
        ));
    }

    public function restoreVersion(Request $request): Response
    {
        try {
            $result = $this->media->restoreVersion(
                (string)($request->params['id'] ?? ''),
                (string)($request->params['versionId'] ?? ''),
                $request->body,
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );
            if ($result === null) {
                return ApiResponse::error('Media asset version not found.', null, 404);
            }

            return ApiResponse::success($result['asset'], 'Request completed successfully', 200, [
                'version' => $result['version'] ?? null,
                'restored_from_version' => $result['restored_from_version'] ?? null,
                'change_log_id' => $result['change_log']['id'] ?? null,
                'action' => 'restore_version',
            ]);
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to restore the selected media version.', null, 500);
        }
    }

    public function restore(Request $request): Response
    {
        try {
            $result = $this->media->restoreFromLog(
                (int)($request->params['logId'] ?? 0),
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );
            if ($result === null) {
                return ApiResponse::error('Media history entry not found.', null, 404);
            }

            return ApiResponse::success($result['asset'], 'Request completed successfully', 200, [
                'versions' => $result['versions'] ?? [],
                'restored_from_log_id' => $result['restored_from']['id'] ?? null,
                'change_log_id' => $result['change_log']['id'] ?? null,
                'action' => 'restore',
            ]);
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to restore media asset history.', null, 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $result = $this->media->delete(
                (string)($request->params['id'] ?? ''),
                DataChangeContext::fromRequest($request, ['change_scope' => 'media_assets'])
            );
            if ($result === null) {
                return ApiResponse::error('Media asset not found.', null, 404);
            }

            return ApiResponse::success([
                'deleted' => (bool)($result['deleted'] ?? false),
                'record_id' => $result['asset']['id'] ?? null,
                'archive_log_id' => $result['change_log']['id'] ?? null,
            ]);
        } catch (RuntimeException $e) {
            return ApiResponse::error('Validation failed', ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to delete media asset.', null, 500);
        }
    }
}
