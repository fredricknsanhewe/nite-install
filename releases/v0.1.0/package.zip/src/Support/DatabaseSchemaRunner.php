<?php
namespace App\Support;

use App\Config\Database;
use PDO;
use RuntimeException;

final class DatabaseSchemaRunner
{
    public static function read(): string
    {
        $schemaPath = Database::schemaPath();
        $schema = is_file($schemaPath) ? file_get_contents($schemaPath) : false;
        if (!is_string($schema) || trim($schema) === '') {
            throw new RuntimeException('Failed to read database schema file: ' . $schemaPath);
        }

        return $schema;
    }

    public static function apply(PDO $connection): void
    {
        $schema = self::read();
        if (Database::driver() !== 'mysql') {
            $connection->exec($schema);
            self::ensureMediaManagerSchema($connection);
            self::ensureMailQueueSchema($connection);
            self::ensureAuthLoginAttemptSchema($connection);
            return;
        }

        foreach (preg_split('/;\s*(?:\r?\n|$)/', $schema) ?: [] as $statement) {
            $statement = trim((string)$statement);
            if ($statement === '') {
                continue;
            }
            $connection->exec($statement);
        }

        self::ensureMediaManagerSchema($connection);
        self::ensureMailQueueSchema($connection);
        self::ensureAuthLoginAttemptSchema($connection);
    }

    private static function ensureMediaManagerSchema(PDO $connection): void
    {
        if (!self::tableExists($connection, 'media_assets')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS access_scope VARCHAR(20) NOT NULL DEFAULT 'private'");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS allowed_roles_json JSONB NOT NULL DEFAULT '[]'::JSONB");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS allowed_user_ids_json JSONB NOT NULL DEFAULT '[]'::JSONB");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS checksum_sha1 VARCHAR(40) NULL");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS current_version_number INTEGER NOT NULL DEFAULT 1");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS version_count INTEGER NOT NULL DEFAULT 1");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS updated_by_user_id UUID NULL");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()");
            $connection->exec("ALTER TABLE media_assets ALTER COLUMN public_url DROP NOT NULL");
            $connection->exec("UPDATE media_assets SET access_scope = 'public' WHERE access_scope = 'private' AND COALESCE(TRIM(public_url), '') <> ''");
            $connection->exec("UPDATE media_assets SET allowed_roles_json = '[]'::JSONB WHERE allowed_roles_json IS NULL");
            $connection->exec("UPDATE media_assets SET allowed_user_ids_json = '[]'::JSONB WHERE allowed_user_ids_json IS NULL");
            return;
        }

        self::ensureMysqlColumn($connection, 'media_assets', 'access_scope', "ALTER TABLE media_assets ADD COLUMN access_scope VARCHAR(20) NOT NULL DEFAULT 'private' AFTER alt_text");
        self::ensureMysqlColumn($connection, 'media_assets', 'allowed_roles_json', "ALTER TABLE media_assets ADD COLUMN allowed_roles_json JSON NULL AFTER access_scope");
        self::ensureMysqlColumn($connection, 'media_assets', 'allowed_user_ids_json', "ALTER TABLE media_assets ADD COLUMN allowed_user_ids_json JSON NULL AFTER allowed_roles_json");
        self::ensureMysqlColumn($connection, 'media_assets', 'checksum_sha1', "ALTER TABLE media_assets ADD COLUMN checksum_sha1 VARCHAR(40) NULL AFTER allowed_user_ids_json");
        self::ensureMysqlColumn($connection, 'media_assets', 'current_version_number', "ALTER TABLE media_assets ADD COLUMN current_version_number INT NOT NULL DEFAULT 1 AFTER checksum_sha1");
        self::ensureMysqlColumn($connection, 'media_assets', 'version_count', "ALTER TABLE media_assets ADD COLUMN version_count INT NOT NULL DEFAULT 1 AFTER current_version_number");
        self::ensureMysqlColumn($connection, 'media_assets', 'updated_by_user_id', "ALTER TABLE media_assets ADD COLUMN updated_by_user_id CHAR(36) NULL AFTER created_by_user_id");
        self::ensureMysqlColumn($connection, 'media_assets', 'updated_at', "ALTER TABLE media_assets ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER created_at");
        $connection->exec('ALTER TABLE media_assets MODIFY COLUMN public_url TEXT NULL');

        $connection->exec("UPDATE media_assets SET access_scope = 'public' WHERE access_scope = 'private' AND COALESCE(TRIM(public_url), '') <> ''");
        $connection->exec("UPDATE media_assets SET allowed_roles_json = JSON_ARRAY() WHERE allowed_roles_json IS NULL");
        $connection->exec("UPDATE media_assets SET allowed_user_ids_json = JSON_ARRAY() WHERE allowed_user_ids_json IS NULL");
    }

    private static function ensureMailQueueSchema(PDO $connection): void
    {
        if (self::tableExists($connection, 'mail_queue')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS mail_queue (
                    id UUID PRIMARY KEY,
                    message_type VARCHAR(80) NOT NULL DEFAULT 'transactional',
                    status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'sent', 'failed')),
                    transport VARCHAR(40) NOT NULL DEFAULT 'smtp',
                    priority INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
                    attempts INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 3,
                    to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    cc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    bcc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    reply_to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    subject VARCHAR(255) NOT NULL,
                    text_body TEXT NULL,
                    html_body TEXT NULL,
                    from_address VARCHAR(255) NOT NULL,
                    from_name VARCHAR(255) NULL,
                    sender_address VARCHAR(255) NULL,
                    headers_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    metadata_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    delivery_meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    last_error TEXT NULL,
                    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    reserved_at TIMESTAMPTZ NULL,
                    sent_at TIMESTAMPTZ NULL,
                    failed_at TIMESTAMPTZ NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_mail_queue_status_available ON mail_queue (status, available_at ASC, created_at ASC)');
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_mail_queue_type_status_created ON mail_queue (message_type, status, created_at DESC)');
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS mail_queue (
                id CHAR(36) PRIMARY KEY,
                message_type VARCHAR(80) NOT NULL DEFAULT 'transactional',
                status VARCHAR(20) NOT NULL DEFAULT 'queued',
                transport VARCHAR(40) NOT NULL DEFAULT 'smtp',
                priority INT NOT NULL DEFAULT 3,
                attempts INT NOT NULL DEFAULT 0,
                max_attempts INT NOT NULL DEFAULT 3,
                to_json JSON NOT NULL,
                cc_json JSON NOT NULL,
                bcc_json JSON NOT NULL,
                reply_to_json JSON NOT NULL,
                subject VARCHAR(255) NOT NULL,
                text_body TEXT NULL,
                html_body LONGTEXT NULL,
                from_address VARCHAR(255) NOT NULL,
                from_name VARCHAR(255) NULL,
                sender_address VARCHAR(255) NULL,
                headers_json JSON NOT NULL,
                metadata_json JSON NOT NULL,
                delivery_meta_json JSON NOT NULL,
                last_error LONGTEXT NULL,
                available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                reserved_at DATETIME NULL,
                sent_at DATETIME NULL,
                failed_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_mail_queue_status_available (status, available_at, created_at),
                KEY idx_mail_queue_type_status_created (message_type, status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function ensureAuthLoginAttemptSchema(PDO $connection): void
    {
        if (self::tableExists($connection, 'auth_login_attempts')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS auth_login_attempts (
                    id UUID PRIMARY KEY,
                    throttle_key VARCHAR(128) NOT NULL UNIQUE,
                    email VARCHAR(255) NOT NULL,
                    ip_address VARCHAR(64) NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    first_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    last_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    locked_until TIMESTAMPTZ NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_auth_login_attempts_last_attempt ON auth_login_attempts (last_attempt_at DESC)');
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS auth_login_attempts (
                id CHAR(36) PRIMARY KEY,
                throttle_key VARCHAR(128) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL,
                ip_address VARCHAR(64) NOT NULL,
                attempts INT NOT NULL DEFAULT 0,
                first_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                locked_until DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_auth_login_attempts_last_attempt (last_attempt_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function tableExists(PDO $connection, string $table): bool
    {
        if (Database::driver() === 'pgsql') {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = :table');
        } else {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :table');
        }

        $statement->execute([':table' => $table]);
        return (int)$statement->fetchColumn() > 0;
    }

    private static function ensureMysqlColumn(PDO $connection, string $table, string $column, string $ddl): void
    {
        $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :column');
        $statement->execute([
            ':table' => $table,
            ':column' => $column,
        ]);
        if ((int)$statement->fetchColumn() > 0) {
            return;
        }

        $connection->exec($ddl);
    }
}
