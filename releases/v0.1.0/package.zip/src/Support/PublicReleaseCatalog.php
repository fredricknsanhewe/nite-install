<?php
namespace App\Support;

final class PublicReleaseCatalog
{
    public const RELEASES_DIRECTORY = 'releases';
    public const LATEST_INDEX = 'latest.json';

    public static function normalizeTag(string $value): string
    {
        $version = self::normalizeVersion($value);
        return $version === '' ? '' : 'v' . $version;
    }

    public static function normalizeVersion(string $value): string
    {
        return ltrim(strtolower(trim($value)), 'v');
    }

    /**
     * @param array<int, string> $tags
     * @return array<int, string>
     */
    public static function sortTags(array $tags): array
    {
        $normalized = [];
        foreach ($tags as $tag) {
            $resolved = self::normalizeTag((string)$tag);
            if ($resolved === '') {
                continue;
            }
            $normalized[$resolved] = true;
        }

        $values = array_keys($normalized);
        usort($values, static function (string $left, string $right): int {
            return version_compare(self::normalizeVersion($left), self::normalizeVersion($right));
        });

        return $values;
    }

    /**
     * @param array<int, string> $tags
     * @return array<string, mixed>
     */
    public static function latestPayload(array $tags): array
    {
        $versions = self::sortTags($tags);
        return [
            'latest' => $versions === [] ? '' : $versions[count($versions) - 1],
            'versions' => $versions,
        ];
    }

    public static function releaseDirectory(string $tag): string
    {
        $resolved = self::normalizeTag($tag);
        return self::RELEASES_DIRECTORY . '/' . $resolved;
    }

    public static function packageRelativePath(string $tag): string
    {
        return self::releaseDirectory($tag) . '/package.zip';
    }

    public static function manifestRelativePath(string $tag): string
    {
        return self::releaseDirectory($tag) . '/release.json';
    }
}
