<?php
namespace App\Support;

use App\Console\ConsoleSupport;
use RuntimeException;

final class AppPresetCatalog
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function presets(): array
    {
        static $presets = null;
        if ($presets !== null) {
            return $presets;
        }

        $presets = [
            'basic' => [
                'key' => 'basic',
                'title' => 'Basic Starter',
                'summary' => 'Content, governance, and light operational CRUD for a small internal or public-facing application.',
                'modules' => ['content', 'catalog', 'governance'],
                'operations' => [
                    'Public pages, posts, media, and settings',
                    'Admin CRUD and RBAC',
                    'Audit logging and JWT auth',
                    'Simple inbound operations records',
                ],
                'resources' => [
                    self::resource('ContactRequest', 'Contact Request', 'Inbound contact or lead submissions that can be reviewed and managed from the admin API.'),
                    self::resource('TeamProfile', 'Team Profile', 'Reusable people, staff, or partner directory entries for public or internal use.'),
                    self::resource('SupportFaq', 'Support FAQ', 'Structured help-center or FAQ entries that sit alongside the main content system.'),
                ],
            ],
            'standard' => [
                'key' => 'standard',
                'title' => 'Standard Operations',
                'summary' => 'A stronger business baseline with content, workflow, messaging, governance, and a clean set of starter business entities.',
                'modules' => ['content', 'catalog', 'workflow', 'messaging', 'governance'],
                'operations' => [
                    'Public content and media',
                    'Customer and work tracking',
                    'Messaging and notification patterns',
                    'Admin CRUD, RBAC, and audit logs',
                ],
                'resources' => [
                    self::resource('CustomerAccount', 'Customer Account', 'Customer or client records that give the app a concrete account-level domain object.'),
                    self::resource('ProjectBoard', 'Project Board', 'High-level projects, workspaces, or engagements used to organize operational work.'),
                    self::resource('TaskItem', 'Task Item', 'Individual work items, follow-ups, or checklist records connected to day-to-day execution.'),
                    self::resource('SupportTicket', 'Support Ticket', 'Issue, request, or case records for internal support and customer support flows.'),
                ],
            ],
            'advanced' => [
                'key' => 'advanced',
                'title' => 'Advanced Platform',
                'summary' => 'A broad, production-shaped blueprint for multi-team systems that need workflow, messaging, analytics, billing, trust, and richer integrations.',
                'modules' => ['content', 'catalog', 'workflow', 'messaging', 'analytics', 'payments', 'subscriptions', 'trust', 'governance'],
                'operations' => [
                    'Public content and media',
                    'Operations and workflow entities',
                    'Messaging, notifications, and webhook-style flows',
                    'Billing and subscription primitives',
                    'Analytics, trust actions, RBAC, and audit logs',
                ],
                'resources' => [
                    self::resource('CustomerAccount', 'Customer Account', 'Customer or tenant records that anchor the rest of the product data model.'),
                    self::resource('ProjectBoard', 'Project Board', 'High-level projects, workspaces, or delivery streams for operational tracking.'),
                    self::resource('TaskItem', 'Task Item', 'Operational tasks and queued work that teams can extend into richer workflows later.'),
                    self::resource('SupportTicket', 'Support Ticket', 'Support or escalation records that fit both internal and external service flows.'),
                    self::resource('InvoiceRecord', 'Invoice Record', 'Billable records and invoice-like entities that complement the built-in payment patterns.'),
                    self::resource('WebhookDelivery', 'Webhook Delivery', 'Tracked webhook send attempts, delivery outcomes, and retry metadata.'),
                    self::resource('IntegrationConnection', 'Integration Connection', 'External service connection records for keys, tenant bindings, or sync state.'),
                    self::resource('RiskIncident', 'Risk Incident', 'Fraud, risk, or compliance incidents that pair with trust and governance workflows.'),
                ],
            ],
        ];

        return $presets;
    }

    /**
     * @return array<string, mixed>
     */
    public static function preset(string $key): array
    {
        $normalized = strtolower(trim($key));
        $preset = self::presets()[$normalized] ?? null;
        if (!is_array($preset)) {
            throw new RuntimeException('Unknown app preset: ' . $key . '. Supported presets: ' . implode(', ', array_keys(self::presets())));
        }

        return $preset;
    }

    /**
     * @param array<int, string> $withModules
     * @param array<int, string> $withoutModules
     * @param array<int, string> $extraResources
     * @return array<string, mixed>
     */
    public static function resolve(string $key, array $withModules = [], array $withoutModules = [], array $extraResources = []): array
    {
        $preset = self::preset($key);
        $modules = array_values($preset['modules']);

        foreach ($withModules as $moduleKey) {
            $normalized = strtolower(trim($moduleKey));
            if ($normalized === '') {
                continue;
            }
            if (!NiteModuleCatalog::hasModule($normalized)) {
                throw new RuntimeException('Unknown module key: ' . $moduleKey);
            }
            if (!in_array($normalized, $modules, true)) {
                $modules[] = $normalized;
            }
        }

        foreach ($withoutModules as $moduleKey) {
            $normalized = strtolower(trim($moduleKey));
            if ($normalized === '') {
                continue;
            }
            if (!NiteModuleCatalog::hasModule($normalized)) {
                throw new RuntimeException('Unknown module key: ' . $moduleKey);
            }
            $modules = array_values(array_filter($modules, static fn (string $value): bool => $value !== $normalized));
        }

        if ($modules === []) {
            throw new RuntimeException('At least one focus module must remain after applying --without.');
        }

        $resources = [];
        foreach (array_values(is_array($preset['resources'] ?? null) ? $preset['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $resources[self::resourceKey((string)($resource['name'] ?? ''))] = $resource;
        }

        foreach ($extraResources as $resourceName) {
            $normalizedName = ConsoleSupport::studly($resourceName);
            if ($normalizedName === '') {
                continue;
            }
            $resources[self::resourceKey($normalizedName)] = self::resource(
                $normalizedName,
                self::labelFromName($normalizedName),
                'Custom starter resource scaffolded during app bootstrap.'
            );
        }

        $preset['modules'] = array_values($modules);
        $preset['resources'] = array_values($resources);

        return $preset;
    }

    /**
     * @return array<string, string>
     */
    private static function resource(string $name, string $label, string $summary): array
    {
        return [
            'name' => ConsoleSupport::studly($name),
            'label' => trim($label),
            'group' => 'generated',
            'item_type' => ConsoleSupport::studly($name),
            'summary' => trim($summary),
        ];
    }

    private static function labelFromName(string $name): string
    {
        return trim((string)(preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', ConsoleSupport::studly($name)) ?? $name));
    }

    private static function resourceKey(string $name): string
    {
        return strtolower(ConsoleSupport::studly($name));
    }
}
