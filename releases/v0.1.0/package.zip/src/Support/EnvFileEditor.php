<?php
namespace App\Support;

use App\Console\ConsoleSupport;
use RuntimeException;

final class EnvFileEditor
{
    /**
     * @return array<string, string>
     */
    public static function read(string $path): array
    {
        if (!is_file($path)) {
            return [];
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            throw new RuntimeException('Failed to read env file: ' . $path);
        }

        $values = [];
        foreach ($lines as $line) {
            $trimmed = trim((string)$line);
            if ($trimmed === '' || str_starts_with($trimmed, '#') || !str_contains($trimmed, '=')) {
                continue;
            }

            [$key, $value] = explode('=', $trimmed, 2);
            $normalizedKey = trim($key);
            if ($normalizedKey === '') {
                continue;
            }

            $values[$normalizedKey] = trim(trim($value), "\"'");
        }

        return $values;
    }

    public static function ensureFile(string $path, ?string $templatePath = null): void
    {
        if (is_file($path)) {
            return;
        }

        ConsoleSupport::ensureDirectory(dirname($path));

        if ($templatePath !== null && $templatePath !== '' && is_file($templatePath)) {
            if (!@copy($templatePath, $path)) {
                throw new RuntimeException('Failed to create env file from template: ' . $path);
            }
            return;
        }

        if (file_put_contents($path, '') === false) {
            throw new RuntimeException('Failed to create env file: ' . $path);
        }
    }

    /**
     * @param array<string, scalar|null> $values
     */
    public static function upsert(string $path, array $values): void
    {
        self::ensureFile($path);

        $lines = file($path, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            throw new RuntimeException('Failed to read env file for update: ' . $path);
        }

        $normalizedValues = [];
        foreach ($values as $key => $value) {
            $normalizedKey = trim((string)$key);
            if ($normalizedKey === '' || $value === null) {
                continue;
            }
            $normalizedValues[$normalizedKey] = (string)$value;
        }

        $written = [];
        foreach ($lines as $index => $line) {
            if (preg_match('/^\s*([A-Z0-9_]+)\s*=/', (string)$line, $matches) !== 1) {
                continue;
            }

            $key = (string)($matches[1] ?? '');
            if (!array_key_exists($key, $normalizedValues)) {
                continue;
            }

            $lines[$index] = $key . '=' . self::formatValue($normalizedValues[$key]);
            $written[$key] = true;
        }

        $append = [];
        foreach ($normalizedValues as $key => $value) {
            if (isset($written[$key])) {
                continue;
            }
            $append[] = $key . '=' . self::formatValue($value);
        }

        if ($append !== []) {
            if ($lines !== [] && trim((string)end($lines)) !== '') {
                $lines[] = '';
            }
            array_push($lines, ...$append);
        }

        $content = implode(PHP_EOL, $lines);
        if ($content !== '') {
            $content .= PHP_EOL;
        }

        if (file_put_contents($path, $content) === false) {
            throw new RuntimeException('Failed to write env file: ' . $path);
        }
    }

    private static function formatValue(string $value): string
    {
        if ($value === '') {
            return '';
        }

        if (preg_match('/^[A-Za-z0-9_:\\/.@,+%-]+$/', $value) === 1) {
            return $value;
        }

        return '"' . addcslashes($value, "\\\"") . '"';
    }
}
