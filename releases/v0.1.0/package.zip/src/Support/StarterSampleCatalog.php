<?php
namespace App\Support;

use App\Console\ConsoleSupport;
use RuntimeException;

/**
 * Starter sample-pack catalog.
 *
 * Sample packs are large, data-driven bundles that can be generated into
 * browsable framework examples and optional JSON artifacts. They are designed to
 * scale without requiring one hand-authored file per example.
 *
 * Built-ins are loaded from PHP arrays and can be extended with local JSON
 * files under `blueprints/starters/samples/*.json`.
 *
 * @phpstan-type SamplePackEntity array{
 *   module_key: string,
 *   entity_type: string,
 *   label: string,
 *   subjects: list<string>,
 *   contexts: list<string>,
 *   pack_key?: string,
 *   pack_title?: string
 * }
 * @phpstan-type SamplePack array{
 *   key: string,
 *   title: string,
 *   summary: string,
 *   entities: list<SamplePackEntity>
 * }
 * @phpstan-type StarterSampleItem array{
 *   module_key: string,
 *   entity_type: string,
 *   pack_key: string,
 *   pack_title: string,
 *   slug: string,
 *   title: string,
 *   summary: string,
 *   status: string,
 *   payload: array<string, mixed>
 * }
 * @phpstan-type StarterSampleBundle array{
 *   starter_key: string,
 *   count: int,
 *   packs: list<array{key: string, title: string, summary: string}>,
 *   items: list<StarterSampleItem>
 * }
 */
final class StarterSampleCatalog
{
    /**
     * List every registered starter sample pack.
     *
     * @return array<string, SamplePack>
     */
    public static function packs(?string $rootPath = null): array
    {
        $rootPath = $rootPath ?? ConsoleSupport::rootPath();
        $packs = [];
        foreach (self::builtIns() as $pack) {
            $packs[(string)$pack['key']] = $pack;
        }
        foreach (self::loadJsonDefinitions($rootPath) as $pack) {
            $packs[(string)$pack['key']] = $pack;
        }

        ksort($packs, SORT_STRING);
        return $packs;
    }

    /**
     * @param array<string, mixed> $starter
     * @param array<int, string> $requestedPackKeys
     *
     * Example:
     * `StarterSampleCatalog::selectedPacks($starter, ['inventory-core', 'inventory-analytics'])`
     *
     * @return list<SamplePack>
     */
    public static function selectedPacks(array $starter, array $requestedPackKeys = [], ?string $rootPath = null): array
    {
        $catalog = self::packs($rootPath);
        $packKeys = $requestedPackKeys !== []
            ? $requestedPackKeys
            : array_values(is_array($starter['sample_packs'] ?? null) ? array_map('strval', $starter['sample_packs']) : []);

        $selected = [];
        foreach ($packKeys as $packKey) {
            $normalized = ConsoleSupport::kebab($packKey);
            $pack = $catalog[$normalized] ?? null;
            if (!is_array($pack)) {
                throw new RuntimeException('Unknown starter sample pack: ' . $packKey);
            }
            $selected[$normalized] = $pack;
        }

        return array_values($selected);
    }

    /**
     * Generate a sample bundle for one starter application.
     *
     * @param array<string, mixed> $starter
     * @param array<int, string> $requestedPackKeys
     *
     * Example:
     * `StarterSampleCatalog::generateBundle($starter, ['pos-retail'], 500)`
     *
     * @return StarterSampleBundle
     */
    public static function generateBundle(
        array $starter,
        array $requestedPackKeys = [],
        ?int $requestedCount = null,
        ?string $rootPath = null
    ): array {
        $packs = self::selectedPacks($starter, $requestedPackKeys, $rootPath);
        $defaultCount = max(0, (int)($starter['default_sample_count'] ?? 0));
        $count = $requestedCount === null ? $defaultCount : max(0, $requestedCount);

        if ($packs === [] || $count === 0) {
            return [
                'starter_key' => (string)($starter['key'] ?? ''),
                'count' => 0,
                'packs' => [],
                'items' => [],
            ];
        }

        $entitySpecs = [];
        foreach ($packs as $pack) {
            foreach (array_values(is_array($pack['entities'] ?? null) ? $pack['entities'] : []) as $entity) {
                if (!is_array($entity)) {
                    continue;
                }

                $moduleKey = trim((string)($entity['module_key'] ?? ''));
                $entityType = trim((string)($entity['entity_type'] ?? ''));
                if ($moduleKey === '' || $entityType === '') {
                    continue;
                }
                if (!NiteModuleCatalog::hasEntity($moduleKey, $entityType)) {
                    continue;
                }

                $entity['pack_key'] = (string)($pack['key'] ?? '');
                $entity['pack_title'] = (string)($pack['title'] ?? '');
                $entitySpecs[] = $entity;
            }
        }

        if ($entitySpecs === []) {
            return [
                'starter_key' => (string)($starter['key'] ?? ''),
                'count' => 0,
                'packs' => $packs,
                'items' => [],
            ];
        }

        $items = [];
        for ($i = 0; $i < $count; $i++) {
            $spec = $entitySpecs[$i % count($entitySpecs)];
            $items[] = self::sampleItem($starter, $spec, $i + 1);
        }

        return [
            'starter_key' => (string)($starter['key'] ?? ''),
            'count' => count($items),
            'packs' => array_map(static function (array $pack): array {
                return [
                    'key' => (string)($pack['key'] ?? ''),
                    'title' => (string)($pack['title'] ?? ''),
                    'summary' => (string)($pack['summary'] ?? ''),
                ];
            }, $packs),
            'items' => $items,
        ];
    }

    /**
     * @return list<SamplePack>
     */
    private static function builtIns(): array
    {
        return [
            self::pack(
                'website-core',
                'Website Core Samples',
                'Pages, resources, and public-facing content structures for a complete website starter.',
                [
                    self::entity('content', 'pages', 'Landing Page', ['North Region', 'Platform', 'Growth', 'Field Operations'], ['overview', 'features', 'faqs', 'cta']),
                    self::entity('content', 'resources', 'Knowledge Resource', ['Implementation', 'Operations', 'Compliance', 'Templates'], ['download', 'guideline', 'reference', 'checklist']),
                    self::entity('content', 'news', 'Announcement', ['Launch', 'Update', 'Service', 'Partner'], ['release', 'notice', 'campaign', 'initiative']),
                ]
            ),
            self::pack(
                'content-marketing',
                'Content Marketing Samples',
                'Campaign-ready entries, tags, and reusable promotional examples.',
                [
                    self::entity('catalog', 'tags', 'Campaign Tag', ['Summer', 'Enterprise', 'Africa', 'Digital'], ['campaign', 'content', 'focus', 'theme']),
                    self::entity('messaging', 'notifications', 'Marketing Notification', ['Launch', 'Newsletter', 'Event', 'Follow-up'], ['email', 'push', 'campaign', 'reminder']),
                    self::entity('analytics', 'dashboards', 'Content Dashboard', ['Engagement', 'Leads', 'SEO', 'Traffic'], ['overview', 'campaign', 'weekly', 'growth']),
                ]
            ),
            self::pack(
                'team-directory',
                'Team Directory Samples',
                'People, supporting content, and governance-side directory examples.',
                [
                    self::entity('governance', 'users', 'Team Member', ['North', 'Central', 'Support', 'Field'], ['lead', 'manager', 'coordinator', 'specialist']),
                    self::entity('content', 'resources', 'Team Resource', ['Onboarding', 'Policy', 'Handbook', 'Profile'], ['guide', 'profile', 'bio', 'document']),
                ]
            ),
            self::pack(
                'inventory-core',
                'Inventory Core Samples',
                'Core inventory entities represented through catalog and workflow examples.',
                [
                    self::entity('catalog', 'categories', 'Inventory Category', ['Raw Material', 'Finished Goods', 'Packaging', 'Consumables'], ['group', 'stock', 'family', 'class']),
                    self::entity('workflow', 'work_items', 'Stock Task', ['Cycle Count', 'Restock', 'Transfer', 'Audit'], ['task', 'queue', 'shift', 'exception']),
                    self::entity('analytics', 'dashboards', 'Stock Dashboard', ['Warehouse', 'Reorder', 'Turnover', 'Loss'], ['overview', 'status', 'insight', 'review']),
                ]
            ),
            self::pack(
                'inventory-procurement',
                'Inventory Procurement Samples',
                'Supplier, purchase, and replenishment operational samples.',
                [
                    self::entity('workflow', 'offers', 'Purchase Offer', ['Primary', 'Fallback', 'Bulk', 'Urgent'], ['quote', 'supply', 'vendor', 'batch']),
                    self::entity('messaging', 'integrations', 'Vendor Integration', ['Supplier Sync', 'EDI Feed', 'Purchase Webhook', 'ASN Flow'], ['integration', 'sync', 'connector', 'feed']),
                    self::entity('workflow', 'reports', 'Procurement Report', ['Variance', 'Shortage', 'Lead Time', 'Pending'], ['report', 'analysis', 'summary', 'review']),
                ]
            ),
            self::pack(
                'inventory-analytics',
                'Inventory Analytics Samples',
                'Monitoring and alerting-oriented stock analytics samples.',
                [
                    self::entity('analytics', 'tracking_events', 'Stock Event', ['Shrinkage', 'Transfer', 'Recount', 'Receipt'], ['event', 'signal', 'monitor', 'stream']),
                    self::entity('analytics', 'anomalies', 'Stock Anomaly', ['Variance', 'Delay', 'Mismatch', 'Spike'], ['flag', 'exception', 'issue', 'alert']),
                    self::entity('analytics', 'rules', 'Inventory Rule', ['Reorder', 'Escalation', 'Aging', 'Threshold'], ['rule', 'policy', 'trigger', 'guard']),
                ]
            ),
            self::pack(
                'pos-retail',
                'POS Retail Samples',
                'Checkout, store, and cashier-focused operational samples.',
                [
                    self::entity('workflow', 'work_items', 'Store Shift Task', ['Open Register', 'Close Register', 'Restock Shelf', 'Price Audit'], ['shift', 'checkout', 'store', 'task']),
                    self::entity('analytics', 'tracking_events', 'POS Event', ['Checkout', 'Return', 'Drawer Open', 'Receipt Send'], ['event', 'sale', 'terminal', 'signal']),
                    self::entity('catalog', 'tags', 'Store Label', ['Promo', 'Seasonal', 'Outlet', 'Fast Lane'], ['tag', 'label', 'channel', 'marker']),
                ]
            ),
            self::pack(
                'pos-payments',
                'POS Payments Samples',
                'Transaction, dispute, and callback oriented POS examples.',
                [
                    self::entity('payments', 'transactions', 'POS Transaction', ['Cash', 'Card', 'Wallet', 'Split'], ['sale', 'payment', 'checkout', 'settlement']),
                    self::entity('payments', 'callback_queue', 'POS Callback', ['Approval', 'Receipt', 'Refund', 'Settlement'], ['callback', 'queue', 'payment', 'webhook']),
                    self::entity('payments', 'disputes', 'POS Dispute', ['Chargeback', 'Mismatch', 'Refund', 'Reversal'], ['issue', 'review', 'payment', 'case']),
                ]
            ),
            self::pack(
                'pos-operations',
                'POS Operations Samples',
                'Operational exceptions, notifications, and store review samples.',
                [
                    self::entity('messaging', 'notifications', 'Store Alert', ['Drawer Variance', 'Terminal Offline', 'Promo Activated', 'Receipt Failure'], ['alert', 'notice', 'store', 'signal']),
                    self::entity('analytics', 'dashboards', 'Retail Dashboard', ['Revenue', 'Store Mix', 'Queue Times', 'Conversion'], ['overview', 'daily', 'weekly', 'regional']),
                    self::entity('workflow', 'reports', 'Store Report', ['Closing', 'Refund', 'Promotion', 'Daily Sales'], ['report', 'summary', 'brief', 'analysis']),
                ]
            ),
            self::pack(
                'crm-pipeline',
                'CRM Pipeline Samples',
                'Pipeline and opportunity examples for CRM-shaped starters.',
                [
                    self::entity('workflow', 'offers', 'Deal Opportunity', ['Expansion', 'Renewal', 'Pilot', 'New Market'], ['pipeline', 'deal', 'account', 'opportunity']),
                    self::entity('messaging', 'conversations', 'Account Conversation', ['Qualification', 'Demo', 'Review', 'Renewal'], ['thread', 'email', 'meeting', 'follow-up']),
                    self::entity('analytics', 'dashboards', 'Sales Dashboard', ['Pipeline', 'Forecast', 'Conversion', 'Retention'], ['overview', 'leaderboard', 'weekly', 'regional']),
                ]
            ),
            self::pack(
                'crm-accounts',
                'CRM Account Samples',
                'Account and relationship-oriented CRM examples.',
                [
                    self::entity('catalog', 'service_areas', 'Customer Segment', ['Enterprise', 'SMB', 'Public Sector', 'Nonprofit'], ['segment', 'account', 'cluster', 'portfolio']),
                    self::entity('workflow', 'milestones', 'Account Milestone', ['Onboarding', 'First Value', 'Renewal', 'Expansion'], ['stage', 'account', 'milestone', 'checkpoint']),
                    self::entity('messaging', 'notifications', 'Relationship Alert', ['Renewal Due', 'Stakeholder Change', 'Escalation', 'Win Risk'], ['alert', 'account', 'success', 'watch']),
                ]
            ),
            self::pack(
                'crm-success',
                'CRM Success Samples',
                'Customer success and retention lifecycle examples.',
                [
                    self::entity('workflow', 'ratings', 'Health Score', ['Green', 'Amber', 'Red', 'Recovery'], ['score', 'health', 'retention', 'status']),
                    self::entity('trust', 'reports', 'Churn Risk Report', ['Adoption Drop', 'Invoice Risk', 'Support Risk', 'Stakeholder Drift'], ['risk', 'retention', 'report', 'signal']),
                    self::entity('analytics', 'tracking_events', 'Success Event', ['QBR', 'Renewal Prep', 'Training', 'Escalation'], ['event', 'customer', 'lifecycle', 'touchpoint']),
                ]
            ),
            self::pack(
                'support-core',
                'Support Core Samples',
                'Ticket queue and response-oriented support examples.',
                [
                    self::entity('workflow', 'work_items', 'Support Task', ['New Ticket', 'Escalated Case', 'Follow-up', 'Resolution'], ['ticket', 'support', 'queue', 'case']),
                    self::entity('messaging', 'conversations', 'Support Conversation', ['First Reply', 'Clarification', 'Escalation', 'Resolution'], ['thread', 'support', 'email', 'chat']),
                    self::entity('analytics', 'dashboards', 'Support Dashboard', ['Backlog', 'SLA', 'First Reply', 'CSAT'], ['overview', 'ops', 'daily', 'queue']),
                ]
            ),
            self::pack(
                'support-escalations',
                'Support Escalation Samples',
                'Escalation and trust-related support samples.',
                [
                    self::entity('trust', 'moderation_actions', 'Escalation Action', ['Priority Raise', 'Supervisor Review', 'Abuse Check', 'Policy Flag'], ['action', 'support', 'review', 'intervention']),
                    self::entity('trust', 'reports', 'Service Risk', ['SLA Breach', 'Repeat Contact', 'Abuse Pattern', 'Data Concern'], ['risk', 'support', 'report', 'case']),
                    self::entity('messaging', 'notifications', 'Escalation Alert', ['SLA Warning', 'Hot Ticket', 'Supervisor Watch', 'Queue Overflow'], ['alert', 'support', 'escalation', 'warning']),
                ]
            ),
            self::pack(
                'support-knowledge',
                'Support Knowledge Samples',
                'FAQ and knowledge sidecar samples for support apps.',
                [
                    self::entity('content', 'resources', 'Knowledge Article', ['Login Issue', 'Billing Question', 'Account Setup', 'Export Guide'], ['article', 'support', 'faq', 'walkthrough']),
                    self::entity('chatbot', 'knowledge', 'Assistant Knowledge', ['Password Reset', 'Receipt Lookup', 'Course Access', 'API Setup'], ['knowledge', 'assistant', 'support', 'faq']),
                ]
            ),
            self::pack(
                'learning-catalog',
                'Learning Catalog Samples',
                'Course and content catalog learning samples.',
                [
                    self::entity('learning', 'courses', 'Course Sample', ['Onboarding', 'Leadership', 'Compliance', 'Field Safety'], ['course', 'path', 'module', 'track']),
                    self::entity('content', 'resources', 'Learning Resource', ['Workbook', 'Guide', 'Slide Deck', 'Checklist'], ['resource', 'learning', 'document', 'asset']),
                    self::entity('analytics', 'dashboards', 'Learning Dashboard', ['Completion', 'Engagement', 'Cohort', 'Trainer'], ['overview', 'weekly', 'insight', 'monitor']),
                ]
            ),
            self::pack(
                'learning-cohorts',
                'Learning Cohort Samples',
                'Enrollment and cohort operation samples.',
                [
                    self::entity('learning', 'events', 'Training Event', ['Cohort Launch', 'Live Session', 'Review Workshop', 'Final Assessment'], ['event', 'cohort', 'session', 'learning']),
                    self::entity('messaging', 'notifications', 'Learner Alert', ['Session Reminder', 'Assignment Due', 'Completion Notice', 'Waitlist Update'], ['alert', 'learner', 'reminder', 'notice']),
                    self::entity('workflow', 'milestones', 'Cohort Milestone', ['Kickoff', 'Midpoint', 'Assessment', 'Completion'], ['milestone', 'cohort', 'learning', 'checkpoint']),
                ]
            ),
            self::pack(
                'learning-assessments',
                'Learning Assessment Samples',
                'Assessment and certification samples for learning systems.',
                [
                    self::entity('workflow', 'reports', 'Assessment Report', ['Quiz Summary', 'Exam Variance', 'Certification Ready', 'Retake Queue'], ['report', 'assessment', 'summary', 'learning']),
                    self::entity('analytics', 'tracking_events', 'Assessment Event', ['Attempt Start', 'Attempt Submit', 'Certificate Issue', 'Retake'], ['event', 'assessment', 'learning', 'signal']),
                    self::entity('content', 'news', 'Program Notice', ['Exam Window', 'Policy Change', 'Certificate Update', 'New Cohort'], ['notice', 'learning', 'announcement', 'bulletin']),
                ]
            ),
            self::pack(
                'clinic-appointments',
                'Clinic Appointment Samples',
                'Appointment and scheduling examples for clinic operations.',
                [
                    self::entity('workflow', 'work_items', 'Appointment Task', ['Confirm Booking', 'Reschedule Visit', 'Intake Review', 'Follow-up Call'], ['task', 'appointment', 'clinic', 'case']),
                    self::entity('messaging', 'notifications', 'Appointment Reminder', ['24 Hour Reminder', 'Missed Visit', 'Doctor Delay', 'Room Ready'], ['reminder', 'appointment', 'clinic', 'notice']),
                    self::entity('analytics', 'dashboards', 'Clinic Schedule Dashboard', ['Utilization', 'No Show', 'Wait Time', 'Provider Mix'], ['overview', 'clinic', 'ops', 'schedule']),
                ]
            ),
            self::pack(
                'clinic-care',
                'Clinic Care Samples',
                'Care-plan and service lifecycle samples.',
                [
                    self::entity('workflow', 'milestones', 'Care Milestone', ['Initial Review', 'Treatment Start', 'Review Visit', 'Discharge'], ['milestone', 'care', 'clinic', 'checkpoint']),
                    self::entity('content', 'resources', 'Care Resource', ['Prep Guide', 'Aftercare Note', 'Consent Form', 'Service Sheet'], ['care', 'clinic', 'resource', 'guide']),
                    self::entity('trust', 'reports', 'Clinical Incident', ['Allergy Alert', 'Consent Gap', 'No Show Pattern', 'Escalation'], ['clinic', 'risk', 'report', 'incident']),
                ]
            ),
            self::pack(
                'clinic-operations',
                'Clinic Operations Samples',
                'Admin and analytics samples for practice operations.',
                [
                    self::entity('analytics', 'tracking_events', 'Clinic Event', ['Check-In', 'Service Complete', 'Prescription Ready', 'Billing Hand-off'], ['event', 'clinic', 'ops', 'service']),
                    self::entity('workflow', 'reports', 'Practice Report', ['Daily Throughput', 'Follow-up Load', 'Staff Coverage', 'Billing Gap'], ['report', 'clinic', 'ops', 'summary']),
                    self::entity('catalog', 'service_areas', 'Service Unit', ['Dentistry', 'Counselling', 'Nursing', 'Telehealth'], ['unit', 'clinic', 'service', 'department']),
                ]
            ),
            self::pack(
                'school-academics',
                'School Academic Samples',
                'Course, class, and academic planning samples.',
                [
                    self::entity('learning', 'courses', 'Subject Track', ['Mathematics', 'Science', 'History', 'Language'], ['course', 'subject', 'class', 'curriculum']),
                    self::entity('workflow', 'milestones', 'Academic Milestone', ['Term Start', 'Exam Prep', 'Results Review', 'Parent Session'], ['milestone', 'school', 'academic', 'checkpoint']),
                    self::entity('content', 'news', 'School Notice', ['Admissions Update', 'Holiday Plan', 'Assessment Week', 'Activities Day'], ['notice', 'school', 'bulletin', 'announcement']),
                ]
            ),
            self::pack(
                'school-attendance',
                'School Attendance Samples',
                'Attendance and learner support operational samples.',
                [
                    self::entity('analytics', 'tracking_events', 'Attendance Event', ['Late Arrival', 'Early Leave', 'Absence Logged', 'Class Entry'], ['attendance', 'school', 'event', 'signal']),
                    self::entity('workflow', 'reports', 'Attendance Report', ['Weekly Attendance', 'At Risk Learners', 'Teacher Rollup', 'Guardian Alert'], ['report', 'attendance', 'school', 'summary']),
                    self::entity('messaging', 'notifications', 'Guardian Alert', ['Missed Class', 'Pickup Reminder', 'Exam Notice', 'Behaviour Note'], ['alert', 'school', 'guardian', 'notice']),
                ]
            ),
            self::pack(
                'school-communications',
                'School Communication Samples',
                'Parent and school communication examples.',
                [
                    self::entity('messaging', 'conversations', 'School Conversation', ['Parent Inquiry', 'Class Update', 'Wellness Check', 'Assignment Question'], ['thread', 'school', 'parent', 'message']),
                    self::entity('chatbot', 'conversations', 'School Assistant Thread', ['Admission Question', 'Fees Query', 'Timetable Help', 'Results Help'], ['assistant', 'school', 'question', 'support']),
                    self::entity('catalog', 'tags', 'School Label', ['Sports', 'STEM', 'Boarding', 'Primary'], ['tag', 'school', 'cohort', 'focus']),
                ]
            ),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function loadJsonDefinitions(string $rootPath): array
    {
        $directory = $rootPath . '/blueprints/starters/samples';
        if (!is_dir($directory)) {
            return [];
        }

        $results = [];
        foreach (glob($directory . '/*.json') ?: [] as $path) {
            $decoded = json_decode((string)file_get_contents($path), true);
            if (!is_array($decoded)) {
                continue;
            }

            $normalized = self::normalizePack($decoded);
            if ($normalized !== null) {
                $results[] = $normalized;
            }
        }

        return $results;
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function normalizePack(array $input): ?array
    {
        $key = ConsoleSupport::kebab((string)($input['key'] ?? ''));
        if ($key === '') {
            return null;
        }

        $entities = [];
        foreach (array_values(is_array($input['entities'] ?? null) ? $input['entities'] : []) as $entity) {
            if (!is_array($entity)) {
                continue;
            }

            $moduleKey = trim((string)($entity['module_key'] ?? ''));
            $entityType = trim((string)($entity['entity_type'] ?? ''));
            if ($moduleKey === '' || $entityType === '') {
                continue;
            }

            $entities[] = self::entity(
                $moduleKey,
                $entityType,
                trim((string)($entity['label'] ?? 'Sample')),
                array_values(is_array($entity['subjects'] ?? null) ? array_map('strval', $entity['subjects']) : ['Example']),
                array_values(is_array($entity['contexts'] ?? null) ? array_map('strval', $entity['contexts']) : ['general'])
            );
        }

        return self::pack(
            $key,
            trim((string)($input['title'] ?? $key)),
            trim((string)($input['summary'] ?? '')),
            $entities
        );
    }

    /**
     * @param array<string, mixed> $starter
     * @param SamplePackEntity $entity
     * @return StarterSampleItem
     */
    private static function sampleItem(array $starter, array $entity, int $position): array
    {
        $subjects = array_values(array_filter(
            array_map('strval', is_array($entity['subjects'] ?? null) ? $entity['subjects'] : []),
            static fn (string $value): bool => trim($value) !== ''
        ));
        $contexts = array_values(array_filter(
            array_map('strval', is_array($entity['contexts'] ?? null) ? $entity['contexts'] : []),
            static fn (string $value): bool => trim($value) !== ''
        ));
        $statuses = ['draft', 'active', 'published', 'archived'];

        $subject = $subjects[($position - 1) % max(1, count($subjects))] ?? 'Example';
        $context = $contexts[(int)(floor(($position - 1) / max(1, count($subjects))) % max(1, count($contexts)))] ?? 'general';
        $label = trim((string)($entity['label'] ?? 'Sample'));
        $starterTitle = (string)($starter['title'] ?? 'Starter');
        $starterKey = (string)($starter['key'] ?? '');
        $packKey = (string)($entity['pack_key'] ?? '');
        $title = trim($subject . ' ' . $label . ' ' . str_pad((string)$position, 4, '0', STR_PAD_LEFT));
        $slug = ConsoleSupport::kebab($starterKey . '-' . $packKey . '-' . $subject . '-' . $context . '-' . $position);
        $status = $statuses[($position - 1) % count($statuses)];

        return [
            'module_key' => (string)($entity['module_key'] ?? ''),
            'entity_type' => (string)($entity['entity_type'] ?? ''),
            'pack_key' => $packKey,
            'pack_title' => (string)($entity['pack_title'] ?? ''),
            'slug' => $slug,
            'title' => $title,
            'summary' => $starterTitle . ' starter sample for ' . strtolower($context) . ' operations around ' . strtolower($subject) . '.',
            'status' => $status,
            'payload' => [
                'starter_key' => $starterKey,
                'starter_title' => $starterTitle,
                'sample_pack_key' => $packKey,
                'sample_pack_title' => (string)($entity['pack_title'] ?? ''),
                'module_key' => (string)($entity['module_key'] ?? ''),
                'entity_type' => (string)($entity['entity_type'] ?? ''),
                'label' => $label,
                'subject' => $subject,
                'context' => $context,
                'position' => $position,
                'resource_targets' => array_values(is_array($starter['resources'] ?? null) ? array_map(
                    static fn (array $resource): string => (string)($resource['name'] ?? ''),
                    $starter['resources']
                ) : []),
            ],
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $entities
     * @return array<string, mixed>
     */
    private static function pack(string $key, string $title, string $summary, array $entities): array
    {
        return [
            'key' => ConsoleSupport::kebab($key),
            'title' => trim($title),
            'summary' => trim($summary),
            'entities' => array_values($entities),
        ];
    }

    /**
     * @param array<int, string> $subjects
     * @param array<int, string> $contexts
     * @return array<string, mixed>
     */
    private static function entity(string $moduleKey, string $entityType, string $label, array $subjects, array $contexts): array
    {
        return [
            'module_key' => trim($moduleKey),
            'entity_type' => trim($entityType),
            'label' => trim($label),
            'subjects' => array_values($subjects),
            'contexts' => array_values($contexts),
        ];
    }
}
