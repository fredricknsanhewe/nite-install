<?php
namespace App\Support;

use PDO;
use RuntimeException;

final class QueryBuilder
{
    private ?PDO $db;
    private string $table;
    private string $driver;
    /** @var list<string> */
    private array $columns = ['*'];
    /** @var list<string> */
    private array $where = [];
    /** @var array<string, mixed> */
    private array $bindings = [];
    /** @var list<string> */
    private array $order = [];
    private ?int $limitValue = null;
    private ?int $offsetValue = null;
    private int $paramCounter = 0;

    public function __construct(?PDO $db, string $table, string $driver = 'pgsql')
    {
        $this->db = $db;
        $this->table = $table;
        $this->driver = strtolower(trim($driver)) === 'mysql' ? 'mysql' : 'pgsql';
    }

    public function select(string|array $columns): self
    {
        $items = is_array($columns) ? $columns : [$columns];
        $this->columns = array_values(array_filter(array_map('strval', $items), static fn (string $item): bool => trim($item) !== ''));
        if ($this->columns === []) {
            $this->columns = ['*'];
        }

        return $this;
    }

    public function where(string $column, mixed $operatorOrValue, mixed $value = null): self
    {
        $operator = func_num_args() === 2 ? '=' : strtoupper(trim((string)$operatorOrValue));
        $boundValue = func_num_args() === 2 ? $operatorOrValue : $value;
        $parameter = $this->parameterName();
        $this->where[] = $column . ' ' . $operator . ' ' . $parameter;
        $this->bindings[$parameter] = $boundValue;

        return $this;
    }

    public function whereNull(string $column): self
    {
        $this->where[] = $column . ' IS NULL';
        return $this;
    }

    public function whereNotNull(string $column): self
    {
        $this->where[] = $column . ' IS NOT NULL';
        return $this;
    }

    public function whereIn(string $column, array $values): self
    {
        $items = array_values($values);
        if ($items === []) {
            $this->where[] = '1 = 0';
            return $this;
        }

        $placeholders = [];
        foreach ($items as $value) {
            $parameter = $this->parameterName();
            $placeholders[] = $parameter;
            $this->bindings[$parameter] = $value;
        }

        $this->where[] = $column . ' IN (' . implode(', ', $placeholders) . ')';
        return $this;
    }

    /**
     * @param list<string>|string $columns
     */
    public function whereLike(array|string $columns, string $needle): self
    {
        $items = is_array($columns) ? $columns : [$columns];
        $clauses = [];
        foreach ($items as $column) {
            $parameter = $this->parameterName();
            $clauses[] = $this->driver === 'pgsql'
                ? $column . ' ILIKE ' . $parameter
                : 'LOWER(' . $column . ') LIKE LOWER(' . $parameter . ')';
            $this->bindings[$parameter] = '%' . $needle . '%';
        }

        if ($clauses !== []) {
            $this->where[] = '(' . implode(' OR ', $clauses) . ')';
        }

        return $this;
    }

    public function orderBy(string $column, string $direction = 'ASC'): self
    {
        $normalized = strtoupper(trim($direction)) === 'DESC' ? 'DESC' : 'ASC';
        $this->order[] = $column . ' ' . $normalized;
        return $this;
    }

    public function limit(int $limit): self
    {
        $this->limitValue = max(1, $limit);
        return $this;
    }

    public function offset(int $offset): self
    {
        $this->offsetValue = max(0, $offset);
        return $this;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function get(): array
    {
        $statement = $this->execute($this->toSql(), $this->bindings());
        return array_values($statement->fetchAll());
    }

    /**
     * @return array<string, mixed>|null
     */
    public function first(): ?array
    {
        $clone = clone $this;
        if ($clone->limitValue === null) {
            $clone->limit(1);
        }
        $statement = $clone->execute($clone->toSql(), $clone->bindings());
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    public function count(string $column = '*'): int
    {
        $sql = 'SELECT COUNT(' . $column . ') AS aggregate FROM ' . $this->table;
        if ($this->where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $this->where);
        }

        $statement = $this->execute($sql, $this->bindings());
        return (int)($statement->fetchColumn() ?: 0);
    }

    /**
     * @return array{data: list<array<string, mixed>>, meta: array<string, int>}
     */
    public function paginate(int $limit = 100, int $offset = 0): array
    {
        $clone = clone $this;
        $total = $clone->count();

        $this->limit($limit)->offset($offset);
        return [
            'data' => $this->get(),
            'meta' => [
                'total' => $total,
                'limit' => max(1, $limit),
                'offset' => max(0, $offset),
            ],
        ];
    }

    public function toSql(): string
    {
        $sql = 'SELECT ' . implode(', ', $this->columns) . ' FROM ' . $this->table;
        if ($this->where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $this->where);
        }
        if ($this->order !== []) {
            $sql .= ' ORDER BY ' . implode(', ', $this->order);
        }
        if ($this->limitValue !== null) {
            $sql .= ' LIMIT ' . $this->limitValue;
        }
        if ($this->offsetValue !== null) {
            $sql .= ' OFFSET ' . $this->offsetValue;
        }

        return $sql;
    }

    /**
     * @return array<string, mixed>
     */
    public function bindings(): array
    {
        return $this->bindings;
    }

    /**
     * @param array<string, mixed> $bindings
     */
    private function execute(string $sql, array $bindings): \PDOStatement
    {
        if (!$this->db instanceof PDO) {
            throw new RuntimeException('QueryBuilder execution requires a PDO connection.');
        }

        $statement = $this->db->prepare($sql);
        foreach ($bindings as $parameter => $value) {
            $type = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $statement->bindValue($parameter, $value, $type);
        }
        $statement->execute();

        return $statement;
    }

    private function parameterName(): string
    {
        $this->paramCounter++;
        return ':qb_' . $this->paramCounter;
    }
}
