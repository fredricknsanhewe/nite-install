<?php
namespace App\Support;

final class NiteModuleCatalog
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function modules(): array
    {
        static $modules = null;
        if ($modules !== null) {
            return $modules;
        }

        $modules = [
            'content' => self::module(
                'Content',
                'Website content management starter with pages, posts, resources, gallery, media, settings, SEO patterns, and public bootstrap responses.',
                ['pages', 'news', 'resources', 'gallery_albums', 'gallery_items', 'media_assets', 'site_settings']
            ),
            'learning' => self::module(
                'Learning',
                'eLearning starter with courses, modules, enrollments, progress tracking, and event registration.',
                ['courses', 'course_modules', 'course_enrollments', 'course_progress', 'events', 'event_registrations']
            ),
            'catalog' => self::module(
                'Catalog',
                'Reusable category, service-area, and taxonomy examples derived from the marketplace catalog patterns.',
                ['categories', 'service_areas', 'tags']
            ),
            'workflow' => self::module(
                'Workflow',
                'Generic work-item lifecycle examples for jobs, offers, counters, ratings, favorites, milestones, and dispute-style workflow entries.',
                ['work_items', 'offers', 'ratings', 'favorites', 'milestones', 'reports']
            ),
            'messaging' => self::module(
                'Messaging',
                'Notifications, conversations, outbound queue, webhook, and integration examples inspired by WhatsApp and Messenger bridge patterns.',
                ['notifications', 'conversations', 'webhooks', 'outbound_queue', 'integrations']
            ),
            'payments' => self::module(
                'Payments',
                'Payment integration, currency, transaction, escrow, callback queue, and dispute examples.',
                ['integrations', 'currencies', 'transactions', 'escrows', 'disputes', 'callback_queue']
            ),
            'subscriptions' => self::module(
                'Subscriptions',
                'Plan, invoice, activation, reminder, and entitlement examples for paid feature control.',
                ['plans', 'features', 'invoices', 'activations']
            ),
            'trust' => self::module(
                'Trust',
                'User block, fraud report, moderation, and trust-action examples.',
                ['reports', 'blocks', 'moderation_actions']
            ),
            'chatbot' => self::module(
                'Chatbot',
                'Knowledge base, assistant configuration, and conversation review examples.',
                ['config', 'knowledge', 'conversations']
            ),
            'analytics' => self::module(
                'Analytics',
                'Tracking event, dashboard metric, anomaly, and admin-intelligence examples.',
                ['tracking_events', 'dashboards', 'anomalies', 'rules']
            ),
            'recruitment' => self::module(
                'Recruitment',
                'Referral programme, activation rule, bonus, tier, and cashout examples.',
                ['programs', 'activation_rules', 'bonuses', 'tiers', 'cashouts']
            ),
            'governance' => self::module(
                'Governance',
                'Auth, users, RBAC, audit logs, and configuration controls that tie the starter together.',
                ['users', 'permissions', 'role_rules', 'audit_logs']
            ),
        ];

        return $modules;
    }

    public static function hasModule(string $moduleKey): bool
    {
        return isset(self::modules()[trim($moduleKey)]);
    }

    public static function hasEntity(string $moduleKey, string $entityType): bool
    {
        $module = self::modules()[trim($moduleKey)] ?? null;
        if ($module === null) {
            return false;
        }
        return in_array(trim($entityType), $module['entities'], true);
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function moduleByKey(string $moduleKey): ?array
    {
        return self::modules()[trim($moduleKey)] ?? null;
    }

    /**
     * @return array<string, mixed>
     */
    private static function module(string $title, string $summary, array $entities): array
    {
        return [
            'title' => $title,
            'summary' => $summary,
            'entities' => array_values($entities),
        ];
    }
}
