<?php
namespace App\Models;

use App\Config\MailConfig;
use App\Utils\UUID;

/**
 * Persistence model for the outbound mail queue.
 *
 * Queue records are transport-agnostic. They store the normalized mail payload
 * that the framework can send later through the currently configured mail
 * transport. This keeps queue behavior stable even if SMTP credentials or DSN
 * strategy change between enqueue and delivery.
 */
final class MailQueueModel extends BaseModel
{
    private const TABLE = 'mail_queue';

    /**
     * Store a normalized outbound message for later delivery.
     *
     * Expected payload keys:
     * - `message_type`: logical classification such as `contact_admin_alert`
     * - `transport`: human label like `smtp` or `dsn`
     * - `priority`: SMTP-style priority from 1..5
     * - `max_attempts`: permanent failure threshold
     * - `to`, `cc`, `bcc`, `reply_to`: address lists with `address`/`name`
     * - `subject`: message subject line
     * - `text_body`, `html_body`: body content
     * - `from_address`, `from_name`, `sender_address`: sender metadata
     * - `headers`, `metadata`: arbitrary key-value maps
     * - `available_at`: optional scheduled delivery time
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        $id = UUID::v4();
        $availableAt = $this->normalizeDateTime($payload['available_at'] ?? null) ?? $this->normalizeDateTime('now');

        $this->query(
            <<<SQL
                INSERT INTO mail_queue (
                    id,
                    message_type,
                    status,
                    transport,
                    priority,
                    attempts,
                    max_attempts,
                    to_json,
                    cc_json,
                    bcc_json,
                    reply_to_json,
                    subject,
                    text_body,
                    html_body,
                    from_address,
                    from_name,
                    sender_address,
                    headers_json,
                    metadata_json,
                    delivery_meta_json,
                    available_at
                ) VALUES (
                    :id,
                    :message_type,
                    'queued',
                    :transport,
                    :priority,
                    0,
                    :max_attempts,
                    {$this->jsonParam(':to_json')},
                    {$this->jsonParam(':cc_json')},
                    {$this->jsonParam(':bcc_json')},
                    {$this->jsonParam(':reply_to_json')},
                    :subject,
                    :text_body,
                    :html_body,
                    :from_address,
                    :from_name,
                    :sender_address,
                    {$this->jsonParam(':headers_json')},
                    {$this->jsonParam(':metadata_json')},
                    {$this->jsonParam(':delivery_meta_json')},
                    :available_at
                )
            SQL,
            [
                ':id' => $id,
                ':message_type' => $this->cleanString($payload['message_type'] ?? 'transactional', true) ?: 'transactional',
                ':transport' => $this->cleanString($payload['transport'] ?? MailConfig::transport(), true) ?: MailConfig::transport(),
                ':priority' => $this->priorityValue($payload['priority'] ?? 3),
                ':max_attempts' => max(1, (int)($payload['max_attempts'] ?? MailConfig::maxAttempts())),
                ':to_json' => $this->jsonEncode($payload['to'] ?? []),
                ':cc_json' => $this->jsonEncode($payload['cc'] ?? []),
                ':bcc_json' => $this->jsonEncode($payload['bcc'] ?? []),
                ':reply_to_json' => $this->jsonEncode($payload['reply_to'] ?? []),
                ':subject' => (string)$this->cleanString($payload['subject'] ?? null),
                ':text_body' => $this->cleanString($payload['text_body'] ?? null, true),
                ':html_body' => $this->cleanString($payload['html_body'] ?? null, true),
                ':from_address' => strtolower((string)$this->cleanString($payload['from_address'] ?? null)),
                ':from_name' => $this->cleanString($payload['from_name'] ?? null, true),
                ':sender_address' => strtolower((string)$this->cleanString($payload['sender_address'] ?? null, true)),
                ':headers_json' => $this->jsonEncode($payload['headers'] ?? []),
                ':metadata_json' => $this->jsonEncode($payload['metadata'] ?? []),
                ':delivery_meta_json' => $this->jsonEncode($payload['delivery_meta'] ?? []),
                ':available_at' => $availableAt,
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM ' . self::TABLE . ' WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];

        $status = strtolower(trim((string)($filters['status'] ?? '')));
        if ($status !== '') {
            $where[] = 'status = :status';
            $params[':status'] = $status;
        }

        $messageType = trim((string)($filters['message_type'] ?? ''));
        if ($messageType !== '') {
            $where[] = 'message_type = :message_type';
            $params[':message_type'] = $messageType;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['subject', 'from_address', 'message_type', 'last_error']);
            $params[':q'] = '%' . $q . '%';
        }

        $limit = max(1, min(200, (int)($filters['limit'] ?? 50)));
        $sql = 'SELECT * FROM ' . self::TABLE;
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC LIMIT ' . $limit;

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    /**
     * Claim a ready batch for delivery.
     *
     * This implementation favors broad compatibility over advanced locking
     * features. Each candidate row is claimed via a status transition guarded by
     * `WHERE status = 'queued'` so competing workers cannot claim the same
     * record twice.
     *
     * @return array<int, array<string, mixed>>
     */
    public function claimReadyBatch(int $limit): array
    {
        $limit = max(1, min(200, $limit));
        $fetchLimit = max($limit, min(500, $limit * 4));
        $sql = 'SELECT id FROM ' . self::TABLE . " WHERE status = 'queued' AND available_at <= " . $this->nowExpression()
            . ' ORDER BY priority ASC, available_at ASC, created_at ASC LIMIT ' . $fetchLimit;

        $candidates = $this->many($sql);
        $claimed = [];
        foreach ($candidates as $candidate) {
            if (count($claimed) >= $limit) {
                break;
            }

            $id = (string)($candidate['id'] ?? '');
            if (!$this->uuidLike($id)) {
                continue;
            }

            $statement = $this->query(
                'UPDATE ' . self::TABLE
                . " SET status = 'processing', reserved_at = " . $this->nowExpression()
                . ', attempts = attempts + 1, updated_at = ' . $this->nowExpression()
                . " WHERE id = :id AND status = 'queued' AND available_at <= " . $this->nowExpression(),
                [':id' => $id]
            );

            if ($statement->rowCount() < 1) {
                continue;
            }

            $row = $this->findById($id);
            if ($row !== null) {
                $claimed[] = $row;
            }
        }

        return $claimed;
    }

    /**
     * @param array<string, mixed> $deliveryMeta
     */
    public function markSent(string $id, array $deliveryMeta = []): void
    {
        $this->query(
            'UPDATE ' . self::TABLE
            . " SET status = 'sent', sent_at = " . $this->nowExpression()
            . ", reserved_at = NULL, last_error = NULL, delivery_meta_json = {$this->jsonParam(':delivery_meta_json')}, updated_at = " . $this->nowExpression()
            . ' WHERE id = :id',
            [
                ':id' => $id,
                ':delivery_meta_json' => $this->jsonEncode($deliveryMeta),
            ]
        );
    }

    /**
     * Release a processing row back into the queue with a future retry time.
     *
     * @param array<string, mixed> $deliveryMeta
     */
    public function releaseForRetry(string $id, string $error, int $delaySeconds, array $deliveryMeta = []): void
    {
        $delay = max(5, $delaySeconds);
        $nextTime = $this->normalizeDateTime('+' . $delay . ' seconds') ?? $this->normalizeDateTime('now');

        $this->query(
            'UPDATE ' . self::TABLE
            . " SET status = 'queued', reserved_at = NULL, last_error = :last_error, failed_at = NULL, available_at = :available_at, delivery_meta_json = {$this->jsonParam(':delivery_meta_json')}, updated_at = "
            . $this->nowExpression()
            . ' WHERE id = :id',
            [
                ':id' => $id,
                ':last_error' => $this->truncateError($error),
                ':available_at' => $nextTime,
                ':delivery_meta_json' => $this->jsonEncode($deliveryMeta),
            ]
        );
    }

    /**
     * @param array<string, mixed> $deliveryMeta
     */
    public function markFailed(string $id, string $error, array $deliveryMeta = []): void
    {
        $this->query(
            'UPDATE ' . self::TABLE
            . " SET status = 'failed', reserved_at = NULL, failed_at = " . $this->nowExpression()
            . ", last_error = :last_error, delivery_meta_json = {$this->jsonParam(':delivery_meta_json')}, updated_at = "
            . $this->nowExpression()
            . ' WHERE id = :id',
            [
                ':id' => $id,
                ':last_error' => $this->truncateError($error),
                ':delivery_meta_json' => $this->jsonEncode($deliveryMeta),
            ]
        );
    }

    public function retry(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }

        $statement = $this->query(
            'UPDATE ' . self::TABLE
            . " SET status = 'queued', reserved_at = NULL, failed_at = NULL, last_error = NULL, available_at = "
            . $this->nowExpression()
            . ', updated_at = ' . $this->nowExpression()
            . " WHERE id = :id AND status IN ('failed', 'processing')",
            [':id' => $id]
        );

        return $statement->rowCount() > 0;
    }

    public function retryFailed(): int
    {
        $statement = $this->query(
            'UPDATE ' . self::TABLE
            . " SET status = 'queued', reserved_at = NULL, failed_at = NULL, last_error = NULL, available_at = "
            . $this->nowExpression()
            . ', updated_at = ' . $this->nowExpression()
            . " WHERE status = 'failed'"
        );

        return $statement->rowCount();
    }

    /**
     * @return array<string, int>
     */
    public function statusCounts(): array
    {
        $rows = $this->many('SELECT status, COUNT(*) AS total FROM ' . self::TABLE . ' GROUP BY status');
        $counts = [
            'queued' => 0,
            'processing' => 0,
            'sent' => 0,
            'failed' => 0,
        ];

        foreach ($rows as $row) {
            $status = strtolower(trim((string)($row['status'] ?? '')));
            if ($status === '') {
                continue;
            }
            $counts[$status] = (int)($row['total'] ?? 0);
        }

        return $counts;
    }

    public function pendingCount(): int
    {
        $row = $this->one("SELECT COUNT(*) AS total FROM " . self::TABLE . " WHERE status IN ('queued', 'processing')");
        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        $row['priority'] = (int)($row['priority'] ?? 3);
        $row['attempts'] = (int)($row['attempts'] ?? 0);
        $row['max_attempts'] = (int)($row['max_attempts'] ?? MailConfig::maxAttempts());
        $row['to'] = is_array($row['to_json'] ?? null) ? $row['to_json'] : $this->decodeJson($row['to_json'] ?? '[]', []);
        $row['cc'] = is_array($row['cc_json'] ?? null) ? $row['cc_json'] : $this->decodeJson($row['cc_json'] ?? '[]', []);
        $row['bcc'] = is_array($row['bcc_json'] ?? null) ? $row['bcc_json'] : $this->decodeJson($row['bcc_json'] ?? '[]', []);
        $row['reply_to'] = is_array($row['reply_to_json'] ?? null) ? $row['reply_to_json'] : $this->decodeJson($row['reply_to_json'] ?? '[]', []);
        $row['headers'] = is_array($row['headers_json'] ?? null) ? $row['headers_json'] : $this->decodeJson($row['headers_json'] ?? '{}', []);
        $row['metadata'] = is_array($row['metadata_json'] ?? null) ? $row['metadata_json'] : $this->decodeJson($row['metadata_json'] ?? '{}', []);
        $row['delivery_meta'] = is_array($row['delivery_meta_json'] ?? null) ? $row['delivery_meta_json'] : $this->decodeJson($row['delivery_meta_json'] ?? '{}', []);
        unset($row['to_json'], $row['cc_json'], $row['bcc_json'], $row['reply_to_json'], $row['headers_json'], $row['metadata_json'], $row['delivery_meta_json']);
        return $row;
    }

    private function priorityValue(mixed $value): int
    {
        $priority = (int)$value;
        return max(1, min(5, $priority === 0 ? 3 : $priority));
    }

    private function jsonEncode(mixed $value): string
    {
        $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        return is_string($encoded) ? $encoded : '{}';
    }

    private function truncateError(string $error): string
    {
        $clean = trim($error);
        if (strlen($clean) <= 5000) {
            return $clean;
        }

        return substr($clean, 0, 4997) . '...';
    }

}
