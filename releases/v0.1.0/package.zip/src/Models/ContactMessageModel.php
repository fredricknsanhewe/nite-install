<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class ContactMessageModel extends BaseModel
{
    public function create(array $data): array
    {
        $fullName = (string)$this->cleanString($data['full_name'] ?? null);
        $email = strtolower((string)$this->cleanString($data['email'] ?? null));
        $subject = (string)$this->cleanString($data['subject'] ?? null);
        $message = (string)$this->cleanString($data['message'] ?? null);

        if ($fullName === '' || $subject === '' || $message === '') {
            throw new RuntimeException('Full name, subject, and message are required.');
        }
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('A valid email address is required.');
        }

        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO contact_messages (
                    id, full_name, email, phone, subject, message, source, status
                ) VALUES (
                    :id, :full_name, :email, :phone, :subject, :message, :source, 'new'
                )
            SQL,
            [
                ':id' => $id,
                ':full_name' => $fullName,
                ':email' => $email,
                ':phone' => $this->cleanString($data['phone'] ?? null, true),
                ':subject' => $subject,
                ':message' => $message,
                ':source' => $this->cleanString($data['source'] ?? 'website', true) ?: 'website',
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one('SELECT * FROM contact_messages WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];
        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['full_name', 'email', 'subject', 'message']);
            $params[':q'] = '%' . $q . '%';
        }
        $status = strtolower(trim((string)($filters['status'] ?? '')));
        if ($status !== '') {
            $where[] = 'status = :status';
            $params[':status'] = $status;
        }

        $sql = 'SELECT * FROM contact_messages';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC';
        return $this->many($sql, $params);
    }

    public function update(string $id, array $data): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }
        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $id];
        foreach (['full_name', 'email', 'phone', 'subject', 'message', 'source'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $field === 'email'
                    ? strtolower((string)$this->cleanString($data[$field], true))
                    : $this->cleanString($data[$field], true);
            }
        }
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['new', 'in_progress', 'resolved', 'closed', 'spam'], true)) {
                throw new RuntimeException('Invalid contact message status supplied.');
            }
            $assignments[] = 'status = :status';
            $params[':status'] = $status;
        }
        if (array_key_exists('assigned_to_user_id', $data)) {
            $assignments[] = 'assigned_to_user_id = :assigned_to_user_id';
            $params[':assigned_to_user_id'] = $this->cleanString($data['assigned_to_user_id'], true);
        }

        $this->query('UPDATE contact_messages SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM contact_messages WHERE id = :id', [':id' => $id]);
        return true;
    }

    public function countOpen(): int
    {
        $row = $this->one("SELECT COUNT(*) AS total FROM contact_messages WHERE status IN ('new', 'in_progress')");
        return (int)($row['total'] ?? 0);
    }
}
