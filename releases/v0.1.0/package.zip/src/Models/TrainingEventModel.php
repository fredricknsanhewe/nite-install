<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class TrainingEventModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "status = 'published'";
        } elseif (trim((string)($filters['status'] ?? '')) !== '') {
            $where[] = 'status = :status';
            $params[':status'] = strtolower(trim((string)$filters['status']));
        }

        if (array_key_exists('featured', $filters)) {
            $where[] = 'is_featured = :is_featured';
            $params[':is_featured'] = $this->boolValue($filters['featured']) ? 1 : 0;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'description', 'location']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM training_events';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY starts_at ASC, created_at DESC';

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(100, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM training_events WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM training_events WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';
        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId);
        $metaJsonParam = $this->jsonParam(':meta_json');

        $this->query(
            <<<SQL
                INSERT INTO training_events (
                    id, slug, title, summary, description, event_format, location, meeting_url,
                    starts_at, ends_at, registration_open, registration_deadline, capacity,
                    status, is_featured, meta_json, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :title, :summary, :description, :event_format, :location, :meeting_url,
                    :starts_at, :ends_at, :registration_open, :registration_deadline, :capacity,
                    :status, :is_featured, {$metaJsonParam}, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }
        $payload = $this->normalizePayload($data, false);
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [':id' => $id, ':updated_by_user_id' => $this->cleanString($actorUserId)];

        foreach ([
            'slug', 'title', 'summary', 'description', 'event_format', 'location', 'meeting_url', 'starts_at', 'ends_at',
            'registration_deadline', 'capacity', 'status'
        ] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }
        foreach (['registration_open', 'is_featured'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }
        if (array_key_exists('meta_json', $payload)) {
            $assignments[] = 'meta_json = ' . $this->jsonParam(':meta_json');
            $params[':meta_json'] = $payload['meta_json'];
        }

        $this->query('UPDATE training_events SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM training_events WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary', 'description', 'location', 'meeting_url', 'starts_at', 'ends_at', 'registration_deadline'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = in_array($field, ['starts_at', 'ends_at', 'registration_deadline'], true)
                    ? $this->normalizeDateTime($data[$field])
                    : $this->cleanString($data[$field], true);
            }
        }
        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '' || ($payload['starts_at'] ?? '') === '')) {
            throw new RuntimeException('Event slug, title, and start date are required.');
        }

        if (array_key_exists('event_format', $data)) {
            $format = strtolower((string)$this->cleanString($data['event_format'], true));
            if (!in_array($format, ['in_person', 'online', 'hybrid'], true)) {
                throw new RuntimeException('Invalid event format supplied.');
            }
            $payload['event_format'] = $format;
        } elseif ($create) {
            $payload['event_format'] = 'in_person';
        }

        if (array_key_exists('registration_open', $data)) {
            $payload['registration_open'] = $this->boolValue($data['registration_open']) ? 1 : 0;
        } elseif ($create) {
            $payload['registration_open'] = 1;
        }

        if (array_key_exists('capacity', $data)) {
            $payload['capacity'] = $data['capacity'] === null || $data['capacity'] === '' ? null : (int)$data['capacity'];
        } elseif ($create) {
            $payload['capacity'] = null;
        }

        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['draft', 'published', 'cancelled', 'completed'], true)) {
                throw new RuntimeException('Invalid event status supplied.');
            }
            $payload['status'] = $status;
        } elseif ($create) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('is_featured', $data)) {
            $payload['is_featured'] = $this->boolValue($data['is_featured']) ? 1 : 0;
        } elseif ($create) {
            $payload['is_featured'] = 0;
        }

        if (array_key_exists('meta', $data) || array_key_exists('meta_json', $data)) {
            $payload['meta_json'] = json_encode(
                is_array($data['meta'] ?? null) ? $data['meta'] : (is_array($data['meta_json'] ?? null) ? $data['meta_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['meta_json'] = '{}';
        }

        if ($create) {
            foreach (['summary', 'location', 'meeting_url', 'ends_at', 'registration_deadline'] as $field) {
                if (!array_key_exists($field, $payload)) {
                    $payload[$field] = null;
                }
            }
            if (!array_key_exists('description', $payload)) {
                $payload['description'] = '';
            }
        }

        return $payload;
    }

    private function hydrate(array $row): array
    {
        $row['meta'] = $this->decodeJson($row['meta_json'] ?? null, []);
        unset($row['meta_json']);
        return $row;
    }
}
