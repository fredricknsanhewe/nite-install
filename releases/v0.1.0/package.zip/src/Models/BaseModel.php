<?php
namespace App\Models;

use App\Config\Database;
use App\Support\QueryBuilder;
use PDO;
use PDOException;
use PDOStatement;

abstract class BaseModel
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    protected function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $statement = $this->db->prepare($sql);
            $statement->execute($params);
            return $statement;
        } catch (PDOException $e) {
            if (!$this->debugEnabled()) {
                throw $e;
            }

            $message = $e->getMessage() . ' SQL: ' . $sql;
            if ($params !== []) {
                $message .= ' Params: ' . implode(', ', array_keys($params));
            }

            throw new PDOException($message, (int)$e->getCode(), $e);
        }
    }

    protected function one(string $sql, array $params = []): ?array
    {
        $row = $this->query($sql, $params)->fetch();
        return $row ?: null;
    }

    protected function many(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    protected function table(string $table): QueryBuilder
    {
        return new QueryBuilder($this->db, $table, $this->databaseDriver());
    }

    protected function decodeJson(mixed $value, mixed $fallback = []): mixed
    {
        if (is_array($value)) {
            return $value;
        }
        if (!is_string($value) || trim($value) === '') {
            return $fallback;
        }

        $decoded = json_decode($value, true);
        return $decoded === null && json_last_error() !== JSON_ERROR_NONE ? $fallback : $decoded;
    }

    protected function boolValue(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int)$value !== 0;
        }
        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }

        return !empty($value);
    }

    protected function cleanString(mixed $value, bool $allowEmpty = false): ?string
    {
        if ($value === null) {
            return null;
        }

        $text = trim((string)$value);
        if ($text === '' && !$allowEmpty) {
            return null;
        }

        return $text;
    }

    protected function uuidLike(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1;
    }

    protected function databaseDriver(): string
    {
        return Database::driver();
    }

    protected function isMysql(): bool
    {
        return $this->databaseDriver() === 'mysql';
    }

    protected function isPgsql(): bool
    {
        return $this->databaseDriver() === 'pgsql';
    }

    protected function jsonParam(string $parameterName): string
    {
        return $this->isPgsql() ? 'CAST(' . $parameterName . ' AS JSONB)' : $parameterName;
    }

    /**
     * @param array<int, string> $columns
     */
    protected function likeAny(array $columns, string $parameterName = ':q'): string
    {
        $clauses = [];
        foreach ($columns as $column) {
            $clauses[] = $this->isPgsql()
                ? $column . ' ILIKE ' . $parameterName
                : 'LOWER(' . $column . ') LIKE LOWER(' . $parameterName . ')';
        }

        return '(' . implode(' OR ', $clauses) . ')';
    }

    protected function orderByNullsLast(string $column, string $direction = 'DESC'): string
    {
        $normalizedDirection = strtoupper(trim($direction)) === 'ASC' ? 'ASC' : 'DESC';
        if ($this->isPgsql()) {
            return $column . ' ' . $normalizedDirection . ' NULLS LAST';
        }

        return '(' . $column . ' IS NULL) ASC, ' . $column . ' ' . $normalizedDirection;
    }

    protected function normalizeDateTime(mixed $value): ?string
    {
        $text = $this->cleanString($value, true);
        if ($text === null || $text === '') {
            return null;
        }

        $timestamp = strtotime($text);
        if ($timestamp === false) {
            return $text;
        }

        return $this->isMysql()
            ? gmdate('Y-m-d H:i:s', $timestamp)
            : gmdate('c', $timestamp);
    }

    protected function nowExpression(): string
    {
        return $this->isPgsql() ? 'NOW()' : 'CURRENT_TIMESTAMP';
    }

    private function debugEnabled(): bool
    {
        $value = getenv('APP_DEBUG');
        if ($value === false) {
            return false;
        }

        return in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on'], true);
    }
}
