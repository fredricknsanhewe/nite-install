<?php
namespace App\Models;

use App\Config\Roles;
use App\Utils\UUID;
use RuntimeException;

final class UserModel extends BaseModel
{
    public function create(array $data): array
    {
        $email = strtolower((string)$this->cleanString($data['email'] ?? null));
        $name = (string)$this->cleanString($data['name'] ?? null);
        $role = strtolower((string)$this->cleanString($data['role'] ?? Roles::MEMBER));
        $passwordHash = (string)($data['password_hash'] ?? '');

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('A valid email address is required.');
        }
        if ($name === '') {
            throw new RuntimeException('Display name is required.');
        }
        if ($passwordHash === '') {
            throw new RuntimeException('Password hash is required.');
        }
        if (!in_array($role, Roles::all(), true)) {
            throw new RuntimeException('Invalid user role supplied.');
        }
        if ($this->findByEmail($email) !== null) {
            throw new RuntimeException('That email address is already registered.');
        }

        $id = UUID::v4();
        $profileJsonParam = $this->jsonParam(':profile_json');
        $this->query(
            <<<SQL
                INSERT INTO users (
                    id, email, password_hash, name, role, account_status, profile_json,
                    created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :email, :password_hash, :name, :role, :account_status, {$profileJsonParam},
                    :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':email' => $email,
                ':password_hash' => $passwordHash,
                ':name' => $name,
                ':role' => $role,
                ':account_status' => in_array(($data['account_status'] ?? 'active'), ['active', 'inactive', 'suspended'], true) ? $data['account_status'] : 'active',
                ':profile_json' => json_encode(is_array($data['profile'] ?? null) ? $data['profile'] : [], JSON_UNESCAPED_SLASHES),
                ':created_by_user_id' => $this->cleanString($data['created_by_user_id'] ?? null),
                ':updated_by_user_id' => $this->cleanString($data['updated_by_user_id'] ?? null),
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM users WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findAuthContextById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one(
            'SELECT id, email, name, role, account_status FROM users WHERE id = :id LIMIT 1',
            [':id' => $id]
        );
    }

    public function findByEmail(string $email): ?array
    {
        $normalized = strtolower(trim($email));
        if ($normalized === '') {
            return null;
        }
        $row = $this->one('SELECT * FROM users WHERE LOWER(email) = :email LIMIT 1', [':email' => $normalized]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findForLogin(string $email): ?array
    {
        $normalized = strtolower(trim($email));
        if ($normalized === '') {
            return null;
        }
        return $this->one('SELECT * FROM users WHERE LOWER(email) = :email LIMIT 1', [':email' => $normalized]);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $query = $this->table('users');
        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $query->whereLike(['name', 'email'], $q);
        }

        $role = strtolower(trim((string)($filters['role'] ?? '')));
        if ($role !== '') {
            $query->where('role', $role);
        }

        $status = strtolower(trim((string)($filters['account_status'] ?? '')));
        if ($status !== '') {
            $query->where('account_status', $status);
        }

        $limit = min(200, max(1, (int)($filters['limit'] ?? 100)));
        $offset = max(0, (int)($filters['offset'] ?? 0));
        $rows = $query
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->offset($offset)
            ->get();

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $rows));
    }

    public function update(string $id, array $data): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $existing = $this->findById($id);
        if ($existing === null) {
            return null;
        }

        $assignments = ['updated_at = ' . $this->nowExpression()];
        $params = [':id' => $id];

        if (array_key_exists('email', $data)) {
            $email = strtolower((string)$this->cleanString($data['email'], true));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('A valid email address is required.');
            }
            $owner = $this->findByEmail($email);
            if ($owner !== null && (string)$owner['id'] !== $id) {
                throw new RuntimeException('That email address is already in use.');
            }
            $assignments[] = 'email = :email';
            $params[':email'] = $email;
        }

        if (array_key_exists('name', $data)) {
            $name = (string)$this->cleanString($data['name'] ?? null);
            if ($name === '') {
                throw new RuntimeException('Display name is required.');
            }
            $assignments[] = 'name = :name';
            $params[':name'] = $name;
        }

        if (array_key_exists('role', $data)) {
            $role = strtolower((string)$this->cleanString($data['role'] ?? null));
            if (!in_array($role, Roles::all(), true)) {
                throw new RuntimeException('Invalid user role supplied.');
            }
            $assignments[] = 'role = :role';
            $params[':role'] = $role;
        }

        if (array_key_exists('account_status', $data)) {
            $status = strtolower((string)$this->cleanString($data['account_status'] ?? null));
            if (!in_array($status, ['active', 'inactive', 'suspended'], true)) {
                throw new RuntimeException('Invalid account status supplied.');
            }
            $assignments[] = 'account_status = :account_status';
            $params[':account_status'] = $status;
        }

        if (array_key_exists('password_hash', $data) && trim((string)$data['password_hash']) !== '') {
            $assignments[] = 'password_hash = :password_hash';
            $params[':password_hash'] = (string)$data['password_hash'];
        }

        if (array_key_exists('profile', $data)) {
            $assignments[] = 'profile_json = ' . $this->jsonParam(':profile_json');
            $params[':profile_json'] = json_encode(is_array($data['profile']) ? $data['profile'] : [], JSON_UNESCAPED_SLASHES);
        }

        if (array_key_exists('updated_by_user_id', $data)) {
            $assignments[] = 'updated_by_user_id = :updated_by_user_id';
            $params[':updated_by_user_id'] = $this->cleanString($data['updated_by_user_id'] ?? null);
        }

        $this->query('UPDATE users SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM users WHERE id = :id', [':id' => $id]);
        return true;
    }

    public function touchLogin(string $id): void
    {
        if (!$this->uuidLike($id)) {
            return;
        }
        $this->query('UPDATE users SET last_login_at = ' . $this->nowExpression() . ', updated_at = ' . $this->nowExpression() . ' WHERE id = :id', [':id' => $id]);
    }

    public function count(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM users');
        return (int)($row['total'] ?? 0);
    }

    private function hydrate(array $row): array
    {
        $row['profile'] = $this->decodeJson($row['profile_json'] ?? null, []);
        unset($row['profile_json']);
        unset($row['password_hash']);
        return $row;
    }
}
