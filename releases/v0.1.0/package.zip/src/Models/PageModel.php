<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class PageModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "status = 'published'";
        } else {
            $status = strtolower(trim((string)($filters['status'] ?? '')));
            if ($status !== '') {
                $where[] = 'status = :status';
                $params[':status'] = $status;
            }
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'slug']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM pages';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY sort_order ASC, ' . $this->orderByNullsLast('published_at', 'DESC') . ', updated_at DESC';

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM pages WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $params = [':slug' => trim($slug)];
        $sql = 'SELECT * FROM pages WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';
        $row = $this->one($sql, $params);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId);
        $contentJsonParam = $this->jsonParam(':content_json');
        $seoJsonParam = $this->jsonParam(':seo_json');

        $this->query(
            <<<SQL
                INSERT INTO pages (
                    id, slug, title, summary, hero_title, hero_summary, hero_image_url,
                    content_json, seo_json, status, sort_order, published_at,
                    created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :title, :summary, :hero_title, :hero_summary, :hero_image_url,
                    {$contentJsonParam}, {$seoJsonParam}, :status, :sort_order, :published_at,
                    :created_by_user_id, :updated_by_user_id
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        $existing = $this->findById($id);
        if ($existing === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $id];

        foreach (['slug', 'title', 'summary', 'hero_title', 'hero_summary', 'hero_image_url', 'status', 'sort_order', 'published_at'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }

        foreach (['content_json', 'seo_json'] as $jsonField) {
            if (array_key_exists($jsonField, $payload)) {
                $assignments[] = $jsonField . ' = ' . $this->jsonParam(':' . $jsonField);
                $params[':' . $jsonField] = $payload[$jsonField];
            }
        }

        $assignments[] = 'updated_by_user_id = :updated_by_user_id';
        $params[':updated_by_user_id'] = $this->cleanString($actorUserId);
        $this->query('UPDATE pages SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM pages WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $requireTitle): array
    {
        $slug = $this->cleanString($data['slug'] ?? null);
        $title = $this->cleanString($data['title'] ?? null);

        if ($requireTitle && $slug === null) {
            throw new RuntimeException('Page slug is required.');
        }
        if ($requireTitle && $title === null) {
            throw new RuntimeException('Page title is required.');
        }

        $payload = [];
        foreach (['slug', 'title', 'summary', 'hero_title', 'hero_summary', 'hero_image_url'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        if (array_key_exists('content', $data) || array_key_exists('content_json', $data)) {
            $payload['content_json'] = json_encode(
                is_array($data['content'] ?? null) ? $data['content'] : (is_array($data['content_json'] ?? null) ? $data['content_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($requireTitle) {
            $payload['content_json'] = '{}';
        }
        if (array_key_exists('seo', $data) || array_key_exists('seo_json', $data)) {
            $payload['seo_json'] = json_encode(
                is_array($data['seo'] ?? null) ? $data['seo'] : (is_array($data['seo_json'] ?? null) ? $data['seo_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($requireTitle) {
            $payload['seo_json'] = '{}';
        }
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['draft', 'published', 'archived'], true)) {
                throw new RuntimeException('Invalid page status supplied.');
            }
            $payload['status'] = $status;
        } elseif ($requireTitle) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('sort_order', $data)) {
            $payload['sort_order'] = (int)$data['sort_order'];
        } elseif ($requireTitle) {
            $payload['sort_order'] = 0;
        }

        if (array_key_exists('published_at', $data)) {
            $payload['published_at'] = $this->normalizeDateTime($data['published_at']);
        } elseif ($requireTitle) {
            $payload['published_at'] = null;
        }

        if ($requireTitle) {
            foreach (['summary', 'hero_title', 'hero_summary', 'hero_image_url'] as $field) {
                if (!array_key_exists($field, $payload)) {
                    $payload[$field] = null;
                }
            }
        }

        return $payload;
    }

    private function hydrate(array $row): array
    {
        $row['content'] = $this->decodeJson($row['content_json'] ?? null, []);
        $row['seo'] = $this->decodeJson($row['seo_json'] ?? null, []);
        unset($row['content_json'], $row['seo_json']);
        return $row;
    }
}
