<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class SampleRecordModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "status = 'active'";
        } else {
            $status = strtolower(trim((string)($filters['status'] ?? '')));
            if ($status !== '') {
                $where[] = 'status = :status';
                $params[':status'] = $status;
            }
        }

        $recordType = strtolower(trim((string)($filters['record_type'] ?? '')));
        if ($recordType !== '') {
            $where[] = 'record_type = :record_type';
            $params[':record_type'] = $recordType;
        }

        $ownerUserId = trim((string)($filters['owner_user_id'] ?? ''));
        if ($ownerUserId !== '') {
            $where[] = 'owner_user_id = :owner_user_id';
            $params[':owner_user_id'] = $ownerUserId;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'slug']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM sample_records';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY updated_at DESC, created_at DESC';

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(100, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM sample_records WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM sample_records WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'active'";
        }
        $sql .= ' LIMIT 1';

        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId);
        $labelsJsonParam = $this->jsonParam(':labels_json');
        $metadataJsonParam = $this->jsonParam(':metadata_json');

        $this->query(
            <<<SQL
                INSERT INTO sample_records (
                    id, slug, title, summary, record_type, status, owner_user_id,
                    labels_json, metadata_json, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :title, :summary, :record_type, :status, :owner_user_id,
                    {$labelsJsonParam}, {$metadataJsonParam}, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [
            ':id' => $id,
            ':updated_by_user_id' => $this->cleanString($actorUserId),
        ];

        foreach (['slug', 'title', 'summary', 'record_type', 'status', 'owner_user_id'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }

        foreach (['labels_json', 'metadata_json'] as $jsonField) {
            if (array_key_exists($jsonField, $payload)) {
                $assignments[] = $jsonField . ' = ' . $this->jsonParam(':' . $jsonField);
                $params[':' . $jsonField] = $payload[$jsonField];
            }
        }

        $this->query('UPDATE sample_records SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }

        $this->query('DELETE FROM sample_records WHERE id = :id', [':id' => $id]);
        return true;
    }

    public function restoreSnapshot(array $snapshot, ?string $actorUserId = null): array
    {
        $id = (string)($snapshot['id'] ?? '');
        if (!$this->uuidLike($id)) {
            throw new RuntimeException('The archived sample record snapshot is invalid.');
        }

        $slug = (string)$this->cleanString($snapshot['slug'] ?? null);
        $title = (string)$this->cleanString($snapshot['title'] ?? null);
        if ($slug === '' || $title === '') {
            throw new RuntimeException('The archived sample record is missing slug or title.');
        }

        $params = [
            ':id' => $id,
            ':slug' => $slug,
            ':title' => $title,
            ':summary' => $this->cleanString($snapshot['summary'] ?? null, true),
            ':record_type' => $this->normalizeRecordType($snapshot['record_type'] ?? 'guide'),
            ':status' => $this->normalizeStatus($snapshot['status'] ?? 'draft'),
            ':owner_user_id' => $this->cleanString($snapshot['owner_user_id'] ?? null),
            ':labels_json' => json_encode($this->normalizeLabels($snapshot['labels'] ?? ($snapshot['labels_json'] ?? [])), JSON_UNESCAPED_SLASHES),
            ':metadata_json' => json_encode($this->normalizeMetadata($snapshot['metadata'] ?? ($snapshot['metadata_json'] ?? [])), JSON_UNESCAPED_SLASHES),
            ':created_by_user_id' => $this->cleanString($snapshot['created_by_user_id'] ?? null),
            ':updated_by_user_id' => $this->cleanString($actorUserId) ?: $this->cleanString($snapshot['updated_by_user_id'] ?? null),
            ':created_at' => $this->normalizeDateTime($snapshot['created_at'] ?? null) ?: $this->normalizeDateTime(gmdate('c')),
        ];

        if ($this->isMysql()) {
            $this->query(
                <<<SQL
                    INSERT INTO sample_records (
                        id, slug, title, summary, record_type, status, owner_user_id,
                        labels_json, metadata_json, created_by_user_id, updated_by_user_id, created_at, updated_at
                    ) VALUES (
                        :id, :slug, :title, :summary, :record_type, :status, :owner_user_id,
                        :labels_json, :metadata_json,
                        :created_by_user_id, :updated_by_user_id, :created_at, NOW()
                    )
                    ON DUPLICATE KEY UPDATE
                        slug = VALUES(slug),
                        title = VALUES(title),
                        summary = VALUES(summary),
                        record_type = VALUES(record_type),
                        status = VALUES(status),
                        owner_user_id = VALUES(owner_user_id),
                        labels_json = VALUES(labels_json),
                        metadata_json = VALUES(metadata_json),
                        created_by_user_id = VALUES(created_by_user_id),
                        updated_by_user_id = VALUES(updated_by_user_id),
                        created_at = VALUES(created_at),
                        updated_at = NOW()
                SQL,
                $params
            );
        } else {
            $labelsJsonParam = $this->jsonParam(':labels_json');
            $metadataJsonParam = $this->jsonParam(':metadata_json');
            $this->query(
                <<<SQL
                    INSERT INTO sample_records (
                        id, slug, title, summary, record_type, status, owner_user_id,
                        labels_json, metadata_json, created_by_user_id, updated_by_user_id, created_at, updated_at
                    ) VALUES (
                        :id, :slug, :title, :summary, :record_type, :status, :owner_user_id,
                        {$labelsJsonParam}, {$metadataJsonParam},
                        :created_by_user_id, :updated_by_user_id, :created_at, NOW()
                    )
                    ON CONFLICT (id) DO UPDATE
                    SET slug = EXCLUDED.slug,
                        title = EXCLUDED.title,
                        summary = EXCLUDED.summary,
                        record_type = EXCLUDED.record_type,
                        status = EXCLUDED.status,
                        owner_user_id = EXCLUDED.owner_user_id,
                        labels_json = EXCLUDED.labels_json,
                        metadata_json = EXCLUDED.metadata_json,
                        created_by_user_id = EXCLUDED.created_by_user_id,
                        updated_by_user_id = EXCLUDED.updated_by_user_id,
                        created_at = EXCLUDED.created_at,
                        updated_at = NOW()
                SQL,
                $params
            );
        }

        return (array)$this->findById($id);
    }

    public function count(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM sample_records');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary', 'owner_user_id'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }
        if ($create && !array_key_exists('owner_user_id', $payload)) {
            $payload['owner_user_id'] = null;
        }

        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '')) {
            throw new RuntimeException('Sample record slug and title are required.');
        }

        if (array_key_exists('record_type', $data)) {
            $payload['record_type'] = $this->normalizeRecordType($data['record_type']);
        } elseif ($create) {
            $payload['record_type'] = 'guide';
        }

        if (array_key_exists('status', $data)) {
            $payload['status'] = $this->normalizeStatus($data['status']);
        } elseif ($create) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('labels', $data) || array_key_exists('labels_json', $data)) {
            $payload['labels_json'] = json_encode(
                $this->normalizeLabels($data['labels'] ?? ($data['labels_json'] ?? [])),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['labels_json'] = '[]';
        }

        if (array_key_exists('metadata', $data) || array_key_exists('metadata_json', $data)) {
            $payload['metadata_json'] = json_encode(
                $this->normalizeMetadata($data['metadata'] ?? ($data['metadata_json'] ?? [])),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['metadata_json'] = '{}';
        }

        if ($create && !array_key_exists('summary', $payload)) {
            $payload['summary'] = null;
        }

        return $payload;
    }

    /**
     * @return array<int, string>
     */
    private function normalizeLabels(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $labels = [];
        foreach ($value as $item) {
            $label = trim((string)$item);
            if ($label !== '') {
                $labels[] = $label;
            }
        }

        return array_values(array_unique($labels));
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizeMetadata(mixed $value): array
    {
        return is_array($value) ? $value : [];
    }

    private function normalizeRecordType(mixed $value): string
    {
        $recordType = strtolower(trim((string)$value));
        if (!in_array($recordType, ['guide', 'workflow', 'policy', 'dataset'], true)) {
            throw new RuntimeException('Invalid sample record type supplied.');
        }
        return $recordType;
    }

    private function normalizeStatus(mixed $value): string
    {
        $status = strtolower(trim((string)$value));
        if (!in_array($status, ['draft', 'active', 'archived'], true)) {
            throw new RuntimeException('Invalid sample record status supplied.');
        }
        return $status;
    }

    private function hydrate(array $row): array
    {
        $row['labels'] = $this->decodeJson($row['labels_json'] ?? null, []);
        $row['metadata'] = $this->decodeJson($row['metadata_json'] ?? null, []);
        unset($row['labels_json'], $row['metadata_json']);
        return $row;
    }
}
