<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class ExampleEntryModel extends BaseModel
{
    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByEntity(string $entityId): array
    {
        if (!$this->uuidLike($entityId)) {
            return [];
        }
        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many(
            'SELECT * FROM example_entries WHERE entity_id = :entity_id ORDER BY created_at ASC',
            [':entity_id' => $entityId]
        )));
    }

    public function create(string $entityId, array $data, ?string $actorUserId = null): array
    {
        if (!$this->uuidLike($entityId)) {
            throw new RuntimeException('Invalid example entity supplied.');
        }
        $body = (string)$this->cleanString($data['body'] ?? null);
        if ($body === '') {
            throw new RuntimeException('Example entry body is required.');
        }
        $id = UUID::v4();
        $payloadJsonParam = $this->jsonParam(':payload_json');
        $this->query(
            <<<SQL
                INSERT INTO example_entries (
                    id, entity_id, entry_type, body, payload_json, created_by_user_id
                ) VALUES (
                    :id, :entity_id, :entry_type, :body, {$payloadJsonParam}, :created_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':entity_id' => $entityId,
                ':entry_type' => $this->normalizeEntryType($data['entry_type'] ?? 'note'),
                ':body' => $body,
                ':payload_json' => json_encode(is_array($data['payload'] ?? null) ? $data['payload'] : [], JSON_UNESCAPED_SLASHES),
                ':created_by_user_id' => $this->cleanString($actorUserId),
            ]
        );
        return (array)$this->one('SELECT * FROM example_entries WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    private function hydrate(array $row): array
    {
        $row['payload'] = $this->decodeJson($row['payload_json'] ?? null, []);
        unset($row['payload_json']);
        return $row;
    }

    private function normalizeEntryType(mixed $value): string
    {
        $type = strtolower(trim((string)$value));
        return in_array($type, ['note', 'message', 'timeline', 'audit', 'status_change'], true) ? $type : 'note';
    }
}
