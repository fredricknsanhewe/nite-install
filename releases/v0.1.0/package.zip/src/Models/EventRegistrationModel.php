<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class EventRegistrationModel extends BaseModel
{
    public function create(string $eventId, array $data, ?string $userId = null): array
    {
        if (!$this->uuidLike($eventId)) {
            throw new RuntimeException('Invalid event supplied.');
        }

        $fullName = (string)$this->cleanString($data['full_name'] ?? null);
        $email = strtolower((string)$this->cleanString($data['email'] ?? null));
        if ($fullName === '') {
            throw new RuntimeException('Full name is required.');
        }
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('A valid email address is required.');
        }

        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO event_registrations (
                    id, event_id, registered_by_user_id, full_name, email, phone,
                    organisation, role_title, notes, status
                ) VALUES (
                    :id, :event_id, :registered_by_user_id, :full_name, :email, :phone,
                    :organisation, :role_title, :notes, :status
                )
            SQL,
            [
                ':id' => $id,
                ':event_id' => $eventId,
                ':registered_by_user_id' => $this->cleanString($userId),
                ':full_name' => $fullName,
                ':email' => $email,
                ':phone' => $this->cleanString($data['phone'] ?? null, true),
                ':organisation' => $this->cleanString($data['organisation'] ?? null, true),
                ':role_title' => $this->cleanString($data['role_title'] ?? null, true),
                ':notes' => $this->cleanString($data['notes'] ?? null, true),
                ':status' => 'pending',
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one('SELECT * FROM event_registrations WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByEvent(string $eventId): array
    {
        if (!$this->uuidLike($eventId)) {
            return [];
        }
        return $this->many(
            'SELECT * FROM event_registrations WHERE event_id = :event_id ORDER BY created_at DESC',
            [':event_id' => $eventId]
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByUser(string $userId): array
    {
        if (!$this->uuidLike($userId)) {
            return [];
        }
        return $this->many(
            <<<SQL
                SELECT r.*, e.title AS event_title, e.slug AS event_slug, e.starts_at, e.ends_at
                FROM event_registrations r
                JOIN training_events e ON e.id = r.event_id
                WHERE r.registered_by_user_id = :user_id
                ORDER BY e.starts_at ASC
            SQL,
            [':user_id' => $userId]
        );
    }

    public function update(string $id, array $data): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }
        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $id];

        foreach (['full_name', 'email', 'phone', 'organisation', 'role_title', 'notes'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $field === 'email'
                    ? strtolower((string)$this->cleanString($data[$field], true))
                    : $this->cleanString($data[$field], true);
            }
        }
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['pending', 'approved', 'waitlisted', 'cancelled', 'declined'], true)) {
                throw new RuntimeException('Invalid registration status supplied.');
            }
            $assignments[] = 'status = :status';
            $params[':status'] = $status;
        }
        if (array_key_exists('attended', $data)) {
            $assignments[] = 'attended = :attended';
            $params[':attended'] = $this->boolValue($data['attended']) ? 1 : 0;
        }

        $this->query('UPDATE event_registrations SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }
}
