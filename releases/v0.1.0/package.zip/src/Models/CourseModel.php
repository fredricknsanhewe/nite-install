<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class CourseModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listCourses(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];
        if (!$admin) {
            $where[] = "status = 'published'";
        } elseif (trim((string)($filters['status'] ?? '')) !== '') {
            $where[] = 'status = :status';
            $params[':status'] = strtolower(trim((string)$filters['status']));
        }
        if (array_key_exists('featured', $filters)) {
            $where[] = 'is_featured = :is_featured';
            $params[':is_featured'] = $this->boolValue($filters['featured']) ? 1 : 0;
        }
        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'description']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM courses';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY ' . $this->orderByNullsLast('starts_at', 'DESC') . ', created_at DESC';

        return array_values(array_map(fn (array $row): array => $this->hydrateCourse($row), $this->many($sql, $params)));
    }

    public function findCourseById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM courses WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrateCourse($row) : null;
    }

    public function findCourseBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM courses WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';
        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrateCourse($row) : null;
    }

    public function createCourse(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizeCoursePayload($data, true);
        $payload['id'] = UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId);
        $metaJsonParam = $this->jsonParam(':meta_json');
        $this->query(
            <<<SQL
                INSERT INTO courses (
                    id, slug, title, summary, description, delivery_mode, lms_url,
                    starts_at, ends_at, certificate_enabled, is_featured, status,
                    meta_json, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :title, :summary, :description, :delivery_mode, :lms_url,
                    :starts_at, :ends_at, :certificate_enabled, :is_featured, :status,
                    {$metaJsonParam}, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            $payload
        );
        return (array)$this->findCourseById($payload['id']);
    }

    public function updateCourse(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findCourseById($id) === null) {
            return null;
        }
        $payload = $this->normalizeCoursePayload($data, false);
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [':id' => $id, ':updated_by_user_id' => $this->cleanString($actorUserId)];
        foreach (['slug', 'title', 'summary', 'description', 'delivery_mode', 'lms_url', 'starts_at', 'ends_at', 'status'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }
        foreach (['certificate_enabled', 'is_featured'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }
        if (array_key_exists('meta_json', $payload)) {
            $assignments[] = 'meta_json = ' . $this->jsonParam(':meta_json');
            $params[':meta_json'] = $payload['meta_json'];
        }
        $this->query('UPDATE courses SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findCourseById($id);
    }

    public function deleteCourse(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM courses WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listModules(string $courseId, bool $admin = false): array
    {
        if (!$this->uuidLike($courseId)) {
            return [];
        }
        $sql = 'SELECT * FROM course_modules WHERE course_id = :course_id';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' ORDER BY sort_order ASC, created_at ASC';
        return $this->many($sql, [':course_id' => $courseId]);
    }

    public function findModule(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one('SELECT * FROM course_modules WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    public function createModule(string $courseId, array $data, ?string $actorUserId = null): array
    {
        if (!$this->uuidLike($courseId)) {
            throw new RuntimeException('Invalid course supplied.');
        }
        $title = (string)$this->cleanString($data['title'] ?? null);
        if ($title === '') {
            throw new RuntimeException('Module title is required.');
        }
        $contentType = strtolower((string)$this->cleanString($data['content_type'] ?? 'document', true));
        if (!in_array($contentType, ['text', 'document', 'video', 'quiz', 'live_session', 'link'], true)) {
            throw new RuntimeException('Invalid module content type supplied.');
        }
        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO course_modules (
                    id, course_id, title, summary, content_type, content_url,
                    sort_order, duration_minutes, status, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :course_id, :title, :summary, :content_type, :content_url,
                    :sort_order, :duration_minutes, :status, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':course_id' => $courseId,
                ':title' => $title,
                ':summary' => $this->cleanString($data['summary'] ?? null, true),
                ':content_type' => $contentType,
                ':content_url' => $this->cleanString($data['content_url'] ?? null, true),
                ':sort_order' => (int)($data['sort_order'] ?? 0),
                ':duration_minutes' => ($data['duration_minutes'] ?? null) === null || ($data['duration_minutes'] ?? null) === '' ? null : (int)$data['duration_minutes'],
                ':status' => in_array(($data['status'] ?? 'draft'), ['draft', 'published'], true) ? $data['status'] : 'draft',
                ':created_by_user_id' => $this->cleanString($actorUserId),
                ':updated_by_user_id' => $this->cleanString($actorUserId),
            ]
        );
        return (array)$this->findModule($id);
    }

    public function updateModule(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findModule($id) === null) {
            return null;
        }
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [':id' => $id, ':updated_by_user_id' => $this->cleanString($actorUserId)];
        foreach (['title', 'summary', 'content_type', 'content_url', 'status'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $this->cleanString($data[$field], true);
            }
        }
        if (array_key_exists('sort_order', $data)) {
            $assignments[] = 'sort_order = :sort_order';
            $params[':sort_order'] = (int)$data['sort_order'];
        }
        if (array_key_exists('duration_minutes', $data)) {
            $assignments[] = 'duration_minutes = :duration_minutes';
            $params[':duration_minutes'] = $data['duration_minutes'] === null || $data['duration_minutes'] === '' ? null : (int)$data['duration_minutes'];
        }
        $this->query('UPDATE course_modules SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findModule($id);
    }

    public function deleteModule(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM course_modules WHERE id = :id', [':id' => $id]);
        return true;
    }

    public function enroll(string $courseId, string $userId): array
    {
        if (!$this->uuidLike($courseId) || !$this->uuidLike($userId)) {
            throw new RuntimeException('Invalid course enrollment request.');
        }
        $existing = $this->one(
            'SELECT * FROM course_enrollments WHERE course_id = :course_id AND user_id = :user_id LIMIT 1',
            [':course_id' => $courseId, ':user_id' => $userId]
        );
        if ($existing !== null) {
            return $existing;
        }
        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO course_enrollments (
                    id, course_id, user_id, status, progress_percent, certificate_issued
                ) VALUES (
                    :id, :course_id, :user_id, 'enrolled', 0, false
                )
            SQL,
            [
                ':id' => $id,
                ':course_id' => $courseId,
                ':user_id' => $userId,
            ]
        );
        return (array)$this->findEnrollment($courseId, $userId);
    }

    public function findEnrollment(string $courseId, string $userId): ?array
    {
        if (!$this->uuidLike($courseId) || !$this->uuidLike($userId)) {
            return null;
        }
        return $this->one(
            'SELECT * FROM course_enrollments WHERE course_id = :course_id AND user_id = :user_id LIMIT 1',
            [':course_id' => $courseId, ':user_id' => $userId]
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listEnrollments(?string $userId = null, ?string $courseId = null): array
    {
        $where = [];
        $params = [];
        if ($userId !== null && $userId !== '') {
            $where[] = 'e.user_id = :user_id';
            $params[':user_id'] = $userId;
        }
        if ($courseId !== null && $courseId !== '') {
            $where[] = 'e.course_id = :course_id';
            $params[':course_id'] = $courseId;
        }
        $sql = <<<SQL
            SELECT
                e.*,
                c.slug AS course_slug,
                c.title AS course_title,
                u.name AS user_name,
                u.email AS user_email
            FROM course_enrollments e
            JOIN courses c ON c.id = e.course_id
            JOIN users u ON u.id = e.user_id
        SQL;
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY e.enrolled_at DESC';
        return $this->many($sql, $params);
    }

    public function updateEnrollment(string $enrollmentId, array $data): ?array
    {
        if (!$this->uuidLike($enrollmentId)) {
            return null;
        }
        $existing = $this->one('SELECT * FROM course_enrollments WHERE id = :id LIMIT 1', [':id' => $enrollmentId]);
        if ($existing === null) {
            return null;
        }

        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $enrollmentId];
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['enrolled', 'completed', 'cancelled'], true)) {
                throw new RuntimeException('Invalid enrollment status supplied.');
            }
            $assignments[] = 'status = :status';
            $params[':status'] = $status;
            if ($status === 'completed') {
                $assignments[] = 'completed_at = COALESCE(completed_at, NOW())';
            }
        }
        if (array_key_exists('progress_percent', $data)) {
            $progress = max(0, min(100, (float)$data['progress_percent']));
            $assignments[] = 'progress_percent = :progress_percent';
            $params[':progress_percent'] = $progress;
            if ($progress >= 100) {
                $assignments[] = "status = 'completed'";
                $assignments[] = 'completed_at = COALESCE(completed_at, NOW())';
            }
        }
        if (array_key_exists('certificate_issued', $data)) {
            $assignments[] = 'certificate_issued = :certificate_issued';
            $params[':certificate_issued'] = $this->boolValue($data['certificate_issued']) ? 1 : 0;
        }
        $assignments[] = 'last_activity_at = NOW()';
        $this->query('UPDATE course_enrollments SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->one('SELECT * FROM course_enrollments WHERE id = :id LIMIT 1', [':id' => $enrollmentId]);
    }

    public function findEnrollmentById(string $enrollmentId): ?array
    {
        if (!$this->uuidLike($enrollmentId)) {
            return null;
        }

        return $this->one(
            <<<SQL
                SELECT
                    e.*,
                    c.slug AS course_slug,
                    c.title AS course_title,
                    u.name AS user_name,
                    u.email AS user_email
                FROM course_enrollments e
                JOIN courses c ON c.id = e.course_id
                JOIN users u ON u.id = e.user_id
                WHERE e.id = :id
                LIMIT 1
            SQL,
            [':id' => $enrollmentId]
        );
    }

    public function updateProgress(string $courseId, string $moduleId, string $userId, array $data): array
    {
        if (!$this->uuidLike($courseId) || !$this->uuidLike($moduleId) || !$this->uuidLike($userId)) {
            throw new RuntimeException('Invalid course progress request.');
        }
        $status = strtolower((string)$this->cleanString($data['status'] ?? 'in_progress', true));
        if (!in_array($status, ['not_started', 'in_progress', 'completed'], true)) {
            throw new RuntimeException('Invalid progress status supplied.');
        }
        $progress = max(0, min(100, (float)($data['progress_percent'] ?? ($status === 'completed' ? 100 : 0))));
        $existing = $this->one(
            'SELECT * FROM course_progress WHERE module_id = :module_id AND user_id = :user_id LIMIT 1',
            [':module_id' => $moduleId, ':user_id' => $userId]
        );

        if ($existing === null) {
            $id = UUID::v4();
            $this->query(
                <<<SQL
                    INSERT INTO course_progress (
                        id, course_id, module_id, user_id, status, progress_percent, completed_at, updated_at
                    ) VALUES (
                        :id, :course_id, :module_id, :user_id, :status, :progress_percent, :completed_at, NOW()
                    )
                SQL,
                [
                    ':id' => $id,
                    ':course_id' => $courseId,
                    ':module_id' => $moduleId,
                    ':user_id' => $userId,
                    ':status' => $status,
                    ':progress_percent' => $progress,
                    ':completed_at' => $status === 'completed' ? $this->normalizeDateTime(gmdate('c')) : null,
                ]
            );
        } else {
            $this->query(
                <<<SQL
                    UPDATE course_progress
                    SET status = :status,
                        progress_percent = :progress_percent,
                        completed_at = :completed_at,
                        updated_at = NOW()
                    WHERE module_id = :module_id AND user_id = :user_id
                SQL,
                [
                    ':status' => $status,
                    ':progress_percent' => $progress,
                    ':completed_at' => $status === 'completed' ? $this->normalizeDateTime(gmdate('c')) : null,
                    ':module_id' => $moduleId,
                    ':user_id' => $userId,
                ]
            );
        }

        $this->recalculateEnrollment($courseId, $userId);

        return (array)$this->one(
            'SELECT * FROM course_progress WHERE module_id = :module_id AND user_id = :user_id LIMIT 1',
            [':module_id' => $moduleId, ':user_id' => $userId]
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listProgress(string $courseId, string $userId): array
    {
        if (!$this->uuidLike($courseId) || !$this->uuidLike($userId)) {
            return [];
        }
        return $this->many(
            <<<SQL
                SELECT
                    p.*,
                    m.title AS module_title,
                    m.sort_order
                FROM course_progress p
                JOIN course_modules m ON m.id = p.module_id
                WHERE p.course_id = :course_id AND p.user_id = :user_id
                ORDER BY m.sort_order ASC
            SQL,
            [':course_id' => $courseId, ':user_id' => $userId]
        );
    }

    public function countEnrollments(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM course_enrollments');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizeCoursePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary', 'description', 'lms_url', 'starts_at', 'ends_at'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = in_array($field, ['starts_at', 'ends_at'], true)
                    ? $this->normalizeDateTime($data[$field])
                    : $this->cleanString($data[$field], true);
            }
        }
        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '')) {
            throw new RuntimeException('Course slug and title are required.');
        }

        if (array_key_exists('delivery_mode', $data)) {
            $mode = strtolower((string)$this->cleanString($data['delivery_mode'], true));
            if (!in_array($mode, ['self_paced', 'cohort', 'webinar', 'external_lms'], true)) {
                throw new RuntimeException('Invalid course delivery mode supplied.');
            }
            $payload['delivery_mode'] = $mode;
        } elseif ($create) {
            $payload['delivery_mode'] = 'self_paced';
        }

        if (array_key_exists('certificate_enabled', $data)) {
            $payload['certificate_enabled'] = $this->boolValue($data['certificate_enabled']) ? 1 : 0;
        } elseif ($create) {
            $payload['certificate_enabled'] = 0;
        }
        if (array_key_exists('is_featured', $data)) {
            $payload['is_featured'] = $this->boolValue($data['is_featured']) ? 1 : 0;
        } elseif ($create) {
            $payload['is_featured'] = 0;
        }
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['draft', 'published', 'archived'], true)) {
                throw new RuntimeException('Invalid course status supplied.');
            }
            $payload['status'] = $status;
        } elseif ($create) {
            $payload['status'] = 'draft';
        }
        if (array_key_exists('meta', $data) || array_key_exists('meta_json', $data)) {
            $payload['meta_json'] = json_encode(
                is_array($data['meta'] ?? null) ? $data['meta'] : (is_array($data['meta_json'] ?? null) ? $data['meta_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['meta_json'] = '{}';
        }

        if ($create) {
            foreach (['summary', 'lms_url', 'starts_at', 'ends_at'] as $field) {
                if (!array_key_exists($field, $payload)) {
                    $payload[$field] = null;
                }
            }
            if (!array_key_exists('description', $payload)) {
                $payload['description'] = '';
            }
        }

        return $payload;
    }

    private function recalculateEnrollment(string $courseId, string $userId): void
    {
        $stats = $this->one(
            <<<SQL
                SELECT
                    COUNT(*) AS module_count,
                    COALESCE(AVG(progress_percent), 0) AS avg_progress
                FROM course_progress
                WHERE course_id = :course_id AND user_id = :user_id
            SQL,
            [':course_id' => $courseId, ':user_id' => $userId]
        );
        $progress = (float)($stats['avg_progress'] ?? 0);
        $status = $progress >= 100 ? 'completed' : 'enrolled';

        $this->query(
            <<<SQL
                UPDATE course_enrollments
                SET progress_percent = :progress_percent,
                    status = :status,
                    completed_at = CASE WHEN :status = 'completed' THEN COALESCE(completed_at, NOW()) ELSE NULL END,
                    last_activity_at = NOW(),
                    updated_at = NOW()
                WHERE course_id = :course_id AND user_id = :user_id
            SQL,
            [
                ':progress_percent' => $progress,
                ':status' => $status,
                ':course_id' => $courseId,
                ':user_id' => $userId,
            ]
        );
    }

    private function hydrateCourse(array $row): array
    {
        $row['meta'] = $this->decodeJson($row['meta_json'] ?? null, []);
        unset($row['meta_json']);
        return $row;
    }
}
