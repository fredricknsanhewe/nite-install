<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class ExampleEntityModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(string $moduleKey, string $entityType, array $filters = []): array
    {
        $where = ['module_key = :module_key', 'entity_type = :entity_type'];
        $params = [
            ':module_key' => $moduleKey,
            ':entity_type' => $entityType,
        ];

        $status = strtolower(trim((string)($filters['status'] ?? '')));
        if ($status !== '') {
            $where[] = 'status = :status';
            $params[':status'] = $status;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'slug']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM example_entities WHERE ' . implode(' AND ', $where) . ' ORDER BY created_at DESC';
        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function find(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM example_entities WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(string $moduleKey, string $entityType, array $data, ?string $actorUserId = null): array
    {
        $title = (string)$this->cleanString($data['title'] ?? null);
        if ($title === '') {
            throw new RuntimeException('Example entity title is required.');
        }

        $id = UUID::v4();
        $payloadJsonParam = $this->jsonParam(':payload_json');
        $this->query(
            <<<SQL
                INSERT INTO example_entities (
                    id, module_key, entity_type, slug, title, summary, status,
                    owner_user_id, payload_json, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :module_key, :entity_type, :slug, :title, :summary, :status,
                    :owner_user_id, {$payloadJsonParam}, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':module_key' => $moduleKey,
                ':entity_type' => $entityType,
                ':slug' => $this->cleanString($data['slug'] ?? null, true),
                ':title' => $title,
                ':summary' => $this->cleanString($data['summary'] ?? null, true),
                ':status' => $this->normalizeStatus($data['status'] ?? 'draft'),
                ':owner_user_id' => $this->cleanString($data['owner_user_id'] ?? null),
                ':payload_json' => json_encode(is_array($data['payload'] ?? null) ? $data['payload'] : $data, JSON_UNESCAPED_SLASHES),
                ':created_by_user_id' => $this->cleanString($actorUserId),
                ':updated_by_user_id' => $this->cleanString($actorUserId),
            ]
        );

        return (array)$this->find($id);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function search(string $query): array
    {
        $q = trim($query);
        if ($q === '') {
            return [];
        }
        $searchCondition = $this->likeAny(['title', 'summary', 'slug']);

        $rows = $this->many(
            <<<SQL
                SELECT * FROM example_entities
                WHERE {$searchCondition}
                ORDER BY created_at DESC
                LIMIT 50
            SQL,
            [':q' => '%' . $q . '%']
        );

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $rows));
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->find($id) === null) {
            return null;
        }

        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [
            ':id' => $id,
            ':updated_by_user_id' => $this->cleanString($actorUserId),
        ];

        foreach (['slug', 'title', 'summary', 'owner_user_id'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $this->cleanString($data[$field], true);
            }
        }
        if (array_key_exists('status', $data)) {
            $assignments[] = 'status = :status';
            $params[':status'] = $this->normalizeStatus($data['status']);
        }
        if (array_key_exists('payload', $data) || array_key_exists('payload_json', $data)) {
            $assignments[] = 'payload_json = ' . $this->jsonParam(':payload_json');
            $params[':payload_json'] = json_encode(
                is_array($data['payload'] ?? null) ? $data['payload'] : (is_array($data['payload_json'] ?? null) ? $data['payload_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        }

        $this->query('UPDATE example_entities SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->find($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM example_entities WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<string, int>
     */
    public function moduleCounts(): array
    {
        $rows = $this->many('SELECT module_key, COUNT(*) AS total FROM example_entities GROUP BY module_key ORDER BY module_key ASC');
        $counts = [];
        foreach ($rows as $row) {
            $counts[(string)$row['module_key']] = (int)$row['total'];
        }
        return $counts;
    }

    private function hydrate(array $row): array
    {
        $row['payload'] = $this->decodeJson($row['payload_json'] ?? null, []);
        unset($row['payload_json']);
        return $row;
    }

    private function normalizeStatus(mixed $value): string
    {
        $status = strtolower(trim((string)$value));
        return in_array($status, ['draft', 'active', 'published', 'archived', 'disabled'], true) ? $status : 'draft';
    }
}
