<?php
namespace App\Models;

final class RbacModel extends BaseModel
{
    /**
     * @param array<int, array<string, mixed>> $definitions
     */
    public function upsertPermissions(array $definitions): void
    {
        foreach ($definitions as $definition) {
            $params = [
                ':code' => $definition['code'],
                ':title' => $definition['title'],
                ':description' => $definition['description'],
                ':section_code' => $definition['section_code'],
                ':section_title' => $definition['section_title'],
                ':module_code' => $definition['module_code'],
                ':module_title' => $definition['module_title'],
                ':action_code' => $definition['action_code'],
                ':action_title' => $definition['action_title'],
                ':sort_order' => $definition['sort_order'],
            ];

            if ($this->isMysql()) {
                $this->query(
                    <<<SQL
                        INSERT INTO permissions (
                            code, title, description, section_code, section_title,
                            module_code, module_title, action_code, action_title, sort_order
                        ) VALUES (
                            :code, :title, :description, :section_code, :section_title,
                            :module_code, :module_title, :action_code, :action_title, :sort_order
                        )
                        ON DUPLICATE KEY UPDATE
                            title = VALUES(title),
                            description = VALUES(description),
                            section_code = VALUES(section_code),
                            section_title = VALUES(section_title),
                            module_code = VALUES(module_code),
                            module_title = VALUES(module_title),
                            action_code = VALUES(action_code),
                            action_title = VALUES(action_title),
                            sort_order = VALUES(sort_order)
                    SQL,
                    $params
                );
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO permissions (
                        code, title, description, section_code, section_title,
                        module_code, module_title, action_code, action_title, sort_order
                    ) VALUES (
                        :code, :title, :description, :section_code, :section_title,
                        :module_code, :module_title, :action_code, :action_title, :sort_order
                    )
                    ON CONFLICT (code) DO UPDATE
                    SET title = EXCLUDED.title,
                        description = EXCLUDED.description,
                        section_code = EXCLUDED.section_code,
                        section_title = EXCLUDED.section_title,
                        module_code = EXCLUDED.module_code,
                        module_title = EXCLUDED.module_title,
                        action_code = EXCLUDED.action_code,
                        action_title = EXCLUDED.action_title,
                        sort_order = EXCLUDED.sort_order
                SQL,
                $params
            );
        }
    }

    public function permissionCount(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM permissions');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listPermissionRows(): array
    {
        return $this->many('SELECT * FROM permissions ORDER BY sort_order ASC, code ASC');
    }

    /**
     * @return array<string, string>
     */
    public function listRoleRuleStates(string $role): array
    {
        $rows = $this->many(
            <<<SQL
                SELECT p.code, r.effect
                FROM role_permission_rules r
                JOIN permissions p ON p.id = r.permission_id
                WHERE r.role = :role
            SQL,
            [':role' => $role]
        );

        $states = [];
        foreach ($rows as $row) {
            $states[(string)$row['code']] = (string)$row['effect'];
        }
        return $states;
    }

    /**
     * @return array<string, array<string, string>>
     */
    public function listAllRoleRuleStates(): array
    {
        $rows = $this->many(
            <<<SQL
                SELECT p.code, r.role, r.effect
                FROM role_permission_rules r
                JOIN permissions p ON p.id = r.permission_id
            SQL
        );
        $states = [];
        foreach ($rows as $row) {
            $code = (string)$row['code'];
            $role = (string)$row['role'];
            $states[$code][$role] = (string)$row['effect'];
        }
        return $states;
    }

    /**
     * @param array<string, string> $statesByCode
     */
    public function replaceRoleRules(string $role, array $statesByCode): void
    {
        $this->query('DELETE FROM role_permission_rules WHERE role = :role', [':role' => $role]);
        if ($statesByCode === []) {
            return;
        }

        $permissionMap = $this->permissionRowsByCodeMap(array_keys($statesByCode));
        foreach ($statesByCode as $code => $effect) {
            if (!isset($permissionMap[$code])) {
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO role_permission_rules (role, permission_id, effect)
                    VALUES (:role, :permission_id, :effect)
                SQL,
                [
                    ':role' => $role,
                    ':permission_id' => $permissionMap[$code]['id'],
                    ':effect' => $effect,
                ]
            );
        }
    }

    /**
     * @return array<string, string>
     */
    public function listUserOverrideStates(string $userId): array
    {
        $rows = $this->many(
            <<<SQL
                SELECT p.code, o.effect
                FROM user_permission_overrides o
                JOIN permissions p ON p.id = o.permission_id
                WHERE o.user_id = :user_id
            SQL,
            [':user_id' => $userId]
        );

        $states = [];
        foreach ($rows as $row) {
            $states[(string)$row['code']] = (string)$row['effect'];
        }
        return $states;
    }

    /**
     * @param array<string, string> $statesByCode
     */
    public function replaceUserOverrides(string $userId, array $statesByCode): void
    {
        $this->query('DELETE FROM user_permission_overrides WHERE user_id = :user_id', [':user_id' => $userId]);
        if ($statesByCode === []) {
            return;
        }

        $permissionMap = $this->permissionRowsByCodeMap(array_keys($statesByCode));
        foreach ($statesByCode as $code => $effect) {
            if (!isset($permissionMap[$code])) {
                continue;
            }

            $this->query(
                <<<SQL
                    INSERT INTO user_permission_overrides (user_id, permission_id, effect)
                    VALUES (:user_id, :permission_id, :effect)
                SQL,
                [
                    ':user_id' => $userId,
                    ':permission_id' => $permissionMap[$code]['id'],
                    ':effect' => $effect,
                ]
            );
        }
    }

    /**
     * @param array<int, string> $codes
     * @return array<string, array<string, mixed>>
     */
    private function permissionRowsByCodeMap(array $codes): array
    {
        if ($codes === []) {
            return [];
        }

        $placeholders = [];
        $params = [];
        foreach (array_values($codes) as $index => $code) {
            $key = ':code' . $index;
            $placeholders[] = $key;
            $params[$key] = $code;
        }

        $rows = $this->many(
            'SELECT id, code FROM permissions WHERE code IN (' . implode(',', $placeholders) . ')',
            $params
        );

        $map = [];
        foreach ($rows as $row) {
            $map[(string)$row['code']] = $row;
        }
        return $map;
    }
}
