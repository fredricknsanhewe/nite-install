<?php
namespace App\Validation;

use App\Exceptions\ValidationException;

final class Validator
{
    /**
     * @param array<string, mixed> $input
     * @param array<string, string|array<int, string>> $rules
     * @return array<string, mixed>
     */
    public static function validate(array $input, array $rules): array
    {
        $errors = [];
        $validated = [];

        foreach ($rules as $field => $fieldRules) {
            $ruleset = self::normalizeRules($fieldRules);
            $present = array_key_exists($field, $input);
            $value = $input[$field] ?? null;

            if (in_array('sometimes', $ruleset, true) && !$present) {
                continue;
            }

            $nullable = in_array('nullable', $ruleset, true);
            $required = in_array('required', $ruleset, true);

            if ($required && self::isEmpty($value)) {
                $errors[$field][] = 'This field is required.';
                continue;
            }

            if (!$required && !$present) {
                continue;
            }

            if ($nullable && ($value === null || $value === '')) {
                $validated[$field] = null;
                continue;
            }

            foreach ($ruleset as $rule) {
                if (in_array($rule, ['required', 'nullable', 'sometimes'], true)) {
                    continue;
                }

                [$name, $parameter] = self::parseRule($rule);
                $message = self::validateRule($name, $parameter, $value, $input);
                if ($message !== null) {
                    $errors[$field][] = $message;
                }
            }

            if (!isset($errors[$field])) {
                $validated[$field] = $value;
            }
        }

        if ($errors !== []) {
            throw new ValidationException($errors);
        }

        return $validated;
    }

    /**
     * @param array<string, string|array<int, string>> $rules
     * @return array<string, mixed>
     */
    public static function assert(array $input, array $rules): array
    {
        return self::validate($input, $rules);
    }

    /**
     * @param string|array<int, string> $rules
     * @return list<string>
     */
    private static function normalizeRules(string|array $rules): array
    {
        if (is_array($rules)) {
            return array_values(array_filter(array_map('strval', $rules), static fn (string $rule): bool => trim($rule) !== ''));
        }

        return array_values(array_filter(array_map('trim', explode('|', $rules)), static fn (string $rule): bool => $rule !== ''));
    }

    /**
     * @return array{0: string, 1: string}
     */
    private static function parseRule(string $rule): array
    {
        if (!str_contains($rule, ':')) {
            return [$rule, ''];
        }

        [$name, $parameter] = explode(':', $rule, 2);
        return [trim($name), trim($parameter)];
    }

    /**
     * @param array<string, mixed> $input
     */
    private static function validateRule(string $rule, string $parameter, mixed $value, array $input): ?string
    {
        return match ($rule) {
            'string' => is_string($value) ? null : 'This field must be a string.',
            'array' => is_array($value) ? null : 'This field must be an array.',
            'boolean' => is_bool($value) || in_array($value, [0, 1, '0', '1', 'true', 'false'], true)
                ? null
                : 'This field must be a boolean.',
            'email' => is_string($value) && filter_var(trim($value), FILTER_VALIDATE_EMAIL) !== false
                ? null
                : 'This field must be a valid email address.',
            'uuid' => is_string($value) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1
                ? null
                : 'This field must be a valid UUID.',
            'min' => self::validateMin($value, (int)$parameter),
            'max' => self::validateMax($value, (int)$parameter),
            'in' => self::validateIn($value, $parameter),
            'regex' => self::validateRegex($value, $parameter),
            'same' => array_key_exists($parameter, $input) && $value === $input[$parameter]
                ? null
                : 'This field must match ' . $parameter . '.',
            default => null,
        };
    }

    private static function validateMin(mixed $value, int $min): ?string
    {
        if (is_string($value) && mb_strlen($value) < $min) {
            return 'This field must be at least ' . $min . ' characters.';
        }
        if (is_array($value) && count($value) < $min) {
            return 'This field must contain at least ' . $min . ' items.';
        }
        if (is_numeric($value) && (float)$value < $min) {
            return 'This field must be at least ' . $min . '.';
        }

        return null;
    }

    private static function validateMax(mixed $value, int $max): ?string
    {
        if (is_string($value) && mb_strlen($value) > $max) {
            return 'This field may not be greater than ' . $max . ' characters.';
        }
        if (is_array($value) && count($value) > $max) {
            return 'This field may not contain more than ' . $max . ' items.';
        }
        if (is_numeric($value) && (float)$value > $max) {
            return 'This field may not be greater than ' . $max . '.';
        }

        return null;
    }

    private static function validateIn(mixed $value, string $parameter): ?string
    {
        $allowed = array_values(array_filter(array_map('trim', explode(',', $parameter)), static fn (string $item): bool => $item !== ''));
        return in_array((string)$value, $allowed, true)
            ? null
            : 'This field must be one of: ' . implode(', ', $allowed) . '.';
    }

    private static function validateRegex(mixed $value, string $parameter): ?string
    {
        if (!is_string($value) || $parameter === '') {
            return 'This field has an invalid format.';
        }

        return preg_match($parameter, $value) === 1
            ? null
            : 'This field has an invalid format.';
    }

    private static function isEmpty(mixed $value): bool
    {
        if ($value === null) {
            return true;
        }
        if (is_string($value)) {
            return trim($value) === '';
        }
        if (is_array($value)) {
            return $value === [];
        }

        return false;
    }
}
