<?php
namespace App\Http;

final class Request
{
    public string $method;
    public string $path;
    public array $query = [];
    public array $headers = [];
    public array $body = [];
    public array $files = [];
    public array $params = [];
    public array $attributes = [];
    public ?array $user = null;
    public string $rawBody = '';
    public string $contentType = '';

    public function __construct(string $method, string $path, array $query, array $headers, array $body, string $rawBody = '', array $files = [], string $contentType = '')
    {
        $this->method = strtoupper($method);
        $this->path = $path;
        $this->query = $query;
        $this->headers = $headers;
        $this->body = $body;
        $this->rawBody = $rawBody;
        $this->files = $files;
        $this->contentType = $contentType;
    }

    public static function fromGlobals(): self
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $authorization = $headers['Authorization'] ?? $headers['authorization'] ?? null;
        if ((!is_string($authorization) || trim($authorization) === '') && is_string($_COOKIE['nite_browsable_api_token'] ?? null)) {
            $token = trim((string)$_COOKIE['nite_browsable_api_token']);
            if ($token !== '') {
                $headers['Authorization'] = str_starts_with($token, 'Bearer ') ? $token : ('Bearer ' . $token);
            }
        }
        $query = $_GET ?? [];
        $contentType = $headers['Content-Type'] ?? $headers['content-type'] ?? '';
        $rawBody = file_get_contents('php://input') ?: '';
        $body = [];
        $parseError = null;

        if (str_contains((string)$contentType, 'application/json')) {
            $decoded = json_decode($rawBody, true);
            if (is_array($decoded)) {
                $body = $decoded;
            } elseif (trim($rawBody) !== '') {
                $parseError = 'Malformed JSON request body.';
            }
        } elseif (!empty($_POST)) {
            $body = $_POST;
        }

        $request = new self($method, $path, $query, $headers, $body, $rawBody, self::normalizeFiles($_FILES ?? []), (string)$contentType);
        if ($parseError !== null) {
            $request->attributes['body_parse_error'] = $parseError;
        }

        return $request;
    }

    public function header(string $key, ?string $default = null): ?string
    {
        foreach ($this->headers as $name => $value) {
            if (strtolower((string)$name) === strtolower($key)) {
                return is_array($value) ? ($value[0] ?? $default) : (string)$value;
            }
        }

        return $default;
    }

    public function prefersHtml(): bool
    {
        $html = $this->acceptQuality('text/html');
        if ($html <= 0.0) {
            return false;
        }

        if (strtolower((string)$this->header('X-Requested-With', '')) === 'xmlhttprequest') {
            return false;
        }

        $json = max(
            $this->acceptQuality('application/json'),
            $this->acceptQuality('application/*'),
            $this->acceptQuality('*/*')
        );

        return $html > $json || ($html > 0.0 && $json === 0.0);
    }

    public function wantsJson(): bool
    {
        $json = max(
            $this->acceptQuality('application/json'),
            $this->acceptQuality('application/*')
        );

        return $json > 0.0 || !$this->prefersHtml();
    }

    public function ipAddress(): string
    {
        $forwarded = trim((string)($this->header('X-Forwarded-For', '') ?? ''));
        if ($forwarded !== '') {
            $parts = array_values(array_filter(array_map('trim', explode(',', $forwarded)), static fn (string $part): bool => $part !== ''));
            if ($parts !== []) {
                return $parts[0];
            }
        }

        return trim((string)($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1')) ?: '127.0.0.1';
    }

    /**
     * @return array<string, mixed>|null
     */
    public function uploadedFile(string $key): ?array
    {
        $files = $this->uploadedFiles($key);
        return $files[0] ?? null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function uploadedFiles(string $key): array
    {
        $files = $this->files[$key] ?? [];
        return is_array($files) ? $files : [];
    }

    /**
     * @param array<string, mixed> $files
     * @return array<string, array<int, array<string, mixed>>>
     */
    private static function normalizeFiles(array $files): array
    {
        $normalized = [];
        foreach ($files as $field => $spec) {
            if (!is_array($spec) || !array_key_exists('name', $spec)) {
                continue;
            }
            $normalized[(string)$field] = self::flattenFileSpec(
                $spec['name'] ?? null,
                $spec['type'] ?? null,
                $spec['tmp_name'] ?? null,
                $spec['error'] ?? null,
                $spec['size'] ?? null
            );
        }

        return $normalized;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function flattenFileSpec(mixed $name, mixed $type, mixed $tmpName, mixed $error, mixed $size): array
    {
        if (is_array($name)) {
            $files = [];
            foreach ($name as $index => $childName) {
                $files = array_merge($files, self::flattenFileSpec(
                    $childName,
                    is_array($type) ? ($type[$index] ?? null) : null,
                    is_array($tmpName) ? ($tmpName[$index] ?? null) : null,
                    is_array($error) ? ($error[$index] ?? null) : null,
                    is_array($size) ? ($size[$index] ?? null) : null
                ));
            }
            return $files;
        }

        return [[
            'name' => is_string($name) ? $name : '',
            'type' => is_string($type) ? $type : '',
            'tmp_name' => is_string($tmpName) ? $tmpName : '',
            'error' => is_numeric($error) ? (int)$error : UPLOAD_ERR_NO_FILE,
            'size' => is_numeric($size) ? (int)$size : 0,
        ]];
    }

    private function acceptQuality(string $target): float
    {
        $header = trim((string)$this->header('Accept', ''));
        if ($header === '') {
            return $target === 'application/json' ? 1.0 : 0.0;
        }

        $best = 0.0;
        foreach (explode(',', $header) as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }

            $segments = array_map('trim', explode(';', $part));
            $mime = strtolower((string)array_shift($segments));
            $quality = 1.0;
            foreach ($segments as $segment) {
                if (str_starts_with(strtolower($segment), 'q=')) {
                    $quality = (float)substr($segment, 2);
                    break;
                }
            }

            if ($mime === strtolower($target)) {
                $best = max($best, $quality);
                continue;
            }

            if ($mime === '*/*') {
                $best = max($best, $quality);
                continue;
            }

            if (str_ends_with($mime, '/*')) {
                $prefix = substr($mime, 0, strpos($mime, '/'));
                if (str_starts_with(strtolower($target), $prefix . '/')) {
                    $best = max($best, $quality);
                }
            }
        }

        return $best;
    }
}
