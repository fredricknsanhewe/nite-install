<?php
namespace App\Http;

final class ApiResponse
{
    /**
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function success(
        mixed $data = [],
        string $message = 'Request completed successfully',
        int $status = 200,
        array $meta = [],
        array $headers = []
    ): Response {
        return Response::api(self::envelope('success', $status, $message, $data, null, $meta), $status, $headers);
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function error(
        string $message = 'Request failed',
        array|string|null $errors = null,
        int $status = 400,
        array $meta = [],
        array $headers = []
    ): Response {
        return Response::api(
            self::envelope('error', $status, $message, null, self::normalizeErrors($errors), $meta),
            $status,
            $headers
        );
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @param array<string, mixed> $meta
     * @param array<string, string> $headers
     */
    public static function validationError(
        array|string|null $errors = null,
        string $message = 'Validation failed',
        array $meta = [],
        array $headers = []
    ): Response {
        return self::error($message, $errors, 422, $meta, $headers);
    }

    /**
     * @return array<string, mixed>
     */
    public static function normalize(mixed $payload, int $status = 200): array
    {
        if (is_array($payload) && self::isEnvelope($payload)) {
            return self::sanitizeEnvelope($payload, $status);
        }

        $meta = [];
        if (is_array($payload) && isset($payload['meta']) && is_array($payload['meta'])) {
            $meta = $payload['meta'];
        }

        $message = is_array($payload) && is_string($payload['message'] ?? null)
            ? trim((string)$payload['message'])
            : '';

        if (is_array($payload) && array_key_exists('error_code', $payload)) {
            $meta['error_code'] = $payload['error_code'];
        }

        if ($status >= 400 || (is_array($payload) && (array_key_exists('error', $payload) || array_key_exists('errors', $payload)))) {
            if (is_array($payload) && array_key_exists('allowed_methods', $payload)) {
                $meta['allowed_methods'] = $payload['allowed_methods'];
            }
            if (is_array($payload) && array_key_exists('required_permissions', $payload)) {
                $meta['required_permissions'] = $payload['required_permissions'];
            }

            $message = $message !== ''
                ? $message
                : (is_array($payload) && is_string($payload['error'] ?? null)
                    ? (string)$payload['error']
                    : self::defaultErrorMessage($status));

            $errors = null;
            if (is_array($payload) && array_key_exists('errors', $payload)) {
                $errors = self::normalizeErrors($payload['errors']);
            } elseif (is_array($payload) && array_key_exists('detail', $payload) && $payload['detail'] !== null) {
                $errors = self::normalizeErrors(['detail' => $payload['detail']]);
            }

            return self::envelope('error', $status, $message, null, $errors, $meta);
        }

        $data = is_array($payload) && array_key_exists('data', $payload)
            ? $payload['data']
            : $payload;

        if (is_array($payload) && array_key_exists('allowed_methods', $payload)) {
            $meta['allowed_methods'] = $payload['allowed_methods'];
        }

        return self::envelope(
            'success',
            $status,
            $message !== '' ? $message : self::defaultSuccessMessage($status),
            $data,
            null,
            $meta
        );
    }

    /**
     * @param array<string, mixed>|string|null $errors
     * @return array<string, mixed>|null
     */
    private static function normalizeErrors(array|string|null $errors): ?array
    {
        if ($errors === null) {
            return null;
        }

        if (is_string($errors)) {
            $trimmed = trim($errors);
            return $trimmed === '' ? null : ['detail' => $trimmed];
        }

        return $errors === [] ? [] : $errors;
    }

    /**
     * @param array<string, mixed> $payload
     */
    private static function isEnvelope(array $payload): bool
    {
        $required = ['status', 'code', 'message', 'data', 'errors', 'meta'];
        foreach ($required as $key) {
            if (!array_key_exists($key, $payload)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private static function sanitizeEnvelope(array $payload, int $status): array
    {
        $state = strtolower(trim((string)($payload['status'] ?? 'success')));
        $state = $state === 'error' || $status >= 400 ? 'error' : 'success';
        $message = trim((string)($payload['message'] ?? ''));
        $meta = is_array($payload['meta'] ?? null) ? $payload['meta'] : [];
        $errors = self::normalizeErrors($payload['errors'] ?? null);
        $data = $payload['data'] ?? null;

        if ($state === 'error') {
            $data = null;
            $errors = $errors ?? [];
            if ($message === '') {
                $message = self::defaultErrorMessage($status);
            }
        } else {
            $errors = null;
            if ($message === '') {
                $message = self::defaultSuccessMessage($status);
            }
        }

        return self::envelope($state, $status, $message, $data, $errors, $meta);
    }

    /**
     * @param array<string, mixed>|null $errors
     * @param array<string, mixed> $meta
     * @return array<string, mixed>
     */
    private static function envelope(string $status, int $code, string $message, mixed $data, ?array $errors, array $meta): array
    {
        return [
            'status' => $status,
            'code' => $code,
            'message' => $message,
            'data' => $status === 'success' ? $data : null,
            'errors' => $status === 'error' ? self::jsonObject($errors ?? []) : null,
            'meta' => self::jsonObject($meta),
        ];
    }

    private static function defaultSuccessMessage(int $status): string
    {
        return match ($status) {
            201 => 'Created successfully',
            202 => 'Request accepted',
            default => 'Request completed successfully',
        };
    }

    private static function defaultErrorMessage(int $status): string
    {
        return match ($status) {
            400 => 'Bad request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not found',
            405 => 'Method not allowed',
            422 => 'Validation failed',
            500 => 'Internal server error',
            default => 'Request failed',
        };
    }

    /**
     * @param array<string, mixed> $value
     */
    private static function jsonObject(array $value): array|\stdClass
    {
        return $value === [] ? (object)[] : $value;
    }
}
