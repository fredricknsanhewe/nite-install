<?php
namespace App\Http;

use App\Config\Env;
use App\Support\ApiExplorerCatalog;
use Closure;

final class Route
{
    public string $method;
    public string $pattern;
    public string $rawPath;
    public $handler;
    public array $middlewares = [];
    public string $name = '';

    public function __construct(string $method, string $pattern, string $rawPath, $handler)
    {
        $this->method = $method;
        $this->pattern = $pattern;
        $this->rawPath = $rawPath;
        $this->handler = $handler;
    }

    public function middleware(callable $middleware): self
    {
        $this->middlewares[] = $middleware;
        return $this;
    }

    public function name(string $name): self
    {
        $this->name = $name;
        return $this;
    }
}

final class Router
{
    private string $base = '';
    /** @var array<int, Route> */
    private array $routes = [];

    public function __construct(string $base = '')
    {
        $this->base = rtrim($base, '/');
    }

    public function group(string $prefix, Closure $callback): void
    {
        $previousBase = $this->base;
        $this->base = $this->base . rtrim($prefix, '/');
        $callback($this);
        $this->base = $previousBase;
    }

    public function add(string $method, string $path, $handler): Route
    {
        $rawPath = $this->base . $path;
        $route = new Route($method, $this->compile($rawPath), $rawPath, $handler);
        $this->routes[] = $route;
        return $route;
    }

    public function get(string $path, $handler): Route
    {
        return $this->add('GET', $path, $handler);
    }

    public function head(string $path, $handler): Route
    {
        return $this->add('HEAD', $path, $handler);
    }

    public function post(string $path, $handler): Route
    {
        return $this->add('POST', $path, $handler);
    }

    public function put(string $path, $handler): Route
    {
        return $this->add('PUT', $path, $handler);
    }

    public function patch(string $path, $handler): Route
    {
        return $this->add('PATCH', $path, $handler);
    }

    public function delete(string $path, $handler): Route
    {
        return $this->add('DELETE', $path, $handler);
    }

    public function dispatch(Request $request): Response
    {
        $matchingRoutes = $this->matchingRoutes($request->path);

        if ($request->method === 'OPTIONS') {
            $allowed = $this->allowedMethods($request->path, $matchingRoutes, true);
            $payload = $this->optionsPayload($request, $matchingRoutes, $allowed);
            $response = Response::json($payload, 200);
            if ($allowed !== []) {
                $response->headers['Allow'] = implode(', ', $allowed);
            }
            return $response;
        }

        foreach ($this->effectiveMethodsForRequest($request->method) as $effectiveMethod) {
            foreach ($matchingRoutes as $route) {
                $params = [];
                if ($route->method !== $effectiveMethod || !$this->match($route->pattern, $request->path, $params)) {
                    continue;
                }

                $request->params = $params;
                $request->attributes['route'] = [
                    'method' => $request->method,
                    'path' => $route->rawPath,
                    'name' => $route->name,
                    'allowed_methods' => $this->allowedMethods($request->path, $matchingRoutes, true),
                ];

                $callable = $this->resolve($route->handler);
                $pipeline = array_reduce(
                    array_reverse($route->middlewares),
                    fn ($next, $mw) => fn ($req) => $mw($req, $next),
                    fn ($req) => $callable($req)
                );

                $response = $this->toResponse($pipeline($request));
                return $request->method === 'HEAD' ? $this->headResponse($response) : $response;
            }
        }

        if ($matchingRoutes !== []) {
            $allowed = $this->allowedMethods($request->path, $matchingRoutes, true);
            $request->attributes['route'] = [
                'method' => $request->method,
                'path' => $matchingRoutes[0]->rawPath,
                'name' => $matchingRoutes[0]->name,
                'allowed_methods' => $allowed,
            ];
            $response = Response::json([
                'error' => 'Method not allowed. The endpoint exists, but does not accept this HTTP method.',
                'allowed_methods' => $allowed,
            ], 405);
            if ($allowed !== []) {
                $response->headers['Allow'] = implode(', ', $allowed);
            }
            return $response;
        }

        return Response::json([
            'error' => 'Not found. The requested endpoint does not exist.',
            'error_code' => 'route_not_found',
        ], 404);
    }

    /**
     * @return array<int, Route>
     */
    public function routes(): array
    {
        return $this->routes;
    }

    /**
     * @return array<int, Route>
     */
    public function matchingRoutes(string $path): array
    {
        $matches = [];
        foreach ($this->routes as $route) {
            $params = [];
            if ($this->match($route->pattern, $path, $params)) {
                $matches[] = $route;
            }
        }

        return $matches;
    }

    private function compile(string $path): string
    {
        $regex = preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $path);
        return '#^' . rtrim((string)$regex, '/') . '/?$#';
    }

    /**
     * @param array<string, string> $params
     */
    private function match(string $pattern, string $path, array &$params): bool
    {
        if (!preg_match($pattern, $path, $matches)) {
            return false;
        }

        foreach ($matches as $key => $value) {
            if (!is_int($key)) {
                $params[(string)$key] = (string)$value;
            }
        }

        return true;
    }

    private function resolve($handler): callable
    {
        if (is_array($handler) && count($handler) === 2) {
            [$class, $method] = $handler;
            return [new $class(), $method];
        }

        if (is_callable($handler)) {
            return $handler;
        }

        throw new \RuntimeException('Invalid route handler.');
    }

    /**
     * @return array<int, string>
     */
    private function allowedMethods(string $path, ?array $matchedRoutes = null, bool $includeOptions = false): array
    {
        $methods = [];
        $routes = $matchedRoutes ?? $this->matchingRoutes($path);
        foreach ($routes as $route) {
            $methods[$route->method] = $route->method;
        }
        if (isset($methods['GET'])) {
            $methods['HEAD'] = 'HEAD';
        }
        if (isset($methods['PUT'])) {
            $methods['PATCH'] = 'PATCH';
        }
        if ($includeOptions && $routes !== []) {
            $methods['OPTIONS'] = 'OPTIONS';
        }

        return $this->sortMethods(array_values($methods));
    }

    /**
     * @param array<int, Route> $matchingRoutes
     * @param array<int, string> $allowed
     * @return array<string, mixed>
     */
    private function optionsPayload(Request $request, array $matchingRoutes, array $allowed): array
    {
        $docs = ApiExplorerCatalog::documentRoutes($matchingRoutes);
        if ($docs === []) {
            return [
                'name' => $this->metadataName($request->path, null),
                'description' => 'No metadata is available for this endpoint.',
                'renders' => ['application/json'],
                'parses' => [],
                'allowed_methods' => $allowed,
                'actions' => (object)[],
                'query_actions' => (object)[],
                'path_actions' => (object)[],
                'method_details' => (object)[],
            ];
        }

        $primary = $this->primaryRouteDoc($docs);
        $actions = [];
        $queryActions = [];
        $pathActions = [];
        $methodDetails = [];
        $renders = [];
        $parses = [];

        foreach ($docs as $doc) {
            $method = strtoupper((string)($doc['method'] ?? 'GET'));
            $requestDoc = is_array($doc['request'] ?? null) ? $doc['request'] : [];
            $responseDoc = is_array($doc['response'] ?? null) ? $doc['response'] : [];

            $methodDetails[$method] = [
                'method' => $method,
                'path' => (string)($doc['path'] ?? $request->path),
                'summary' => (string)($doc['summary'] ?? ''),
                'auth_required' => (bool)($doc['auth_required'] ?? false),
                'permissions' => array_values(is_array($doc['permissions'] ?? null) ? $doc['permissions'] : []),
                'request_content_type' => $requestDoc['content_type'] ?? null,
                'response_content_type' => $responseDoc['content_type'] ?? 'application/json; charset=UTF-8',
                'success_status' => (int)($responseDoc['success_status'] ?? 200),
                'return_type' => (string)($responseDoc['return_type'] ?? 'object'),
            ];

            $bodyFields = $this->metadataFieldMap(
                is_array($requestDoc['body'] ?? null) ? $requestDoc['body'] : [],
                $method
            );
            if ($bodyFields !== []) {
                $actions[$method] = $bodyFields;
            }

            $queryFields = $this->metadataFieldMap(
                is_array($requestDoc['query'] ?? null) ? $requestDoc['query'] : [],
                $method
            );
            if ($queryFields !== []) {
                $queryActions[$method] = $queryFields;
            }

            $pathFields = $this->metadataFieldMap(
                is_array($requestDoc['path_params'] ?? null) ? $requestDoc['path_params'] : [],
                $method
            );
            if ($pathFields !== []) {
                $pathActions[$method] = $pathFields;
            }

            $responseType = trim((string)($responseDoc['content_type'] ?? 'application/json; charset=UTF-8'));
            if ($responseType !== '') {
                $renders[strtolower($responseType)] = $responseType;
                if (str_starts_with(strtolower($responseType), 'application/json') && Env::bool('NITE_BROWSABLE_API', Env::bool('NITE_HTML_INTERFACE_ENABLED', true))) {
                    $renders['text/html'] = 'text/html';
                }
            }

            $requestType = trim((string)($requestDoc['content_type'] ?? ''));
            if ($requestType !== '') {
                $parses[strtolower($requestType)] = $requestType;
            }
        }

        if (in_array('HEAD', $allowed, true) && isset($methodDetails['GET'])) {
            $headDetails = $methodDetails['GET'];
            $headDetails['method'] = 'HEAD';
            $headDetails['summary'] = 'Read headers for this endpoint without returning a response body.';
            $headDetails['request_content_type'] = null;
            $methodDetails['HEAD'] = $headDetails;

            if (!isset($queryActions['HEAD']) && isset($queryActions['GET'])) {
                $queryActions['HEAD'] = $queryActions['GET'];
            }
            if (!isset($pathActions['HEAD']) && isset($pathActions['GET'])) {
                $pathActions['HEAD'] = $pathActions['GET'];
            }
        }

        if (in_array('PATCH', $allowed, true) && !isset($methodDetails['PATCH']) && isset($methodDetails['PUT'])) {
            $patchDetails = $methodDetails['PUT'];
            $patchDetails['method'] = 'PATCH';
            $patchDetails['summary'] = 'Partially update this endpoint.';
            $methodDetails['PATCH'] = $patchDetails;

            if (!isset($actions['PATCH']) && isset($actions['PUT'])) {
                $actions['PATCH'] = $actions['PUT'];
            }
            if (!isset($queryActions['PATCH']) && isset($queryActions['PUT'])) {
                $queryActions['PATCH'] = $queryActions['PUT'];
            }
            if (!isset($pathActions['PATCH']) && isset($pathActions['PUT'])) {
                $pathActions['PATCH'] = $pathActions['PUT'];
            }
        }

        if (in_array('OPTIONS', $allowed, true)) {
            $methodDetails['OPTIONS'] = [
                'method' => 'OPTIONS',
                'path' => (string)($primary['path'] ?? $request->path),
                'summary' => 'Inspect available methods and documented request metadata for this endpoint.',
                'auth_required' => false,
                'permissions' => [],
                'request_content_type' => null,
                'response_content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => 'OptionsMetadata',
            ];
        }

        return [
            'name' => $this->metadataName((string)($primary['path'] ?? $request->path), $primary),
            'description' => (string)($primary['summary'] ?? 'Browsable metadata for this endpoint.'),
            'renders' => array_values($renders !== [] ? $renders : ['application/json']),
            'parses' => array_values($parses),
            'allowed_methods' => $allowed,
            'actions' => $actions !== [] ? $actions : (object)[],
            'query_actions' => $queryActions !== [] ? $queryActions : (object)[],
            'path_actions' => $pathActions !== [] ? $pathActions : (object)[],
            'method_details' => $methodDetails !== [] ? $methodDetails : (object)[],
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $docs
     * @return array<string, mixed>|null
     */
    private function primaryRouteDoc(array $docs): ?array
    {
        foreach ($docs as $doc) {
            if (strtoupper((string)($doc['method'] ?? '')) === 'GET') {
                return $doc;
            }
        }

        return $docs[0] ?? null;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, array<string, mixed>>
     */
    private function metadataFieldMap(array $fields, string $method): array
    {
        $output = [];
        foreach ($fields as $field) {
            $name = trim((string)($field['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            $output[$name] = $this->metadataField($field, $method);
        }

        return $output;
    }

    /**
     * @param array<string, mixed> $field
     * @return array<string, mixed>
     */
    private function metadataField(array $field, string $method): array
    {
        $options = array_values(is_array($field['options'] ?? null) ? $field['options'] : []);
        $metadata = [
            'type' => $this->metadataFieldType($field),
            'required' => $this->fieldRequiredForMethod($field, $method),
            'read_only' => (bool)($field['read_only'] ?? false),
            'write_only' => (bool)($field['write_only'] ?? false),
            'label' => $this->humanize((string)($field['name'] ?? 'field')),
            'help_text' => (string)($field['description'] ?? ''),
            'nullable' => (bool)($field['nullable'] ?? true),
        ];

        $format = trim((string)($field['format'] ?? ''));
        if ($format !== '') {
            $metadata['format'] = $format;
        }

        if ($options !== []) {
            $metadata['choices'] = array_map(
                fn (mixed $value): array => [
                    'value' => $value,
                    'display_name' => $this->humanize((string)$value),
                ],
                $options
            );
        }

        if (is_array($field['media_upload'] ?? null)) {
            $metadata['media_upload'] = $field['media_upload'];
        }

        if (is_array($field['relation'] ?? null)) {
            $metadata['relation'] = $field['relation'];
        }

        return $metadata;
    }

    /**
     * @return array<int, string>
     */
    private function effectiveMethodsForRequest(string $method): array
    {
        $resolved = strtoupper(trim($method));
        if ($resolved === 'HEAD') {
            return ['GET'];
        }

        if ($resolved === 'PATCH') {
            return ['PATCH', 'PUT'];
        }

        return [$resolved];
    }

    /**
     * @param array<string, mixed> $field
     */
    private function metadataFieldType(array $field): string
    {
        $type = trim((string)($field['data_type'] ?? 'string'));
        $format = trim((string)($field['format'] ?? ''));

        return $format !== '' ? $type . ':' . $format : $type;
    }

    /**
     * @param array<string, mixed> $field
     */
    private function fieldRequiredForMethod(array $field, string $method): bool
    {
        $resolvedMethod = strtoupper($method);
        if ($resolvedMethod === 'POST') {
            return (bool)($field['required_on_create'] ?? false);
        }

        if (in_array($resolvedMethod, ['PUT', 'PATCH'], true)) {
            return (bool)($field['required_on_update'] ?? false);
        }

        return false;
    }

    /**
     * @param array<string, mixed>|null $doc
     */
    private function metadataName(string $path, ?array $doc): string
    {
        $resourceKey = trim((string)($doc['resource_key'] ?? ''));
        if ($resourceKey !== '') {
            return $this->humanize($resourceKey);
        }

        $name = trim((string)($doc['name'] ?? ''));
        if ($name !== '') {
            return $this->humanize($name);
        }

        $summary = trim((string)($doc['summary'] ?? ''));
        if ($summary !== '') {
            $parts = preg_split('/[.,]/', $summary);
            $first = trim((string)($parts[0] ?? ''));
            if ($first !== '') {
                return $first;
            }
        }

        $segments = array_values(array_filter(
            explode('/', trim($path, '/')),
            static fn (string $segment): bool => $segment !== '' && !str_starts_with($segment, '{')
        ));
        if ($segments === []) {
            return 'API endpoint';
        }

        return $this->humanize((string)end($segments));
    }

    private function humanize(string $value): string
    {
        $normalized = preg_replace('/[_\-.]+/', ' ', trim($value)) ?? $value;
        $normalized = preg_replace('/\s+/', ' ', $normalized) ?? $normalized;
        return ucwords(strtolower(trim($normalized)));
    }

    private function headResponse(Response $response): Response
    {
        $head = new Response('', $response->status, $response->headers);
        $head->format = $response->format;
        $head->payload = $response->payload;
        return $head;
    }

    /**
     * @param array<int, string> $methods
     * @return array<int, string>
     */
    private function sortMethods(array $methods): array
    {
        $order = [
            'GET' => 10,
            'HEAD' => 20,
            'POST' => 30,
            'PUT' => 40,
            'PATCH' => 50,
            'DELETE' => 60,
            'OPTIONS' => 70,
        ];

        usort($methods, static function (string $left, string $right) use ($order): int {
            $leftRank = $order[$left] ?? 999;
            $rightRank = $order[$right] ?? 999;
            return [$leftRank, $left] <=> [$rightRank, $right];
        });

        return $methods;
    }

    private function toResponse(mixed $result): Response
    {
        if ($result instanceof Response) {
            return $result;
        }

        return Response::json($result);
    }
}
