<?php
namespace App\Http\Middleware;

use App\Config\Env;
use App\Http\Request;
use App\Http\Response;
use App\Models\UserModel;
use App\Utils\JWT;

final class AuthMiddleware
{
    public function __invoke(Request $request, callable $next): Response
    {
        $authorization = $request->header('Authorization');
        if ($authorization === null || !str_starts_with($authorization, 'Bearer ')) {
            return Response::json([
                'error' => 'Unauthorized. A bearer token is required.',
                'error_code' => 'auth_required',
            ], 401);
        }

        $token = substr($authorization, 7);
        $payload = JWT::decode($token, (string)Env::get('JWT_SECRET', 'unsafe-default'));
        if (!is_array($payload)) {
            return Response::json([
                'error' => 'Unauthorized. The bearer token is invalid or expired.',
                'error_code' => 'invalid_token',
            ], 401);
        }

        $userId = (string)($payload['sub'] ?? '');
        $user = (new UserModel())->findAuthContextById($userId);
        if ($user === null) {
            return Response::json([
                'error' => 'Unauthorized. The linked account could not be found.',
                'error_code' => 'session_user_missing',
            ], 401);
        }

        if (($user['account_status'] ?? 'inactive') !== 'active') {
            return Response::json([
                'error' => 'Forbidden. This account is not active.',
                'error_code' => 'account_inactive',
            ], 403);
        }

        $request->user = [
            'id' => (string)$user['id'],
            'email' => (string)$user['email'],
            'name' => (string)$user['name'],
            'role' => (string)$user['role'],
        ];

        return $next($request);
    }
}
