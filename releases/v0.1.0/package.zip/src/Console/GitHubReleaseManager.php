<?php
namespace App\Console;

use App\Config\App;
use App\Support\PublicReleaseCatalog;
use RuntimeException;
use ZipArchive;

final class GitHubReleaseManager
{
    private string $rootPath;

    public function __construct(?string $rootPath = null)
    {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
    }

    /**
     * @return array<string, string>
     */
    public function repository(): array
    {
        return [
            'slug' => App::publicRepository(),
            'url' => App::publicRepositoryUrl(),
            'api' => App::publicRepositoryApi(),
            'ref' => App::publicRepositoryRef(),
            'raw' => App::publicRepositoryRawUrl(),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function availableReleases(int $limit = 10): array
    {
        $limit = max(1, min(50, $limit));
        $public = $this->fetchPublicReleases($limit);
        if ($public !== []) {
            return $public;
        }

        $releases = $this->fetchReleaseList($limit);
        if ($releases !== []) {
            return $releases;
        }

        return $this->fetchTagList($limit);
    }

    /**
     * @return array<string, mixed>
     */
    public function latestRelease(): array
    {
        $public = $this->fetchPublicIndex();
        if ($public !== []) {
            $latest = (string)($public['latest'] ?? '');
            if ($latest !== '') {
                return $this->fetchPublicRelease($latest);
            }
        }

        try {
            $release = $this->requestJson($this->repository()['api'] . '/releases/latest');
            if (is_array($release) && trim((string)($release['tag_name'] ?? '')) !== '') {
                return $this->normalizeRelease($release, true);
            }
        } catch (\Throwable) {
            // Fall back to tags when releases are not published yet.
        }

        $tags = $this->fetchTagList(1);
        if ($tags === []) {
            throw new RuntimeException('No GitHub releases or tags were found for ' . $this->repository()['slug'] . '.');
        }

        return $tags[0];
    }

    /**
     * @return array<string, mixed>
     */
    public function releaseForVersion(string $version): array
    {
        $requested = $this->normalizeVersion($version);
        if ($requested === '') {
            throw new RuntimeException('A target version is required.');
        }

        $public = $this->fetchPublicIndex();
        if ($public !== []) {
            foreach (array_values(is_array($public['versions'] ?? null) ? $public['versions'] : []) as $tag) {
                if ($this->normalizeVersion((string)$tag) === $requested) {
                    return $this->fetchPublicRelease((string)$tag);
                }
            }
        }

        foreach ($this->candidateTags($requested) as $tag) {
            try {
                $release = $this->requestJson($this->repository()['api'] . '/releases/tags/' . rawurlencode($tag));
                if (is_array($release) && trim((string)($release['tag_name'] ?? '')) !== '') {
                    return $this->normalizeRelease($release, true);
                }
            } catch (\Throwable) {
                // Fall back to the tag list when the repository uses tags without releases.
            }
        }

        foreach ($this->fetchTagList(100) as $tag) {
            if ((string)($tag['version'] ?? '') === $requested) {
                return $tag;
            }
        }

        throw new RuntimeException('No public GitHub release or tag matched version ' . $requested . '.');
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function syncRelease(?string $version = null, array $options = []): array
    {
        $release = $version === null || trim($version) === '' || strtolower(trim($version)) === 'latest'
            ? $this->latestRelease()
            : $this->releaseForVersion($version);

        $this->assertWorkspaceReady(
            (bool)($options['force'] ?? false),
            (bool)($options['accept_conflicts'] ?? false)
        );

        $tempRoot = $this->rootPath . '/storage/console/tmp/' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(4));
        $archivePath = $tempRoot . '/release.zip';
        $extractPath = $tempRoot . '/extract';
        ConsoleSupport::ensureDirectory($extractPath);

        try {
            $this->downloadArchive((string)$release['archive_url'], $archivePath);
            $this->verifyArchiveChecksum($archivePath, (string)($release['archive_sha256'] ?? ''));
            $releaseRoot = $this->extractArchive($archivePath, $extractPath);
            $releaseFiles = $this->collectReleaseFiles($releaseRoot);
            if ($releaseFiles === []) {
                throw new RuntimeException('The downloaded GitHub archive did not contain any releasable files.');
            }

            $previousFiles = array_values(array_filter(
                array_map('strval', is_array($options['previous_files'] ?? null) ? $options['previous_files'] : []),
                static fn (string $value): bool => trim($value) !== ''
            ));
            $conflicts = $this->detectConflictingFiles($previousFiles, $releaseFiles);
            if (
                $conflicts !== []
                && !(bool)($options['force'] ?? false)
                && !(bool)($options['accept_conflicts'] ?? false)
            ) {
                throw new RuntimeException(
                    'Managed release sync would overwrite local files: ' . implode(', ', array_slice($conflicts, 0, 10))
                    . (count($conflicts) > 10 ? ' ...' : '')
                    . '. Commit/stash them or rerun with --accept-conflicts or --force.'
                );
            }

            $backupDir = $this->boolOption($options, 'backup', true)
                ? $this->rootPath . '/storage/console/backups/' . gmdate('YmdHis') . '_' . (string)$release['tag']
                : null;

            $removed = $this->removeStaleFiles($previousFiles, $releaseFiles, $backupDir);
            $written = $this->writeReleaseFiles($releaseFiles, $backupDir);

            return [
                'release' => $release,
                'repository' => $this->repository(),
                'archive_url' => (string)$release['archive_url'],
                'written' => $written,
                'removed' => $removed,
                'backup_dir' => $backupDir,
                'installed_files' => array_keys($releaseFiles),
            ];
        } finally {
            $this->deleteDirectory($tempRoot);
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchReleaseList(int $limit): array
    {
        try {
            $payload = $this->requestJson($this->repository()['api'] . '/releases?per_page=' . $limit);
        } catch (\Throwable) {
            return [];
        }

        if (!is_array($payload)) {
            return [];
        }

        $releases = [];
        foreach ($payload as $item) {
            if (!is_array($item) || trim((string)($item['tag_name'] ?? '')) === '') {
                continue;
            }
            $releases[] = $this->normalizeRelease($item, true);
        }

        return $releases;
    }

    /**
     * @return array<string, mixed>
     */
    private function fetchPublicIndex(): array
    {
        try {
            $payload = $this->requestJson($this->repository()['raw'] . '/' . PublicReleaseCatalog::LATEST_INDEX);
        } catch (\Throwable) {
            return [];
        }

        if (!is_array($payload)) {
            return [];
        }

        $versions = [];
        foreach (array_values(is_array($payload['versions'] ?? null) ? $payload['versions'] : []) as $tag) {
            $resolved = PublicReleaseCatalog::normalizeTag((string)$tag);
            if ($resolved === '') {
                continue;
            }
            $versions[] = $resolved;
        }

        $versions = PublicReleaseCatalog::sortTags($versions);
        $latest = PublicReleaseCatalog::normalizeTag((string)($payload['latest'] ?? ''));
        if ($latest === '' && $versions !== []) {
            $latest = $versions[count($versions) - 1];
        }

        if ($latest === '' && $versions === []) {
            return [];
        }

        return [
            'latest' => $latest,
            'versions' => $versions,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchPublicReleases(int $limit): array
    {
        $index = $this->fetchPublicIndex();
        if ($index === []) {
            return [];
        }

        $tags = array_reverse(array_values(is_array($index['versions'] ?? null) ? $index['versions'] : []));
        $tags = array_slice($tags, 0, $limit);
        $releases = [];

        foreach ($tags as $tag) {
            $releases[] = $this->fetchPublicRelease((string)$tag);
        }

        return $releases;
    }

    /**
     * @return array<string, mixed>
     */
    private function fetchPublicRelease(string $tag): array
    {
        $resolvedTag = PublicReleaseCatalog::normalizeTag($tag);
        if ($resolvedTag === '') {
            throw new RuntimeException('Invalid public release tag ' . $tag . '.');
        }

        $manifestUrl = $this->repository()['raw'] . '/' . PublicReleaseCatalog::manifestRelativePath($resolvedTag);

        try {
            $payload = $this->requestJson($manifestUrl);
            if (is_array($payload)) {
                return $this->normalizePublicRelease($payload, $resolvedTag, $manifestUrl);
            }
        } catch (\Throwable) {
            // Fall back to a deterministic package URL when the manifest is unavailable.
        }

        return $this->normalizePublicRelease([], $resolvedTag, $manifestUrl);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function normalizePublicRelease(array $payload, string $tag, string $manifestUrl): array
    {
        $resolvedTag = PublicReleaseCatalog::normalizeTag((string)($payload['tag'] ?? $tag));
        $version = $this->normalizeVersion((string)($payload['version'] ?? $resolvedTag));
        if ($resolvedTag === '' || $version === '') {
            throw new RuntimeException('The public release manifest did not contain a valid tag.');
        }

        $package = trim((string)($payload['package'] ?? PublicReleaseCatalog::packageRelativePath($resolvedTag)));
        $archiveUrl = str_starts_with($package, 'http://') || str_starts_with($package, 'https://')
            ? $package
            : $this->repository()['raw'] . '/' . ltrim($package, '/');

        return [
            'version' => $version,
            'tag' => $resolvedTag,
            'name' => trim((string)($payload['name'] ?? $resolvedTag)),
            'archive_url' => $archiveUrl,
            'archive_sha256' => trim((string)($payload['package_sha256'] ?? '')),
            'html_url' => $this->repository()['url'] . '/tree/' . rawurlencode($this->repository()['ref']) . '/' . str_replace('%2F', '/', rawurlencode(PublicReleaseCatalog::releaseDirectory($resolvedTag))),
            'published_at' => trim((string)($payload['published_at'] ?? '')),
            'prerelease' => (bool)($payload['prerelease'] ?? false),
            'source' => 'public-install',
            'manifest_url' => $manifestUrl,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchTagList(int $limit): array
    {
        $payload = $this->requestJson($this->repository()['api'] . '/tags?per_page=' . max(1, min(100, $limit)));
        if (!is_array($payload)) {
            return [];
        }

        $tags = [];
        foreach ($payload as $item) {
            if (!is_array($item)) {
                continue;
            }

            $tagName = trim((string)($item['name'] ?? ''));
            if ($tagName === '') {
                continue;
            }

            $tags[] = [
                'version' => $this->normalizeVersion($tagName),
                'tag' => $tagName,
                'name' => $tagName,
                'archive_url' => $this->archiveUrlForTag($tagName),
                'html_url' => $this->repository()['url'] . '/tree/' . rawurlencode($tagName),
                'published_at' => '',
                'prerelease' => false,
                'source' => 'tag',
            ];
        }

        return $tags;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function normalizeRelease(array $payload, bool $isRelease): array
    {
        $tag = trim((string)($payload['tag_name'] ?? $payload['name'] ?? ''));
        $version = $this->normalizeVersion($tag);
        if ($version === '') {
            throw new RuntimeException('The GitHub release payload did not contain a valid tag name.');
        }

        return [
            'version' => $version,
            'tag' => $tag === '' ? 'v' . $version : $tag,
            'name' => trim((string)($payload['name'] ?? ($tag === '' ? 'v' . $version : $tag))),
            'archive_url' => $this->archiveUrlForTag($tag === '' ? 'v' . $version : $tag),
            'html_url' => trim((string)($payload['html_url'] ?? ($this->repository()['url'] . '/releases/tag/' . rawurlencode($tag === '' ? 'v' . $version : $tag)))),
            'published_at' => trim((string)($payload['published_at'] ?? $payload['created_at'] ?? '')),
            'prerelease' => (bool)($payload['prerelease'] ?? false),
            'source' => $isRelease ? 'release' : 'tag',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function candidateTags(string $version): array
    {
        $normalized = $this->normalizeVersion($version);
        $candidates = [$normalized, 'v' . $normalized];
        return array_values(array_unique(array_filter($candidates, static fn (string $value): bool => trim($value) !== '')));
    }

    private function normalizeVersion(string $value): string
    {
        return ltrim(strtolower(trim($value)), 'v');
    }

    private function archiveUrlForTag(string $tag): string
    {
        return $this->repository()['url'] . '/archive/refs/tags/' . rawurlencode($tag) . '.zip';
    }

    /**
     * @return array<string, mixed>
     */
    private function requestJson(string $url): array
    {
        $body = $this->request($url, ['Accept: application/vnd.github+json']);
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            throw new RuntimeException('GitHub returned invalid JSON for ' . $url . '.');
        }

        return $decoded;
    }

    private function request(string $url, array $extraHeaders = []): string
    {
        if (function_exists('curl_init')) {
            $headers = array_merge([
                'User-Agent: ' . App::NAME . ' Console/' . App::VERSION,
                'X-GitHub-Api-Version: 2022-11-28',
            ], $extraHeaders);

            $token = trim((string)getenv('GITHUB_TOKEN'));
            if ($token !== '') {
                $headers[] = 'Authorization: Bearer ' . $token;
            }

            $handle = curl_init($url);
            if ($handle === false) {
                throw new RuntimeException('Failed to initialize the GitHub HTTP client.');
            }

            curl_setopt_array($handle, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 120,
                CURLOPT_HTTPHEADER => $headers,
            ]);

            $body = curl_exec($handle);
            $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
            $error = curl_error($handle);
            curl_close($handle);

            if (!is_string($body) || $body === '') {
                throw new RuntimeException($error !== '' ? $error : 'GitHub returned an empty response.');
            }

            if ($status >= 400) {
                throw new RuntimeException(
                    'GitHub request failed with HTTP ' . $status . '. Confirm that ' . $this->repository()['url'] . ' is public or override NITE_PUBLIC_REPOSITORY*.'
                );
            }

            return $body;
        }

        $headers = array_merge([
            'User-Agent: ' . App::NAME . ' Console/' . App::VERSION,
            'X-GitHub-Api-Version: 2022-11-28',
        ], $extraHeaders);
        $token = trim((string)getenv('GITHUB_TOKEN'));
        if ($token !== '') {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => implode("\r\n", $headers),
                'ignore_errors' => true,
                'timeout' => 120,
            ],
        ]);
        $body = @file_get_contents($url, false, $context);
        if (!is_string($body) || $body === '') {
            throw new RuntimeException('GitHub request failed for ' . $url . '.');
        }

        return $body;
    }

    private function downloadArchive(string $url, string $destination): void
    {
        ConsoleSupport::ensureDirectory(dirname($destination));

        if (function_exists('curl_init')) {
            $headers = [
                'User-Agent: ' . App::NAME . ' Console/' . App::VERSION,
                'Accept: application/octet-stream',
            ];
            $token = trim((string)getenv('GITHUB_TOKEN'));
            if ($token !== '') {
                $headers[] = 'Authorization: Bearer ' . $token;
            }

            $handle = curl_init($url);
            if ($handle === false) {
                throw new RuntimeException('Failed to initialize the GitHub archive download.');
            }

            $stream = fopen($destination, 'wb');
            if ($stream === false) {
                curl_close($handle);
                throw new RuntimeException('Failed to create the archive destination file.');
            }

            curl_setopt_array($handle, [
                CURLOPT_FILE => $stream,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 300,
                CURLOPT_HTTPHEADER => $headers,
            ]);

            $ok = curl_exec($handle);
            $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
            $error = curl_error($handle);
            fclose($stream);
            curl_close($handle);

            if ($ok === false || $status >= 400 || !is_file($destination) || filesize($destination) === 0) {
                throw new RuntimeException(
                    $error !== '' ? $error : ('GitHub archive download failed with HTTP ' . $status . '. Confirm that ' . $this->repository()['url'] . ' is public or override NITE_PUBLIC_REPOSITORY*.')
                );
            }
            return;
        }

        $body = $this->request($url, ['Accept: application/octet-stream']);
        if (file_put_contents($destination, $body) === false) {
            throw new RuntimeException('Failed to save the downloaded GitHub archive.');
        }
    }

    private function extractArchive(string $archivePath, string $extractPath): string
    {
        $zip = new ZipArchive();
        if ($zip->open($archivePath) !== true) {
            throw new RuntimeException('Failed to open the downloaded GitHub archive.');
        }

        if (!$zip->extractTo($extractPath)) {
            $zip->close();
            throw new RuntimeException('Failed to extract the downloaded GitHub archive.');
        }
        $zip->close();

        $entries = array_values(array_filter(
            glob($extractPath . '/*') ?: [],
            static fn (string $path): bool => is_dir($path)
        ));

        if ($entries === []) {
            return $extractPath;
        }

        if (count($entries) === 1) {
            return $entries[0];
        }

        return $extractPath;
    }

    /**
     * @return array<string, string>
     */
    private function collectReleaseFiles(string $releaseRoot): array
    {
        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($releaseRoot, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $item) {
            if (!$item->isFile()) {
                continue;
            }

            $absolute = $item->getPathname();
            $relative = str_replace('\\', '/', substr($absolute, strlen($releaseRoot) + 1));
            if ($relative === '' || $this->protectedPath($relative)) {
                continue;
            }

            $files[$relative] = $absolute;
        }

        ksort($files);
        return $files;
    }

    /**
     * @param array<int, string> $previousFiles
     * @param array<string, string> $releaseFiles
     * @return array<int, string>
     */
    private function removeStaleFiles(array $previousFiles, array $releaseFiles, ?string $backupDir): array
    {
        $releaseLookup = array_fill_keys(array_keys($releaseFiles), true);
        $removed = [];

        foreach ($previousFiles as $relativePath) {
            $normalized = str_replace('\\', '/', trim($relativePath));
            if ($normalized === '' || isset($releaseLookup[$normalized]) || $this->protectedPath($normalized)) {
                continue;
            }

            $absolute = $this->rootPath . '/' . $normalized;
            if (!is_file($absolute)) {
                continue;
            }

            if ($backupDir !== null) {
                $this->backupFile($absolute, $normalized, $backupDir);
            }

            if (!@unlink($absolute)) {
                throw new RuntimeException('Failed to remove stale file during release sync: ' . $normalized);
            }
            $removed[] = $absolute;
        }

        return $removed;
    }

    /**
     * @param array<string, string> $releaseFiles
     * @return array<int, string>
     */
    private function writeReleaseFiles(array $releaseFiles, ?string $backupDir): array
    {
        $written = [];

        foreach ($releaseFiles as $relativePath => $sourcePath) {
            $destination = $this->rootPath . '/' . $relativePath;
            ConsoleSupport::ensureDirectory(dirname($destination));

            $existing = is_file($destination) ? file_get_contents($destination) : null;
            $incoming = file_get_contents($sourcePath);
            if (!is_string($incoming)) {
                throw new RuntimeException('Failed to read release file ' . $relativePath . '.');
            }

            if ($existing === $incoming) {
                continue;
            }

            if ($backupDir !== null && is_file($destination)) {
                $this->backupFile($destination, $relativePath, $backupDir);
            }

            if (file_put_contents($destination, $incoming) === false) {
                throw new RuntimeException('Failed to write release file ' . $relativePath . '.');
            }
            $written[] = $destination;
        }

        return $written;
    }

    /**
     * @param array<int, string> $previousFiles
     * @param array<string, string> $releaseFiles
     * @return array<int, string>
     */
    private function detectConflictingFiles(array $previousFiles, array $releaseFiles): array
    {
        $managed = array_fill_keys(array_map('strval', $previousFiles), true);
        $conflicts = [];

        foreach ($releaseFiles as $relativePath => $sourcePath) {
            if ($this->protectedPath($relativePath)) {
                continue;
            }

            $destination = $this->rootPath . '/' . $relativePath;
            if (!is_file($destination)) {
                continue;
            }

            $incoming = file_get_contents($sourcePath);
            $existing = file_get_contents($destination);
            if (!is_string($incoming) || !is_string($existing) || $incoming === $existing) {
                continue;
            }

            if (isset($managed[$relativePath])) {
                continue;
            }

            $conflicts[] = $relativePath;
        }

        sort($conflicts);
        return $conflicts;
    }

    private function backupFile(string $absolutePath, string $relativePath, string $backupDir): void
    {
        $backupPath = $backupDir . '/' . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
        ConsoleSupport::ensureDirectory(dirname($backupPath));
        if (!@copy($absolutePath, $backupPath)) {
            throw new RuntimeException('Failed to create a backup copy of ' . $relativePath . '.');
        }
    }

    private function assertWorkspaceReady(bool $force, bool $acceptConflicts): void
    {
        if ($force || $acceptConflicts || !is_dir($this->rootPath . '/.git')) {
            return;
        }

        $output = [];
        $code = 0;
        @exec('git status --porcelain --untracked-files=no', $output, $code);
        if ($code === 0 && trim(implode("\n", $output)) !== '') {
            throw new RuntimeException('The working tree has local changes. Commit/stash them or rerun with --accept-conflicts or --force.');
        }
    }

    private function protectedPath(string $relativePath): bool
    {
        $normalized = trim(str_replace('\\', '/', $relativePath), '/');
        if ($normalized === '') {
            return true;
        }

        if (in_array($normalized, ['.env', '.env.docker'], true)) {
            return true;
        }

        if (preg_match('#^projects/[^/]+/\.env(\.docker)?$#', $normalized) === 1) {
            return true;
        }

        foreach (['.git/', 'storage/', 'public/uploads/', 'routes/generated/'] as $prefix) {
            if (str_starts_with($normalized . '/', $prefix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }

    private function deleteDirectory(string $path): void
    {
        if (!is_dir($path)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
                continue;
            }
            @unlink($item->getPathname());
        }

        @rmdir($path);
    }

    private function verifyArchiveChecksum(string $archivePath, string $expectedHash): void
    {
        $normalized = strtolower(trim($expectedHash));
        if ($normalized === '') {
            return;
        }

        $actual = hash_file('sha256', $archivePath);
        if (!is_string($actual) || strtolower($actual) !== $normalized) {
            throw new RuntimeException('The downloaded release package failed checksum verification.');
        }
    }
}
