<?php
namespace App\Console;

use App\Config\Database;
use RuntimeException;

final class SampleRemovalManager
{
    /** @var array<int, string> */
    private const SAMPLE_PERMISSION_CODES = [
        'admin.sample_records.view',
        'admin.sample_records.manage',
    ];

    /** @var array<int, string> */
    private const SAMPLE_FILES = [
        'src/Controllers/SampleRecordsController.php',
        'src/Services/SampleRecordService.php',
        'src/Models/SampleRecordModel.php',
        'docs/sample-crud.md',
    ];

    public function __construct(
        private readonly string $rootPath,
        private readonly ConsoleIO $io
    ) {
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function remove(array $options = []): array
    {
        $backupEnabled = $this->boolOption($options, 'backup', true);
        $backupDir = null;
        if ($backupEnabled && !$this->boolOption($options, 'db-only', false)) {
            $backupDir = $this->rootPath . '/storage/backups/remove-samples-' . gmdate('Ymd_His');
        }

        $result = [
            'backup_dir' => $backupDir,
            'database' => $this->boolOption($options, 'files-only', false)
                ? ['status' => 'skipped', 'detail' => 'Database cleanup skipped by --files-only.']
                : $this->removeDatabaseArtifacts(),
            'files' => $this->boolOption($options, 'db-only', false)
                ? ['modified' => [], 'deleted' => [], 'missing' => [], 'warnings' => []]
                : $this->removeFileArtifacts($backupDir, $this->boolOption($options, 'keep-docs', false)),
        ];

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    private function removeDatabaseArtifacts(): array
    {
        try {
            $connection = Database::connection();
        } catch (\Throwable $e) {
            return [
                'status' => 'warning',
                'detail' => 'Database cleanup skipped because the database connection failed: ' . $e->getMessage(),
            ];
        }

        $driver = Database::driver();
        $permissionPlaceholders = implode(', ', array_fill(0, count(self::SAMPLE_PERMISSION_CODES), '?'));

        try {
            $connection->beginTransaction();

            $deleteLogs = $connection->prepare(
                'DELETE FROM data_change_logs WHERE table_name = ? OR change_scope = ?'
            );
            $deleteLogs->execute(['sample_records', 'sample_records']);
            $deletedLogRows = $deleteLogs->rowCount();

            $deletePermissions = $connection->prepare(
                'DELETE FROM permissions WHERE code IN (' . $permissionPlaceholders . ')'
            );
            $deletePermissions->execute(self::SAMPLE_PERMISSION_CODES);
            $deletedPermissionRows = $deletePermissions->rowCount();

            if ($driver === 'pgsql') {
                $connection->exec('DROP TABLE IF EXISTS sample_records CASCADE');
            } else {
                $connection->exec('DROP TABLE IF EXISTS sample_records');
            }

            $connection->commit();

            return [
                'status' => 'completed',
                'detail' => 'Removed sample_records database artifacts.',
                'deleted_log_rows' => $deletedLogRows,
                'deleted_permission_rows' => $deletedPermissionRows,
                'dropped_table' => 'sample_records',
            ];
        } catch (\Throwable $e) {
            if ($connection->inTransaction()) {
                $connection->rollBack();
            }

            return [
                'status' => 'warning',
                'detail' => 'Database cleanup partially failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function removeFileArtifacts(?string $backupDir, bool $keepDocs): array
    {
        $modified = [];
        $deleted = [];
        $missing = [];
        $warnings = [];

        $this->transformFile('public/index.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("use App\\Controllers\\SampleRecordsController;\r\n", '', $content);
            $content = str_replace("use App\\Controllers\\SampleRecordsController;\n", '', $content);
            $content = $this->removePattern(
                $content,
                '/\h*\$r->get\(\'\/sample-records\', \[SampleRecordsController::class, \'list\'\]\);\R\h*\$r->get\(\'\/sample-records\/\{slug\}\', \[SampleRecordsController::class, \'show\'\]\);\R/s',
                'public sample record routes'
            );
            $content = $this->removePattern(
                $content,
                '/\h*\$r->get\(\'\/admin\/sample-records\/history\', \[SampleRecordsController::class, \'history\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.view\'\)\);\R\h*\$r->post\(\'\/admin\/sample-records\/history\/\{logId\}\/restore\', \[SampleRecordsController::class, \'restore\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.manage\'\)\);\R\h*\$r->get\(\'\/admin\/sample-records\', \[SampleRecordsController::class, \'adminList\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.view\'\)\);\R\h*\$r->post\(\'\/admin\/sample-records\', \[SampleRecordsController::class, \'create\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.manage\'\)\);\R\h*\$r->get\(\'\/admin\/sample-records\/\{id\}\/history\', \[SampleRecordsController::class, \'recordHistory\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.view\'\)\);\R\h*\$r->get\(\'\/admin\/sample-records\/\{id\}\', \[SampleRecordsController::class, \'adminShow\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.view\'\)\);\R\h*\$r->put\(\'\/admin\/sample-records\/\{id\}\', \[SampleRecordsController::class, \'update\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.manage\'\)\);\R\h*\$r->patch\(\'\/admin\/sample-records\/\{id\}\', \[SampleRecordsController::class, \'update\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.manage\'\)\);\R\h*\$r->delete\(\'\/admin\/sample-records\/\{id\}\', \[SampleRecordsController::class, \'delete\'\]\)->middleware\(\$auth\)->middleware\(\$perm\(\'admin\.sample_records\.manage\'\)\);\R/s',
                'admin sample record routes'
            );
            return $content;
        }, $warnings);

        $this->transformFile('src/Controllers/FrameworkController.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("use App\\Models\\SampleRecordModel;\r\n", '', $content);
            $content = str_replace("use App\\Models\\SampleRecordModel;\n", '', $content);
            $content = str_replace("                'sample_records' => '/api/v1/sample-records',\r\n", '', $content);
            $content = str_replace("                'sample_records' => '/api/v1/sample-records',\n", '', $content);
            $content = str_replace("            'sample_records' => null,\r\n", '', $content);
            $content = str_replace("            'sample_records' => null,\n", '', $content);
            $content = str_replace("            \$sampleRecords = new SampleRecordModel();\r\n", '', $content);
            $content = str_replace("            \$sampleRecords = new SampleRecordModel();\n", '', $content);
            $content = str_replace("                'sample_records' => \$sampleRecords->count(),\r\n", '', $content);
            $content = str_replace("                'sample_records' => \$sampleRecords->count(),\n", '', $content);
            $content = str_replace("                    'sample_records' => '/api/v1/sample-records',\r\n", '', $content);
            $content = str_replace("                    'sample_records' => '/api/v1/sample-records',\n", '', $content);
            $content = str_replace("                    'sample_record_history' => '/api/v1/admin/sample-records/history',\r\n", '', $content);
            $content = str_replace("                    'sample_record_history' => '/api/v1/admin/sample-records/history',\n", '', $content);
            return $content;
        }, $warnings);

        $this->transformFile('src/Controllers/SearchController.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("use App\\Models\\SampleRecordModel;\r\n", '', $content);
            $content = str_replace("use App\\Models\\SampleRecordModel;\n", '', $content);
            $content = str_replace("        \$sampleRecords = (new SampleRecordModel())->list(['q' => \$q], true);\r\n", '', $content);
            $content = str_replace("        \$sampleRecords = (new SampleRecordModel())->list(['q' => \$q], true);\n", '', $content);
            $content = str_replace("                'sample_records' => \$sampleRecords,\r\n", '', $content);
            $content = str_replace("                'sample_records' => \$sampleRecords,\n", '', $content);
            return $content;
        }, $warnings);

        $this->transformFile('src/Support/ApiExplorerCatalog.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("            self::sampleRecordsResource(),\r\n", '', $content);
            $content = str_replace("            self::sampleRecordsResource(),\n", '', $content);
            $content = str_replace(
                "                'return_type' => '{ pages: Page[], news: NewsPost[], resources: Resource[], courses: Course[], sample_records: SampleRecord[], examples: ExampleEntity[] }',",
                "                'return_type' => '{ pages: Page[], news: NewsPost[], resources: Resource[], courses: Course[], examples: ExampleEntity[] }',",
                $content
            );
            $content = str_replace(
                "            self::fieldDoc('record_id', 'string:uuid', 'Filter by sample record identifier.'),",
                "            self::fieldDoc('record_id', 'string:uuid', 'Filter by record identifier.'),",
                $content
            );
            $content = str_replace(
                "        ], '/api/v1/admin/sample-records/history', true);",
                "        ], '/api/v1/admin/media/history', true);",
                $content
            );
            $content = $this->removePattern(
                $content,
                '/\R\s*\/\*\*\R\s*\* @return array<string, mixed>\R\s*\*\/\R\s*private static function sampleRecordsResource\(\): array\s*\{.*?\R\s*\}\R(?=\R\s*\/\*\*\R\s*\* @return array<string, mixed>\R\s*\*\/\R\s*private static function dataChangeLogsResource\(\): array)/s',
                'sampleRecordsResource catalog block'
            );
            $content = $this->removePattern(
                $content,
                '/\h*self::endpointDoc\(\'GET\', \'\/api\/v1\/admin\/sample-records\/history\', .*?\R\h*self::endpointDoc\(\'POST\', \'\/api\/v1\/admin\/sample-records\/history\/\{logId\}\/restore\', .*?\R\h*\]\),\R/s',
                'sample data change log endpoints'
            );
            return $content;
        }, $warnings);

        $this->transformFile('src/Config/PermissionCatalog.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = preg_replace('/^\h*self::def\(\'admin\.sample_records\.(?:view|manage)\'.*\R/m', '', $content) ?? $content;
            return $content;
        }, $warnings);

        $this->transformFile('scripts/seed.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("use App\\Models\\SampleRecordModel;\r\n", '', $content);
            $content = str_replace("use App\\Models\\SampleRecordModel;\n", '', $content);
            $content = str_replace("use App\\Services\\SampleRecordService;\r\n", '', $content);
            $content = str_replace("use App\\Services\\SampleRecordService;\n", '', $content);
            $content = str_replace("    \$sampleRecordModel = new SampleRecordModel();\r\n", '', $content);
            $content = str_replace("    \$sampleRecordModel = new SampleRecordModel();\n", '', $content);
            $content = str_replace("    \$sampleRecords = new SampleRecordService();\r\n", '', $content);
            $content = str_replace("    \$sampleRecords = new SampleRecordService();\n", '', $content);
            $content = $this->removePattern(
                $content,
                '/\R\$seedSampleRecords = \[\R.*?\R\];\R\R\s*foreach \(\$seedSampleRecords as \$sampleRecord\) \{\R.*?\R\s*\}\R(?=\R\$exampleSeeds = \[)/s',
                'seed sample records block'
            );
            $content = str_replace("        'sample_records',\r\n", '', $content);
            $content = str_replace("        'sample_records',\n", '', $content);
            return $content;
        }, $warnings);

        $this->transformFile('scripts/smoke-test.php', $backupDir, $modified, $missing, function (string $content): string {
            $content = str_replace("    \$targets[] = '/api/v1/sample-records';\r\n", '', $content);
            $content = str_replace("    \$targets[] = '/api/v1/sample-records';\n", '', $content);
            return $content;
        }, $warnings);

        $this->transformFile('database/schema.sql', $backupDir, $modified, $missing, function (string $content): string {
            return $this->removePattern(
                $content,
                '/\RCREATE TABLE IF NOT EXISTS sample_records \(.*?CREATE INDEX IF NOT EXISTS idx_sample_records_type_status ON sample_records \(record_type, status, updated_at DESC\);\R(?=\RCREATE TABLE IF NOT EXISTS data_change_logs)/s',
                'sample_records block in database/schema.sql'
            );
        }, $warnings);

        $this->transformFile('database/schema.mysql.sql', $backupDir, $modified, $missing, function (string $content): string {
            return $this->removePattern(
                $content,
                '/\RCREATE TABLE IF NOT EXISTS sample_records \(.*?\) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\R(?=\RCREATE TABLE IF NOT EXISTS data_change_logs)/s',
                'sample_records block in database/schema.mysql.sql'
            );
        }, $warnings);

        if (!$keepDocs) {
            $this->transformFile('README.md', $backupDir, $modified, $missing, function (string $content): string {
                $content = str_replace("- a complete sample CRUD module with controller, service, model, archive history, and restore flow\r\n", '', $content);
                $content = str_replace("- a complete sample CRUD module with controller, service, model, archive history, and restore flow\n", '', $content);
                foreach ([
                    "- `http://127.0.0.1:8185/api/v1/sample-records`\r\n",
                    "- `http://127.0.0.1:8185/api/v1/sample-records`\n",
                    "- `GET /api/v1/sample-records`\r\n",
                    "- `GET /api/v1/sample-records`\n",
                    "- `GET /api/v1/admin/sample-records/history`\r\n",
                    "- `GET /api/v1/admin/sample-records/history`\n",
                    "- [Sample CRUD Module](docs/sample-crud.md)\r\n",
                    "- [Sample CRUD Module](docs/sample-crud.md)\n",
                ] as $snippet) {
                    $content = str_replace($snippet, '', $content);
                }
                return $content;
            }, $warnings);

            $this->transformFile('docs/quick-start.md', $backupDir, $modified, $missing, function (string $content): string {
                $content = str_replace("- `/api/v1/sample-records`\r\n", '', $content);
                $content = str_replace("- `/api/v1/sample-records`\n", '', $content);
                return $content;
            }, $warnings);

            $this->transformFile('docs/examples.md', $backupDir, $modified, $missing, function (string $content): string {
                $content = str_replace(
                    "The sample CRUD module is available at `/api/v1/sample-records` and the admin archive history routes under `/api/v1/admin/sample-records/*`.\r\n",
                    '',
                    $content
                );
                $content = str_replace(
                    "The sample CRUD module is available at `/api/v1/sample-records` and the admin archive history routes under `/api/v1/admin/sample-records/*`.\n",
                    '',
                    $content
                );
                return $content;
            }, $warnings);

            $this->transformFile('docs/extending.md', $backupDir, $modified, $missing, function (string $content): string {
                $target = <<<'TEXT'
Use the sample CRUD module as the reference implementation:

- `src/Controllers/SampleRecordsController.php`
- `src/Services/SampleRecordService.php`
- `src/Models/SampleRecordModel.php`
- `src/Services/DataChangeLogService.php`
- `src/Models/DataChangeLogModel.php`

See [Sample CRUD Module](sample-crud.md) for the full archive-delete and restore flow.
TEXT;

                $replacement = <<<'TEXT'
Use generated resources and the audit-log services as the reference implementation:

- run `php nite create resource Report`
- inspect the generated controller, service, model, migration, and route manifest
- use `src/Services/DataChangeLogService.php` and `src/Models/DataChangeLogModel.php` when you need restore-friendly archive flows
TEXT;

                return str_replace($target, $replacement, $content);
            }, $warnings);
        }

        foreach (self::SAMPLE_FILES as $relativePath) {
            if ($keepDocs && str_starts_with($relativePath, 'docs/')) {
                continue;
            }
            $this->deleteFile($relativePath, $backupDir, $deleted, $missing);
        }

        return [
            'modified' => $modified,
            'deleted' => $deleted,
            'missing' => $missing,
            'warnings' => $warnings,
        ];
    }

    /**
     * @param array<int, string> $modified
     * @param array<int, string> $missing
     * @param array<int, string> $warnings
     */
    private function transformFile(
        string $relativePath,
        ?string $backupDir,
        array &$modified,
        array &$missing,
        callable $transform,
        array &$warnings
    ): void {
        $path = $this->rootPath . '/' . $relativePath;
        if (!is_file($path)) {
            $missing[] = $relativePath;
            return;
        }

        $original = file_get_contents($path);
        if (!is_string($original)) {
            throw new RuntimeException('Failed to read file for sample removal: ' . $relativePath);
        }

        $updated = $transform($original);
        if ($updated === $original) {
            $warnings[] = 'No sample changes applied to ' . $relativePath . '.';
            return;
        }

        $this->backupPath($relativePath, $backupDir);
        if (file_put_contents($path, $updated) === false) {
            throw new RuntimeException('Failed to update file for sample removal: ' . $relativePath);
        }

        $modified[] = $relativePath;
    }

    /**
     * @param array<int, string> $deleted
     * @param array<int, string> $missing
     */
    private function deleteFile(string $relativePath, ?string $backupDir, array &$deleted, array &$missing): void
    {
        $path = $this->rootPath . '/' . $relativePath;
        if (!is_file($path)) {
            $missing[] = $relativePath;
            return;
        }

        $this->backupPath($relativePath, $backupDir);
        if (!@unlink($path)) {
            throw new RuntimeException('Failed to delete sample file: ' . $relativePath);
        }

        $deleted[] = $relativePath;
    }

    private function backupPath(string $relativePath, ?string $backupDir): void
    {
        if ($backupDir === null) {
            return;
        }

        $sourcePath = $this->rootPath . '/' . $relativePath;
        if (!is_file($sourcePath)) {
            return;
        }

        $backupPath = $backupDir . '/' . str_replace('\\', '/', $relativePath);
        ConsoleSupport::ensureDirectory(dirname($backupPath));
        if (!@copy($sourcePath, $backupPath)) {
            throw new RuntimeException('Failed to back up file before sample removal: ' . $relativePath);
        }
    }

    private function removePattern(string $content, string $pattern, string $label): string
    {
        $updated = preg_replace($pattern, "\n", $content, 1, $count);
        if (!is_string($updated)) {
            throw new RuntimeException('Invalid sample removal pattern for ' . $label . '.');
        }

        if ($count === 0) {
            return $content;
        }

        return $updated;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }
}
