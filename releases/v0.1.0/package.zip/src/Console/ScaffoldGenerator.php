<?php
namespace App\Console;

use App\Config\App;
use App\Support\GeneratedResourceRegistry;
use RuntimeException;

final class ScaffoldGenerator
{
    private string $rootPath;

    public function __construct(?string $rootPath = null)
    {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function create(string $type, string $name, array $options = []): array
    {
        return match ($this->normalizeType($type)) {
            'model' => $this->createModel($name, $options),
            'controller' => $this->createController($name, $options),
            'service' => $this->createService($name, $options),
            'migration' => $this->createMigration($name, $options),
            'resource' => $this->createResource($name, $options),
            default => throw new RuntimeException('Unsupported scaffold type: ' . $type),
        };
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function remove(string $type, string $name, array $options = []): array
    {
        return match ($this->normalizeType($type)) {
            'model' => $this->removePaths([$this->modelPath($this->classBase($name))], $options),
            'controller' => $this->removePaths([$this->controllerPath($this->classBase($name))], $options),
            'service' => $this->removePaths([$this->servicePath($this->classBase($name))], $options),
            'migration' => $this->removeMigrationFiles($name, $options),
            'resource' => $this->removeResource($name, $options),
            default => throw new RuntimeException('Unsupported scaffold type: ' . $type),
        };
    }

    /**
     * @return array<int, string>
     */
    public function conflictPaths(string $type, string $name, ?string $table = null): array
    {
        $normalized = $this->normalizeType($type);
        if ($normalized === 'migration') {
            return $this->migrationPaths($normalized, $name, $table);
        }

        if ($normalized === 'resource') {
            $meta = $this->resourceMeta($name, $table);
            $paths = [
                $this->modelPath($meta['base']),
                $this->servicePath($meta['base']),
                $this->controllerPath($meta['base']),
                $this->manifestPath($meta['route_segment']),
                $this->routeSnippetPath($meta['route_segment']),
            ];
            $paths = array_merge($paths, glob($this->migrationDirectory() . '/*create_' . $meta['table'] . '_table.php') ?: []);
            return array_values(array_filter($paths, 'is_file'));
        }

        $base = $this->classBase($name);
        $path = match ($normalized) {
            'model' => $this->modelPath($base),
            'controller' => $this->controllerPath($base),
            'service' => $this->servicePath($base),
            default => '',
        };

        return $path !== '' && is_file($path) ? [$path] : [];
    }

    /**
     * @return array<int, string>
     */
    public function migrationPaths(string $type, string $name, ?string $table = null): array
    {
        $normalized = $this->normalizeType($type);
        if ($normalized === 'migration') {
            $snake = ConsoleSupport::snake($name);
            return glob($this->migrationDirectory() . '/*' . $snake . '.php') ?: [];
        }

        if ($normalized === 'resource') {
            $meta = $this->resourceMeta($name, $table);
            return glob($this->migrationDirectory() . '/*create_' . $meta['table'] . '_table.php') ?: [];
        }

        return [];
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createModel(string $name, array $options): array
    {
        $meta = $this->resourceMeta($name, $this->stringOption($options, 'table'), $options);
        return $this->writeFiles([
            $this->modelPath($meta['base']) => $this->modelTemplate($meta),
        ], $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createController(string $name, array $options): array
    {
        $meta = $this->resourceMeta($name, $this->stringOption($options, 'table'), $options);
        return $this->writeFiles([
            $this->controllerPath($meta['base']) => $this->controllerTemplate($meta),
        ], $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createService(string $name, array $options): array
    {
        $meta = $this->resourceMeta($name, $this->stringOption($options, 'table'), $options);
        return $this->writeFiles([
            $this->servicePath($meta['base']) => $this->serviceTemplate($meta),
        ], $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createMigration(string $name, array $options): array
    {
        $snake = ConsoleSupport::snake($name);
        if ($snake === '') {
            throw new RuntimeException('Migration name is required.');
        }

        $version = $this->stringOption($options, 'version') ?: App::VERSION;
        $path = $this->migrationDirectory() . '/' . ConsoleSupport::timestamp() . '_' . $snake . '.php';

        return $this->writeFiles([
            $path => $this->genericMigrationTemplate($snake, $version),
        ], $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createResource(string $name, array $options): array
    {
        $meta = $this->resourceMeta($name, $this->stringOption($options, 'table'), $options);
        $version = $this->stringOption($options, 'version') ?: App::VERSION;
        $migrationPath = $this->migrationDirectory() . '/' . ConsoleSupport::timestamp() . '_create_' . $meta['table'] . '_table.php';

        return $this->writeFiles([
            $this->modelPath($meta['base']) => $this->modelTemplate($meta),
            $this->servicePath($meta['base']) => $this->serviceTemplate($meta),
            $this->controllerPath($meta['base']) => $this->controllerTemplate($meta),
            $migrationPath => $this->resourceMigrationTemplate($meta, $version),
            $this->manifestPath($meta['route_segment']) => $this->resourceManifestTemplate($meta, $version),
            $this->routeSnippetPath($meta['route_segment']) => $this->routeSnippetTemplate($meta),
        ], $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function removeResource(string $name, array $options): array
    {
        $meta = $this->resourceMeta($name, $this->stringOption($options, 'table'));
        $paths = [
            $this->modelPath($meta['base']),
            $this->servicePath($meta['base']),
            $this->controllerPath($meta['base']),
            $this->manifestPath($meta['route_segment']),
            $this->routeSnippetPath($meta['route_segment']),
        ];
        if (!$this->boolOption($options, 'keep-migrations', false)) {
            $paths = array_merge($paths, $this->migrationPaths('resource', $name, $this->stringOption($options, 'table')));
        }
        return $this->removePaths($paths, $options);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function removeMigrationFiles(string $name, array $options): array
    {
        $snake = ConsoleSupport::snake($name);
        $paths = glob($this->migrationDirectory() . '/*' . $snake . '.php') ?: [];
        return $this->removePaths($paths, $options);
    }

    /**
     * @param array<int, string> $paths
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function removePaths(array $paths, array $options): array
    {
        $backup = $this->boolOption($options, 'backup', false);
        $removed = [];
        $backedUp = [];
        $missing = [];

        foreach (array_values(array_unique($paths)) as $path) {
            if (!is_file($path)) {
                $missing[] = $path;
                continue;
            }

            if ($backup) {
                $backupPath = $path . '.bak.' . gmdate('YmdHis');
                if (!@rename($path, $backupPath)) {
                    throw new RuntimeException('Failed to back up file before removal: ' . $path);
                }
                $backedUp[] = $backupPath;
                $removed[] = $path;
                continue;
            }

            if (!@unlink($path)) {
                throw new RuntimeException('Failed to remove file: ' . $path);
            }
            $removed[] = $path;
        }

        return [
            'written' => [],
            'removed' => $removed,
            'backups' => $backedUp,
            'missing' => $missing,
        ];
    }

    /**
     * @param array<string, string> $files
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function writeFiles(array $files, array $options): array
    {
        $force = $this->boolOption($options, 'force', false);
        $backup = $this->boolOption($options, 'backup', false);
        $conflicts = [];

        foreach ($files as $path => $_content) {
            if (is_file($path)) {
                $conflicts[] = $path;
            }
        }

        if ($conflicts !== [] && !$force && !$backup) {
            throw new RuntimeException(
                'Conflicting files already exist: ' . implode(', ', $conflicts) . '. Use --force to overwrite or --backup to preserve them.'
            );
        }

        $written = [];
        $backups = [];
        foreach ($files as $path => $content) {
            ConsoleSupport::ensureDirectory(dirname($path));
            if (is_file($path) && $backup) {
                $backupPath = $path . '.bak.' . gmdate('YmdHis');
                if (!@rename($path, $backupPath)) {
                    throw new RuntimeException('Failed to back up file before overwrite: ' . $path);
                }
                $backups[] = $backupPath;
            }

            if (file_put_contents($path, $content) === false) {
                throw new RuntimeException('Failed to write file: ' . $path);
            }
            $written[] = $path;
        }

        return [
            'written' => $written,
            'removed' => [],
            'backups' => $backups,
            'missing' => [],
        ];
    }

    /**
     * @return array<string, string>
     */
    private function resourceMeta(string $name, ?string $table = null, array $options = []): array
    {
        $base = $this->classBase($name);
        if ($base === '') {
            throw new RuntimeException('A scaffold name is required.');
        }

        $singularSnake = ConsoleSupport::snake($base);
        $tableName = $table !== null && trim($table) !== ''
            ? ConsoleSupport::snake($table)
            : ConsoleSupport::pluralize($singularSnake);
        $pluralStudly = ConsoleSupport::studly(ConsoleSupport::singularize($tableName));
        $pluralStudly = ConsoleSupport::pluralize($pluralStudly);
        $routeSegment = ConsoleSupport::kebab($tableName);
        $variable = lcfirst($base);
        $variablePlural = lcfirst($pluralStudly);
        $label = $this->stringOption($options, 'label');
        if ($label === null) {
            $label = trim(preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', $base) ?? $base);
        }
        $group = $this->stringOption($options, 'group') ?? 'generated';
        $itemType = $this->stringOption($options, 'item-type') ?? $base;
        $summary = $this->stringOption($options, 'summary') ?? ('Generated starter CRUD resource for ' . strtolower(ConsoleSupport::pluralize($label)) . '.');

        return [
            'base' => $base,
            'resource_key' => $tableName,
            'table' => $tableName,
            'route_segment' => $routeSegment,
            'variable' => $variable,
            'variable_plural' => $variablePlural,
            'label' => $label,
            'label_plural' => ConsoleSupport::pluralize($label),
            'label_lower' => strtolower($label),
            'label_plural_lower' => strtolower(ConsoleSupport::pluralize($label)),
            'group' => ConsoleSupport::snake($group) !== '' ? ConsoleSupport::snake($group) : 'generated',
            'item_type' => $itemType,
            'summary' => str_replace("'", "\\'", $summary),
            'view_permission' => 'admin.' . $tableName . '.view',
            'manage_permission' => 'admin.' . $tableName . '.manage',
        ];
    }

    private function classBase(string $name): string
    {
        $studly = ConsoleSupport::studly($name);
        foreach (['Controller', 'Service', 'Model'] as $suffix) {
            if (str_ends_with($studly, $suffix)) {
                return substr($studly, 0, -strlen($suffix));
            }
        }

        return ConsoleSupport::singularize($studly);
    }

    private function normalizeType(string $type): string
    {
        $normalized = strtolower(trim($type));
        return match ($normalized) {
            'module', 'all', 'item' => 'resource',
            default => $normalized,
        };
    }

    private function modelPath(string $base): string
    {
        return $this->rootPath . '/src/Models/' . $base . 'Model.php';
    }

    private function servicePath(string $base): string
    {
        return $this->rootPath . '/src/Services/' . $base . 'Service.php';
    }

    private function controllerPath(string $base): string
    {
        return $this->rootPath . '/src/Controllers/' . $base . 'Controller.php';
    }

    private function routeSnippetPath(string $routeSegment): string
    {
        return $this->rootPath . '/examples/generated/' . $routeSegment . '.routes.php';
    }

    private function manifestPath(string $routeSegment): string
    {
        return GeneratedResourceRegistry::manifestDirectory($this->rootPath) . '/' . $routeSegment . '.php';
    }

    private function migrationDirectory(): string
    {
        return $this->rootPath . '/database/migrations';
    }

    private function stringOption(array $options, string $key): ?string
    {
        if (!array_key_exists($key, $options)) {
            return null;
        }

        $value = trim((string)$options[$key]);
        return $value === '' ? null : $value;
    }

    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }

    /**
     * @param array<string, string> $meta
     */
    private function modelTemplate(array $meta): string
    {
        $template = <<<'PHP'
<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class {{Base}}Model extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "status = 'published'";
        } else {
            $status = strtolower(trim((string)($filters['status'] ?? '')));
            if ($status !== '') {
                $where[] = 'status = :status';
                $params[':status'] = $this->normalizeStatus($status);
            }
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['slug', 'title', 'summary']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM {{table}}';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY updated_at DESC, created_at DESC';

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(100, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM {{table}} WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM {{table}} WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';

        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();

        $this->query(
            'INSERT INTO {{table}} (id, slug, title, summary, status, data_json) VALUES (:id, :slug, :title, :summary, :status, ' . $this->jsonParam(':data_json') . ')',
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        if ($payload === []) {
            return $this->findById($id);
        }

        $assignments = ['updated_at = NOW()'];
        $params = [':id' => $id];
        foreach (['slug', 'title', 'summary', 'status'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }

        if (array_key_exists('data_json', $payload)) {
            $assignments[] = 'data_json = ' . $this->jsonParam(':data_json');
            $params[':data_json'] = $payload['data_json'];
        }

        $this->query('UPDATE {{table}} SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }

        $statement = $this->query('DELETE FROM {{table}} WHERE id = :id', [':id' => $id]);
        return $statement->rowCount() > 0;
    }

    public function count(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM {{table}}');
        return (int)($row['total'] ?? 0);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        if (array_key_exists('status', $data)) {
            $payload['status'] = $this->normalizeStatus($data['status']);
        } elseif ($create) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('data_json', $data)) {
            $payload['data_json'] = json_encode(is_array($data['data_json']) ? $data['data_json'] : [], JSON_UNESCAPED_SLASHES);
        } elseif (array_key_exists('data', $data)) {
            $payload['data_json'] = json_encode(is_array($data['data']) ? $data['data'] : [], JSON_UNESCAPED_SLASHES);
        } elseif ($create) {
            $payload['data_json'] = json_encode([], JSON_UNESCAPED_SLASHES);
        }

        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '')) {
            throw new RuntimeException('{{Base}} slug and title are required.');
        }

        return $payload;
    }

    private function normalizeStatus(mixed $value): string
    {
        $status = strtolower(trim((string)$value));
        if (!in_array($status, ['draft', 'published', 'archived'], true)) {
            return 'draft';
        }

        return $status;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        $row['data'] = $this->decodeJson($row['data_json'] ?? []);
        unset($row['data_json']);
        return $row;
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => $meta['base'],
            '{{table}}' => $meta['table'],
        ]);
    }

    /**
     * @param array<string, string> $meta
     */
    private function serviceTemplate(array $meta): string
    {
        $template = <<<'PHP'
<?php
namespace App\Services;

use App\Models\{{Base}}Model;

final class {{Base}}Service
{
    private {{Base}}Model ${{variable_plural}};

    public function __construct()
    {
        $this->{{variable_plural}} = new {{Base}}Model();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->{{variable_plural}}->list($filters, $admin);
    }

    public function showPublic(string $slug): ?array
    {
        return $this->{{variable_plural}}->findBySlug($slug, false);
    }

    public function showAdmin(string $id): ?array
    {
        return $this->{{variable_plural}}->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->{{variable_plural}}->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->{{variable_plural}}->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->{{variable_plural}}->delete($id);
    }

    public function count(): int
    {
        return $this->{{variable_plural}}->count();
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => $meta['base'],
            '{{variable_plural}}' => $meta['variable_plural'],
        ]);
    }

    /**
     * @param array<string, string> $meta
     */
    private function controllerTemplate(array $meta): string
    {
        $template = <<<'PHP'
<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\{{Base}}Service;
use RuntimeException;

final class {{Base}}Controller
{
    private {{Base}}Service ${{variable_plural}};

    public function __construct()
    {
        $this->{{variable_plural}} = new {{Base}}Service();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->{{variable_plural}}->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->{{variable_plural}}->showPublic((string)($request->params['slug'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{Label}} not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->{{variable_plural}}->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->{{variable_plural}}->showAdmin((string)($request->params['id'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{Label}} not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            return Response::json(['data' => $this->{{variable_plural}}->create($request->body)], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create {{label_lower}}.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->{{variable_plural}}->update((string)($request->params['id'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{Label}} not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update {{label_lower}}.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->{{variable_plural}}->delete((string)($request->params['id'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => '{{Label}} not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete {{label_lower}}.'], 500);
        }
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => $meta['base'],
            '{{variable_plural}}' => $meta['variable_plural'],
            '{{Label}}' => $meta['label'],
            '{{label_lower}}' => strtolower($meta['label']),
        ]);
    }

    /**
     * @param array<string, string> $meta
     */
    private function resourceMigrationTemplate(array $meta, string $version): string
    {
        $template = <<<'PHP'
<?php
return [
    'name' => 'create_{{table}}_table',
    'version' => '{{version}}',
    'up' => [
        'pgsql' => [
            <<<'SQL'
CREATE TABLE IF NOT EXISTS {{table}} (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    data_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)
SQL,
            "CREATE INDEX IF NOT EXISTS idx_{{table}}_status_updated ON {{table}} (status, updated_at DESC)",
        ],
        'mysql' => [
            <<<'SQL'
CREATE TABLE IF NOT EXISTS {{table}} (
    id CHAR(36) PRIMARY KEY,
    slug VARCHAR(140) NOT NULL,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    data_json JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_{{table}}_slug (slug),
    KEY idx_{{table}}_status_updated (status, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        ],
    ],
    'down' => [
        'pgsql' => [
            'DROP TABLE IF EXISTS {{table}} CASCADE',
        ],
        'mysql' => [
            'DROP TABLE IF EXISTS {{table}}',
        ],
    ],
];
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{table}}' => $meta['table'],
            '{{version}}' => $version,
        ]);
    }

    private function genericMigrationTemplate(string $name, string $version): string
    {
        $template = <<<'PHP'
<?php
return [
    'name' => '{{name}}',
    'version' => '{{version}}',
    'up' => [
        'pgsql' => [
            // "ALTER TABLE example ADD COLUMN sample VARCHAR(120) NULL",
        ],
        'mysql' => [
            // "ALTER TABLE example ADD COLUMN sample VARCHAR(120) NULL",
        ],
    ],
    'down' => [
        'pgsql' => [
            // "ALTER TABLE example DROP COLUMN IF EXISTS sample",
        ],
        'mysql' => [
            // "ALTER TABLE example DROP COLUMN sample",
        ],
    ],
];
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{name}}' => $name,
            '{{version}}' => $version,
        ]);
    }

    /**
     * @param array<string, string> $meta
     */
    private function resourceManifestTemplate(array $meta, string $version): string
    {
        $template = <<<'PHP'
<?php
return [
    'key' => '{{resource_key}}',
    'label' => '{{label_plural}}',
    'group' => '{{group}}',
    'item_type' => '{{item_type}}',
    'table' => '{{table}}',
    'summary' => '{{summary}}',
    'controller' => App\Controllers\{{Base}}Controller::class,
    'route_segment' => '{{route_segment}}',
    'scaffold_version' => '{{version}}',
    'default_data_path' => '/api/v1/{{route_segment}}',
    'default_data_auth_required' => false,
    'fields' => [
        [
            'name' => 'id',
            'data_type' => 'string',
            'format' => 'uuid',
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => true,
            'write_only' => false,
            'options' => [],
            'description' => '{{label}} identifier.',
            'database_column' => 'id',
        ],
        [
            'name' => 'slug',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => true,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Stable public slug.',
            'database_column' => 'slug',
        ],
        [
            'name' => 'title',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => true,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Display title.',
            'database_column' => 'title',
        ],
        [
            'name' => 'summary',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Short summary text.',
            'database_column' => 'summary',
        ],
        [
            'name' => 'status',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => ['draft', 'published', 'archived'],
            'description' => 'Publication status.',
            'database_column' => 'status',
        ],
        [
            'name' => 'data',
            'data_type' => 'object',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Flexible JSON payload.',
            'database_column' => 'data_json',
        ],
        [
            'name' => 'created_at',
            'data_type' => 'string',
            'format' => 'date-time',
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => true,
            'write_only' => false,
            'options' => [],
            'description' => 'Creation timestamp.',
            'database_column' => 'created_at',
        ],
        [
            'name' => 'updated_at',
            'data_type' => 'string',
            'format' => 'date-time',
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => true,
            'write_only' => false,
            'options' => [],
            'description' => 'Last update timestamp.',
            'database_column' => 'updated_at',
        ],
    ],
    'create_fields' => [
        [
            'name' => 'slug',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => true,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Stable public slug.',
            'database_column' => 'slug',
        ],
        [
            'name' => 'title',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => true,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Display title.',
            'database_column' => 'title',
        ],
        [
            'name' => 'summary',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Short summary text.',
            'database_column' => 'summary',
        ],
        [
            'name' => 'status',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => ['draft', 'published', 'archived'],
            'description' => 'Publication status.',
            'database_column' => 'status',
        ],
        [
            'name' => 'data',
            'data_type' => 'object',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Flexible JSON payload.',
            'database_column' => 'data_json',
        ],
    ],
    'update_fields' => [
        [
            'name' => 'slug',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Stable public slug.',
            'database_column' => 'slug',
        ],
        [
            'name' => 'title',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Display title.',
            'database_column' => 'title',
        ],
        [
            'name' => 'summary',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Short summary text.',
            'database_column' => 'summary',
        ],
        [
            'name' => 'status',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => ['draft', 'published', 'archived'],
            'description' => 'Publication status.',
            'database_column' => 'status',
        ],
        [
            'name' => 'data',
            'data_type' => 'object',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Flexible JSON payload.',
            'database_column' => 'data_json',
        ],
    ],
    'query_options' => [
        [
            'name' => 'q',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Search slug, title, and summary.',
        ],
        [
            'name' => 'status',
            'data_type' => 'string',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => ['draft', 'published', 'archived'],
            'description' => 'Filter by status on admin reads.',
        ],
        [
            'name' => 'limit',
            'data_type' => 'integer',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Limit the result set to 1-100 rows.',
        ],
    ],
    'permissions_catalog' => [
        [
            'code' => '{{view_permission}}',
            'title' => 'View {{label_plural}}',
            'description' => 'Read generated {{label_plural_lower}} in the admin console.',
            'section_code' => 'generated_resources',
            'section_title' => 'Generated Resources',
            'module_code' => '{{resource_key}}',
            'module_title' => '{{label_plural}}',
            'action_code' => 'view',
            'action_title' => 'View',
            'sort_order' => 1000,
            'default_roles' => ['editor', 'support', 'admin'],
        ],
        [
            'code' => '{{manage_permission}}',
            'title' => 'Manage {{label_plural}}',
            'description' => 'Create, update, and delete generated {{label_plural_lower}}.',
            'section_code' => 'generated_resources',
            'section_title' => 'Generated Resources',
            'module_code' => '{{resource_key}}',
            'module_title' => '{{label_plural}}',
            'action_code' => 'manage',
            'action_title' => 'Manage',
            'sort_order' => 1010,
            'default_roles' => ['editor', 'admin'],
        ],
    ],
    'routes' => [
        [
            'method' => 'GET',
            'path' => '/api/v1/{{route_segment}}',
            'summary' => 'List published {{label_plural_lower}}.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'list',
            'auth_required' => false,
            'permissions' => [],
            'request' => [
                'content_type' => null,
                'path_params' => [],
                'query' => [
                    [
                        'name' => 'q',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Search slug, title, and summary.',
                    ],
                    [
                        'name' => 'limit',
                        'data_type' => 'integer',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Limit the result set to 1-100 rows.',
                    ],
                ],
                'body' => [],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}[]',
                'envelope' => '{ data: {{Base}}[] }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'GET',
            'path' => '/api/v1/{{route_segment}}/{slug}',
            'summary' => 'Read one published {{label_lower}} by slug.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'show',
            'auth_required' => false,
            'permissions' => [],
            'request' => [
                'content_type' => null,
                'path_params' => [
                    [
                        'name' => 'slug',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Public slug.',
                    ],
                ],
                'query' => [],
                'body' => [],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}',
                'envelope' => '{ data: {{Base}} }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'GET',
            'path' => '/api/v1/admin/{{route_segment}}',
            'summary' => 'List {{label_plural_lower}} for admins.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'adminList',
            'auth_required' => true,
            'permissions' => ['{{view_permission}}'],
            'request' => [
                'content_type' => null,
                'path_params' => [],
                'query' => [
                    [
                        'name' => 'q',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Search slug, title, and summary.',
                    ],
                    [
                        'name' => 'status',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => ['draft', 'published', 'archived'],
                        'description' => 'Filter by status.',
                    ],
                    [
                        'name' => 'limit',
                        'data_type' => 'integer',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Limit the result set to 1-100 rows.',
                    ],
                ],
                'body' => [],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}[]',
                'envelope' => '{ data: {{Base}}[] }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'POST',
            'path' => '/api/v1/admin/{{route_segment}}',
            'summary' => 'Create a {{label_lower}}.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'create',
            'auth_required' => true,
            'permissions' => ['{{manage_permission}}'],
            'request' => [
                'content_type' => 'application/json',
                'path_params' => [],
                'query' => [],
                'body' => [
                    [
                        'name' => 'slug',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Stable public slug.',
                        'database_column' => 'slug',
                    ],
                    [
                        'name' => 'title',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Display title.',
                        'database_column' => 'title',
                    ],
                    [
                        'name' => 'summary',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Short summary text.',
                        'database_column' => 'summary',
                    ],
                    [
                        'name' => 'status',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => ['draft', 'published', 'archived'],
                        'description' => 'Publication status.',
                        'database_column' => 'status',
                    ],
                    [
                        'name' => 'data',
                        'data_type' => 'object',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Flexible JSON payload.',
                        'database_column' => 'data_json',
                    ],
                ],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 201,
                'return_type' => '{{Base}}',
                'envelope' => '{ data: {{Base}} }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'GET',
            'path' => '/api/v1/admin/{{route_segment}}/{id}',
            'summary' => 'Read one {{label_lower}} by id.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'adminShow',
            'auth_required' => true,
            'permissions' => ['{{view_permission}}'],
            'request' => [
                'content_type' => null,
                'path_params' => [
                    [
                        'name' => 'id',
                        'data_type' => 'string',
                        'format' => 'uuid',
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => '{{label}} identifier.',
                    ],
                ],
                'query' => [],
                'body' => [],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}',
                'envelope' => '{ data: {{Base}} }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'PUT',
            'path' => '/api/v1/admin/{{route_segment}}/{id}',
            'summary' => 'Update a {{label_lower}}.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'update',
            'auth_required' => true,
            'permissions' => ['{{manage_permission}}'],
            'request' => [
                'content_type' => 'application/json',
                'path_params' => [
                    [
                        'name' => 'id',
                        'data_type' => 'string',
                        'format' => 'uuid',
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => '{{label}} identifier.',
                    ],
                ],
                'query' => [],
                'body' => [
                    [
                        'name' => 'slug',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Stable public slug.',
                        'database_column' => 'slug',
                    ],
                    [
                        'name' => 'title',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Display title.',
                        'database_column' => 'title',
                    ],
                    [
                        'name' => 'summary',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Short summary text.',
                        'database_column' => 'summary',
                    ],
                    [
                        'name' => 'status',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => ['draft', 'published', 'archived'],
                        'description' => 'Publication status.',
                        'database_column' => 'status',
                    ],
                    [
                        'name' => 'data',
                        'data_type' => 'object',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Flexible JSON payload.',
                        'database_column' => 'data_json',
                    ],
                ],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}',
                'envelope' => '{ data: {{Base}} }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'PATCH',
            'path' => '/api/v1/admin/{{route_segment}}/{id}',
            'summary' => 'Partially update a {{label_lower}}.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'update',
            'auth_required' => true,
            'permissions' => ['{{manage_permission}}'],
            'request' => [
                'content_type' => 'application/json',
                'path_params' => [
                    [
                        'name' => 'id',
                        'data_type' => 'string',
                        'format' => 'uuid',
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => '{{label}} identifier.',
                    ],
                ],
                'query' => [],
                'body' => [
                    [
                        'name' => 'slug',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Stable public slug.',
                        'database_column' => 'slug',
                    ],
                    [
                        'name' => 'title',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Display title.',
                        'database_column' => 'title',
                    ],
                    [
                        'name' => 'summary',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => true,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Short summary text.',
                        'database_column' => 'summary',
                    ],
                    [
                        'name' => 'status',
                        'data_type' => 'string',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => ['draft', 'published', 'archived'],
                        'description' => 'Publication status.',
                        'database_column' => 'status',
                    ],
                    [
                        'name' => 'data',
                        'data_type' => 'object',
                        'format' => null,
                        'required_on_create' => false,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => 'Flexible JSON payload.',
                        'database_column' => 'data_json',
                    ],
                ],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{{Base}}',
                'envelope' => '{ data: {{Base}} }',
                'error_type' => '{ error: string }',
            ],
        ],
        [
            'method' => 'DELETE',
            'path' => '/api/v1/admin/{{route_segment}}/{id}',
            'summary' => 'Delete a {{label_lower}}.',
            'resource_key' => '{{resource_key}}',
            'controller' => App\Controllers\{{Base}}Controller::class,
            'action' => 'delete',
            'auth_required' => true,
            'permissions' => ['{{manage_permission}}'],
            'request' => [
                'content_type' => null,
                'path_params' => [
                    [
                        'name' => 'id',
                        'data_type' => 'string',
                        'format' => 'uuid',
                        'required_on_create' => true,
                        'required_on_update' => false,
                        'nullable' => false,
                        'read_only' => false,
                        'write_only' => false,
                        'options' => [],
                        'description' => '{{label}} identifier.',
                    ],
                ],
                'query' => [],
                'body' => [],
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => 200,
                'return_type' => '{ deleted: boolean }',
                'envelope' => '{ data: { deleted: boolean } }',
                'error_type' => '{ error: string }',
            ],
        ],
    ],
];
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => $meta['base'],
            '{{resource_key}}' => $meta['resource_key'],
            '{{label}}' => $meta['label'],
            '{{label_lower}}' => $meta['label_lower'],
            '{{label_plural}}' => $meta['label_plural'],
            '{{label_plural_lower}}' => $meta['label_plural_lower'],
            '{{group}}' => $meta['group'],
            '{{item_type}}' => $meta['item_type'],
            '{{summary}}' => $meta['summary'],
            '{{table}}' => $meta['table'],
            '{{route_segment}}' => $meta['route_segment'],
            '{{version}}' => $version,
            '{{view_permission}}' => $meta['view_permission'],
            '{{manage_permission}}' => $meta['manage_permission'],
        ]);
    }

    /**
     * @param array<string, string> $meta
     */
    private function routeSnippetTemplate(array $meta): string
    {
        $template = <<<'PHP'
<?php
use App\Controllers\{{Base}}Controller;

// Auto-registered from routes/generated/{{route_segment}}.php.
// Public routes.
$r->get('/{{route_segment}}', [{{Base}}Controller::class, 'list']);
$r->get('/{{route_segment}}/{slug}', [{{Base}}Controller::class, 'show']);

// Admin routes.
// View permission: {{view_permission}}
// Manage permission: {{manage_permission}}
$r->get('/admin/{{route_segment}}', [{{Base}}Controller::class, 'adminList'])->middleware($auth)->middleware($perm('{{view_permission}}'));
$r->post('/admin/{{route_segment}}', [{{Base}}Controller::class, 'create'])->middleware($auth)->middleware($perm('{{manage_permission}}'));
$r->get('/admin/{{route_segment}}/{id}', [{{Base}}Controller::class, 'adminShow'])->middleware($auth)->middleware($perm('{{view_permission}}'));
$r->put('/admin/{{route_segment}}/{id}', [{{Base}}Controller::class, 'update'])->middleware($auth)->middleware($perm('{{manage_permission}}'));
$r->patch('/admin/{{route_segment}}/{id}', [{{Base}}Controller::class, 'update'])->middleware($auth)->middleware($perm('{{manage_permission}}'));
$r->delete('/admin/{{route_segment}}/{id}', [{{Base}}Controller::class, 'delete'])->middleware($auth)->middleware($perm('{{manage_permission}}'));
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => $meta['base'],
            '{{route_segment}}' => $meta['route_segment'],
            '{{view_permission}}' => $meta['view_permission'],
            '{{manage_permission}}' => $meta['manage_permission'],
        ]);
    }
}
