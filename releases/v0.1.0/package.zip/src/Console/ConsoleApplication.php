<?php
namespace App\Console;

use App\Config\App;
use App\Config\Env;
use App\Services\MailService;
use App\Support\StarterAppCatalog;
use App\Support\StarterSampleCatalog;
use App\Support\ProjectRegistry;
use RuntimeException;

final class ConsoleApplication
{
    private string $rootPath;
    private ConsoleIO $io;
    private MigrationManager $migrations;
    private ScaffoldGenerator $scaffolds;
    private VersionManager $versions;
    private GitHubReleaseManager $releases;
    private FrameworkInspector $framework;
    private ProjectRegistry $projects;
    private AppBootstrapper $bootstrapper;
    private ResourceDefinitionManager $resourceDefinitions;
    /** @var array<string, mixed>|null */
    private ?array $activeProject = null;

    public function __construct(
        ?string $rootPath = null,
        ?ConsoleIO $io = null,
        ?MigrationManager $migrations = null,
        ?ScaffoldGenerator $scaffolds = null,
        ?VersionManager $versions = null,
        ?GitHubReleaseManager $releases = null,
        ?FrameworkInspector $framework = null,
        ?ProjectRegistry $projects = null,
        ?AppBootstrapper $bootstrapper = null,
        ?ResourceDefinitionManager $resourceDefinitions = null
    ) {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
        $this->io = $io ?? new ConsoleIO();
        $this->migrations = $migrations ?? new MigrationManager($this->rootPath);
        $this->scaffolds = $scaffolds ?? new ScaffoldGenerator($this->rootPath);
        $this->versions = $versions ?? new VersionManager($this->rootPath);
        $this->releases = $releases ?? new GitHubReleaseManager($this->rootPath);
        $this->framework = $framework ?? new FrameworkInspector($this->rootPath, $this->migrations, $this->versions, $this->releases);
        $this->projects = $projects ?? new ProjectRegistry($this->rootPath);
        $this->bootstrapper = $bootstrapper ?? new AppBootstrapper($this->rootPath, $this->io, $this->projects, $this->scaffolds, $this->migrations);
        $this->resourceDefinitions = $resourceDefinitions ?? new ResourceDefinitionManager($this->rootPath, $this->scaffolds, $this->migrations);
    }

    /**
     * @param array<int, string> $argv
     */
    public function run(array $argv): int
    {
        $options = [];
        try {
            [$command, $tokens] = $this->resolveCommand($argv);
            ['args' => $args, 'options' => $options] = $this->parseTokens($tokens);
            $this->bootstrapProjectContext($command, $options);

            return match ($command) {
                'help', 'list' => $this->renderHelp(),
                'create:model' => $this->create('model', $args, $options),
                'create:controller' => $this->create('controller', $args, $options),
                'create:service' => $this->create('service', $args, $options),
                'create:migration' => $this->create('migration', $args, $options),
                'create:resource' => $this->create('resource', $args, $options),
                'schema:apply' => $this->schemaApply($args, $options),
                'schema:explain' => $this->schemaExplain($args, $options),
                'remove:model' => $this->remove('model', $args, $options),
                'remove:controller' => $this->remove('controller', $args, $options),
                'remove:service' => $this->remove('service', $args, $options),
                'remove:migration' => $this->remove('migration', $args, $options),
                'remove:resource' => $this->remove('resource', $args, $options),
                'db:migrate' => $this->dbMigrate(),
                'db:seed' => $this->dbSeed($options),
                'db:rollback' => $this->dbRollback($options),
                'db:status' => $this->dbStatus(),
                'db:refresh' => $this->dbRefresh($options),
                'db:wipe' => $this->dbWipe($options),
                'route:list' => $this->routeList($options),
                'resource:list' => $this->resourceList($options),
                'module:list' => $this->moduleList($options),
                'permission:list' => $this->permissionList($options),
                'starter:list' => $this->starterList($options),
                'starter:show' => $this->starterShow($args, $options),
                'mail:test' => $this->mailTest($args, $options),
                'mail:queue:list' => $this->mailQueueList($options),
                'mail:queue:work' => $this->mailQueueWork($options),
                'mail:queue:retry' => $this->mailQueueRetry($options),
                'queue:stats' => $this->mailQueueStats($options),
                'app:about' => $this->appAbout($options),
                'app:doctor' => $this->appDoctor($options),
                'app:install' => $this->appInstall($args, $options),
                'app:bootstrap' => $this->appBootstrap($args, $options),
                'app:remove-samples' => $this->appRemoveSamples($options),
                'app:serve' => $this->appServe($options),
                'app:uninstall' => $this->appUninstall($options),
                'app:update' => $this->appUpdate($args, $options),
                'app:version' => $this->appVersion(),
                'app:releases' => $this->appReleases($options),
                'app:upgrade' => $this->appUpgrade($args, $options),
                'app:downgrade' => $this->appDowngrade($args, $options),
                'app:compatibility:accept' => $this->appCompatibilityAccept($args),
                'app:conflicts:check' => $this->conflictsCheck($args, $options),
                'project:create' => $this->projectCreate($args, $options),
                'project:list' => $this->projectList($options),
                'eval' => $this->evaluate($args),
                default => throw new RuntimeException('Unknown command: ' . $command),
            };
        } catch (\Throwable $e) {
            if ($this->wantsJson($options)) {
                $this->renderJson([
                    'status' => 'error',
                    'message' => $e->getMessage(),
                    'exception' => get_class($e),
                ]);
                return 1;
            }

            $this->io->error($e->getMessage());
            return 1;
        }
    }

    /**
     * @param array<int, string> $argv
     * @return array{0: string, 1: array<int, string>}
     */
    private function resolveCommand(array $argv): array
    {
        $command = strtolower(trim((string)($argv[1] ?? 'help')));
        $tokens = array_slice($argv, 2);

        if (in_array($command, ['create', 'remove'], true)) {
            $noun = strtolower(trim((string)($tokens[0] ?? '')));
            $command .= ':' . $noun;
            $tokens = array_slice($tokens, 1);
        }

        if (in_array($command, ['route', 'routes', 'resource', 'resources', 'module', 'modules', 'permission', 'permissions', 'project', 'projects', 'starter', 'starters'], true)) {
            $noun = strtolower(trim((string)($tokens[0] ?? '')));
            if ($noun !== '') {
                $command .= ':' . $noun;
                $tokens = array_slice($tokens, 1);
            }
        }

        $aliases = [
            'make:model' => 'create:model',
            'make:controller' => 'create:controller',
            'make:service' => 'create:service',
            'make:migration' => 'create:migration',
            'make:resource' => 'create:resource',
            'dsl:apply' => 'schema:apply',
            'dsl:explain' => 'schema:explain',
            'resource:apply' => 'schema:apply',
            'resource:explain' => 'schema:explain',
            'make:module' => 'create:resource',
            'create:module' => 'create:resource',
            'create:all' => 'create:resource',
            'remove:module' => 'remove:resource',
            'remove:all' => 'remove:resource',
            'migrate' => 'db:migrate',
            'seed' => 'db:seed',
            'rollback' => 'db:rollback',
            'refresh' => 'db:refresh',
            'wipe' => 'db:wipe',
            'about' => 'app:about',
            'doctor' => 'app:doctor',
            'mail:work' => 'mail:queue:work',
            'mail:retry' => 'mail:queue:retry',
            'queue:list' => 'mail:queue:list',
            'queue:work' => 'mail:queue:work',
            'queue:retry' => 'mail:queue:retry',
            'queue:failed' => 'mail:queue:list',
            'queue:status' => 'queue:stats',
            'status' => 'db:status',
            'install' => 'app:install',
            'bootstrap' => 'app:bootstrap',
            'init' => 'app:bootstrap',
            'remove:samples' => 'app:remove-samples',
            'samples:remove' => 'app:remove-samples',
            'serve' => 'app:serve',
            'uninstall' => 'app:uninstall',
            'update' => 'app:update',
            'version' => 'app:version',
            'releases' => 'app:releases',
            'upgrade' => 'app:upgrade',
            'downgrade' => 'app:downgrade',
            'compatibility:accept' => 'app:compatibility:accept',
            'conflicts:check' => 'app:conflicts:check',
            'routes:list' => 'route:list',
            'resources:list' => 'resource:list',
            'modules:list' => 'module:list',
            'permissions:list' => 'permission:list',
            'projects:list' => 'project:list',
            'starters:list' => 'starter:list',
            'starter:explain' => 'starter:show',
            'starter:bootstrap' => 'app:bootstrap',
        ];

        return [$aliases[$command] ?? $command, $tokens];
    }

    /**
     * @param array<int, string> $tokens
     * @return array{args: array<int, string>, options: array<string, mixed>}
     */
    private function parseTokens(array $tokens): array
    {
        $args = [];
        $options = [];

        foreach ($tokens as $token) {
            if (!str_starts_with($token, '--')) {
                $args[] = $token;
                continue;
            }

            $normalized = substr($token, 2);
            if ($normalized === '') {
                continue;
            }

            if (str_starts_with($normalized, 'no-')) {
                $options[substr($normalized, 3)] = false;
                continue;
            }

            if (str_contains($normalized, '=')) {
                [$key, $value] = explode('=', $normalized, 2);
                $options[$key] = $value;
                continue;
            }

            $options[$normalized] = true;
        }

        return ['args' => $args, 'options' => $options];
    }

    private function renderHelp(): int
    {
        $this->io->line(App::NAME . ' console ' . App::VERSION);
        $this->io->line('');
        $this->io->line('Usage:');
        $this->io->line('  php nite list');
        $this->io->line('  php nite create resource Report --table=reports --version=1.0.0');
        $this->io->line('  php nite make:model Report');
        $this->io->line('  php nite create migration add_reports_table');
        $this->io->line('  php nite remove resource Report --backup');
        $this->io->line('  php nite schema:apply --file=docs/examples/lesson-schedules.nite --migrate');
        $this->io->line('  php nite schema:explain --statement="CREATE RESOURCE `lesson_schedules` DB:lesson_schedules{ slug string(140) required unique public; }" --json');
        $this->io->line('  php nite db:migrate');
        $this->io->line('  php nite db:seed');
        $this->io->line('  php nite db:rollback --steps=1');
        $this->io->line('  php nite db:refresh --force --seed');
        $this->io->line('  php nite db:wipe --force');
        $this->io->line('  php nite route:list --method=GET --path=/admin');
        $this->io->line('  php nite resource:list --group=content');
        $this->io->line('  php nite permission:list --role=admin');
        $this->io->line('  php nite module:list');
        $this->io->line('  php nite starter:list');
        $this->io->line('  php nite starter:show inventory-management --json');
        $this->io->line('  php nite app:bootstrap "Acme Inventory" --starter=inventory-management --sample-count=120 --seed');
        $this->io->line('  php nite mail:test --to=dev@example.com');
        $this->io->line('  php nite mail:queue:work --limit=25');
        $this->io->line('  php nite mail:queue:list --status=failed');
        $this->io->line('  php nite mail:queue:retry --all');
        $this->io->line('  php nite queue:stats');
        $this->io->line('  php nite queue:work --daemon --sleep=3');
        $this->io->line('  php nite app:about');
        $this->io->line('  php nite app:doctor');
        $this->io->line('  php nite app:install --seed');
        $this->io->line('  php nite app:bootstrap "Acme Ops" --preset=standard --seed');
        $this->io->line('  php nite app:bootstrap "Client Portal" --project=client-portal --preset=advanced --port=8286 --no-migrate');
        $this->io->line('  php nite app:remove-samples --force');
        $this->io->line('  php nite app:serve --host=127.0.0.1 --port=8185');
        $this->io->line('  php nite project:create "Project 1" --slug=project1 --port=8286');
        $this->io->line('  php nite project:list');
        $this->io->line('  php nite app:install 0.2.0 --seed');
        $this->io->line('  php nite app:uninstall --force');
        $this->io->line('  php nite app:update');
        $this->io->line('  php nite app:releases --limit=10');
        $this->io->line('  php nite app:upgrade 1.1.0 --accept-compatibility');
        $this->io->line('  php nite app:downgrade 1.0.0 --force');
        $this->io->line('  php nite eval "return App\Config\Database::driver();"');
        $this->io->line('');
        $this->io->line('Commands:');
        $this->io->line('  create model|controller|service|migration|resource <Name>');
        $this->io->line('  schema:apply | schema:explain');
        $this->io->line('  remove model|controller|service|migration|resource <Name>');
        $this->io->line('  db:migrate | db:seed | db:rollback | db:status | db:refresh | db:wipe');
        $this->io->line('  route:list | resource:list | module:list | permission:list | starter:list | starter:show');
        $this->io->line('  mail:test | mail:queue:list | mail:queue:work | mail:queue:retry | queue:stats');
        $this->io->line('  project:create | project:list');
        $this->io->line('  app:about | app:doctor | app:install | app:bootstrap | app:remove-samples | app:serve | app:uninstall');
        $this->io->line('  app:update | app:version | app:releases | app:upgrade | app:downgrade');
        $this->io->line('  app:compatibility:accept | app:conflicts:check | eval');
        $this->io->line('');
        $this->io->line('Options:');
        $this->io->line('  --table=custom_table   Override the generated table name for model/resource scaffolds.');
        $this->io->line('  --file=docs/examples/lesson-schedules.nite  Load a schema DSL document from disk.');
        $this->io->line('  --statement="CREATE RESOURCE ..."  Pass a schema DSL statement inline.');
        $this->io->line('  --version=1.2.0        Stamp generated migrations and resources with a target version.');
        $this->io->line('  --force                Overwrite existing generated files.');
        $this->io->line('  --backup / --no-backup Back up conflicting files and GitHub release overwrites before changes.');
        $this->io->line('  --rollback             Roll back matched console migrations before removing migration/resource files.');
        $this->io->line('  --accept-conflicts     Allow GitHub release sync to overwrite a dirty git worktree.');
        $this->io->line('  --seed / --no-seed     Enable or disable seed execution on install/refresh.');
        $this->io->line('  --migrate / --no-migrate  Control whether db:seed applies migrations first.');
        $this->io->line('  --migrate on schema:apply  Run generated migrations immediately after writing resource files.');
        $this->io->line('  --preset=advanced      Choose the app bootstrap preset: basic, standard, or advanced.');
        $this->io->line('  --starter=inventory-management  Resolve a product-shaped starter app on top of the preset system.');
        $this->io->line('  --with=messaging       Add focus modules during app:bootstrap without changing framework-wide built-ins.');
        $this->io->line('  --without=analytics    Remove focus modules from the selected preset during app:bootstrap.');
        $this->io->line('  --resources=Ticket,ProjectBoard  Add extra generated starter resources during app:bootstrap.');
        $this->io->line('  --sample-packs=inventory-core,inventory-analytics  Choose starter sample bundles explicitly.');
        $this->io->line('  --sample-count=1000    Generate large starter sample bundles for examples and AI context.');
        $this->io->line('  --install-samples / --no-install-samples  Control whether generated starter samples are inserted into example_entities.');
        $this->io->line('  --db-driver=mysql      Choose the bootstrap database driver.');
        $this->io->line('  --db-host=127.0.0.1    Set the host runtime database host.');
        $this->io->line('  --db-port=3306         Set the host runtime database port.');
        $this->io->line('  --db-user=root         Set the host runtime database user.');
        $this->io->line('  --db-password=secret   Set the host runtime database password.');
        $this->io->line('  --media-driver=s3      Set the storage driver written into env files during app:bootstrap.');
        $this->io->line('  --provision-db / --no-provision-db  Attempt to create the configured database before migrations.');
        $this->io->line('  --db-only / --files-only  Limit app:remove-samples to database cleanup or file cleanup only.');
        $this->io->line('  --keep-docs             Keep sample documentation files while removing the live sample module.');
        $this->io->line('  --limit=10             Control how many GitHub releases or tags are listed.');
        $this->io->line('  --steps=2              Control rollback depth.');
        $this->io->line('  --accept-compatibility Allow a major-version upgrade to proceed and record acceptance.');
        $this->io->line('  --host=127.0.0.1       Bind address for app:serve.');
        $this->io->line('  --port=8185            Port for app:serve.');
        $this->io->line('  --project=project1     Load one named project manifest and env overlay.');
        $this->io->line('  --slug=project1        Explicit slug for project:create.');
        $this->io->line('  --db-name=nite_proj1   Override the default project database name.');
        $this->io->line('  --app-url=http://127.0.0.1:8286  Override the generated project APP_URL.');
        $this->io->line('  --to=dev@example.com   Recipient for mail:test.');
        $this->io->line('  --subject="Hello"      Subject override for mail:test.');
        $this->io->line('  --queue / --no-queue   Force queueing or direct send for mail:test.');
        $this->io->line('  --status=failed        Filter mail:queue:list by delivery status.');
        $this->io->line('  --message-type=contact_admin_alert  Filter mail:queue:list by message type.');
        $this->io->line('  --limit=25             Max rows to list or queue items to process.');
        $this->io->line('  --daemon               Keep queue:work running as a worker loop instead of a one-shot drain.');
        $this->io->line('  --sleep=3              Seconds to wait between empty queue polls in daemon mode.');
        $this->io->line('  --max-runtime=3600     Stop queue workers after this many seconds. 0 means unlimited.');
        $this->io->line('  --max-jobs=500         Stop queue workers after claiming this many jobs. 0 means unlimited.');
        $this->io->line('  --stop-when-empty      Exit queue workers after the queue drains once.');
        $this->io->line('  --all                  Retry all failed queue items on mail:queue:retry.');
        $this->io->line('  --id=<uuid>            Retry one failed queue item on mail:queue:retry.');
        $this->io->line('  --method=GET           Filter route:list by HTTP method.');
        $this->io->line('  --path=/admin          Filter route:list by path substring.');
        $this->io->line('  --resource=pages       Filter route:list by resource key.');
        $this->io->line('  --public / --protected / --admin  Filter route:list by access level.');
        $this->io->line('  --group=content        Filter resource:list by resource group.');
        $this->io->line('  --module=governance    Filter module:list or permission:list by module.');
        $this->io->line('  --role=admin           Filter permission:list by default role.');
        $this->io->line('  --code=admin.users     Filter permission:list by code or title.');
        $this->io->line('  --json                 Emit JSON for the framework inspection commands.');
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function starterList(array $options): int
    {
        $starters = StarterAppCatalog::starters($this->rootPath);

        if ($this->wantsJson($options)) {
            $payload = array_map(function (array $starter): array {
                return [
                    'key' => (string)($starter['key'] ?? ''),
                    'title' => (string)($starter['title'] ?? ''),
                    'summary' => (string)($starter['summary'] ?? ''),
                    'preset' => (string)($starter['preset'] ?? 'standard'),
                    'resource_count' => count(array_values(is_array($starter['resources'] ?? null) ? $starter['resources'] : [])),
                    'sample_pack_count' => count(array_values(is_array($starter['sample_packs'] ?? null) ? $starter['sample_packs'] : [])),
                    'default_sample_count' => (int)($starter['default_sample_count'] ?? 0),
                    'tags' => array_values(is_array($starter['tags'] ?? null) ? $starter['tags'] : []),
                ];
            }, array_values($starters));

            $this->renderJson([
                'data' => array_values($payload),
                'meta' => ['count' => count($payload)],
            ]);
            return 0;
        }

        if ($starters === []) {
            $this->io->warn('No starter apps are registered.');
            return 0;
        }

        $rows = array_map(static function (array $starter): array {
            return [
                (string)($starter['key'] ?? ''),
                substr((string)($starter['title'] ?? ''), 0, 28),
                (string)($starter['preset'] ?? 'standard'),
                (string)count(array_values(is_array($starter['resources'] ?? null) ? $starter['resources'] : [])),
                (string)count(array_values(is_array($starter['sample_packs'] ?? null) ? $starter['sample_packs'] : [])),
                (string)($starter['default_sample_count'] ?? 0),
            ];
        }, array_values($starters));

        $this->io->table(['KEY', 'TITLE', 'PRESET', 'RES', 'PACKS', 'SAMPLES'], $rows);
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function starterShow(array $args, array $options): int
    {
        $key = trim((string)($args[0] ?? $options['starter'] ?? ''));
        if ($key === '') {
            throw new RuntimeException('A starter key is required for starter:show.');
        }

        $starter = StarterAppCatalog::resolve($key, [], [], [], $this->rootPath);
        $packs = StarterSampleCatalog::selectedPacks($starter, [], $this->rootPath);
        $payload = [
            'starter' => $starter,
            'sample_packs' => $packs,
        ];

        if ($this->wantsJson($options)) {
            $this->renderJson($payload);
            return 0;
        }

        $this->io->success((string)($starter['title'] ?? $key));
        $this->io->info('Key: ' . (string)($starter['key'] ?? ''));
        $this->io->info('Preset: ' . (string)($starter['preset'] ?? '') . ' (' . (string)($starter['preset_title'] ?? '') . ')');
        $this->io->info('Summary: ' . (string)($starter['summary'] ?? ''));
        if ((array)($starter['tags'] ?? []) !== []) {
            $this->io->info('Tags: ' . implode(', ', array_values((array)$starter['tags'])));
        }

        $this->io->line('');
        $this->io->line('Operations:');
        foreach (array_values(is_array($starter['operations'] ?? null) ? $starter['operations'] : []) as $operation) {
            $this->io->line('  - ' . (string)$operation);
        }

        $this->io->line('');
        $this->io->line('Resources:');
        foreach (array_values(is_array($starter['resources'] ?? null) ? $starter['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $this->io->line('  - ' . (string)($resource['name'] ?? '') . ': ' . (string)($resource['summary'] ?? ''));
        }

        if ($packs !== []) {
            $this->io->line('');
            $this->io->line('Sample Packs:');
            foreach ($packs as $pack) {
                $this->io->line('  - ' . (string)($pack['key'] ?? '') . ': ' . (string)($pack['summary'] ?? ''));
            }
        }

        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function mailTest(array $args, array $options): int
    {
        $recipient = trim((string)($options['to'] ?? $args[0] ?? ''));
        if ($recipient === '') {
            throw new RuntimeException('A recipient is required for mail:test. Use --to=dev@example.com.');
        }

        $service = new MailService();
        $result = $service->sendTest([
            'to' => $recipient,
            'subject' => $options['subject'] ?? null,
            'queue' => $this->boolOption($options, 'queue', false),
        ]);

        if ($this->wantsJson($options)) {
            $this->renderJson($result);
            return 0;
        }

        $status = (string)($result['status'] ?? 'unknown');
        if ($status === 'queued') {
            $queueItem = is_array($result['queue_item'] ?? null) ? $result['queue_item'] : [];
            $this->io->success('Test mail queued.');
            $this->io->info('Queue ID: ' . (string)($queueItem['id'] ?? ''));
            $this->io->info('Subject: ' . (string)($queueItem['subject'] ?? ''));
            return 0;
        }

        if ($status === 'disabled') {
            $this->io->warn((string)($result['message'] ?? 'Outbound mail is disabled.'));
            return 0;
        }

        $this->io->success('Test mail sent.');
        $this->io->info('Transport message id: ' . (string)($result['transport_message_id'] ?? 'n/a'));
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function mailQueueList(array $options): int
    {
        $service = new MailService();
        $items = $service->queueList([
            'status' => $options['status'] ?? '',
            'message_type' => $options['message-type'] ?? '',
            'q' => $options['q'] ?? '',
            'limit' => $options['limit'] ?? 50,
        ]);

        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $items,
                'meta' => [
                    'count' => count($items),
                    'status_counts' => $service->queueStatusCounts(),
                ],
            ]);
            return 0;
        }

        if ($items === []) {
            $this->io->warn('No queued mail records matched the selected filters.');
            return 0;
        }

        $rows = array_map(static function (array $item): array {
            $to = array_map(static fn (array $recipient): string => (string)($recipient['address'] ?? ''), is_array($item['to'] ?? null) ? $item['to'] : []);
            return [
                (string)($item['id'] ?? ''),
                (string)($item['status'] ?? ''),
                (string)($item['message_type'] ?? ''),
                substr((string)($item['subject'] ?? ''), 0, 36),
                implode(',', array_slice($to, 0, 2)),
                (string)($item['created_at'] ?? ''),
            ];
        }, $items);

        $this->io->table(['ID', 'STATUS', 'TYPE', 'SUBJECT', 'TO', 'CREATED'], $rows);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function mailQueueWork(array $options): int
    {
        $service = new MailService();
        $workerOptions = [
            'limit' => $options['limit'] ?? 25,
            'sleep' => $options['sleep'] ?? null,
            'max_runtime' => $options['max-runtime'] ?? null,
            'max_jobs' => $options['max-jobs'] ?? null,
            'stop_when_empty' => $this->boolOption($options, 'stop-when-empty', false),
        ];
        $result = $this->boolOption($options, 'daemon', false)
            ? $service->workLoop($workerOptions + ['daemon' => true])
            : $service->work($workerOptions);

        if ($this->wantsJson($options)) {
            $this->renderJson($result);
            return 0;
        }

        if (array_key_exists('mode', $result)) {
            $this->io->info('Mode: ' . (string)($result['mode'] ?? 'drain'));
            $this->io->info('Iterations: ' . (string)($result['iterations'] ?? 0));
            $this->io->info('Runtime: ' . (string)($result['runtime_seconds'] ?? 0) . 's');
        }
        $this->io->info('Claimed: ' . (string)($result['claimed'] ?? 0));
        $this->io->info('Sent: ' . (string)($result['sent'] ?? 0));
        $this->io->info('Retried: ' . (string)($result['retried'] ?? 0));
        $this->io->info('Failed: ' . (string)($result['failed'] ?? 0));

        $items = is_array($result['items'] ?? null) ? $result['items'] : [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $line = (string)($item['id'] ?? '') . ' ' . (string)($item['status'] ?? '');
            if (trim((string)($item['error'] ?? '')) !== '') {
                $line .= ' - ' . (string)$item['error'];
            }
            $this->io->line('  ' . trim($line));
        }

        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function mailQueueRetry(array $options): int
    {
        $service = new MailService();
        $id = trim((string)($options['id'] ?? ''));
        $all = $this->boolOption($options, 'all', false);

        if ($all) {
            $count = $service->retryFailedQueue();
            if ($this->wantsJson($options)) {
                $this->renderJson(['retried' => $count, 'scope' => 'all_failed']);
                return 0;
            }

            $this->io->success('Requeued failed mail items: ' . $count);
            return 0;
        }

        if ($id === '') {
            throw new RuntimeException('mail:queue:retry requires --id=<uuid> or --all.');
        }

        $ok = $service->retryQueueItem($id);
        if ($this->wantsJson($options)) {
            $this->renderJson(['id' => $id, 'retried' => $ok]);
            return 0;
        }

        if (!$ok) {
            throw new RuntimeException('Queue item could not be retried: ' . $id);
        }

        $this->io->success('Requeued mail item: ' . $id);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function mailQueueStats(array $options): int
    {
        $summary = (new MailService())->queueSummary();
        if ($this->wantsJson($options)) {
            $this->renderJson($summary);
            return 0;
        }

        $counts = is_array($summary['status_counts'] ?? null) ? $summary['status_counts'] : [];
        $this->io->info('Queued: ' . (string)($counts['queued'] ?? 0));
        $this->io->info('Processing: ' . (string)($counts['processing'] ?? 0));
        $this->io->info('Sent: ' . (string)($counts['sent'] ?? 0));
        $this->io->info('Failed: ' . (string)($counts['failed'] ?? 0));
        $this->io->info('Pending total: ' . (string)($summary['pending'] ?? 0));
        $this->io->info('Worker sleep: ' . (string)($summary['worker_sleep_seconds'] ?? 0) . 's');
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function create(string $type, array $args, array $options): int
    {
        $name = trim((string)($args[0] ?? ''));
        if ($name === '') {
            throw new RuntimeException('A name is required for create ' . $type . '.');
        }

        $result = $this->scaffolds->create($type, $name, $options);
        $this->reportFileResult('Created ' . $type . ' ' . $name . '.', $result);
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function remove(string $type, array $args, array $options): int
    {
        $name = trim((string)($args[0] ?? ''));
        if ($name === '') {
            throw new RuntimeException('A name is required for remove ' . $type . '.');
        }

        $migrationPaths = $this->scaffolds->migrationPaths($type, $name, isset($options['table']) ? (string)$options['table'] : null);
        $migrationIds = $this->migrationIdsFromPaths($migrationPaths);
        $appliedIds = [];

        if ($migrationIds !== []) {
            try {
                $appliedIds = $this->migrations->appliedMigrationIds($migrationIds);
            } catch (\Throwable $e) {
                if ($this->boolOption($options, 'rollback', false)) {
                    throw $e;
                }

                if ($type === 'resource') {
                    $options['keep-migrations'] = true;
                    $this->io->warn('Could not inspect migration state; migration files were kept. Use --rollback when the database is reachable to drop the database structure too.');
                } else {
                    throw new RuntimeException('Could not inspect migration state. Reconnect the database or use db:rollback first.');
                }
            }
        }

        if ($appliedIds !== []) {
            if ($type === 'migration' && !$this->boolOption($options, 'rollback', false)) {
                throw new RuntimeException('The matched migration is already applied. Run remove migration with --rollback or use db:rollback first.');
            }

            if ($this->boolOption($options, 'rollback', false)) {
                $rollback = $this->migrations->rollbackIds($appliedIds);
                $this->io->info('Rolled back console migrations before removal: ' . count($rollback['rolled_back']));
            } elseif ($type === 'resource') {
                $options['keep-migrations'] = true;
                $this->io->warn('Applied migration files were kept. Use --rollback to drop the database structure too.');
            }
        }

        $result = $this->scaffolds->remove($type, $name, $options);
        $this->reportFileResult('Removed ' . $type . ' ' . $name . '.', $result);
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function schemaApply(array $args, array $options): int
    {
        $input = $this->resourceDslInput($args, $options);
        $result = $this->resourceDefinitions->apply($input, $options);

        if ($this->wantsJson($options)) {
            $this->renderJson($result);
            return 0;
        }

        $this->reportFileResult('Schema apply completed.', $result);
        foreach (array_values(is_array($result['applied'] ?? null) ? $result['applied'] : []) as $applied) {
            if (!is_array($applied)) {
                continue;
            }
            $kind = (string)($applied['kind'] ?? 'item');
            $verb = (string)($applied['verb'] ?? '');
            $name = (string)($applied['resource_key'] ?? $applied['name'] ?? '');
            $this->io->line('  = ' . $verb . ' ' . $kind . ' ' . $name);
        }
        foreach (array_values(is_array($result['warnings'] ?? null) ? $result['warnings'] : []) as $warning) {
            $this->io->warn((string)$warning);
        }
        if (is_array($result['database'] ?? null)) {
            $database = (array)$result['database'];
            $this->io->info('Database: ' . (string)($database['status'] ?? '') . ' (' . (string)($database['applied_count'] ?? 0) . ' migrations applied)');
        }

        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function schemaExplain(array $args, array $options): int
    {
        $input = $this->resourceDslInput($args, $options);
        $result = $this->resourceDefinitions->explain($input);

        if ($this->wantsJson($options)) {
            $this->renderJson($result);
            return 0;
        }

        $statements = array_values(is_array($result['statements'] ?? null) ? $result['statements'] : []);
        $this->io->line('Statements: ' . count($statements));
        foreach ($statements as $statement) {
            if (!is_array($statement)) {
                continue;
            }

            $kind = (string)($statement['kind'] ?? 'statement');
            $verb = (string)($statement['verb'] ?? '');
            if (is_array($statement['resource'] ?? null)) {
                $resource = (array)$statement['resource'];
                $this->io->line(
                    '  - ' . $verb . ' ' . $kind
                    . ' ' . (string)($resource['key'] ?? '')
                    . ' [' . (string)($resource['table'] ?? '') . ']'
                    . ' fields=' . count((array)($resource['fields'] ?? []))
                );
                continue;
            }

            $this->io->line('  - ' . $verb . ' ' . $kind . ' ' . (string)($statement['name'] ?? $statement['resource_name'] ?? ''));
        }
        foreach (array_values(is_array($result['warnings'] ?? null) ? $result['warnings'] : []) as $warning) {
            $this->io->warn((string)$warning);
        }

        return 0;
    }

    private function dbMigrate(): int
    {
        $result = $this->migrations->migrate();
        $this->io->success('Database migration completed.');
        $this->io->info('Driver: ' . (string)$result['driver']);
        $this->io->info('Schema: ' . (string)$result['schema_path']);
        $this->io->info('Applied migrations: ' . (string)$result['applied_count']);
        foreach ($result['applied'] as $migration) {
            $this->io->line('  - ' . $migration['id'] . ' [' . $migration['version'] . ']');
        }
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function dbSeed(array $options): int
    {
        $result = $this->migrations->seed($this->boolOption($options, 'migrate', true));
        $this->io->success('Database seed completed.');
        $this->io->info('Driver: ' . (string)$result['driver']);
        $this->io->info('Seeded: yes');
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function dbRollback(array $options): int
    {
        $steps = max(1, (int)($options['steps'] ?? 1));
        $result = $this->migrations->rollback($steps);
        $this->io->success('Rollback completed.');
        foreach ($result['rolled_back'] as $migration) {
            $this->io->line('  - ' . $migration['id'] . ' [' . $migration['version'] . ']');
        }
        if ($result['rolled_back'] === []) {
            $this->io->warn('No applied console migrations were available to roll back.');
        }
        return 0;
    }

    private function dbStatus(): int
    {
        $status = $this->migrations->status();
        $this->io->line('Driver: ' . (string)$status['driver']);
        $this->io->line('Schema: ' . (string)$status['schema_path']);
        $this->io->line('Migration directory: ' . (string)$status['migration_directory']);
        $this->io->line('Applied: ' . count($status['applied']));
        foreach ($status['applied'] as $migration) {
            $this->io->line('  - ' . $migration['id'] . ' [' . $migration['version'] . ']');
        }
        $this->io->line('Pending: ' . count($status['pending']));
        foreach ($status['pending'] as $migration) {
            $this->io->line('  - ' . $migration['id'] . ' [' . $migration['version'] . ']');
        }

        $conflicts = $status['conflicts'];
        if (($conflicts['duplicate_ids'] ?? []) !== [] || ($conflicts['duplicate_names'] ?? []) !== []) {
            $this->io->warn('Migration conflicts detected.');
        }
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function dbRefresh(array $options): int
    {
        if (!$this->confirmDestructive('This will drop every table in the configured database. Continue?', $options)) {
            throw new RuntimeException('Refresh cancelled.');
        }

        $seed = $this->boolOption($options, 'seed', false);
        $result = $this->migrations->refresh($seed);
        $this->io->success('Database refresh completed.');
        $this->io->info('Applied migrations: ' . (string)$result['applied_count']);
        $this->io->info('Seeded: ' . ($seed ? 'yes' : 'no'));
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function dbWipe(array $options): int
    {
        if (!$this->confirmDestructive('This will drop every table in the configured database without reinstalling it. Continue?', $options)) {
            throw new RuntimeException('Wipe cancelled.');
        }

        $result = $this->migrations->wipe();
        $this->io->success('Database wipe completed.');
        $this->io->info('Driver: ' . (string)$result['driver']);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function routeList(array $options): int
    {
        $routes = $this->framework->routes($options);
        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $routes,
                'meta' => ['count' => count($routes)],
            ]);
            return 0;
        }

        $this->io->line('Routes: ' . count($routes));
        if ($routes === []) {
            $this->io->warn('No routes matched the current filters.');
            return 0;
        }

        $rows = array_map(function (array $route): array {
            return [
                (string)$route['method'],
                (string)$route['access'],
                (string)$route['path'],
                $route['resource_key'] !== '' ? (string)$route['resource_key'] : '-',
                $this->truncate(implode(',', (array)$route['permissions']), 42) ?: '-',
                (bool)$route['generated'] ? 'generated' : 'core',
            ];
        }, $routes);

        $this->io->table(['METHOD', 'ACCESS', 'PATH', 'RESOURCE', 'PERMISSIONS', 'SOURCE'], $rows);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function resourceList(array $options): int
    {
        $resources = $this->framework->resources($options);
        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $resources,
                'meta' => ['count' => count($resources)],
            ]);
            return 0;
        }

        $this->io->line('Resources: ' . count($resources));
        if ($resources === []) {
            $this->io->warn('No resources matched the current filters.');
            return 0;
        }

        $rows = array_map(static function (array $resource): array {
            return [
                (string)$resource['key'],
                (string)$resource['group'],
                (string)$resource['table'],
                (string)$resource['route_count'],
                (string)$resource['write_route_count'],
                (bool)$resource['generated'] ? 'generated' : 'core',
            ];
        }, $resources);

        $this->io->table(['KEY', 'GROUP', 'TABLE', 'ROUTES', 'WRITES', 'SOURCE'], $rows);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function moduleList(array $options): int
    {
        $modules = $this->framework->modules($options);
        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $modules,
                'meta' => ['count' => count($modules)],
            ]);
            return 0;
        }

        $this->io->line('Modules: ' . count($modules));
        if ($modules === []) {
            $this->io->warn('No modules matched the current filters.');
            return 0;
        }

        $rows = array_map(function (array $module): array {
            return [
                (string)$module['key'],
                $this->truncate((string)$module['title'], 22),
                (string)$module['entity_count'],
                (string)$module['resource_count'],
                $this->truncate(implode(',', (array)$module['resources']), 40) ?: '-',
            ];
        }, $modules);

        $this->io->table(['KEY', 'TITLE', 'ENTITIES', 'RESOURCES', 'LINKED RESOURCES'], $rows);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function permissionList(array $options): int
    {
        $permissions = $this->framework->permissions($options);
        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $permissions,
                'meta' => ['count' => count($permissions)],
            ]);
            return 0;
        }

        $this->io->line('Permissions: ' . count($permissions));
        if ($permissions === []) {
            $this->io->warn('No permissions matched the current filters.');
            return 0;
        }

        $rows = array_map(function (array $permission): array {
            return [
                $this->truncate((string)$permission['code'], 34),
                (string)$permission['module_code'],
                (string)$permission['action_code'],
                $this->truncate(implode(',', (array)$permission['default_roles']), 28),
                (bool)$permission['generated'] ? 'generated' : 'core',
            ];
        }, $permissions);

        $this->io->table(['CODE', 'MODULE', 'ACTION', 'DEFAULT ROLES', 'SOURCE'], $rows);
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appAbout(array $options): int
    {
        $about = $this->framework->about();
        if ($this->wantsJson($options)) {
            $this->renderJson($about);
            return 0;
        }

        $counts = is_array($about['counts'] ?? null) ? $about['counts'] : [];
        $repository = is_array($about['repository'] ?? null) ? $about['repository'] : [];
        $api = is_array($about['api'] ?? null) ? $about['api'] : [];
        $project = is_array($about['project'] ?? null) ? $about['project'] : [];

        $this->io->line('Application: ' . (string)($about['application'] ?? App::NAME));
        $this->io->line('Code version: ' . (string)($about['code_version'] ?? App::VERSION));
        $this->io->line('Installed version: ' . (string)($about['installed_version'] ?? App::VERSION));
        $this->io->line('Installed tag: ' . (string)($about['installed_tag'] ?? ('v' . App::VERSION)));
        $this->io->line('PHP: ' . (string)($about['php_version'] ?? PHP_VERSION) . ' (' . (string)($about['php_sapi'] ?? PHP_SAPI) . ')');
        $this->io->line('Repository: ' . (string)($repository['url'] ?? ''));
        if ($project !== []) {
            $this->io->line('Project: ' . (string)($project['slug'] ?? '') . ' (' . (string)($project['name'] ?? '') . ')');
            $this->io->line('Project URL: ' . (string)($project['app_url'] ?? ''));
        }
        $this->io->line('API root: ' . (string)($api['api_root_path'] ?? '/api/v1'));
        $this->io->line('Modules: ' . (string)($counts['modules'] ?? 0));
        $this->io->line('Resources: ' . (string)($counts['resources'] ?? 0) . ' (' . (string)($counts['generated_resources'] ?? 0) . ' generated)');
        $this->io->line('Routes: ' . (string)($counts['routes'] ?? 0));
        $this->io->line('Permissions: ' . (string)($counts['permissions'] ?? 0));
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appDoctor(array $options): int
    {
        $doctor = $this->framework->doctor();
        if ($this->wantsJson($options)) {
            $this->renderJson($doctor);
            return 0;
        }

        $summary = is_array($doctor['summary'] ?? null) ? $doctor['summary'] : [];
        $checks = array_values(is_array($doctor['checks'] ?? null) ? $doctor['checks'] : []);
        $this->io->line(
            'Doctor summary: '
            . (string)($summary['ok'] ?? 0) . ' ok, '
            . (string)($summary['warn'] ?? 0) . ' warnings, '
            . (string)($summary['error'] ?? 0) . ' errors'
        );

        $rows = array_map(static function (array $check): array {
            return [
                strtoupper((string)($check['status'] ?? 'warn')),
                (string)($check['group'] ?? ''),
                (string)($check['name'] ?? ''),
                (string)($check['detail'] ?? ''),
            ];
        }, $checks);
        $this->io->table(['STATUS', 'GROUP', 'CHECK', 'DETAIL'], $rows);
        return (int)($summary['error'] ?? 0) > 0 ? 1 : 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appInstall(array $args, array $options): int
    {
        $releaseState = $this->downloadReleaseFromArgs($args, $options);
        $envPath = $this->rootPath . '/.env';
        $envExample = $this->rootPath . '/.env.example';
        if (!is_file($envPath) && is_file($envExample)) {
            if (!@copy($envExample, $envPath)) {
                throw new RuntimeException('Failed to create .env from .env.example.');
            }
            $this->io->info('Created .env from .env.example.');
        }

        $seed = $this->boolOption($options, 'seed', true);
        if ($seed) {
            $this->migrations->seed(true);
        } else {
            $this->migrations->migrate(true);
        }

        $installedVersion = (string)($releaseState['release']['version'] ?? App::VERSION);
        $this->versions->markInstalled($seed, $installedVersion, $this->releaseVersionMeta($releaseState));
        $this->io->success('Application install completed.');
        $this->reportReleaseState($releaseState);
        $this->io->info('Seeded: ' . ($seed ? 'yes' : 'no'));
        $this->io->info('Use `php nite app:version` to inspect the version ledger.');
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function appBootstrap(array $args, array $options): int
    {
        $name = trim((string)($args[0] ?? ''));
        $summary = $this->bootstrapper->bootstrap($name === '' ? null : $name, $options);

        if ($this->wantsJson($options)) {
            $this->renderJson($summary);
            return 0;
        }

        $application = is_array($summary['application'] ?? null) ? $summary['application'] : [];
        $preset = is_array($summary['preset'] ?? null) ? $summary['preset'] : [];
        $starter = is_array($summary['starter'] ?? null) ? $summary['starter'] : [];
        $database = is_array($summary['database'] ?? null) ? $summary['database'] : [];
        $samples = is_array($summary['samples'] ?? null) ? $summary['samples'] : [];
        $blueprints = is_array($summary['blueprint_files'] ?? null) ? $summary['blueprint_files'] : [];

        $this->io->success('Application bootstrap completed.');
        $this->io->info('Mode: ' . (string)($summary['mode'] ?? 'root'));
        $this->io->info('Name: ' . (string)($application['name'] ?? 'Nite Application'));
        $this->io->info('URL: ' . (string)($application['url'] ?? ''));
        $this->io->info('Preset: ' . (string)($preset['key'] ?? '') . ' (' . (string)($preset['title'] ?? '') . ')');
        if ($starter !== []) {
            $this->io->info('Starter: ' . (string)($starter['key'] ?? '') . ' (' . (string)($starter['title'] ?? '') . ')');
        }
        $this->io->info('Database: ' . (string)($database['driver'] ?? '') . ' ' . (string)($database['host'] ?? '') . ':' . (string)($database['port'] ?? '') . '/' . (string)($database['name'] ?? ''));

        $project = is_array($application['project'] ?? null) ? $application['project'] : [];
        if ($project !== []) {
            $this->io->info('Project: ' . (string)($project['slug'] ?? '') . ' on port ' . (string)($project['port'] ?? ''));
        }

        foreach (array_values(is_array($summary['generated_resources'] ?? null) ? $summary['generated_resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $this->io->line('  [' . (string)($resource['status'] ?? '') . '] ' . (string)($resource['name'] ?? '') . ' -> ' . (string)($resource['public_path'] ?? ''));
        }

        if ($blueprints !== []) {
            $this->io->info('Blueprint JSON: ' . (string)($blueprints['json'] ?? ''));
            $this->io->info('Blueprint Markdown: ' . (string)($blueprints['markdown'] ?? ''));
        }

        if ((int)($samples['count'] ?? 0) > 0) {
            $this->io->info('Starter samples: ' . (string)($samples['count'] ?? 0));
            $sampleFiles = is_array($samples['files'] ?? null) ? $samples['files'] : [];
            if ($sampleFiles !== []) {
                $this->io->info('Sample JSON: ' . (string)($sampleFiles['json'] ?? ''));
                $this->io->info('Sample Markdown: ' . (string)($sampleFiles['markdown'] ?? ''));
            }
            $sampleInstall = is_array($samples['install'] ?? null) ? $samples['install'] : [];
            if ($sampleInstall !== []) {
                $this->io->info('Sample install: ' . (string)($sampleInstall['status'] ?? '') . ' - ' . (string)($sampleInstall['detail'] ?? ''));
            }
        }

        $provision = is_array($database['provision'] ?? null) ? $database['provision'] : [];
        if ($provision !== []) {
            $this->io->info('DB provisioning: ' . (string)($provision['status'] ?? '') . ' - ' . (string)($provision['detail'] ?? ''));
        }

        $bootstrap = is_array($database['bootstrap'] ?? null) ? $database['bootstrap'] : [];
        if ($bootstrap !== []) {
            $this->io->info('DB bootstrap: ' . (string)($bootstrap['detail'] ?? ''));
        }

        foreach (array_values(is_array($summary['recommended_commands'] ?? null) ? $summary['recommended_commands'] : []) as $command) {
            $this->io->line('  next: ' . (string)$command);
        }

        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appRemoveSamples(array $options): int
    {
        if (!$this->confirmDestructive('This will remove the built-in sample CRUD module from the codebase and drop its database artifacts when reachable. Continue?', $options)) {
            throw new RuntimeException('Sample removal cancelled.');
        }

        $result = (new SampleRemovalManager($this->rootPath, $this->io))->remove($options);

        if ($this->wantsJson($options)) {
            $this->renderJson($result);
            return 0;
        }

        $this->io->success('Sample removal completed.');

        $database = is_array($result['database'] ?? null) ? $result['database'] : [];
        if ($database !== []) {
            $this->io->info('Database: ' . (string)($database['status'] ?? '') . ' - ' . (string)($database['detail'] ?? ''));
        }

        $files = is_array($result['files'] ?? null) ? $result['files'] : [];
        foreach (array_values(is_array($files['modified'] ?? null) ? $files['modified'] : []) as $path) {
            $this->io->line('  ~ ' . (string)$path);
        }
        foreach (array_values(is_array($files['deleted'] ?? null) ? $files['deleted'] : []) as $path) {
            $this->io->line('  - ' . (string)$path);
        }
        foreach (array_values(is_array($files['missing'] ?? null) ? $files['missing'] : []) as $path) {
            $this->io->line('  ? ' . (string)$path);
        }
        foreach (array_values(is_array($files['warnings'] ?? null) ? $files['warnings'] : []) as $warning) {
            $this->io->warn((string)$warning);
        }

        $backupDir = trim((string)($result['backup_dir'] ?? ''));
        if ($backupDir !== '') {
            $this->io->info('Backup: ' . $backupDir);
        }

        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appServe(array $options): int
    {
        $projectHost = is_array($this->activeProject) ? trim((string)($this->activeProject['host'] ?? '')) : '';
        $projectPort = is_array($this->activeProject) ? (int)($this->activeProject['port'] ?? 0) : 0;
        $host = trim((string)($options['host'] ?? $projectHost ?: '127.0.0.1'));
        $host = $host === '' ? '127.0.0.1' : $host;
        $port = (int)($options['port'] ?? ($projectPort > 0 ? $projectPort : 8185));
        if ($port < 1 || $port > 65535) {
            throw new RuntimeException('Port must be between 1 and 65535.');
        }

        $routerScript = $this->rootPath . '/public/index.php';
        if (!is_file($routerScript)) {
            throw new RuntimeException('Missing public/index.php. Cannot start the built-in server.');
        }

        $url = 'http://' . $host . ':' . $port;
        if (is_array($this->activeProject)) {
            Env::apply([
                'APP_URL' => $url,
                'NITE_PROJECT' => (string)($this->activeProject['slug'] ?? ''),
                'NITE_PROJECT_NAME' => (string)($this->activeProject['name'] ?? ''),
            ], true);
            $this->io->info('Starting project server for ' . (string)($this->activeProject['slug'] ?? '') . ' at ' . $url);
        } else {
            Env::apply(['APP_URL' => $url], true);
            $this->io->info('Starting PHP built-in server at ' . $url);
        }
        $this->io->info('Press Ctrl+C to stop.');

        $previousCwd = getcwd();
        if ($previousCwd === false || !@chdir($this->rootPath)) {
            throw new RuntimeException('Failed to switch into the project root before starting the server.');
        }

        try {
            $command = escapeshellarg(PHP_BINARY)
                . ' -S ' . escapeshellarg($host . ':' . $port)
                . ' -t ' . escapeshellarg('public')
                . ' ' . escapeshellarg('public/index.php');
            passthru($command, $exitCode);
        } finally {
            @chdir($previousCwd ?: $this->rootPath);
        }

        return (int)($exitCode ?? 0);
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appUninstall(array $options): int
    {
        if (!$this->confirmDestructive('This will wipe the configured database and clear the console version ledger. Continue?', $options)) {
            throw new RuntimeException('Uninstall cancelled.');
        }

        $this->migrations->wipe();
        $this->versions->clear();
        $this->io->success('Application uninstall completed.');
        return 0;
    }

    private function appUpdate(array $args, array $options): int
    {
        $release = $this->resolveReleaseFromArgs($args);
        $targetVersion = (string)$release['version'];
        $currentVersion = $this->versions->currentVersion();
        $acceptCompatibility = $this->boolOption($options, 'accept-compatibility', false);

        if (version_compare($targetVersion, $currentVersion, '<')) {
            throw new RuntimeException('Update targets must be greater than or equal to the installed version. Use app:downgrade for older releases.');
        }

        if (version_compare($targetVersion, $currentVersion, '>')) {
            $this->versions->assertCanUpgrade($targetVersion, $acceptCompatibility);
        }

        $releaseState = $this->syncRelease($release, $options);
        $this->migrations->migrate(true);
        if (
            $acceptCompatibility
            && version_compare($targetVersion, $currentVersion, '>')
            && (int)explode('.', $targetVersion)[0] > (int)explode('.', $currentVersion)[0]
        ) {
            $this->versions->acceptCompatibility($targetVersion);
        }
        $this->versions->markUpdated($targetVersion, $this->releaseVersionMeta($releaseState));
        $this->io->success('Application update completed.');
        $this->reportReleaseState($releaseState);
        return 0;
    }

    private function appVersion(): int
    {
        $info = $this->versions->info();
        $this->io->line('Application: ' . (string)$info['application']);
        $this->io->line('Code version: ' . (string)$info['code_version']);
        $this->io->line('Installed version: ' . (string)$info['installed_version']);
        $repository = is_array($info['repository'] ?? null) ? $info['repository'] : [];
        $this->io->line('Repository: ' . (string)($repository['url'] ?? App::publicRepositoryUrl()));
        $this->io->line('Installed tag: ' . (string)($info['installed_tag'] ?? ('v' . $info['installed_version'])));
        $this->io->line('Managed files: ' . (string)($info['installed_files_count'] ?? 0));
        $acceptances = is_array($info['compatibility_acceptances']) ? $info['compatibility_acceptances'] : [];
        if ($acceptances !== []) {
            $this->io->line('Accepted compatibility targets:');
            foreach ($acceptances as $item) {
                $this->io->line('  - ' . (string)($item['version'] ?? '') . ' at ' . (string)($item['accepted_at'] ?? ''));
            }
        }
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function appReleases(array $options): int
    {
        $limit = max(1, min(50, (int)($options['limit'] ?? 10)));
        $releases = $this->releases->availableReleases($limit);
        $this->io->line('Repository: ' . $this->releases->repository()['url']);
        $this->io->line('Available releases/tags: ' . count($releases));
        foreach ($releases as $release) {
            $line = '  - ' . (string)$release['version'] . ' [' . (string)$release['tag'] . ']';
            $publishedAt = trim((string)($release['published_at'] ?? ''));
            if ($publishedAt !== '') {
                $line .= ' ' . $publishedAt;
            }
            $line .= ' ' . (string)($release['html_url'] ?? '');
            $this->io->line($line);
        }
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function appUpgrade(array $args, array $options): int
    {
        $release = $this->resolveReleaseFromArgs($args);
        $target = (string)$release['version'];
        $acceptCompatibility = $this->boolOption($options, 'accept-compatibility', false);

        $this->versions->assertCanUpgrade($target, $acceptCompatibility);
        $releaseState = $this->syncRelease($release, $options);
        $this->migrations->migrate(true);
        $this->versions->upgrade($target, $acceptCompatibility, $this->releaseVersionMeta($releaseState));
        $this->io->success('Application upgraded to ' . $target . '.');
        $this->reportReleaseState($releaseState);
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function appDowngrade(array $args, array $options): int
    {
        $target = trim((string)($args[0] ?? ''));
        if ($target === '') {
            throw new RuntimeException('Downgrade target version is required.');
        }

        if (!$this->confirmDestructive('This may roll back database changes above version ' . $target . '. Continue?', $options)) {
            throw new RuntimeException('Downgrade cancelled.');
        }

        $release = $this->releases->releaseForVersion($target);
        $resolvedTarget = (string)$release['version'];
        $result = $this->migrations->rollbackToVersion($resolvedTarget);
        $releaseState = $this->syncRelease($release, $options);
        $this->versions->downgrade($resolvedTarget, array_merge(
            $this->releaseVersionMeta($releaseState),
            ['rolled_back_migrations' => count($result['rolled_back'])]
        ));
        $this->io->success('Application downgraded to ' . $resolvedTarget . '.');
        $this->reportReleaseState($releaseState);
        $this->io->info('Rolled back migrations: ' . count($result['rolled_back']));
        return 0;
    }

    /**
     * @param array<int, string> $args
     */
    private function appCompatibilityAccept(array $args): int
    {
        $target = trim((string)($args[0] ?? ''));
        if ($target === '') {
            throw new RuntimeException('Compatibility target version is required.');
        }

        $this->versions->acceptCompatibility($target);
        $this->io->success('Compatibility accepted for ' . $target . '.');
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function conflictsCheck(array $args, array $options): int
    {
        $type = trim((string)($args[0] ?? ''));
        $name = trim((string)($args[1] ?? ''));

        $migrationConflicts = $this->migrations->migrationConflicts();
        if (($migrationConflicts['duplicate_ids'] ?? []) === [] && ($migrationConflicts['duplicate_names'] ?? []) === []) {
            $this->io->info('No migration ID or name conflicts detected.');
        } else {
            $this->io->warn('Migration conflicts detected.');
            foreach (($migrationConflicts['duplicate_ids'] ?? []) as $id => $paths) {
                $this->io->line('  duplicate id ' . $id . ': ' . implode(', ', $paths));
            }
            foreach (($migrationConflicts['duplicate_names'] ?? []) as $migrationName => $paths) {
                $this->io->line('  duplicate name ' . $migrationName . ': ' . implode(', ', $paths));
            }
        }

        if ($type !== '' && $name !== '') {
            $paths = $this->scaffolds->conflictPaths($type, $name, isset($options['table']) ? (string)$options['table'] : null);
            if ($paths === []) {
                $this->io->info('No scaffold conflicts detected for ' . $type . ' ' . $name . '.');
                return 0;
            }

            $this->io->warn('Scaffold conflicts for ' . $type . ' ' . $name . ':');
            foreach ($paths as $path) {
                $this->io->line('  - ' . $path);
            }
            return 0;
        }

        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function projectCreate(array $args, array $options): int
    {
        $name = trim((string)($args[0] ?? ''));
        if ($name === '') {
            throw new RuntimeException('A project name is required for project:create.');
        }

        $project = $this->projects->create($name, $options);
        $this->io->success('Project created: ' . (string)$project['slug']);
        $this->io->info('Name: ' . (string)$project['name']);
        $this->io->info('URL: ' . (string)$project['app_url']);
        $this->io->info('Port: ' . (string)$project['port']);
        $this->io->info('Manifest: ' . (string)($project['paths']['manifest'] ?? ''));
        $this->io->info('Host env: ' . (string)($project['paths']['env'] ?? ''));
        $this->io->info('Docker env: ' . (string)($project['paths']['docker_env'] ?? ''));
        $this->io->info('Docker compose: ' . (string)($project['paths']['compose'] ?? ''));
        $this->io->info('Use `php nite db:migrate --project=' . (string)$project['slug'] . '` to install its database schema.');
        $this->io->info('Use `php nite app:serve --project=' . (string)$project['slug'] . '` to run it on its configured port.');
        $this->io->info('Use `docker compose -f projects/' . (string)$project['slug'] . '/docker-compose.yml up --build` to run it in Docker.');
        return 0;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function projectList(array $options): int
    {
        $projects = $this->projects->all();
        if ($this->wantsJson($options)) {
            $this->renderJson([
                'data' => $projects,
                'meta' => ['count' => count($projects)],
            ]);
            return 0;
        }

        $this->io->line('Projects: ' . count($projects));
        if ($projects === []) {
            $this->io->warn('No project manifests have been created yet.');
            return 0;
        }

        $rows = array_map(function (array $project): array {
            $env = is_array($project['env'] ?? null) ? $project['env'] : [];
            return [
                (string)($project['slug'] ?? ''),
                $this->truncate((string)($project['name'] ?? ''), 24),
                (string)($project['port'] ?? ''),
                (string)($project['app_url'] ?? ''),
                (string)($env['DB_NAME'] ?? ''),
            ];
        }, $projects);

        $this->io->table(['SLUG', 'NAME', 'PORT', 'APP URL', 'DB NAME'], $rows);
        return 0;
    }

    /**
     * @param array<int, string> $args
     */
    private function evaluate(array $args): int
    {
        $code = trim(implode(' ', $args));
        if ($code === '') {
            throw new RuntimeException('Inline PHP code is required for eval.');
        }

        if (str_starts_with($code, '<?php')) {
            $code = trim(substr($code, 5));
        }

        $result = eval($code);
        if ($result !== null) {
            $this->io->line(var_export($result, true));
        }
        return 0;
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function downloadReleaseFromArgs(array $args, array $options): array
    {
        $release = $this->resolveReleaseFromArgs($args);
        return $this->syncRelease($release, $options);
    }

    /**
     * @param array<int, string> $args
     * @return array<string, mixed>
     */
    private function resolveReleaseFromArgs(array $args): array
    {
        $target = trim((string)($args[0] ?? ''));
        return $target === '' ? $this->releases->latestRelease() : $this->releases->releaseForVersion($target);
    }

    /**
     * @param array<string, mixed> $release
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function syncRelease(array $release, array $options): array
    {
        return $this->releases->syncRelease((string)($release['version'] ?? ''), [
            'force' => $this->boolOption($options, 'force', false),
            'backup' => $this->boolOption($options, 'backup', true),
            'accept_conflicts' => $this->boolOption($options, 'accept-conflicts', false),
            'previous_files' => $this->versions->installedFiles(),
        ]);
    }

    /**
     * @param array<string, mixed> $releaseState
     * @return array<string, mixed>
     */
    private function releaseVersionMeta(array $releaseState): array
    {
        $release = is_array($releaseState['release'] ?? null) ? $releaseState['release'] : [];
        return [
            'installed_tag' => (string)($release['tag'] ?? ''),
            'installed_files' => array_values(is_array($releaseState['installed_files'] ?? null) ? $releaseState['installed_files'] : []),
            'repository' => is_array($releaseState['repository'] ?? null) ? $releaseState['repository'] : [
                'slug' => App::publicRepository(),
                'url' => App::publicRepositoryUrl(),
                'api' => App::publicRepositoryApi(),
            ],
            'release' => $release,
            'backup_dir' => (string)($releaseState['backup_dir'] ?? ''),
        ];
    }

    /**
     * @param array<string, mixed> $releaseState
     */
    private function reportReleaseState(array $releaseState): void
    {
        $release = is_array($releaseState['release'] ?? null) ? $releaseState['release'] : [];
        if ($release !== []) {
            $this->io->info('Release: ' . (string)($release['tag'] ?? '') . ' from ' . (string)($release['html_url'] ?? ''));
        }

        $written = array_values(is_array($releaseState['written'] ?? null) ? $releaseState['written'] : []);
        $removed = array_values(is_array($releaseState['removed'] ?? null) ? $releaseState['removed'] : []);
        if ($written !== []) {
            $this->io->info('Updated files: ' . count($written));
        }
        if ($removed !== []) {
            $this->io->info('Removed stale files: ' . count($removed));
        }

        $backupDir = trim((string)($releaseState['backup_dir'] ?? ''));
        if ($backupDir !== '') {
            $this->io->info('Backup: ' . $backupDir);
        }
    }

    /**
     * @param array<string, mixed> $options
     */
    private function bootstrapProjectContext(string $command, array $options): void
    {
        if (str_starts_with($command, 'project:')) {
            return;
        }

        $slug = trim((string)($options['project'] ?? Env::get('NITE_PROJECT', '')));
        if ($slug === '') {
            $this->activeProject = null;
            return;
        }

        if ($command === 'app:bootstrap') {
            $project = $this->projects->find($slug);
            $this->activeProject = $project;
            if ($project !== null) {
                $this->projects->apply($slug);
            }
            return;
        }

        $this->activeProject = $this->projects->apply($slug);
    }

    /**
     * @param array<string, mixed> $result
     */
    private function reportFileResult(string $headline, array $result): void
    {
        $this->io->success($headline);

        foreach (array_values($result['written'] ?? []) as $path) {
            $this->io->line('  + ' . $path);
        }
        foreach (array_values($result['removed'] ?? []) as $path) {
            $this->io->line('  - ' . $path);
        }
        foreach (array_values($result['backups'] ?? []) as $path) {
            $this->io->line('  ~ ' . $path);
        }
        foreach (array_values($result['missing'] ?? []) as $path) {
            $this->io->line('  ? ' . $path);
        }
    }

    /**
     * @param array<string, mixed> $options
     */
    private function confirmDestructive(string $prompt, array $options): bool
    {
        if ($this->boolOption($options, 'force', false)) {
            return true;
        }

        return $this->io->confirm($prompt, false);
    }

    /**
     * @param array<int, string> $args
     * @param array<string, mixed> $options
     */
    private function resourceDslInput(array $args, array $options): string
    {
        $file = trim((string)($options['file'] ?? ''));
        if ($file !== '') {
            $path = $this->resolveInputPath($file);
            $contents = @file_get_contents($path);
            if (!is_string($contents)) {
                throw new RuntimeException('Failed to read schema DSL file: ' . $path);
            }
            return $contents;
        }

        $statement = trim((string)($options['statement'] ?? ''));
        if ($statement !== '') {
            return $statement;
        }

        $joined = trim(implode(' ', $args));
        if ($joined === '') {
            throw new RuntimeException('A schema DSL statement or --file path is required.');
        }

        $path = $this->resolveInputPath($joined, false);
        if ($path !== null) {
            $contents = @file_get_contents($path);
            if (!is_string($contents)) {
                throw new RuntimeException('Failed to read schema DSL file: ' . $path);
            }
            return $contents;
        }

        return $joined;
    }

    private function resolveInputPath(string $value, bool $required = true): ?string
    {
        $candidate = str_starts_with($value, DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $value) === 1
            ? $value
            : $this->rootPath . '/' . ltrim(str_replace('\\', '/', $value), '/');

        if (is_file($candidate)) {
            return $candidate;
        }

        if ($required) {
            throw new RuntimeException('Schema DSL file not found: ' . $candidate);
        }

        return null;
    }

    /**
     * @param array<string, mixed> $options
     */
    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }

    /**
     * @param array<int, string> $paths
     * @return array<int, string>
     */
    private function migrationIdsFromPaths(array $paths): array
    {
        return array_values(array_unique(array_map(
            static fn (string $path): string => pathinfo($path, PATHINFO_FILENAME),
            $paths
        )));
    }

    /**
     * @param array<string, mixed> $options
     */
    private function wantsJson(array $options): bool
    {
        if ($this->boolOption($options, 'json', false)) {
            return true;
        }

        return strtolower(trim((string)($options['format'] ?? ''))) === 'json';
    }

    private function renderJson(mixed $payload): void
    {
        $encoded = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode JSON output.');
        }

        $this->io->line($encoded);
    }

    private function truncate(string $value, int $max): string
    {
        $clean = trim($value);
        if ($clean === '' || strlen($clean) <= $max) {
            return $clean;
        }

        return rtrim(substr($clean, 0, max(1, $max - 3))) . '...';
    }
}
