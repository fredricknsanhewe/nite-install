<?php
namespace App\Console;

use App\Config\App;
use RuntimeException;

final class ResourceDefinitionManager
{
    /** @var array<int, string> */
    private const PUBLIC_ROLES = ['guest', 'public', 'anonymous', 'all', 'anyone'];

    /** @var array<string, array<int, string>> */
    private const ACTION_ALIASES = [
        'read' => ['list', 'show', 'admin_list', 'admin_show'],
        'view' => ['list', 'show', 'admin_list', 'admin_show'],
        'browse' => ['list'],
        'index' => ['list'],
        'detail' => ['show'],
        'manage' => ['admin_list', 'admin_show', 'create', 'update', 'delete'],
        'write' => ['create', 'update', 'delete'],
        'edit' => ['update'],
        'remove' => ['delete'],
        'drop' => ['delete'],
    ];

    /** @var array<int, string> */
    private const SUPPORTED_ACTIONS = ['list', 'show', 'admin_list', 'admin_show', 'create', 'update', 'delete'];

    private string $rootPath;
    private ScaffoldGenerator $scaffolds;
    private MigrationManager $migrations;
    private ResourceDefinitionParser $parser;

    public function __construct(
        ?string $rootPath = null,
        ?ScaffoldGenerator $scaffolds = null,
        ?MigrationManager $migrations = null,
        ?ResourceDefinitionParser $parser = null
    ) {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
        $this->scaffolds = $scaffolds ?? new ScaffoldGenerator($this->rootPath);
        $this->migrations = $migrations ?? new MigrationManager($this->rootPath);
        $this->parser = $parser ?? new ResourceDefinitionParser();
    }

    /**
     * @return array<string, mixed>
     */
    public function explain(string $input): array
    {
        $statements = $this->parser->parse($input);
        $explained = [];
        $warnings = [];

        foreach ($statements as $statement) {
            $summary = [
                'kind' => (string)($statement['kind'] ?? ''),
                'verb' => (string)($statement['verb'] ?? ''),
            ];

            if (($statement['kind'] ?? '') === 'component') {
                $summary['noun'] = strtolower((string)($statement['noun'] ?? ''));
                $summary['name'] = (string)($statement['name'] ?? '');
                $explained[] = $summary;
                continue;
            }

            if (($statement['kind'] ?? '') !== 'resource') {
                $explained[] = $summary;
                continue;
            }

            if (($statement['verb'] ?? '') === 'CREATE') {
                [$resource, $resourceWarnings] = $this->compileCreateResourceDefinition((array)$statement['resource'], []);
                $warnings = array_merge($warnings, $resourceWarnings);
                $summary['resource'] = $this->resourcePreview($resource);
                $explained[] = $summary;
                continue;
            }

            if (($statement['verb'] ?? '') === 'ALTER') {
                $name = (string)($statement['resource_name'] ?? '');
                $existing = $this->findDefinition($name);
                if ($existing === null) {
                    $warnings[] = 'ALTER RESOURCE `' . $name . '` could not be previewed because no stored resource definition was found.';
                    $summary['resource_name'] = $name;
                    $summary['operations'] = $statement['operations'] ?? [];
                    $explained[] = $summary;
                    continue;
                }

                [$resource, $resourceWarnings] = $this->applyAlterOperations($existing, (array)($statement['operations'] ?? []));
                $warnings = array_merge($warnings, $resourceWarnings);
                $summary['resource'] = $this->resourcePreview($resource);
                $explained[] = $summary;
                continue;
            }

            $summary['resource_name'] = (string)($statement['resource_name'] ?? '');
            $explained[] = $summary;
        }

        return [
            'statements' => $explained,
            'warnings' => array_values(array_unique($warnings)),
        ];
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function apply(string $input, array $options = []): array
    {
        $statements = $this->parser->parse($input);
        $result = $this->emptyResult();

        foreach ($statements as $statement) {
            $statementResult = match ((string)($statement['kind'] ?? '')) {
                'component' => $this->applyComponentStatement($statement, $options),
                'resource' => $this->applyResourceStatement($statement, $options),
                default => throw new RuntimeException('Unsupported resource DSL statement kind.'),
            };

            $result = $this->mergeResults($result, $statementResult);
        }

        if ($this->boolOption($options, 'migrate', false)) {
            $migrationResult = $this->migrations->migrate();
            $result['database'] = [
                'status' => 'migrated',
                'driver' => (string)($migrationResult['driver'] ?? ''),
                'applied_count' => (int)($migrationResult['applied_count'] ?? 0),
            ];
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $statement
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function applyComponentStatement(array $statement, array $options): array
    {
        $noun = strtolower((string)($statement['noun'] ?? ''));
        $name = (string)($statement['name'] ?? '');
        $verb = strtoupper((string)($statement['verb'] ?? ''));

        $result = $verb === 'CREATE'
            ? $this->scaffolds->create($noun, $name, $options)
            : $this->scaffolds->remove($noun, $name, $options);

        $result['applied'] = [[
            'kind' => 'component',
            'verb' => $verb,
            'noun' => $noun,
            'name' => $name,
        ]];

        return $result;
    }

    /**
     * @param array<string, mixed> $statement
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function applyResourceStatement(array $statement, array $options): array
    {
        return match (strtoupper((string)($statement['verb'] ?? ''))) {
            'CREATE' => $this->createResource($statement, $options),
            'ALTER' => $this->alterResource($statement, $options),
            'DROP' => $this->dropResource($statement, $options),
            default => throw new RuntimeException('Unsupported resource DSL verb.'),
        };
    }

    /**
     * @param array<string, mixed> $statement
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function createResource(array $statement, array $options): array
    {
        [$resource, $warnings] = $this->compileCreateResourceDefinition((array)$statement['resource'], $options);
        if ($this->findDefinition((string)$resource['route_segment']) !== null) {
            throw new RuntimeException('Resource `' . (string)$resource['route_segment'] . '` already exists. Use ALTER RESOURCE or DROP RESOURCE first.');
        }

        $version = $this->stringOption($options, 'version') ?: App::VERSION;
        $resource['paths'] = $this->artifactPaths($resource);

        $migrationPath = $this->migrationDirectory() . '/' . ConsoleSupport::timestamp() . '_create_' . (string)$resource['table'] . '_table.php';
        $resource['migrations'] = [[
            'id' => pathinfo($migrationPath, PATHINFO_FILENAME),
            'path' => $this->relativePath($migrationPath),
            'name' => 'create_' . (string)$resource['table'] . '_table',
        ]];

        $files = $this->resourceFileMap($resource, $version, [
            $migrationPath => $this->createMigrationTemplate($resource, $version),
        ]);

        $result = $this->writeFiles($files, $options);
        $result['warnings'] = $warnings;
        $result['applied'] = [[
            'kind' => 'resource',
            'verb' => 'CREATE',
            'resource_key' => (string)$resource['key'],
            'table' => (string)$resource['table'],
            'route_segment' => (string)$resource['route_segment'],
        ]];

        return $result;
    }

    /**
     * @param array<string, mixed> $statement
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function alterResource(array $statement, array $options): array
    {
        $name = (string)($statement['resource_name'] ?? '');
        $existing = $this->requireDefinition($name);
        [$resource, $warnings] = $this->applyAlterOperations($existing, (array)($statement['operations'] ?? []));
        $version = $this->stringOption($options, 'version') ?: App::VERSION;

        $extraFiles = [];
        $migrationWarnings = [];
        $migrationFile = $this->buildAlterMigration($existing, $resource, $version);
        if ($migrationFile !== null) {
            $migrationPath = $migrationFile['path'];
            $extraFiles[$migrationPath] = (string)$migrationFile['content'];

            $resource['migrations'] = array_values(array_merge(
                is_array($existing['migrations'] ?? null) ? $existing['migrations'] : [],
                [[
                    'id' => pathinfo($migrationPath, PATHINFO_FILENAME),
                    'path' => $this->relativePath($migrationPath),
                    'name' => (string)($migrationFile['name'] ?? ''),
                ]]
            ));
            $migrationWarnings = array_values(is_array($migrationFile['warnings'] ?? null) ? $migrationFile['warnings'] : []);
        } else {
            $resource['migrations'] = array_values(is_array($existing['migrations'] ?? null) ? $existing['migrations'] : []);
        }

        $resource['paths'] = $this->artifactPaths($resource);
        $writeOptions = $options;
        $writeOptions['force'] = true;
        $result = $this->writeFiles($this->resourceFileMap($resource, $version, $extraFiles), $writeOptions);
        $result['warnings'] = array_values(array_unique(array_merge($warnings, $migrationWarnings)));
        $result['applied'] = [[
            'kind' => 'resource',
            'verb' => 'ALTER',
            'resource_key' => (string)$resource['key'],
            'table' => (string)$resource['table'],
            'route_segment' => (string)$resource['route_segment'],
        ]];

        return $result;
    }

    /**
     * @param array<string, mixed> $statement
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function dropResource(array $statement, array $options): array
    {
        $resource = $this->requireDefinition((string)($statement['resource_name'] ?? ''));
        $paths = [];

        foreach ((array)($resource['paths'] ?? []) as $path) {
            if (is_string($path) && trim($path) !== '') {
                $paths[] = $this->rootPath . '/' . ltrim($path, '/');
            }
        }

        if (!$this->boolOption($options, 'keep-migrations', false)) {
            foreach ((array)($resource['migrations'] ?? []) as $migration) {
                if (is_array($migration) && trim((string)($migration['path'] ?? '')) !== '') {
                    $paths[] = $this->rootPath . '/' . ltrim((string)$migration['path'], '/');
                }
            }
        }

        if ($this->boolOption($options, 'rollback', false)) {
            $ids = [];
            foreach ((array)($resource['migrations'] ?? []) as $migration) {
                if (is_array($migration) && trim((string)($migration['id'] ?? '')) !== '') {
                    $ids[] = (string)$migration['id'];
                }
            }
            if ($ids !== []) {
                $this->migrations->rollbackIds($ids);
            }
        }

        $result = $this->removePaths($paths, $options);
        $result['applied'] = [[
            'kind' => 'resource',
            'verb' => 'DROP',
            'resource_key' => (string)($resource['key'] ?? ''),
            'table' => (string)($resource['table'] ?? ''),
            'route_segment' => (string)($resource['route_segment'] ?? ''),
        ]];

        return $result;
    }

    /**
     * @param array<string, mixed> $resourceInput
     * @param array<string, mixed> $options
     * @return array{0: array<string, mixed>, 1: array<int, string>}
     */
    private function compileCreateResourceDefinition(array $resourceInput, array $options): array
    {
        $warnings = [];
        $table = ConsoleSupport::snake((string)($resourceInput['table'] ?? ''));
        if ($table === '') {
            $name = ConsoleSupport::snake((string)($resourceInput['name'] ?? ''));
            $table = ConsoleSupport::pluralize(ConsoleSupport::singularize($name));
        }

        $base = ConsoleSupport::studly(ConsoleSupport::singularize((string)($resourceInput['name'] ?? $table)));
        if ($base === '') {
            throw new RuntimeException('A resource name is required.');
        }

        $routeSegment = trim((string)($resourceInput['route_segment'] ?? ''));
        if ($routeSegment === '') {
            $routeSegment = ConsoleSupport::kebab($table);
        }

        $labelPlural = trim((string)($resourceInput['label'] ?? ''));
        if ($labelPlural === '') {
            $labelPlural = ucwords(str_replace('_', ' ', $table));
        }
        $labelSingular = ConsoleSupport::singularize($labelPlural);
        $itemType = trim((string)($resourceInput['item_type'] ?? ''));
        if ($itemType === '') {
            $itemType = $labelSingular;
        }

        $rawFields = is_array($resourceInput['fields'] ?? null) ? $resourceInput['fields'] : [];
        $fields = array_values(array_map(fn (array $field): array => $this->normalizeFieldDefinition($field, $warnings), $rawFields));
        $fields = $this->ensureStandardFields($fields);
        $fields = $this->normalizeFieldFlags($fields);

        $primaryField = $this->primaryField($fields);
        $publicLookupField = trim((string)($resourceInput['public_lookup'] ?? ''));
        if ($publicLookupField === '') {
            $publicLookupField = $this->detectPublicLookupField($fields);
        }
        $fields = $this->applyPublicLookupSelection($fields, $publicLookupField);
        $publicLookupField = $this->detectPublicLookupField($fields);

        if ($publicLookupField === '') {
            $warnings[] = 'No public lookup field was selected; the public show route will not be generated until one field is marked PUBLIC.';
        }

        $accessRules = is_array($resourceInput['access_rules'] ?? null) ? $resourceInput['access_rules'] : [];
        if ($accessRules === []) {
            $accessRules = $this->defaultAccessRules();
        }

        $access = $this->compileAccessPolicy($accessRules, $warnings);

        $resource = [
            'schema_kind' => 'nite_resource',
            'schema_version' => 1,
            'name' => (string)($resourceInput['name'] ?? $table),
            'base' => $base,
            'key' => $table,
            'table' => $table,
            'group' => ConsoleSupport::snake((string)($resourceInput['group'] ?? 'generated')) ?: 'generated',
            'route_segment' => $routeSegment,
            'label' => $labelPlural,
            'label_singular' => $labelSingular,
            'item_type' => $itemType,
            'summary' => trim((string)($resourceInput['summary'] ?? ('Generated resource for ' . strtolower($labelPlural) . '.'))),
            'primary_field' => (string)($primaryField['name'] ?? 'id'),
            'public_lookup_field' => $publicLookupField,
            'public_visibility' => $this->detectPublicVisibility($fields),
            'fields' => $fields,
            'access' => $access,
            'paths' => [],
            'migrations' => [],
            'meta' => [
                'version' => $this->stringOption($options, 'version') ?: App::VERSION,
                'generated_at' => gmdate('c'),
            ],
        ];

        return [$resource, array_values(array_unique($warnings))];
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<int, array<string, mixed>> $operations
     * @return array{0: array<string, mixed>, 1: array<int, string>}
     */
    private function applyAlterOperations(array $resource, array $operations): array
    {
        $warnings = [];
        $fields = array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []);
        $accessRules = array_values((array)($resource['access']['rules'] ?? []));

        foreach ($operations as $operation) {
            $type = (string)($operation['type'] ?? '');
            if ($type === 'add_field') {
                $field = $this->normalizeFieldDefinition((array)$operation['field'], $warnings);
                $names = array_map(static fn (array $item): string => (string)($item['name'] ?? ''), $fields);
                if (in_array((string)$field['name'], $names, true)) {
                    throw new RuntimeException('Field `' . (string)$field['name'] . '` already exists on resource `' . (string)($resource['key'] ?? '') . '`.');
                }
                $fields[] = $field;
                continue;
            }

            if ($type === 'modify_field') {
                $field = $this->normalizeFieldDefinition((array)$operation['field'], $warnings);
                $modified = false;
                foreach ($fields as $index => $current) {
                    if ((string)($current['name'] ?? '') !== (string)$field['name']) {
                        continue;
                    }
                    $fields[$index] = array_merge($current, $field);
                    $modified = true;
                    break;
                }
                if (!$modified) {
                    throw new RuntimeException('Field `' . (string)$field['name'] . '` does not exist on resource `' . (string)($resource['key'] ?? '') . '`.');
                }
                continue;
            }

            if ($type === 'drop_field') {
                $target = ConsoleSupport::snake((string)($operation['name'] ?? ''));
                $fields = array_values(array_filter($fields, static fn (array $field): bool => (string)($field['name'] ?? '') !== $target));
                continue;
            }

            if ($type === 'grant_access') {
                $rule = (array)($operation['rule'] ?? []);
                $rule['effect'] = 'allow';
                $accessRules[] = $rule;
                continue;
            }

            if ($type === 'revoke_access') {
                $rule = (array)($operation['rule'] ?? []);
                $rule['effect'] = 'deny';
                $accessRules[] = $rule;
                continue;
            }

            if ($type === 'replace_access') {
                $accessRules = array_values(is_array($operation['rules'] ?? null) ? $operation['rules'] : []);
                continue;
            }

            if ($type === 'set_group') {
                $resource['group'] = ConsoleSupport::snake((string)($operation['value'] ?? '')) ?: 'generated';
                continue;
            }

            if ($type === 'set_label') {
                $resource['label'] = trim((string)($operation['value'] ?? '')) ?: (string)($resource['label'] ?? '');
                $resource['label_singular'] = ConsoleSupport::singularize((string)$resource['label']);
                continue;
            }

            if ($type === 'set_summary') {
                $resource['summary'] = trim((string)($operation['value'] ?? ''));
                continue;
            }

            if ($type === 'set_item_type') {
                $resource['item_type'] = trim((string)($operation['value'] ?? '')) ?: (string)($resource['item_type'] ?? '');
                continue;
            }

            if ($type === 'set_route_segment') {
                $resource['route_segment'] = ConsoleSupport::kebab((string)($operation['value'] ?? '')) ?: (string)($resource['route_segment'] ?? '');
                continue;
            }

            if ($type === 'set_table') {
                $resource['table'] = ConsoleSupport::snake((string)($operation['value'] ?? '')) ?: (string)($resource['table'] ?? '');
                $resource['key'] = (string)$resource['table'];
                continue;
            }

            if ($type === 'set_public_lookup') {
                $resource['public_lookup_field'] = ConsoleSupport::snake((string)($operation['value'] ?? ''));
                continue;
            }
        }

        $fields = $this->ensureStandardFields($fields);
        $fields = $this->normalizeFieldFlags($fields);
        $fields = $this->applyPublicLookupSelection($fields, (string)($resource['public_lookup_field'] ?? ''));
        $resource['public_lookup_field'] = $this->detectPublicLookupField($fields);
        $resource['primary_field'] = (string)($this->primaryField($fields)['name'] ?? 'id');
        $resource['fields'] = $fields;
        $resource['public_visibility'] = $this->detectPublicVisibility($fields);
        $resource['access'] = $this->compileAccessPolicy($accessRules !== [] ? $accessRules : $this->defaultAccessRules(), $warnings);

        return [$resource, array_values(array_unique($warnings))];
    }

    /**
     * @param array<string, mixed> $field
     * @param array<int, string> $warnings
     * @return array<string, mixed>
     */
    private function normalizeFieldDefinition(array $field, array &$warnings): array
    {
        $type = strtolower(trim((string)($field['type'] ?? 'string')));
        $parameters = array_values(is_array($field['parameters'] ?? null) ? $field['parameters'] : []);
        $options = [];
        $dataType = 'string';
        $format = trim((string)($field['format'] ?? ''));
        $length = null;
        $precision = null;
        $scale = null;

        switch ($type) {
            case 'uuid':
                $dataType = 'string';
                $format = $format !== '' ? $format : 'uuid';
                break;
            case 'string':
            case 'varchar':
                $type = 'string';
                $dataType = 'string';
                $length = max(1, (int)($parameters[0] ?? 255));
                break;
            case 'text':
                $dataType = 'string';
                break;
            case 'integer':
            case 'int':
                $type = 'integer';
                $dataType = 'integer';
                break;
            case 'bigint':
                $dataType = 'integer';
                break;
            case 'decimal':
            case 'numeric':
                $type = 'decimal';
                $dataType = 'number';
                $precision = max(1, (int)($parameters[0] ?? 10));
                $scale = max(0, (int)($parameters[1] ?? 2));
                break;
            case 'boolean':
            case 'bool':
                $type = 'boolean';
                $dataType = 'boolean';
                break;
            case 'json':
            case 'object':
                $type = 'json';
                $dataType = 'object';
                break;
            case 'date':
                $dataType = 'string';
                $format = $format !== '' ? $format : 'date';
                break;
            case 'datetime':
            case 'timestamp':
                $type = 'timestamp';
                $dataType = 'string';
                $format = $format !== '' ? $format : 'date-time';
                break;
            case 'enum':
                $dataType = 'string';
                $options = array_values(array_filter(array_map(static fn (mixed $value): string => trim((string)$value), $parameters), static fn (string $value): bool => $value !== ''));
                $length = max(32, ...array_map('strlen', $options ?: ['']));
                break;
            default:
                $warnings[] = 'Unknown field type `' . $type . '` was compiled as a string column.';
                $type = 'string';
                $dataType = 'string';
                $length = max(1, (int)($parameters[0] ?? 255));
                break;
        }

        $name = ConsoleSupport::snake((string)($field['name'] ?? ''));
        if ($name === '') {
            throw new RuntimeException('Each resource field needs a valid name.');
        }

        $default = $field['default'] ?? null;
        if ($type === 'json' && $field['has_default'] ?? false) {
            if (is_string($default) && trim($default) !== '') {
                $decoded = json_decode((string)$default, true);
                if ($decoded !== null || trim((string)$default) === 'null') {
                    $default = $decoded;
                }
            }
            if ($default === '{}' || $default === [] || $default === null) {
                $default = [];
            }
        }

        return [
            'name' => $name,
            'database_column' => $name,
            'type' => $type,
            'data_type' => $dataType,
            'format' => $format === '' ? null : $format,
            'parameters' => $parameters,
            'length' => $length,
            'precision' => $precision,
            'scale' => $scale,
            'nullable' => (bool)($field['nullable'] ?? false),
            'required' => (bool)($field['required'] ?? false),
            'required_on_create' => false,
            'required_on_update' => false,
            'read_only' => (bool)($field['read_only'] ?? false),
            'write_only' => (bool)($field['write_only'] ?? false),
            'primary' => (bool)($field['primary'] ?? false),
            'auto' => (bool)($field['auto'] ?? false),
            'generated' => (bool)($field['generated'] ?? false),
            'unique' => (bool)($field['unique'] ?? false),
            'index' => (bool)($field['index'] ?? false),
            'searchable' => (bool)($field['searchable'] ?? false),
            'filterable' => (bool)($field['filterable'] ?? false),
            'public_lookup' => (bool)($field['public_lookup'] ?? false),
            'default' => $default,
            'has_default' => (bool)($field['has_default'] ?? false),
            'options' => $options,
            'references' => is_array($field['references'] ?? null) ? $field['references'] : null,
            'relationship' => is_array($field['relationship'] ?? null) ? $field['relationship'] : null,
            'label' => trim((string)($field['label'] ?? '')),
            'description' => trim((string)($field['description'] ?? '')),
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private function ensureStandardFields(array $fields): array
    {
        $names = array_fill_keys(array_map(static fn (array $field): string => (string)($field['name'] ?? ''), $fields), true);

        if (!isset($names['id'])) {
            array_unshift($fields, [
                'name' => 'id',
                'database_column' => 'id',
                'type' => 'uuid',
                'data_type' => 'string',
                'format' => 'uuid',
                'parameters' => [],
                'length' => null,
                'precision' => null,
                'scale' => null,
                'nullable' => false,
                'required' => false,
                'required_on_create' => false,
                'required_on_update' => false,
                'read_only' => true,
                'write_only' => false,
                'primary' => true,
                'auto' => true,
                'generated' => true,
                'unique' => true,
                'index' => false,
                'searchable' => false,
                'filterable' => false,
                'public_lookup' => false,
                'default' => null,
                'has_default' => false,
                'options' => [],
                'references' => null,
                'relationship' => null,
                'label' => 'ID',
                'description' => 'Primary resource identifier.',
            ]);
        }

        if (!isset($names['created_at'])) {
            $fields[] = [
                'name' => 'created_at',
                'database_column' => 'created_at',
                'type' => 'timestamp',
                'data_type' => 'string',
                'format' => 'date-time',
                'parameters' => [],
                'length' => null,
                'precision' => null,
                'scale' => null,
                'nullable' => false,
                'required' => false,
                'required_on_create' => false,
                'required_on_update' => false,
                'read_only' => true,
                'write_only' => false,
                'primary' => false,
                'auto' => true,
                'generated' => true,
                'unique' => false,
                'index' => false,
                'searchable' => false,
                'filterable' => false,
                'public_lookup' => false,
                'default' => null,
                'has_default' => false,
                'options' => [],
                'references' => null,
                'relationship' => null,
                'label' => 'Created At',
                'description' => 'Creation timestamp.',
            ];
        }

        if (!isset($names['updated_at'])) {
            $fields[] = [
                'name' => 'updated_at',
                'database_column' => 'updated_at',
                'type' => 'timestamp',
                'data_type' => 'string',
                'format' => 'date-time',
                'parameters' => [],
                'length' => null,
                'precision' => null,
                'scale' => null,
                'nullable' => false,
                'required' => false,
                'required_on_create' => false,
                'required_on_update' => false,
                'read_only' => true,
                'write_only' => false,
                'primary' => false,
                'auto' => true,
                'generated' => true,
                'unique' => false,
                'index' => false,
                'searchable' => false,
                'filterable' => false,
                'public_lookup' => false,
                'default' => null,
                'has_default' => false,
                'options' => [],
                'references' => null,
                'relationship' => null,
                'label' => 'Updated At',
                'description' => 'Last update timestamp.',
            ];
        }

        return array_values($fields);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private function normalizeFieldFlags(array $fields): array
    {
        foreach ($fields as $index => $field) {
            $isSystem = in_array((string)($field['name'] ?? ''), ['id', 'created_at', 'updated_at'], true);
            $hasDefault = (bool)($field['has_default'] ?? false);
            $nullable = (bool)($field['nullable'] ?? false);
            $auto = (bool)($field['auto'] ?? false) || $isSystem;
            $readOnly = (bool)($field['read_only'] ?? false) || $isSystem;
            $required = (bool)($field['required'] ?? false);

            $fields[$index]['auto'] = $auto;
            $fields[$index]['generated'] = (bool)($field['generated'] ?? false) || $isSystem;
            $fields[$index]['read_only'] = $readOnly;
            $fields[$index]['required_on_create'] = !$readOnly && !$auto && !$nullable && !$hasDefault && $required;
            $fields[$index]['required_on_update'] = false;

            if ((string)($field['type'] ?? '') === 'enum') {
                $fields[$index]['filterable'] = true;
            }
            if ((string)($field['type'] ?? '') === 'boolean') {
                $fields[$index]['filterable'] = true;
            }
            if (is_array($field['references'] ?? null)) {
                $fields[$index]['filterable'] = true;
                $fields[$index]['index'] = true;
            }
            if ((string)($field['name'] ?? '') === 'status') {
                $fields[$index]['filterable'] = true;
            }
            if (in_array((string)($field['name'] ?? ''), ['slug', 'title', 'name', 'summary'], true)) {
                $fields[$index]['searchable'] = true;
            }
        }

        return $fields;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, mixed>
     */
    private function primaryField(array $fields): array
    {
        foreach ($fields as $field) {
            if ((bool)($field['primary'] ?? false)) {
                return $field;
            }
        }

        return $fields[0] ?? ['name' => 'id'];
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     */
    private function detectPublicLookupField(array $fields): string
    {
        foreach ($fields as $field) {
            if ((bool)($field['public_lookup'] ?? false)) {
                return (string)($field['name'] ?? '');
            }
        }

        foreach (['slug', 'code', 'name'] as $candidate) {
            foreach ($fields as $field) {
                if ((string)($field['name'] ?? '') === $candidate) {
                    return $candidate;
                }
            }
        }

        return '';
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private function applyPublicLookupSelection(array $fields, string $publicLookupField): array
    {
        $normalized = ConsoleSupport::snake($publicLookupField);
        foreach ($fields as $index => $field) {
            $fields[$index]['public_lookup'] = $normalized !== '' && (string)($field['name'] ?? '') === $normalized;
        }

        return $fields;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, mixed>|null
     */
    private function detectPublicVisibility(array $fields): ?array
    {
        foreach ($fields as $field) {
            if ((string)($field['name'] ?? '') === 'status' && in_array('published', (array)($field['options'] ?? []), true)) {
                return [
                    'field' => 'status',
                    'operator' => '=',
                    'value' => 'published',
                ];
            }

            if ((string)($field['name'] ?? '') === 'published' && (string)($field['type'] ?? '') === 'boolean') {
                return [
                    'field' => 'published',
                    'operator' => '=',
                    'value' => true,
                ];
            }
        }

        return null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function defaultAccessRules(): array
    {
        return [
            [
                'effect' => 'allow',
                'subject' => 'guest',
                'roles' => ['guest'],
                'derivable' => true,
                'actions' => ['list', 'show'],
            ],
            [
                'effect' => 'allow',
                'subject' => 'role.support',
                'roles' => ['support'],
                'derivable' => true,
                'actions' => ['admin_list', 'admin_show'],
            ],
            [
                'effect' => 'allow',
                'subject' => 'role.editor',
                'roles' => ['editor'],
                'derivable' => true,
                'actions' => ['admin_list', 'admin_show', 'create', 'update', 'delete'],
            ],
            [
                'effect' => 'allow',
                'subject' => 'role.admin',
                'roles' => ['admin'],
                'derivable' => true,
                'actions' => ['admin_list', 'admin_show', 'create', 'update', 'delete'],
            ],
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @param array<int, string> $warnings
     * @return array<string, mixed>
     */
    private function compileAccessPolicy(array $rules, array &$warnings): array
    {
        $matrix = [];
        foreach (self::SUPPORTED_ACTIONS as $action) {
            $matrix[$action] = [
                'allow_roles' => [],
                'deny_roles' => [],
                'default_roles' => [],
                'public' => false,
            ];
        }

        foreach ($rules as $rule) {
            $actions = $this->expandActions(array_values(is_array($rule['actions'] ?? null) ? $rule['actions'] : []), $warnings);
            $roles = array_values(array_filter(array_map(static fn (mixed $value): string => strtolower(trim((string)$value)), is_array($rule['roles'] ?? null) ? $rule['roles'] : []), static fn (string $value): bool => $value !== ''));
            $effect = strtolower(trim((string)($rule['effect'] ?? 'allow'))) === 'deny' ? 'deny' : 'allow';

            if (!$actions) {
                continue;
            }

            if (!(bool)($rule['derivable'] ?? false)) {
                $warnings[] = 'Access rule `' . (string)($rule['subject'] ?? '') . '` uses a complex boolean expression. It was preserved in the blueprint but not compiled into default role grants.';
                continue;
            }

            foreach ($actions as $action) {
                if (!isset($matrix[$action])) {
                    continue;
                }

                foreach ($roles as $role) {
                    if ($effect === 'deny') {
                        $matrix[$action]['deny_roles'][] = $role;
                        continue;
                    }

                    $matrix[$action]['allow_roles'][] = $role;
                }
            }
        }

        foreach ($matrix as $action => $row) {
            $allowRoles = array_values(array_unique(array_map('strval', (array)$row['allow_roles'])));
            $denyRoles = array_values(array_unique(array_map('strval', (array)$row['deny_roles'])));
            $public = array_intersect($allowRoles, self::PUBLIC_ROLES) !== [];
            $defaultRoles = array_values(array_diff($allowRoles, $denyRoles, self::PUBLIC_ROLES));

            $matrix[$action] = [
                'allow_roles' => $allowRoles,
                'deny_roles' => $denyRoles,
                'default_roles' => $defaultRoles,
                'public' => $public,
            ];
        }

        return [
            'rules' => $rules,
            'matrix' => $matrix,
        ];
    }

    /**
     * @param array<int, string> $actions
     * @param array<int, string> $warnings
     * @return array<int, string>
     */
    private function expandActions(array $actions, array &$warnings): array
    {
        $expanded = [];
        foreach ($actions as $action) {
            $normalized = strtolower(trim($action));
            if ($normalized === '') {
                continue;
            }

            if (isset(self::ACTION_ALIASES[$normalized])) {
                $expanded = array_merge($expanded, self::ACTION_ALIASES[$normalized]);
                continue;
            }

            if (in_array($normalized, self::SUPPORTED_ACTIONS, true)) {
                $expanded[] = $normalized;
                continue;
            }

            $warnings[] = 'Unsupported action alias `' . $normalized . '` was ignored.';
        }

        return array_values(array_unique($expanded));
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, string>
     */
    private function artifactPaths(array $resource): array
    {
        $base = (string)$resource['base'];
        $routeSegment = (string)$resource['route_segment'];

        return [
            'model' => 'src/Models/' . $base . 'Model.php',
            'service' => 'src/Services/' . $base . 'Service.php',
            'controller' => 'src/Controllers/' . $base . 'Controller.php',
            'manifest' => 'routes/generated/' . $routeSegment . '.php',
            'route_snippet' => 'examples/generated/' . $routeSegment . '.routes.php',
            'definition' => 'blueprints/resources/' . $routeSegment . '.resource.json',
        ];
    }

    private function migrationDirectory(): string
    {
        return $this->rootPath . '/database/migrations';
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<string, string> $extraFiles
     * @return array<string, string>
     */
    private function resourceFileMap(array $resource, string $version, array $extraFiles = []): array
    {
        $paths = is_array($resource['paths'] ?? null) ? $resource['paths'] : [];

        $files = [
            $this->rootPath . '/' . (string)$paths['model'] => $this->modelTemplate($resource),
            $this->rootPath . '/' . (string)$paths['service'] => $this->serviceTemplate($resource),
            $this->rootPath . '/' . (string)$paths['controller'] => $this->controllerTemplate($resource),
            $this->rootPath . '/' . (string)$paths['manifest'] => $this->manifestTemplate($resource, $version),
            $this->rootPath . '/' . (string)$paths['route_snippet'] => $this->routeSnippetTemplate($resource),
            $this->rootPath . '/' . (string)$paths['definition'] => $this->definitionTemplate($resource),
        ];

        foreach ($extraFiles as $path => $content) {
            $files[$path] = $content;
        }

        return $files;
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function definitionTemplate(array $resource): string
    {
        $payload = $resource;
        $payload['paths'] = array_map('strval', is_array($resource['paths'] ?? null) ? $resource['paths'] : []);
        $payload['migrations'] = array_values(is_array($resource['migrations'] ?? null) ? $resource['migrations'] : []);

        $encoded = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode the generated resource blueprint JSON.');
        }

        return $encoded . PHP_EOL;
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function modelTemplate(array $resource): string
    {
        $fields = array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []);
        $fieldMap = [];
        foreach ($fields as $field) {
            $fieldMap[(string)$field['name']] = $field;
        }

        $searchColumns = array_values(array_map(
            static fn (array $field): string => (string)$field['database_column'],
            array_values(array_filter($fields, static fn (array $field): bool => (bool)($field['searchable'] ?? false)))
        ));
        $filterFields = array_values(array_map(
            static fn (array $field): string => (string)$field['name'],
            array_values(array_filter($fields, static fn (array $field): bool => (bool)($field['filterable'] ?? false)))
        ));
        $createFields = array_values(array_map(
            static fn (array $field): string => (string)$field['name'],
            array_values(array_filter($fields, static fn (array $field): bool => !(bool)($field['read_only'] ?? false)))
        ));
        $updateFields = $createFields;

        $publicVisibility = is_array($resource['public_visibility'] ?? null) ? $resource['public_visibility'] : null;
        $orderColumns = array_values(array_filter(['updated_at', 'created_at', (string)($resource['primary_field'] ?? 'id')], static fn (string $value): bool => $value !== ''));

        $template = <<<'PHP'
<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class {{Base}}Model extends BaseModel
{
    private const TABLE = {{table}};
    private const PRIMARY_FIELD = {{primary_field}};
    private const PUBLIC_LOOKUP_FIELD = {{public_lookup_field}};
    private const PUBLIC_VISIBILITY = {{public_visibility}};
    private const FIELD_MAP = {{field_map}};
    private const SEARCH_COLUMNS = {{search_columns}};
    private const FILTER_FIELDS = {{filter_fields}};
    private const CREATE_FIELDS = {{create_fields}};
    private const UPDATE_FIELDS = {{update_fields}};
    private const ORDER_COLUMNS = {{order_columns}};

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin && is_array(self::PUBLIC_VISIBILITY)) {
            $where[] = self::PUBLIC_VISIBILITY['field'] . ' = :_public_visibility';
            $params[':_public_visibility'] = self::PUBLIC_VISIBILITY['value'];
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '' && self::SEARCH_COLUMNS !== []) {
            $where[] = $this->likeAny(self::SEARCH_COLUMNS);
            $params[':q'] = '%' . $q . '%';
        }

        foreach (self::FILTER_FIELDS as $fieldName) {
            if (!array_key_exists($fieldName, $filters)) {
                continue;
            }

            $field = self::FIELD_MAP[$fieldName] ?? null;
            if (!is_array($field)) {
                continue;
            }

            if (!$admin && is_array(self::PUBLIC_VISIBILITY) && (string)($field['name'] ?? '') === (string)(self::PUBLIC_VISIBILITY['field'] ?? '')) {
                continue;
            }

            $normalized = $this->normalizeFilterValue($field, $filters[$fieldName]);
            if ($normalized === null || $normalized === '') {
                continue;
            }

            $column = (string)($field['database_column'] ?? $fieldName);
            $parameter = ':filter_' . $fieldName;
            $where[] = $column . ' = ' . ($this->isJsonField($field) ? $this->jsonParam($parameter) : $parameter);
            $params[$parameter] = $normalized;
        }

        $sql = 'SELECT * FROM ' . self::TABLE;
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        $orderBy = [];
        foreach (self::ORDER_COLUMNS as $column) {
            if ($column === '') {
                continue;
            }
            $orderBy[] = $column . ' DESC';
        }
        if ($orderBy !== []) {
            $sql .= ' ORDER BY ' . implode(', ', $orderBy);
        }

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(200, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findByPrimaryKey(string $value): ?array
    {
        $row = $this->one(
            'SELECT * FROM ' . self::TABLE . ' WHERE ' . self::PRIMARY_FIELD . ' = :value LIMIT 1',
            [':value' => $value]
        );

        return $row ? $this->hydrate($row) : null;
    }

    public function findByPublicLookup(string $value, bool $admin = false): ?array
    {
        if (self::PUBLIC_LOOKUP_FIELD === '') {
            return null;
        }

        $sql = 'SELECT * FROM ' . self::TABLE . ' WHERE ' . self::PUBLIC_LOOKUP_FIELD . ' = :value';
        $params = [':value' => $value];
        if (!$admin && is_array(self::PUBLIC_VISIBILITY)) {
            $sql .= ' AND ' . self::PUBLIC_VISIBILITY['field'] . ' = :_public_visibility';
            $params[':_public_visibility'] = self::PUBLIC_VISIBILITY['value'];
        }
        $sql .= ' LIMIT 1';

        $row = $this->one($sql, $params);
        return $row ? $this->hydrate($row) : null;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function create(array $data): array
    {
        $payload = $this->normalizePayload($data, true);
        $primary = self::FIELD_MAP[self::PRIMARY_FIELD] ?? null;
        if (is_array($primary) && (bool)($primary['primary'] ?? false) && (bool)($primary['auto'] ?? false) && (string)($primary['type'] ?? '') === 'uuid') {
            $payload[self::PRIMARY_FIELD] = UUID::v4();
        }

        if ($payload === []) {
            throw new RuntimeException('{{LabelSingular}} payload is empty.');
        }

        $columns = [];
        $placeholders = [];
        $params = [];
        foreach ($payload as $fieldName => $value) {
            $field = self::FIELD_MAP[$fieldName] ?? null;
            if (!is_array($field)) {
                continue;
            }

            $column = (string)($field['database_column'] ?? $fieldName);
            $parameter = ':' . $fieldName;
            $columns[] = $column;
            $placeholders[] = $this->isJsonField($field) ? $this->jsonParam($parameter) : $parameter;
            $params[$parameter] = $value;
        }

        $sql = 'INSERT INTO ' . self::TABLE
            . ' (' . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')';
        $this->query($sql, $params);

        $identifier = $payload[self::PRIMARY_FIELD] ?? null;
        if ($identifier === null || $identifier === '') {
            $identifier = (string)$this->db->lastInsertId();
        }

        $record = $this->findByPrimaryKey((string)$identifier);
        if ($record === null) {
            throw new RuntimeException('Failed to reload the created {{label_singular_lower}}.');
        }

        return $record;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>|null
     */
    public function update(string $value, array $data): ?array
    {
        if ($this->findByPrimaryKey($value) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        if ($payload === []) {
            return $this->findByPrimaryKey($value);
        }

        $assignments = [];
        $params = [':primary_value' => $value];
        foreach ($payload as $fieldName => $fieldValue) {
            $field = self::FIELD_MAP[$fieldName] ?? null;
            if (!is_array($field)) {
                continue;
            }

            $column = (string)($field['database_column'] ?? $fieldName);
            $parameter = ':' . $fieldName;
            $assignments[] = $column . ' = ' . ($this->isJsonField($field) ? $this->jsonParam($parameter) : $parameter);
            $params[$parameter] = $fieldValue;
        }

        if (isset(self::FIELD_MAP['updated_at'])) {
            $assignments[] = 'updated_at = NOW()';
        }

        $sql = 'UPDATE ' . self::TABLE
            . ' SET ' . implode(', ', $assignments)
            . ' WHERE ' . self::PRIMARY_FIELD . ' = :primary_value';
        $this->query($sql, $params);

        return $this->findByPrimaryKey($value);
    }

    public function delete(string $value): bool
    {
        $statement = $this->query(
            'DELETE FROM ' . self::TABLE . ' WHERE ' . self::PRIMARY_FIELD . ' = :value',
            [':value' => $value]
        );

        return $statement->rowCount() > 0;
    }

    public function count(): int
    {
        $row = $this->one('SELECT COUNT(*) AS total FROM ' . self::TABLE);
        return (int)($row['total'] ?? 0);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        $fieldNames = $create ? self::CREATE_FIELDS : self::UPDATE_FIELDS;

        foreach ($fieldNames as $fieldName) {
            $field = self::FIELD_MAP[$fieldName] ?? null;
            if (!is_array($field) || (bool)($field['read_only'] ?? false) || (bool)($field['auto'] ?? false)) {
                continue;
            }

            if (array_key_exists($fieldName, $data)) {
                $payload[$fieldName] = $this->normalizeFieldValue($field, $data[$fieldName]);
                continue;
            }

            if (!$create) {
                continue;
            }

            if ((bool)($field['has_default'] ?? false)) {
                $payload[$fieldName] = $this->defaultFieldValue($field);
                continue;
            }

            if ((bool)($field['required_on_create'] ?? false)) {
                throw new RuntimeException('{{LabelSingular}} field `' . $fieldName . '` is required.');
            }
        }

        return $payload;
    }

    private function normalizeFilterValue(array $field, mixed $value): mixed
    {
        if ($value === null || $value === '') {
            return null;
        }

        try {
            return $this->normalizeFieldValue($field, $value);
        } catch (RuntimeException) {
            return null;
        }
    }

    private function defaultFieldValue(array $field): mixed
    {
        $default = $field['default'] ?? null;
        if ($this->isJsonField($field)) {
            $json = json_encode(is_array($default) ? $default : [], JSON_UNESCAPED_SLASHES);
            return is_string($json) ? $json : '{}';
        }

        if ((string)($field['type'] ?? '') === 'boolean') {
            return $this->boolValue($default);
        }

        return $default;
    }

    private function normalizeFieldValue(array $field, mixed $value): mixed
    {
        $name = (string)($field['name'] ?? 'field');
        if ($value === null) {
            if ((bool)($field['nullable'] ?? false)) {
                return null;
            }

            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` cannot be null.');
        }

        if ($this->isJsonField($field)) {
            $decoded = is_string($value) ? json_decode($value, true) : $value;
            if (!is_array($decoded)) {
                throw new RuntimeException('{{LabelSingular}} field `' . $name . '` expects a JSON object.');
            }

            $encoded = json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            if (!is_string($encoded)) {
                throw new RuntimeException('Failed to encode JSON for `' . $name . '`.');
            }

            return $encoded;
        }

        return match ((string)($field['type'] ?? 'string')) {
            'uuid', 'string', 'varchar', 'text', 'enum', 'date', 'timestamp' => $this->normalizeStringField($field, $value),
            'integer', 'bigint' => $this->normalizeIntegerField($name, $value),
            'decimal' => $this->normalizeDecimalField($name, $value),
            'boolean' => $this->boolValue($value),
            default => $this->cleanString($value, true),
        };
    }

    private function normalizeStringField(array $field, mixed $value): string
    {
        $name = (string)($field['name'] ?? 'field');
        $text = $this->cleanString($value, true);
        if ($text === null || trim($text) === '') {
            if ((bool)($field['nullable'] ?? false)) {
                return '';
            }

            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` cannot be empty.');
        }

        if ((string)($field['format'] ?? '') === 'uuid' && !$this->uuidLike($text)) {
            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` must be a UUID.');
        }

        $options = array_values(is_array($field['options'] ?? null) ? $field['options'] : []);
        if ($options !== [] && !in_array($text, $options, true)) {
            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` must be one of: ' . implode(', ', $options) . '.');
        }

        return $text;
    }

    private function normalizeIntegerField(string $name, mixed $value): int
    {
        if (!is_numeric($value)) {
            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` must be numeric.');
        }

        return (int)$value;
    }

    private function normalizeDecimalField(string $name, mixed $value): float
    {
        if (!is_numeric($value)) {
            throw new RuntimeException('{{LabelSingular}} field `' . $name . '` must be a decimal value.');
        }

        return (float)$value;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        foreach (self::FIELD_MAP as $fieldName => $field) {
            if (!is_array($field)) {
                continue;
            }

            $column = (string)($field['database_column'] ?? $fieldName);
            if (!array_key_exists($column, $row)) {
                continue;
            }

            $value = $row[$column];
            if ($this->isJsonField($field)) {
                $row[$fieldName] = $this->decodeJson($value, []);
            } elseif ((string)($field['type'] ?? '') === 'boolean') {
                $row[$fieldName] = $this->boolValue($value);
            } elseif (in_array((string)($field['type'] ?? ''), ['integer', 'bigint'], true)) {
                $row[$fieldName] = $value === null ? null : (int)$value;
            } elseif ((string)($field['type'] ?? '') === 'decimal') {
                $row[$fieldName] = $value === null ? null : (float)$value;
            } else {
                $row[$fieldName] = $value;
            }

            if ($column !== $fieldName) {
                unset($row[$column]);
            }
        }

        return $row;
    }

    private function isJsonField(array $field): bool
    {
        return (string)($field['type'] ?? '') === 'json';
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => (string)$resource['base'],
            '{{table}}' => $this->exportPhp((string)$resource['table']),
            '{{primary_field}}' => $this->exportPhp((string)$resource['primary_field']),
            '{{public_lookup_field}}' => $this->exportPhp((string)($resource['public_lookup_field'] ?? '')),
            '{{public_visibility}}' => $this->exportPhp($publicVisibility),
            '{{field_map}}' => $this->exportPhp($fieldMap, 1),
            '{{search_columns}}' => $this->exportPhp($searchColumns, 1),
            '{{filter_fields}}' => $this->exportPhp($filterFields, 1),
            '{{create_fields}}' => $this->exportPhp($createFields, 1),
            '{{update_fields}}' => $this->exportPhp($updateFields, 1),
            '{{order_columns}}' => $this->exportPhp($orderColumns, 1),
            '{{LabelSingular}}' => addslashes((string)$resource['label_singular']),
            '{{label_singular_lower}}' => strtolower((string)$resource['label_singular']),
        ]);
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function serviceTemplate(array $resource): string
    {
        $template = <<<'PHP'
<?php
namespace App\Services;

use App\Models\{{Base}}Model;

final class {{Base}}Service
{
    private {{Base}}Model $model;

    public function __construct()
    {
        $this->model = new {{Base}}Model();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->model->list($filters, $admin);
    }

    public function showPublic(string $value): ?array
    {
        return $this->model->findByPublicLookup($value, false);
    }

    public function showAdmin(string $value): ?array
    {
        return $this->model->findByPrimaryKey($value);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        return $this->model->create($payload);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $value, array $payload): ?array
    {
        return $this->model->update($value, $payload);
    }

    public function delete(string $value): bool
    {
        return $this->model->delete($value);
    }

    public function count(): int
    {
        return $this->model->count();
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => (string)$resource['base'],
        ]);
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function controllerTemplate(array $resource): string
    {
        $publicLookupField = trim((string)($resource['public_lookup_field'] ?? ''));
        $primaryField = trim((string)($resource['primary_field'] ?? 'id'));

        $template = <<<'PHP'
<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\{{Base}}Service;
use RuntimeException;

final class {{Base}}Controller
{
    private {{Base}}Service $service;

    public function __construct()
    {
        $this->service = new {{Base}}Service();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->service->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $record = $this->service->showPublic((string)($request->params['{{public_lookup_field}}'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{LabelSingular}} not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->service->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $record = $this->service->showAdmin((string)($request->params['{{primary_field}}'] ?? ''));
        return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{LabelSingular}} not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $record = $this->service->create($request->body);
            return Response::json(['data' => $record], 201, [
                'Location' => '/api/v1/admin/{{route_segment}}/' . (string)($record['{{primary_field}}'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create {{label_singular_lower}}.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $record = $this->service->update((string)($request->params['{{primary_field}}'] ?? ''), $request->body);
            return $record ? Response::json(['data' => $record]) : Response::json(['error' => '{{LabelSingular}} not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update {{label_singular_lower}}.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->service->delete((string)($request->params['{{primary_field}}'] ?? ''));
            if (!$deleted) {
                return Response::json(['error' => '{{LabelSingular}} not found.'], 404);
            }

            return Response::json(['data' => ['deleted' => true]]);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to delete {{label_singular_lower}}.'], 500);
        }
    }
}
PHP;

        return ConsoleSupport::renderTemplate($template, [
            '{{Base}}' => (string)$resource['base'],
            '{{route_segment}}' => (string)$resource['route_segment'],
            '{{public_lookup_field}}' => $publicLookupField !== '' ? $publicLookupField : 'slug',
            '{{primary_field}}' => $primaryField,
            '{{LabelSingular}}' => (string)$resource['label_singular'],
            '{{label_singular_lower}}' => strtolower((string)$resource['label_singular']),
        ]);
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function manifestTemplate(array $resource, string $version): string
    {
        $manifest = [
            'key' => (string)$resource['key'],
            'label' => (string)$resource['label'],
            'group' => (string)$resource['group'],
            'item_type' => (string)$resource['item_type'],
            'table' => (string)$resource['table'],
            'summary' => (string)$resource['summary'],
            'controller' => 'App\\Controllers\\' . (string)$resource['base'] . 'Controller',
            'route_segment' => (string)$resource['route_segment'],
            'scaffold_version' => $version,
            'default_data_path' => '/api/v1/' . (string)$resource['route_segment'],
            'default_data_auth_required' => false,
            'blueprint_path' => (string)($resource['paths']['definition'] ?? ''),
            'access_policies' => (array)($resource['access'] ?? []),
            'fields' => $this->manifestFields($resource),
            'create_fields' => $this->manifestWritableFields($resource, true),
            'update_fields' => $this->manifestWritableFields($resource, false),
            'query_options' => $this->manifestQueryOptions($resource, false),
            'permissions_catalog' => $this->permissionDefinitions($resource),
            'routes' => $this->routeDefinitions($resource),
        ];

        return "<?php\nreturn " . $this->exportPhp($manifest, 0) . ";\n";
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function routeSnippetTemplate(array $resource): string
    {
        $lines = [
            "<?php",
            'use App\Controllers\\' . (string)$resource['base'] . 'Controller;',
            '',
            '// Auto-registered from routes/generated/' . (string)$resource['route_segment'] . '.php.',
        ];

        foreach ($this->routeDefinitions($resource) as $route) {
            $method = strtolower((string)($route['method'] ?? 'get'));
            $path = str_replace('/api/v1', '', (string)($route['path'] ?? ''));
            $action = (string)($route['action'] ?? 'list');
            $line = '$r->' . $method . "('" . $path . "', [" . (string)$resource['base'] . "Controller::class, '" . $action . "'])";

            if ((bool)($route['auth_required'] ?? false)) {
                $line .= '->middleware($auth)';
            }

            $permissions = array_values(is_array($route['permissions'] ?? null) ? $route['permissions'] : []);
            foreach ($permissions as $permission) {
                $line .= "->middleware(\$perm('" . (string)$permission . "'))";
            }

            $lines[] = $line . ';';
        }

        return implode("\n", $lines) . "\n";
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function createMigrationTemplate(array $resource, string $version): string
    {
        $migration = [
            'name' => 'create_' . (string)$resource['table'] . '_table',
            'version' => $version,
            'up' => [
                'pgsql' => $this->createMigrationStatements($resource, 'pgsql'),
                'mysql' => $this->createMigrationStatements($resource, 'mysql'),
            ],
            'down' => [
                'pgsql' => ['DROP TABLE IF EXISTS ' . (string)$resource['table'] . ' CASCADE'],
                'mysql' => ['DROP TABLE IF EXISTS ' . (string)$resource['table']],
            ],
        ];

        return "<?php\nreturn " . $this->exportPhp($migration, 0) . ";\n";
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     * @return array<string, mixed>|null
     */
    private function buildAlterMigration(array $before, array $after, string $version): ?array
    {
        $warnings = [];
        $upPgsql = [];
        $downPgsql = [];
        $upMysql = [];
        $downMysql = [];

        $beforeTable = (string)($before['table'] ?? '');
        $afterTable = (string)($after['table'] ?? $beforeTable);

        if ($beforeTable !== '' && $afterTable !== '' && $beforeTable !== $afterTable) {
            $upPgsql[] = 'ALTER TABLE ' . $beforeTable . ' RENAME TO ' . $afterTable;
            $downPgsql[] = 'ALTER TABLE ' . $afterTable . ' RENAME TO ' . $beforeTable;
            $upMysql[] = 'RENAME TABLE ' . $beforeTable . ' TO ' . $afterTable;
            $downMysql[] = 'RENAME TABLE ' . $afterTable . ' TO ' . $beforeTable;
        }

        $beforeFields = $this->fieldMapByName(array_values(is_array($before['fields'] ?? null) ? $before['fields'] : []));
        $afterFields = $this->fieldMapByName(array_values(is_array($after['fields'] ?? null) ? $after['fields'] : []));

        foreach ($afterFields as $name => $field) {
            if (!isset($beforeFields[$name])) {
                $upPgsql[] = 'ALTER TABLE ' . $afterTable . ' ADD COLUMN ' . $this->columnDefinitionSql($field, 'pgsql', false);
                $upMysql[] = 'ALTER TABLE ' . $afterTable . ' ADD COLUMN ' . $this->columnDefinitionSql($field, 'mysql', false);
                $downPgsql[] = 'ALTER TABLE ' . $afterTable . ' DROP COLUMN IF EXISTS ' . (string)$field['database_column'];
                $downMysql[] = 'ALTER TABLE ' . $afterTable . ' DROP COLUMN ' . (string)$field['database_column'];
                $upPgsql = array_merge($upPgsql, $this->fieldIndexStatements($afterTable, $field, 'pgsql', true));
                $upMysql = array_merge($upMysql, $this->fieldIndexStatements($afterTable, $field, 'mysql', true));
                $downPgsql = array_merge($downPgsql, $this->fieldIndexStatements($afterTable, $field, 'pgsql', false));
                $downMysql = array_merge($downMysql, $this->fieldIndexStatements($afterTable, $field, 'mysql', false));
                continue;
            }

            $beforeField = $beforeFields[$name];
            if (!$this->fieldSchemaChanged($beforeField, $field)) {
                continue;
            }

            if ((bool)($beforeField['primary'] ?? false) !== (bool)($field['primary'] ?? false)) {
                $warnings[] = 'Primary-key changes on `' . $name . '` were not compiled into an automatic ALTER TABLE statement.';
                continue;
            }

            $upPgsql = array_merge($upPgsql, $this->fieldAlterStatements($beforeField, $field, $afterTable, 'pgsql'));
            $upMysql = array_merge($upMysql, $this->fieldAlterStatements($beforeField, $field, $afterTable, 'mysql'));
            $downPgsql = array_merge($downPgsql, $this->fieldAlterStatements($field, $beforeField, $afterTable, 'pgsql'));
            $downMysql = array_merge($downMysql, $this->fieldAlterStatements($field, $beforeField, $afterTable, 'mysql'));
        }

        foreach ($beforeFields as $name => $field) {
            if (isset($afterFields[$name])) {
                continue;
            }

            $upPgsql = array_merge($upPgsql, $this->fieldIndexStatements($afterTable, $field, 'pgsql', false));
            $upMysql = array_merge($upMysql, $this->fieldIndexStatements($afterTable, $field, 'mysql', false));
            $upPgsql[] = 'ALTER TABLE ' . $afterTable . ' DROP COLUMN IF EXISTS ' . (string)$field['database_column'];
            $upMysql[] = 'ALTER TABLE ' . $afterTable . ' DROP COLUMN ' . (string)$field['database_column'];

            $downPgsql[] = 'ALTER TABLE ' . $afterTable . ' ADD COLUMN ' . $this->columnDefinitionSql($field, 'pgsql', false);
            $downMysql[] = 'ALTER TABLE ' . $afterTable . ' ADD COLUMN ' . $this->columnDefinitionSql($field, 'mysql', false);
            $downPgsql = array_merge($downPgsql, $this->fieldIndexStatements($afterTable, $field, 'pgsql', true));
            $downMysql = array_merge($downMysql, $this->fieldIndexStatements($afterTable, $field, 'mysql', true));
        }

        if ($upPgsql === [] && $upMysql === []) {
            return null;
        }

        $migrationName = 'alter_' . $afterTable . '_table';
        $path = $this->migrationDirectory() . '/' . ConsoleSupport::timestamp() . '_' . $migrationName . '.php';
        $migration = [
            'name' => $migrationName,
            'version' => $version,
            'up' => [
                'pgsql' => $upPgsql,
                'mysql' => $upMysql,
            ],
            'down' => [
                'pgsql' => $downPgsql,
                'mysql' => $downMysql,
            ],
        ];

        return [
            'name' => $migrationName,
            'path' => $path,
            'content' => "<?php\nreturn " . $this->exportPhp($migration, 0) . ";\n",
            'warnings' => $warnings,
        ];
    }

    /**
     * @param array<string, mixed> $field
     * @return array<int, string>
     */
    private function createMigrationStatements(array $resource, string $driver): array
    {
        $table = (string)$resource['table'];
        $fields = array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []);

        $columns = array_map(fn (array $field): string => '    ' . $this->columnDefinitionSql($field, $driver, true), $fields);
        $createTable = "CREATE TABLE IF NOT EXISTS " . $table . " (\n" . implode(",\n", $columns) . "\n)";
        if ($driver === 'mysql') {
            $createTable .= ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        }

        $statements = [$createTable];
        foreach ($fields as $field) {
            $statements = array_merge($statements, $this->fieldIndexStatements($table, $field, $driver, true));
        }

        return array_values(array_unique($statements));
    }

    /**
     * @param array<string, mixed> $field
     * @return array<int, string>
     */
    private function fieldIndexStatements(string $table, array $field, string $driver, bool $create): array
    {
        $column = (string)($field['database_column'] ?? $field['name'] ?? '');
        if ($column === '' || (bool)($field['primary'] ?? false)) {
            return [];
        }

        $statements = [];
        $unique = (bool)($field['unique'] ?? false);
        $index = (bool)($field['index'] ?? false);

        if ($unique) {
            $name = $this->uniqueIndexName($table, $column);
            if ($create) {
                $statements[] = $driver === 'pgsql'
                    ? 'CREATE UNIQUE INDEX IF NOT EXISTS ' . $name . ' ON ' . $table . ' (' . $column . ')'
                    : 'CREATE UNIQUE INDEX ' . $name . ' ON ' . $table . ' (' . $column . ')';
            } else {
                $statements[] = $driver === 'pgsql'
                    ? 'DROP INDEX IF EXISTS ' . $name
                    : 'DROP INDEX ' . $name . ' ON ' . $table;
            }
        }

        if ($index) {
            $name = $this->indexName($table, $column);
            if ($create) {
                $statements[] = $driver === 'pgsql'
                    ? 'CREATE INDEX IF NOT EXISTS ' . $name . ' ON ' . $table . ' (' . $column . ')'
                    : 'CREATE INDEX ' . $name . ' ON ' . $table . ' (' . $column . ')';
            } else {
                $statements[] = $driver === 'pgsql'
                    ? 'DROP INDEX IF EXISTS ' . $name
                    : 'DROP INDEX ' . $name . ' ON ' . $table;
            }
        }

        return array_values(array_unique($statements));
    }

    /**
     * @param array<string, mixed> $field
     */
    private function columnDefinitionSql(array $field, string $driver, bool $creatingTable): string
    {
        $column = (string)($field['database_column'] ?? $field['name']);
        $typeSql = $this->columnTypeSql($field, $driver, $creatingTable);
        $parts = [$column, $typeSql];

        if ((bool)($field['primary'] ?? false)) {
            $parts[] = 'PRIMARY KEY';
        }

        if (!(bool)($field['nullable'] ?? false)) {
            $parts[] = 'NOT NULL';
        } else {
            $parts[] = 'NULL';
        }

        $defaultSql = $this->columnDefaultSql($field, $driver);
        if ($defaultSql !== null) {
            $parts[] = 'DEFAULT ' . $defaultSql;
        }

        $references = is_array($field['references'] ?? null) ? $field['references'] : null;
        if ($creatingTable && $references !== null) {
            $parts[] = 'REFERENCES ' . (string)$references['table'] . ' (' . (string)$references['column'] . ')';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, mixed> $field
     */
    private function columnTypeSql(array $field, string $driver, bool $creatingTable): string
    {
        $type = (string)($field['type'] ?? 'string');
        $length = (int)($field['length'] ?? 0);
        $precision = (int)($field['precision'] ?? 0);
        $scale = (int)($field['scale'] ?? 0);
        $primary = (bool)($field['primary'] ?? false);
        $auto = (bool)($field['auto'] ?? false);

        return match ($type) {
            'uuid' => $driver === 'pgsql' ? 'UUID' : 'CHAR(36)',
            'string' => 'VARCHAR(' . max(1, $length ?: 255) . ')',
            'text' => 'TEXT',
            'integer' => $driver === 'pgsql'
                ? (($primary && $auto) ? 'SERIAL' : 'INTEGER')
                : (($primary && $auto) ? 'INT AUTO_INCREMENT' : 'INT'),
            'bigint' => $driver === 'pgsql' && $primary && $auto ? 'BIGSERIAL' : ($driver === 'mysql' && $primary && $auto ? 'BIGINT AUTO_INCREMENT' : 'BIGINT'),
            'decimal' => ($driver === 'pgsql' ? 'NUMERIC' : 'DECIMAL') . '(' . max(1, $precision ?: 10) . ',' . max(0, $scale ?: 2) . ')',
            'boolean' => $driver === 'pgsql' ? 'BOOLEAN' : 'TINYINT(1)',
            'json' => $driver === 'pgsql' ? 'JSONB' : 'JSON',
            'date' => 'DATE',
            'timestamp' => $driver === 'pgsql' ? 'TIMESTAMPTZ' : 'DATETIME',
            'enum' => 'VARCHAR(' . max(1, $length ?: 64) . ')',
            default => 'VARCHAR(' . max(1, $length ?: 255) . ')',
        };
    }

    /**
     * @param array<string, mixed> $field
     */
    private function columnDefaultSql(array $field, string $driver): ?string
    {
        $name = (string)($field['name'] ?? '');
        if (in_array($name, ['created_at', 'updated_at'], true) && (string)($field['type'] ?? '') === 'timestamp') {
            return $driver === 'pgsql' ? 'NOW()' : 'CURRENT_TIMESTAMP';
        }

        if (!(bool)($field['has_default'] ?? false)) {
            return null;
        }

        $default = $field['default'] ?? null;
        if ($default === null) {
            return 'NULL';
        }

        if (is_bool($default)) {
            return $driver === 'pgsql'
                ? ($default ? 'TRUE' : 'FALSE')
                : ($default ? '1' : '0');
        }

        if (is_int($default) || is_float($default)) {
            return (string)$default;
        }

        if ((string)($field['type'] ?? '') === 'json') {
            if ($driver === 'pgsql') {
                $json = json_encode(is_array($default) ? $default : [], JSON_UNESCAPED_SLASHES);
                return "'" . str_replace("'", "''", (string)$json) . "'::JSONB";
            }
            return null;
        }

        return "'" . str_replace("'", "''", (string)$default) . "'";
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     */
    private function fieldSchemaChanged(array $before, array $after): bool
    {
        $keys = ['type', 'length', 'precision', 'scale', 'nullable', 'unique', 'index', 'has_default', 'default', 'references'];
        foreach ($keys as $key) {
            if (($before[$key] ?? null) !== ($after[$key] ?? null)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     * @return array<int, string>
     */
    private function fieldAlterStatements(array $before, array $after, string $table, string $driver): array
    {
        $column = (string)($after['database_column'] ?? $after['name'] ?? '');
        if ($column === '') {
            return [];
        }

        $statements = [];
        if ($driver === 'pgsql') {
            $statements[] = 'ALTER TABLE ' . $table . ' ALTER COLUMN ' . $column . ' TYPE ' . $this->columnTypeSql($after, $driver, false);
            $statements[] = 'ALTER TABLE ' . $table . ' ALTER COLUMN ' . $column . ' ' . ((bool)($after['nullable'] ?? false) ? 'DROP NOT NULL' : 'SET NOT NULL');

            if ((bool)($after['has_default'] ?? false)) {
                $defaultSql = $this->columnDefaultSql($after, $driver);
                if ($defaultSql !== null) {
                    $statements[] = 'ALTER TABLE ' . $table . ' ALTER COLUMN ' . $column . ' SET DEFAULT ' . $defaultSql;
                }
            } else {
                $statements[] = 'ALTER TABLE ' . $table . ' ALTER COLUMN ' . $column . ' DROP DEFAULT';
            }
        } else {
            $statements[] = 'ALTER TABLE ' . $table . ' MODIFY COLUMN ' . $this->columnDefinitionSql($after, $driver, false);
        }

        if ((bool)($before['unique'] ?? false) !== (bool)($after['unique'] ?? false)) {
            $statements = array_merge($statements, $this->fieldIndexStatements($table, $before, $driver, false));
            $statements = array_merge($statements, $this->fieldIndexStatements($table, $after, $driver, true));
        } elseif ((bool)($before['index'] ?? false) !== (bool)($after['index'] ?? false)) {
            $statements = array_merge($statements, $this->fieldIndexStatements($table, $before, $driver, false));
            $statements = array_merge($statements, $this->fieldIndexStatements($table, $after, $driver, true));
        }

        return array_values(array_unique($statements));
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, array<string, mixed>>
     */
    private function manifestFields(array $resource): array
    {
        return array_values(array_map(function (array $field): array {
            return [
                'name' => (string)$field['name'],
                'data_type' => (string)$field['data_type'],
                'format' => $field['format'] ?? null,
                'required_on_create' => (bool)($field['required_on_create'] ?? false),
                'required_on_update' => (bool)($field['required_on_update'] ?? false),
                'nullable' => (bool)($field['nullable'] ?? false),
                'read_only' => (bool)($field['read_only'] ?? false),
                'write_only' => (bool)($field['write_only'] ?? false),
                'options' => array_values(is_array($field['options'] ?? null) ? $field['options'] : []),
                'description' => $this->fieldDescription($field),
                'database_column' => (string)($field['database_column'] ?? $field['name']),
                'database_type' => (string)($field['type'] ?? 'string'),
                'default' => $field['default'] ?? null,
                'references' => is_array($field['references'] ?? null) ? $field['references'] : null,
                'relationship' => is_array($field['relationship'] ?? null) ? $field['relationship'] : null,
            ];
        }, array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : [])));
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, array<string, mixed>>
     */
    private function manifestWritableFields(array $resource, bool $create): array
    {
        return array_values(array_filter($this->manifestFields($resource), static function (array $field) use ($create): bool {
            if ((bool)($field['read_only'] ?? false)) {
                return false;
            }

            return true;
        }));
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, array<string, mixed>>
     */
    private function manifestQueryOptions(array $resource, bool $public): array
    {
        $options = [];
        $fields = array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []);
        $searchFields = array_values(array_filter($fields, static fn (array $field): bool => (bool)($field['searchable'] ?? false)));
        if ($searchFields !== []) {
            $options[] = [
                'name' => 'q',
                'data_type' => 'string',
                'format' => null,
                'required_on_create' => false,
                'required_on_update' => false,
                'nullable' => true,
                'read_only' => false,
                'write_only' => false,
                'options' => [],
                'description' => 'Free-text search across ' . implode(', ', array_map(static fn (array $field): string => (string)$field['name'], $searchFields)) . '.',
            ];
        }

        foreach ($fields as $field) {
            if (!(bool)($field['filterable'] ?? false)) {
                continue;
            }

            if ($public && is_array($resource['public_visibility'] ?? null) && (string)($field['name'] ?? '') === (string)($resource['public_visibility']['field'] ?? '')) {
                continue;
            }

            $options[] = [
                'name' => (string)$field['name'],
                'data_type' => (string)$field['data_type'],
                'format' => $field['format'] ?? null,
                'required_on_create' => false,
                'required_on_update' => false,
                'nullable' => true,
                'read_only' => false,
                'write_only' => false,
                'options' => array_values(is_array($field['options'] ?? null) ? $field['options'] : []),
                'description' => 'Filter by ' . (string)$field['name'] . '.',
            ];
        }

        $options[] = [
            'name' => 'limit',
            'data_type' => 'integer',
            'format' => null,
            'required_on_create' => false,
            'required_on_update' => false,
            'nullable' => true,
            'read_only' => false,
            'write_only' => false,
            'options' => [],
            'description' => 'Limit the result set size.',
        ];

        return $options;
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, array<string, mixed>>
     */
    private function permissionDefinitions(array $resource): array
    {
        $definitions = [];
        $routeActions = $this->routePermissionsByAction($resource);
        $sort = 1000;
        foreach ($routeActions as $action => $permission) {
            $matrix = (array)($resource['access']['matrix'][$action] ?? []);
            $defaultRoles = array_values(array_filter(
                array_map('strval', is_array($matrix['default_roles'] ?? null) ? $matrix['default_roles'] : []),
                static fn (string $value): bool => $value !== ''
            ));
            if ($permission === '' || $defaultRoles === [] && (bool)($matrix['public'] ?? false)) {
                continue;
            }

            $definitions[] = [
                'code' => $permission,
                'title' => ucwords(str_replace('_', ' ', $action)) . ' ' . (string)$resource['label'],
                'description' => 'Generated permission for the `' . (string)$resource['key'] . '` resource action `' . $action . '`.',
                'section_code' => 'generated_resources',
                'section_title' => 'Generated Resources',
                'module_code' => (string)$resource['key'],
                'module_title' => (string)$resource['label'],
                'action_code' => $action,
                'action_title' => ucwords(str_replace('_', ' ', $action)),
                'sort_order' => $sort,
                'default_roles' => $defaultRoles,
            ];
            $sort += 10;
        }

        return $definitions;
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, string>
     */
    private function routePermissionsByAction(array $resource): array
    {
        $permissions = [];
        foreach (self::SUPPORTED_ACTIONS as $action) {
            $matrix = (array)($resource['access']['matrix'][$action] ?? []);
            $isPublic = (bool)($matrix['public'] ?? false);
            $defaultRoles = array_values(is_array($matrix['default_roles'] ?? null) ? $matrix['default_roles'] : []);
            if ($isPublic && $action === 'list') {
                $permissions[$action] = '';
                continue;
            }
            if ($isPublic && $action === 'show') {
                $permissions[$action] = '';
                continue;
            }
            if ($defaultRoles === [] && !$isPublic) {
                $permissions[$action] = $this->permissionCode($resource, $action);
                continue;
            }
            $permissions[$action] = $this->permissionCode($resource, $action);
        }

        return $permissions;
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function permissionCode(array $resource, string $action): string
    {
        $key = (string)$resource['key'];
        return match ($action) {
            'list', 'show' => $key . '.' . $action,
            default => 'admin.' . $key . '.' . $action,
        };
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, array<string, mixed>>
     */
    private function routeDefinitions(array $resource): array
    {
        $routes = [];
        $routeSegment = (string)$resource['route_segment'];
        $baseController = 'App\\Controllers\\' . (string)$resource['base'] . 'Controller';
        $publicLookup = trim((string)($resource['public_lookup_field'] ?? ''));
        $primaryField = trim((string)($resource['primary_field'] ?? 'id'));
        $permissionByAction = $this->routePermissionsByAction($resource);

        foreach (self::SUPPORTED_ACTIONS as $action) {
            $matrix = (array)($resource['access']['matrix'][$action] ?? []);
            $defaultRoles = array_values(is_array($matrix['default_roles'] ?? null) ? $matrix['default_roles'] : []);
            $public = (bool)($matrix['public'] ?? false);
            if ($defaultRoles === [] && !$public && in_array($action, ['list', 'show'], true)) {
                continue;
            }
            if ($defaultRoles === [] && !$public && !in_array($action, ['list', 'show'], true) && !isset($permissionByAction[$action])) {
                continue;
            }

            if ($action === 'list') {
                $routes[] = $this->routeDefinition(
                    'GET',
                    '/api/v1/' . $routeSegment,
                    'list',
                    $resource,
                    $baseController,
                    $public ? [] : $this->permissionList($permissionByAction[$action] ?? ''),
                    !$public,
                    [],
                    $this->manifestQueryOptions($resource, true),
                    [],
                    200,
                    (string)$resource['item_type'] . '[]',
                    '{ data: ' . (string)$resource['item_type'] . '[] }',
                    'List public ' . strtolower((string)$resource['label']) . '.'
                );
                continue;
            }

            if ($action === 'show') {
                if ($publicLookup === '') {
                    continue;
                }
                $routes[] = $this->routeDefinition(
                    'GET',
                    '/api/v1/' . $routeSegment . '/{' . $publicLookup . '}',
                    'show',
                    $resource,
                    $baseController,
                    $public ? [] : $this->permissionList($permissionByAction[$action] ?? ''),
                    !$public,
                    [$this->pathParam($this->fieldByName($resource, $publicLookup), 'Public lookup value.')],
                    [],
                    [],
                    200,
                    (string)$resource['item_type'],
                    '{ data: ' . (string)$resource['item_type'] . ' }',
                    'Read one public ' . strtolower((string)$resource['label_singular']) . '.'
                );
                continue;
            }

            if ($action === 'admin_list') {
                $routes[] = $this->routeDefinition(
                    'GET',
                    '/api/v1/admin/' . $routeSegment,
                    'adminList',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    [],
                    $this->manifestQueryOptions($resource, false),
                    [],
                    200,
                    (string)$resource['item_type'] . '[]',
                    '{ data: ' . (string)$resource['item_type'] . '[] }',
                    'List ' . strtolower((string)$resource['label']) . ' for administrators.'
                );
                continue;
            }

            if ($action === 'admin_show') {
                $routes[] = $this->routeDefinition(
                    'GET',
                    '/api/v1/admin/' . $routeSegment . '/{' . $primaryField . '}',
                    'adminShow',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    [$this->pathParam($this->fieldByName($resource, $primaryField), 'Primary identifier.')],
                    [],
                    [],
                    200,
                    (string)$resource['item_type'],
                    '{ data: ' . (string)$resource['item_type'] . ' }',
                    'Read one ' . strtolower((string)$resource['label_singular']) . ' by its primary identifier.'
                );
                continue;
            }

            if ($action === 'create') {
                $routes[] = $this->routeDefinition(
                    'POST',
                    '/api/v1/admin/' . $routeSegment,
                    'create',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    [],
                    [],
                    $this->manifestWritableFields($resource, true),
                    201,
                    (string)$resource['item_type'],
                    '{ data: ' . (string)$resource['item_type'] . ' }',
                    'Create a new ' . strtolower((string)$resource['label_singular']) . '.'
                );
                continue;
            }

            if ($action === 'update') {
                $pathParams = [$this->pathParam($this->fieldByName($resource, $primaryField), 'Primary identifier.')];
                $body = $this->manifestWritableFields($resource, false);
                $routes[] = $this->routeDefinition(
                    'PUT',
                    '/api/v1/admin/' . $routeSegment . '/{' . $primaryField . '}',
                    'update',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    $pathParams,
                    [],
                    $body,
                    200,
                    (string)$resource['item_type'],
                    '{ data: ' . (string)$resource['item_type'] . ' }',
                    'Replace a ' . strtolower((string)$resource['label_singular']) . '.'
                );
                $routes[] = $this->routeDefinition(
                    'PATCH',
                    '/api/v1/admin/' . $routeSegment . '/{' . $primaryField . '}',
                    'update',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    $pathParams,
                    [],
                    $body,
                    200,
                    (string)$resource['item_type'],
                    '{ data: ' . (string)$resource['item_type'] . ' }',
                    'Partially update a ' . strtolower((string)$resource['label_singular']) . '.'
                );
                continue;
            }

            if ($action === 'delete') {
                $routes[] = $this->routeDefinition(
                    'DELETE',
                    '/api/v1/admin/' . $routeSegment . '/{' . $primaryField . '}',
                    'delete',
                    $resource,
                    $baseController,
                    $this->permissionList($permissionByAction[$action] ?? ''),
                    true,
                    [$this->pathParam($this->fieldByName($resource, $primaryField), 'Primary identifier.')],
                    [],
                    [],
                    200,
                    '{ deleted: boolean }',
                    '{ data: { deleted: boolean } }',
                    'Delete a ' . strtolower((string)$resource['label_singular']) . '.'
                );
            }
        }

        return $routes;
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<int, string> $permissions
     * @param array<int, array<string, mixed>> $pathParams
     * @param array<int, array<string, mixed>> $query
     * @param array<int, array<string, mixed>> $body
     * @return array<string, mixed>
     */
    private function routeDefinition(
        string $method,
        string $path,
        string $action,
        array $resource,
        string $controller,
        array $permissions,
        bool $authRequired,
        array $pathParams,
        array $query,
        array $body,
        int $successStatus,
        string $returnType,
        string $envelope,
        string $summary
    ): array {
        return [
            'method' => $method,
            'path' => $path,
            'summary' => $summary,
            'resource_key' => (string)$resource['key'],
            'controller' => $controller,
            'action' => $action,
            'auth_required' => $authRequired,
            'permissions' => $permissions,
            'request' => [
                'content_type' => $body === [] ? null : 'application/json',
                'path_params' => $pathParams,
                'query' => $query,
                'body' => $body,
            ],
            'response' => [
                'content_type' => 'application/json; charset=UTF-8',
                'success_status' => $successStatus,
                'return_type' => $returnType,
                'envelope' => $envelope,
                'error_type' => '{ error: string }',
            ],
        ];
    }

    /**
     * @param array<string, mixed>|null $field
     * @return array<string, mixed>
     */
    private function pathParam(?array $field, string $description): array
    {
        $field = $field ?? [
            'name' => 'id',
            'data_type' => 'string',
            'format' => 'uuid',
        ];

        return [
            'name' => (string)($field['name'] ?? 'id'),
            'data_type' => (string)($field['data_type'] ?? 'string'),
            'format' => $field['format'] ?? null,
            'required_on_create' => true,
            'required_on_update' => false,
            'nullable' => false,
            'read_only' => false,
            'write_only' => false,
            'options' => array_values(is_array($field['options'] ?? null) ? $field['options'] : []),
            'description' => $description,
        ];
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, mixed>|null
     */
    private function fieldByName(array $resource, string $name): ?array
    {
        foreach (array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []) as $field) {
            if ((string)($field['name'] ?? '') === $name) {
                return $field;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $field
     */
    private function fieldDescription(array $field): string
    {
        $description = trim((string)($field['description'] ?? ''));
        if ($description !== '') {
            return $description;
        }

        return ucwords(str_replace('_', ' ', (string)$field['name'])) . ' field.';
    }

    /**
     * @return array<int, string>
     */
    private function permissionList(string $permission): array
    {
        return $permission === '' ? [] : [$permission];
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, array<string, mixed>>
     */
    private function fieldMapByName(array $fields): array
    {
        $map = [];
        foreach ($fields as $field) {
            $map[(string)($field['name'] ?? '')] = $field;
        }

        return $map;
    }

    private function uniqueIndexName(string $table, string $column): string
    {
        return 'uidx_' . $table . '_' . $column;
    }

    private function indexName(string $table, string $column): string
    {
        return 'idx_' . $table . '_' . $column;
    }

    /**
     * @return array<string, mixed>
     */
    private function resourcePreview(array $resource): array
    {
        return [
            'key' => (string)($resource['key'] ?? ''),
            'table' => (string)($resource['table'] ?? ''),
            'route_segment' => (string)($resource['route_segment'] ?? ''),
            'label' => (string)($resource['label'] ?? ''),
            'group' => (string)($resource['group'] ?? ''),
            'primary_field' => (string)($resource['primary_field'] ?? ''),
            'public_lookup_field' => (string)($resource['public_lookup_field'] ?? ''),
            'fields' => array_map(static function (array $field): array {
                return [
                    'name' => (string)($field['name'] ?? ''),
                    'type' => (string)($field['type'] ?? ''),
                    'nullable' => (bool)($field['nullable'] ?? false),
                    'default' => $field['default'] ?? null,
                    'primary' => (bool)($field['primary'] ?? false),
                    'public_lookup' => (bool)($field['public_lookup'] ?? false),
                ];
            }, array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : [])),
            'access' => [
                'rules' => array_values(is_array($resource['access']['rules'] ?? null) ? $resource['access']['rules'] : []),
                'matrix' => is_array($resource['access']['matrix'] ?? null) ? $resource['access']['matrix'] : [],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function requireDefinition(string $name): array
    {
        $resource = $this->findDefinition($name);
        if ($resource === null) {
            throw new RuntimeException('No stored generated resource definition matched `' . $name . '`.');
        }

        return $resource;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function findDefinition(string $name): ?array
    {
        $normalized = strtolower(trim($name));
        if ($normalized === '') {
            return null;
        }

        $directory = $this->rootPath . '/blueprints/resources';
        if (!is_dir($directory)) {
            return null;
        }

        foreach (glob($directory . '/*.resource.json') ?: [] as $path) {
            $decoded = json_decode((string)file_get_contents($path), true);
            if (!is_array($decoded)) {
                continue;
            }

            $candidates = array_filter([
                strtolower((string)($decoded['name'] ?? '')),
                strtolower((string)($decoded['key'] ?? '')),
                strtolower((string)($decoded['table'] ?? '')),
                strtolower((string)($decoded['route_segment'] ?? '')),
                strtolower((string)($decoded['base'] ?? '')),
            ]);

            if (in_array($normalized, $candidates, true)) {
                return $decoded;
            }
        }

        return null;
    }

    /**
     * @return array<string, mixed>
     */
    private function emptyResult(): array
    {
        return [
            'written' => [],
            'removed' => [],
            'backups' => [],
            'missing' => [],
            'warnings' => [],
            'applied' => [],
        ];
    }

    /**
     * @param array<string, mixed> $left
     * @param array<string, mixed> $right
     * @return array<string, mixed>
     */
    private function mergeResults(array $left, array $right): array
    {
        foreach (['written', 'removed', 'backups', 'missing', 'warnings', 'applied'] as $key) {
            $left[$key] = array_values(array_merge(
                is_array($left[$key] ?? null) ? $left[$key] : [],
                is_array($right[$key] ?? null) ? $right[$key] : []
            ));
        }

        if (isset($right['database'])) {
            $left['database'] = $right['database'];
        }

        return $left;
    }

    /**
     * @param array<string, string> $files
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function writeFiles(array $files, array $options): array
    {
        $force = $this->boolOption($options, 'force', false);
        $backup = $this->boolOption($options, 'backup', false);
        $conflicts = [];
        foreach ($files as $path => $_content) {
            if (is_file($path)) {
                $conflicts[] = $path;
            }
        }

        if ($conflicts !== [] && !$force && !$backup) {
            throw new RuntimeException(
                'Conflicting files already exist: ' . implode(', ', $conflicts) . '. Use --force to overwrite or --backup to preserve them.'
            );
        }

        $result = $this->emptyResult();
        foreach ($files as $path => $content) {
            ConsoleSupport::ensureDirectory(dirname($path));
            if (is_file($path) && $backup) {
                $backupPath = $path . '.bak.' . gmdate('YmdHis');
                if (!@rename($path, $backupPath)) {
                    throw new RuntimeException('Failed to back up file before overwrite: ' . $path);
                }
                $result['backups'][] = $backupPath;
            }

            if (file_put_contents($path, $content) === false) {
                throw new RuntimeException('Failed to write file: ' . $path);
            }
            $result['written'][] = $path;
        }

        return $result;
    }

    /**
     * @param array<int, string> $paths
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function removePaths(array $paths, array $options): array
    {
        $backup = $this->boolOption($options, 'backup', false);
        $result = $this->emptyResult();

        foreach (array_values(array_unique($paths)) as $path) {
            if (!is_file($path)) {
                $result['missing'][] = $path;
                continue;
            }

            if ($backup) {
                $backupPath = $path . '.bak.' . gmdate('YmdHis');
                if (!@rename($path, $backupPath)) {
                    throw new RuntimeException('Failed to back up file before removal: ' . $path);
                }
                $result['backups'][] = $backupPath;
                $result['removed'][] = $path;
                continue;
            }

            if (!@unlink($path)) {
                throw new RuntimeException('Failed to remove file: ' . $path);
            }
            $result['removed'][] = $path;
        }

        return $result;
    }

    private function relativePath(string $path): string
    {
        $normalizedRoot = str_replace('\\', '/', rtrim($this->rootPath, '\\/'));
        $normalizedPath = str_replace('\\', '/', $path);
        if (str_starts_with($normalizedPath, $normalizedRoot . '/')) {
            return substr($normalizedPath, strlen($normalizedRoot) + 1);
        }

        return $normalizedPath;
    }

    private function stringOption(array $options, string $key): ?string
    {
        if (!array_key_exists($key, $options)) {
            return null;
        }

        $value = trim((string)$options[$key]);
        return $value === '' ? null : $value;
    }

    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }

    private function exportPhp(mixed $value, int $indent = 0): string
    {
        if ($value === null) {
            return 'null';
        }

        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        if (is_int($value) || is_float($value)) {
            return var_export($value, true);
        }

        if (is_string($value)) {
            return "'" . str_replace(['\\', '\''], ['\\\\', '\\\''], $value) . "'";
        }

        if (!is_array($value)) {
            return var_export($value, true);
        }

        if ($value === []) {
            return '[]';
        }

        $isList = array_keys($value) === range(0, count($value) - 1);
        $padding = str_repeat('    ', $indent);
        $childPadding = str_repeat('    ', $indent + 1);
        $lines = ['['];
        foreach ($value as $key => $item) {
            $line = $childPadding;
            if (!$isList) {
                $line .= $this->exportPhp((string)$key) . ' => ';
            }
            $line .= $this->exportPhp($item, $indent + 1) . ',';
            $lines[] = $line;
        }
        $lines[] = $padding . ']';

        return implode("\n", $lines);
    }
}
