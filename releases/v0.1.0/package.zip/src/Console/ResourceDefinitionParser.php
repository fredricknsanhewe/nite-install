<?php
namespace App\Console;

use RuntimeException;

final class ResourceDefinitionParser
{
    /** @var array<int, array<string, mixed>> */
    private array $tokens = [];
    private int $index = 0;

    /**
     * @return array<int, array<string, mixed>>
     */
    public function parse(string $input): array
    {
        if (str_starts_with($input, "\xEF\xBB\xBF")) {
            $input = substr($input, 3);
        }

        $this->tokens = $this->tokenize($input);
        $this->index = 0;

        $statements = [];
        while (!$this->isEnd()) {
            if ($this->matchSymbol(';')) {
                continue;
            }

            $statements[] = $this->parseStatement();
            $this->matchSymbol(';');
        }

        return $statements;
    }

    /**
     * @return array<string, mixed>
     */
    private function parseStatement(): array
    {
        $verb = strtoupper($this->expectWord('Expected a statement verb like CREATE, ALTER, or DROP.'));
        $noun = strtoupper($this->expectWord('Expected a statement target like RESOURCE, MODEL, or SERVICE.'));

        if (in_array($noun, ['MODEL', 'SERVICE', 'CONTROLLER', 'MIGRATION'], true)) {
            return $this->parseComponentStatement($verb, $noun);
        }

        if ($noun !== 'RESOURCE') {
            throw $this->error('Unsupported statement target `' . $noun . '`.');
        }

        return match ($verb) {
            'CREATE' => $this->parseCreateResourceStatement(),
            'ALTER', 'UPDATE' => $this->parseAlterResourceStatement($verb),
            'DROP', 'DELETE' => $this->parseDropResourceStatement($verb),
            default => throw $this->error('Unsupported resource verb `' . $verb . '`.'),
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function parseComponentStatement(string $verb, string $noun): array
    {
        if (!in_array($verb, ['CREATE', 'DROP', 'DELETE'], true)) {
            throw $this->error('Unsupported component verb `' . $verb . '` for `' . $noun . '`.');
        }

        $name = $this->parseIdentifier('Expected a scaffold name after ' . $verb . ' ' . $noun . '.');

        return [
            'kind' => 'component',
            'verb' => $verb,
            'noun' => $noun,
            'name' => $name,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function parseCreateResourceStatement(): array
    {
        $name = $this->parseIdentifier('Expected a resource name after CREATE RESOURCE.');
        $resource = [
            'name' => $name,
            'table' => null,
            'group' => null,
            'label' => null,
            'item_type' => null,
            'summary' => null,
            'route_segment' => null,
            'public_lookup' => null,
            'fields' => [],
            'access_rules' => [],
        ];

        while (!$this->isEnd() && !$this->checkSymbol(';')) {
            if ($this->matchWord('GROUP')) {
                $resource['group'] = $this->parseValueAsString('Expected a group value after GROUP.');
                continue;
            }

            if ($this->matchWord('LABEL')) {
                $resource['label'] = $this->parseValueAsString('Expected a label value after LABEL.');
                continue;
            }

            if ($this->matchWord('ITEM')) {
                if ($this->matchWord('TYPE')) {
                    $resource['item_type'] = $this->parseValueAsString('Expected a value after ITEM TYPE.');
                    continue;
                }

                throw $this->error('Expected TYPE after ITEM.');
            }

            if ($this->matchWord('ITEM_TYPE')) {
                $resource['item_type'] = $this->parseValueAsString('Expected a value after ITEM_TYPE.');
                continue;
            }

            if ($this->matchWord('SUMMARY', 'DESCRIPTION')) {
                $resource['summary'] = $this->parseValueAsString('Expected a summary after SUMMARY.');
                continue;
            }

            if ($this->matchWord('ROUTE', 'PATH', 'ROUTE_SEGMENT')) {
                $resource['route_segment'] = $this->parseValueAsString('Expected a route segment after ROUTE/PATH.');
                continue;
            }

            if ($this->matchWord('PUBLIC')) {
                if ($this->matchWord('KEY', 'LOOKUP')) {
                    $resource['public_lookup'] = $this->parseIdentifier('Expected a field name after PUBLIC KEY.');
                    continue;
                }

                throw $this->error('Expected KEY or LOOKUP after PUBLIC.');
            }

            if ($this->matchWord('ACCESS', 'WHERE')) {
                $resource['access_rules'] = array_merge($resource['access_rules'], $this->parseAccessBlock());
                continue;
            }

            if ($this->matchWord('HAS')) {
                $this->parseCreateResourceStorageClause($resource);
                continue;
            }

            if ($this->matchWord('DB', 'TABLE', 'FIELDS')) {
                $this->rewindOne();
                $this->parseCreateResourceStorageClause($resource);
                continue;
            }

            throw $this->error('Unexpected token while parsing CREATE RESOURCE `' . $name . '`.');
        }

        return [
            'kind' => 'resource',
            'verb' => 'CREATE',
            'resource' => $resource,
        ];
    }

    /**
     * @param array<string, mixed> $resource
     */
    private function parseCreateResourceStorageClause(array &$resource): void
    {
        if ($this->matchWord('FIELDS')) {
            $this->expectSymbol('{', 'Expected `{` after FIELDS.');
            $resource['fields'] = $this->parseFieldBlock();
            return;
        }

        if (!$this->matchWord('DB', 'TABLE')) {
            throw $this->error('Expected DB, TABLE, or FIELDS in the resource storage clause.');
        }

        $this->matchSymbol(':');
        $resource['table'] = $this->parseIdentifier('Expected a database table name after DB/TABLE.');
        if ($this->matchSymbol('{')) {
            $resource['fields'] = $this->parseFieldBlock();
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function parseAlterResourceStatement(string $verb): array
    {
        $name = $this->parseIdentifier('Expected a resource name after ' . $verb . ' RESOURCE.');
        $operations = [];

        while (!$this->isEnd() && !$this->checkSymbol(';')) {
            if ($this->matchWord('ADD')) {
                $this->expectWordValue('FIELD', 'Expected FIELD after ADD.');
                $operations[] = [
                    'type' => 'add_field',
                    'field' => $this->parseFieldDefinition(),
                ];
                continue;
            }

            if ($this->matchWord('MODIFY', 'CHANGE')) {
                $this->expectWordValue('FIELD', 'Expected FIELD after MODIFY.');
                $operations[] = [
                    'type' => 'modify_field',
                    'field' => $this->parseFieldDefinition(),
                ];
                continue;
            }

            if ($this->matchWord('DROP', 'DELETE', 'REMOVE')) {
                $this->expectWordValue('FIELD', 'Expected FIELD after DROP/DELETE/REMOVE.');
                $operations[] = [
                    'type' => 'drop_field',
                    'name' => $this->parseIdentifier('Expected a field name after DROP FIELD.'),
                ];
                continue;
            }

            if ($this->matchWord('GRANT')) {
                $operations[] = [
                    'type' => 'grant_access',
                    'rule' => $this->parseAccessRule('allow'),
                ];
                continue;
            }

            if ($this->matchWord('REVOKE', 'DENY')) {
                $operations[] = [
                    'type' => 'revoke_access',
                    'rule' => $this->parseAccessRule('deny'),
                ];
                continue;
            }

            if ($this->matchWord('ACCESS', 'WHERE')) {
                $operations[] = [
                    'type' => 'replace_access',
                    'rules' => $this->parseAccessBlock(),
                ];
                continue;
            }

            if ($this->matchWord('SET')) {
                $operations[] = $this->parseSetOperation();
                continue;
            }

            if ($this->matchWord('TABLE', 'DB')) {
                $this->rewindOne();
                $operations[] = $this->parseSetTableOperation();
                continue;
            }

            throw $this->error('Unexpected ALTER RESOURCE clause for `' . $name . '`.');
        }

        if ($operations === []) {
            throw $this->error('ALTER RESOURCE `' . $name . '` did not contain any operations.');
        }

        return [
            'kind' => 'resource',
            'verb' => 'ALTER',
            'resource_name' => $name,
            'operations' => $operations,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function parseSetOperation(): array
    {
        if ($this->matchWord('GROUP')) {
            return [
                'type' => 'set_group',
                'value' => $this->parseValueAsString('Expected a value after SET GROUP.'),
            ];
        }

        if ($this->matchWord('LABEL')) {
            return [
                'type' => 'set_label',
                'value' => $this->parseValueAsString('Expected a value after SET LABEL.'),
            ];
        }

        if ($this->matchWord('SUMMARY', 'DESCRIPTION')) {
            return [
                'type' => 'set_summary',
                'value' => $this->parseValueAsString('Expected a value after SET SUMMARY.'),
            ];
        }

        if ($this->matchWord('ITEM_TYPE')) {
            return [
                'type' => 'set_item_type',
                'value' => $this->parseValueAsString('Expected a value after SET ITEM_TYPE.'),
            ];
        }

        if ($this->matchWord('ITEM')) {
            $this->expectWordValue('TYPE', 'Expected TYPE after SET ITEM.');
            return [
                'type' => 'set_item_type',
                'value' => $this->parseValueAsString('Expected a value after SET ITEM TYPE.'),
            ];
        }

        if ($this->matchWord('ROUTE', 'PATH', 'ROUTE_SEGMENT')) {
            return [
                'type' => 'set_route_segment',
                'value' => $this->parseValueAsString('Expected a value after SET ROUTE/PATH.'),
            ];
        }

        if ($this->matchWord('PUBLIC')) {
            $this->expectWordValue('KEY', 'Expected KEY after SET PUBLIC.');
            return [
                'type' => 'set_public_lookup',
                'value' => $this->parseIdentifier('Expected a field name after SET PUBLIC KEY.'),
            ];
        }

        if ($this->checkWord('TABLE') || $this->checkWord('DB')) {
            return $this->parseSetTableOperation();
        }

        throw $this->error('Unsupported SET clause in ALTER RESOURCE.');
    }

    /**
     * @return array<string, mixed>
     */
    private function parseSetTableOperation(): array
    {
        if (!$this->matchWord('TABLE', 'DB')) {
            throw $this->error('Expected TABLE or DB in ALTER RESOURCE.');
        }

        return [
            'type' => 'set_table',
            'value' => $this->parseIdentifier('Expected a new table name after TABLE.'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function parseDropResourceStatement(string $verb): array
    {
        $name = $this->parseIdentifier('Expected a resource name after ' . $verb . ' RESOURCE.');

        return [
            'kind' => 'resource',
            'verb' => 'DROP',
            'resource_name' => $name,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function parseFieldBlock(): array
    {
        $fields = [];
        while (!$this->isEnd() && !$this->checkSymbol('}')) {
            if ($this->matchSymbol(';', ',')) {
                continue;
            }

            $fields[] = $this->parseFieldDefinition();
            $this->matchSymbol(';', ',');
        }

        $this->expectSymbol('}', 'Expected `}` to close the field block.');
        return $fields;
    }

    /**
     * @return array<string, mixed>
     */
    private function parseFieldDefinition(): array
    {
        $name = $this->parseIdentifier('Expected a field name.');
        $type = strtolower($this->parseIdentifier('Expected a field type after `' . $name . '`.'));

        $parameters = [];
        if ($this->matchSymbol('(')) {
            while (!$this->isEnd() && !$this->checkSymbol(')')) {
                if ($this->matchSymbol(',')) {
                    continue;
                }
                $parameters[] = $this->parseLiteralValue();
            }
            $this->expectSymbol(')', 'Expected `)` after the field type parameters.');
        }

        $field = [
            'name' => ConsoleSupport::snake($name),
            'type' => $type,
            'parameters' => $parameters,
            'nullable' => false,
            'required' => false,
            'unique' => false,
            'index' => false,
            'searchable' => false,
            'filterable' => false,
            'public_lookup' => false,
            'read_only' => false,
            'write_only' => false,
            'primary' => false,
            'auto' => false,
            'generated' => false,
            'default' => null,
            'has_default' => false,
            'references' => null,
            'relationship' => null,
            'label' => null,
            'description' => null,
            'format' => null,
        ];

        while (!$this->isEnd() && !$this->checkSymbol(';') && !$this->checkSymbol(',') && !$this->checkSymbol('}')) {
            $keyword = strtoupper($this->expectWord('Expected a field modifier.'));

            if ($keyword === 'NOT') {
                $this->expectWordValue('NULL', 'Expected NULL after NOT in a field definition.');
                $field['nullable'] = false;
                continue;
            }

            if ($keyword === 'NULL' || $keyword === 'NULLABLE') {
                $field['nullable'] = true;
                continue;
            }

            if ($keyword === 'REQUIRED') {
                $field['required'] = true;
                $field['nullable'] = false;
                continue;
            }

            if ($keyword === 'PRIMARY') {
                $field['primary'] = true;
                $field['nullable'] = false;
                continue;
            }

            if ($keyword === 'UNIQUE') {
                $field['unique'] = true;
                continue;
            }

            if ($keyword === 'INDEX') {
                $field['index'] = true;
                $field['filterable'] = true;
                continue;
            }

            if ($keyword === 'SEARCH' || $keyword === 'SEARCHABLE') {
                $field['searchable'] = true;
                continue;
            }

            if ($keyword === 'FILTER' || $keyword === 'FILTERABLE') {
                $field['filterable'] = true;
                continue;
            }

            if ($keyword === 'PUBLIC') {
                $field['public_lookup'] = true;
                continue;
            }

            if ($keyword === 'READ_ONLY' || $keyword === 'READONLY') {
                $field['read_only'] = true;
                continue;
            }

            if ($keyword === 'WRITE_ONLY' || $keyword === 'WRITEONLY') {
                $field['write_only'] = true;
                continue;
            }

            if ($keyword === 'AUTO') {
                $field['auto'] = true;
                continue;
            }

            if ($keyword === 'GENERATED') {
                $field['generated'] = true;
                continue;
            }

            if ($keyword === 'DEFAULT') {
                $field['default'] = $this->parseLiteralValue();
                $field['has_default'] = true;
                continue;
            }

            if ($keyword === 'FORMAT') {
                $field['format'] = $this->parseValueAsString('Expected a format value after FORMAT.');
                continue;
            }

            if ($keyword === 'LABEL') {
                $field['label'] = $this->parseValueAsString('Expected a label after LABEL.');
                continue;
            }

            if ($keyword === 'DESCRIPTION') {
                $field['description'] = $this->parseValueAsString('Expected a description after DESCRIPTION.');
                continue;
            }

            if ($keyword === 'REFERENCES') {
                $field['references'] = $this->parseReferenceTarget();
                continue;
            }

            if (in_array($keyword, ['BELONGS_TO', 'HAS_ONE', 'HAS_MANY'], true)) {
                $field['relationship'] = [
                    'type' => strtolower($keyword),
                    'target' => $this->parseReferenceTarget(),
                ];
                continue;
            }

            throw $this->error('Unsupported field modifier `' . $keyword . '` on `' . $field['name'] . '`.');
        }

        return $field;
    }

    /**
     * @return array<string, string>
     */
    private function parseReferenceTarget(): array
    {
        $target = $this->parseIdentifier('Expected a reference target like users.id.');
        if (!str_contains($target, '.')) {
            $column = $this->parseIdentifier('Expected a column name after the reference table.');
            $target .= '.' . $column;
        }

        [$table, $column] = array_pad(explode('.', $target, 2), 2, 'id');

        return [
            'table' => ConsoleSupport::snake($table),
            'column' => ConsoleSupport::snake($column),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function parseAccessBlock(): array
    {
        $this->matchSymbol(':');
        $this->expectSymbol('{', 'Expected `{` after ACCESS/WHERE.');

        $rules = [];
        while (!$this->isEnd() && !$this->checkSymbol('}')) {
            if ($this->matchSymbol(';', ',')) {
                continue;
            }

            $rules[] = $this->parseAccessRule(null);
            $this->matchSymbol(';', ',');
        }

        $this->expectSymbol('}', 'Expected `}` to close the access block.');
        return $rules;
    }

    /**
     * @return array<string, mixed>
     */
    private function parseAccessRule(?string $forcedEffect): array
    {
        $negated = false;
        if ($forcedEffect === null && $this->matchWord('NOT')) {
            $negated = true;
        }

        $subjectTokens = [];
        while (
            !$this->isEnd()
            && !$this->checkWord('CAN')
            && !$this->checkWord('CANNOT')
            && !$this->checkWord('CANT')
            && !$this->checkSymbol('{')
            && !$this->checkSymbol('}')
            && !$this->checkSymbol(';')
        ) {
            $subjectTokens[] = $this->advance();
        }

        if ($subjectTokens === []) {
            throw $this->error('Expected an access subject before CAN.');
        }

        $effect = $forcedEffect ?? ($negated ? 'deny' : 'allow');
        if ($this->matchWord('CAN')) {
            // The action block follows.
        } elseif ($this->matchWord('CANNOT', 'CANT')) {
            $effect = 'deny';
        } else {
            throw $this->error('Expected CAN or CANNOT in the access rule.');
        }

        $subject = $this->tokensToPhrase($subjectTokens);
        $roles = $this->extractRoles($subjectTokens);
        $actions = $this->parseActionList();

        return [
            'effect' => $effect,
            'subject' => $subject,
            'roles' => $roles['roles'],
            'derivable' => $roles['derivable'],
            'actions' => $actions,
        ];
    }

    /**
     * @return array<int, string>
     */
    private function parseActionList(): array
    {
        $this->expectSymbol('{', 'Expected `{` before the access action list.');

        $actions = [];
        while (!$this->isEnd() && !$this->checkSymbol('}')) {
            if ($this->matchSymbol(',')) {
                continue;
            }

            $actions[] = strtolower($this->parseIdentifier('Expected an access action name.'));
        }

        $this->expectSymbol('}', 'Expected `}` after the access action list.');
        return array_values(array_unique($actions));
    }

    /**
     * @param array<int, array<string, mixed>> $tokens
     * @return array{roles: array<int, string>, derivable: bool}
     */
    private function extractRoles(array $tokens): array
    {
        $raw = $this->tokensToPhrase($tokens);
        $derivable = !preg_match('/\bAND\b/i', $raw) && !str_contains($raw, '(') && !str_contains($raw, ')');
        $roles = [];

        if (preg_match_all('/(?:role|user_type)\.([a-z0-9_-]+)/i', $raw, $matches) === 1 || count($matches[1] ?? []) > 0) {
            $roles = array_values(array_unique(array_map(static fn (string $value): string => strtolower(trim($value)), $matches[1])));
        } else {
            $parts = preg_split('/\s+/', trim($raw)) ?: [];
            foreach ($parts as $part) {
                $normalized = strtolower(trim($part));
                if ($normalized === '' || in_array($normalized, ['or', 'and', 'not'], true)) {
                    continue;
                }
                $roles[] = $normalized;
            }
            $roles = array_values(array_unique($roles));
        }

        return [
            'roles' => $roles,
            'derivable' => $derivable && $roles !== [],
        ];
    }

    private function parseLiteralValue(): mixed
    {
        if ($this->matchSymbol('{')) {
            $this->expectSymbol('}', 'Expected `}` after `{` in a literal value.');
            return '{}';
        }

        if ($this->matchSymbol('[')) {
            $this->expectSymbol(']', 'Expected `]` after `[` in a literal value.');
            return '[]';
        }

        $token = $this->advance();
        if ($token === null) {
            throw $this->error('Unexpected end of input while reading a literal value.');
        }

        if (($token['type'] ?? '') === 'string') {
            return $token['value'];
        }

        $value = (string)($token['value'] ?? '');
        $lower = strtolower($value);
        if ($lower === 'true') {
            return true;
        }
        if ($lower === 'false') {
            return false;
        }
        if ($lower === 'null') {
            return null;
        }
        if (is_numeric($value)) {
            return str_contains($value, '.') ? (float)$value : (int)$value;
        }

        return $value;
    }

    private function parseValueAsString(string $message): string
    {
        $value = $this->parseLiteralValue();
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        if ($value === null) {
            return 'null';
        }

        return trim((string)$value);
    }

    private function parseIdentifier(string $message): string
    {
        $token = $this->advance();
        if ($token === null) {
            throw $this->error($message);
        }

        $type = (string)($token['type'] ?? '');
        if (!in_array($type, ['word', 'string'], true)) {
            throw $this->error($message);
        }

        $value = (string)($token['value'] ?? '');
        while ($this->matchSymbol('.')) {
            $value .= '.' . $this->parseIdentifier('Expected an identifier segment after `.`.');
        }

        return trim($value);
    }

    private function expectWord(string $message): string
    {
        $token = $this->advance();
        if ($token === null || ($token['type'] ?? '') !== 'word') {
            throw $this->error($message);
        }

        return (string)$token['value'];
    }

    private function expectWordValue(string $expected, string $message): void
    {
        $value = strtoupper($this->expectWord($message));
        if ($value !== strtoupper($expected)) {
            throw $this->error($message);
        }
    }

    private function expectSymbol(string $symbol, string $message): void
    {
        if (!$this->matchSymbol($symbol)) {
            throw $this->error($message);
        }
    }

    private function checkWord(string ...$values): bool
    {
        $token = $this->peek();
        if ($token === null || ($token['type'] ?? '') !== 'word') {
            return false;
        }

        return in_array(strtoupper((string)$token['value']), array_map('strtoupper', $values), true);
    }

    private function matchWord(string ...$values): bool
    {
        if (!$this->checkWord(...$values)) {
            return false;
        }

        $this->index++;
        return true;
    }

    private function checkSymbol(string $symbol): bool
    {
        $token = $this->peek();
        return $token !== null && ($token['type'] ?? '') === 'symbol' && ($token['value'] ?? '') === $symbol;
    }

    private function matchSymbol(string ...$symbols): bool
    {
        foreach ($symbols as $symbol) {
            if ($this->checkSymbol($symbol)) {
                $this->index++;
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<int, array<string, mixed>> $tokens
     */
    private function tokensToPhrase(array $tokens): string
    {
        $buffer = '';
        foreach ($tokens as $index => $token) {
            $value = (string)($token['value'] ?? '');
            if ($value === '.') {
                $buffer = rtrim($buffer) . '.';
                continue;
            }

            if ($index > 0 && !str_ends_with($buffer, '.')) {
                $buffer .= ' ';
            }
            $buffer .= $value;
        }

        return trim($buffer);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function tokenize(string $input): array
    {
        $tokens = [];
        $length = strlen($input);
        $line = 1;
        $column = 1;

        for ($index = 0; $index < $length; ) {
            $char = $input[$index];

            if ($char === "\r") {
                $index++;
                continue;
            }

            if ($char === "\n") {
                $line++;
                $column = 1;
                $index++;
                continue;
            }

            if (ctype_space($char)) {
                $index++;
                $column++;
                continue;
            }

            if ($char === '#' || ($char === '-' && substr($input, $index, 2) === '--') || ($char === '/' && substr($input, $index, 2) === '//')) {
                while ($index < $length && !in_array($input[$index], ["\r", "\n"], true)) {
                    $index++;
                }
                continue;
            }

            if (in_array($char, ['`', '\'', '"'], true)) {
                $quote = $char;
                $value = '';
                $startLine = $line;
                $startColumn = $column;
                $index++;
                $column++;

                while ($index < $length) {
                    $current = $input[$index];
                    if ($current === '\\' && $index + 1 < $length) {
                        $value .= $input[$index + 1];
                        $index += 2;
                        $column += 2;
                        continue;
                    }

                    if ($current === $quote) {
                        $index++;
                        $column++;
                        break;
                    }

                    if ($current === "\n") {
                        $line++;
                        $column = 1;
                        $value .= $current;
                        $index++;
                        continue;
                    }

                    $value .= $current;
                    $index++;
                    $column++;
                }

                $tokens[] = [
                    'type' => 'string',
                    'value' => $value,
                    'line' => $startLine,
                    'column' => $startColumn,
                ];
                continue;
            }

            if (in_array($char, ['{', '}', '(', ')', '[', ']', ',', ';', ':', '.'], true)) {
                $tokens[] = [
                    'type' => 'symbol',
                    'value' => $char,
                    'line' => $line,
                    'column' => $column,
                ];
                $index++;
                $column++;
                continue;
            }

            if (preg_match('/[A-Za-z0-9_\\-]/', $char) === 1) {
                $start = $index;
                $startColumn = $column;
                while ($index < $length && preg_match('/[A-Za-z0-9_\\-]/', $input[$index]) === 1) {
                    $index++;
                    $column++;
                }

                $tokens[] = [
                    'type' => 'word',
                    'value' => substr($input, $start, $index - $start),
                    'line' => $line,
                    'column' => $startColumn,
                ];
                continue;
            }

            throw new RuntimeException('Unexpected character `' . $char . '` at line ' . $line . ', column ' . $column . '.');
        }

        return $tokens;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function peek(): ?array
    {
        return $this->tokens[$this->index] ?? null;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function advance(): ?array
    {
        $token = $this->peek();
        if ($token !== null) {
            $this->index++;
        }

        return $token;
    }

    private function rewindOne(): void
    {
        $this->index = max(0, $this->index - 1);
    }

    private function isEnd(): bool
    {
        return $this->index >= count($this->tokens);
    }

    private function error(string $message): RuntimeException
    {
        $token = $this->peek();
        if ($token === null) {
            return new RuntimeException($message . ' Reached the end of the DSL input.');
        }

        return new RuntimeException(
            $message
            . ' Near `'
            . (string)($token['value'] ?? '')
            . '` at line '
            . (string)($token['line'] ?? 0)
            . ', column '
            . (string)($token['column'] ?? 0)
            . '.'
        );
    }
}
