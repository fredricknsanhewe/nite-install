<?php
namespace App\Services;

use App\Config\Database;
use App\Models\SampleRecordModel;
use RuntimeException;

/**
 * Application service for the sample record module.
 *
 * This class is the transaction boundary for sample record writes. Every
 * create, update, delete, or restore operation writes the domain row and the
 * matching audit log entry inside the same database transaction, so callers do
 * not need to coordinate those steps manually.
 *
 * The aliases below are intentionally verbose so IDEs and static analyzers can
 * expose the supported keys while developers read or type against the service.
 *
 * @phpstan-type SampleRecordType 'guide'|'workflow'|'policy'|'dataset'
 * @phpstan-type SampleRecordStatus 'draft'|'active'|'archived'
 * @phpstan-type SampleRecordFilters array{
 *     q?: string,
 *     status?: SampleRecordStatus,
 *     record_type?: SampleRecordType,
 *     owner_user_id?: string,
 *     limit?: int
 * }
 * @phpstan-type SampleRecordPayload array{
 *     slug?: non-empty-string,
 *     title?: non-empty-string,
 *     summary?: string|null,
 *     record_type?: SampleRecordType,
 *     status?: SampleRecordStatus,
 *     owner_user_id?: string|null,
 *     labels?: list<string>,
 *     labels_json?: list<string>,
 *     metadata?: array<string, mixed>,
 *     metadata_json?: array<string, mixed>
 * }
 * @phpstan-type SampleRecordRow array{
 *     id: string,
 *     slug: non-empty-string,
 *     title: non-empty-string,
 *     summary: string|null,
 *     record_type: SampleRecordType,
 *     status: SampleRecordStatus,
 *     owner_user_id: string|null,
 *     labels: list<string>,
 *     metadata: array<string, mixed>,
 *     created_by_user_id?: string|null,
 *     updated_by_user_id?: string|null,
 *     created_at?: string|null,
 *     updated_at?: string|null
 * }
 * @phpstan-type SampleRecordHistoryFilters array{
 *     q?: string,
 *     action?: 'create'|'update'|'delete'|'restore',
 *     actor_user_id?: string,
 *     limit?: int,
 *     offset?: int
 * }
 * @phpstan-type SampleRecordChangeContext array{
 *     change_scope?: string,
 *     actor_user_id?: string|null,
 *     actor_role?: string|null,
 *     request_method?: string|null,
 *     request_path?: string|null,
 *     route_path?: string|null,
 *     ip_address?: string|null,
 *     user_agent?: string|null,
 *     reason?: string|null,
 *     restored_from_log_id?: int|null,
 *     metadata?: array<string, mixed>
 * }
 * @phpstan-type SampleRecordChangeLog array{
 *     id?: int,
 *     table_name?: string,
 *     record_id?: string,
 *     record_slug?: string|null,
 *     record_title?: string|null,
 *     action?: 'create'|'update'|'delete'|'restore'|string,
 *     change_scope?: string,
 *     actor_user_id?: string|null,
 *     actor_role?: string|null,
 *     request_method?: string|null,
 *     request_path?: string|null,
 *     route_path?: string|null,
 *     ip_address?: string|null,
 *     user_agent?: string|null,
 *     reason?: string|null,
 *     before_json?: array<string, mixed>,
 *     after_json?: array<string, mixed>,
 *     diff_json?: array<string, mixed>,
 *     metadata_json?: array<string, mixed>,
 *     restorable_json?: array<string, mixed>,
 *     restored_from_log_id?: int|null,
 *     created_at?: string|null
 * }
 * @phpstan-type SampleRecordMutationResult array{
 *     record: SampleRecordRow,
 *     change_log: SampleRecordChangeLog
 * }
 * @phpstan-type SampleRecordDeleteResult array{
 *     deleted: bool,
 *     record: SampleRecordRow,
 *     change_log: SampleRecordChangeLog
 * }
 * @phpstan-type SampleRecordRestoreResult array{
 *     record: SampleRecordRow,
 *     restored_from: SampleRecordChangeLog,
 *     change_log: SampleRecordChangeLog
 * }
 */
final class SampleRecordService
{
    private const TABLE = 'sample_records';

    private SampleRecordModel $records;
    private DataChangeLogService $changes;

    public function __construct()
    {
        $this->records = new SampleRecordModel();
        $this->changes = new DataChangeLogService();
    }

    /**
     * List sample records using the same filter contract exposed by the HTTP API.
     *
     * Supported filters:
     * - `q`: free-text match against `title`, `summary`, and `slug`
     * - `record_type`: one of `guide`, `workflow`, `policy`, or `dataset`
     * - `owner_user_id`: limit rows to one owner
     * - `status`: only honored when `$admin` is `true`
     * - `limit`: maximum rows to return, clamped by the model layer
     *
     * Example:
     * `list(['q' => 'policy', 'record_type' => 'policy', 'limit' => 20], true)`
     *
     * @param array<string, mixed> $filters Filter map received from the controller or a direct caller.
     * @param bool $admin When `false`, only active records are returned. When `true`, draft and archived rows may also be returned.
     * @return array<int, array<string, mixed>> Hydrated sample record rows.
     * @phpstan-param SampleRecordFilters $filters
     * @phpstan-return list<SampleRecordRow>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        return $this->records->list($filters, $admin);
    }

    /**
     * Fetch one publicly visible sample record by slug.
     *
     * This method only returns records whose persisted status is `active`.
     * Draft and archived rows are intentionally hidden from public callers.
     *
     * Example:
     * `showPublic('api-quick-start')`
     *
     * @param string $slug Public slug exposed in `/api/v1/sample-records/{slug}`.
     * @return array<string, mixed>|null One hydrated record row, or `null` when the slug is missing or not public.
     * @phpstan-return SampleRecordRow|null
     */
    public function showPublic(string $slug): ?array
    {
        return $this->records->findBySlug($slug, false);
    }

    /**
     * Fetch one sample record by its internal UUID without public visibility checks.
     *
     * Example:
     * `showAdmin('6c9c1f2d-3b98-4c3d-9e74-1f8fef124321')`
     *
     * @param string $id Internal sample record UUID.
     * @return array<string, mixed>|null One hydrated record row, or `null` when the UUID does not exist.
     * @phpstan-return SampleRecordRow|null
     */
    public function showAdmin(string $id): ?array
    {
        return $this->records->findById($id);
    }

    /**
     * Create a sample record and its audit log entry in one database transaction.
     *
     * Required payload keys on create:
     * - `slug`
     * - `title`
     *
     * Optional payload keys:
     * - `summary`
     * - `record_type`: `guide`, `workflow`, `policy`, or `dataset`
     * - `status`: `draft`, `active`, or `archived`
     * - `owner_user_id`
     * - `labels`
     * - `metadata`
     *
     * Example payload:
     * `[
     *     'slug' => 'api-quick-start',
     *     'title' => 'API Quick Start',
     *     'summary' => 'Checklist for onboarding a new API consumer.',
     *     'record_type' => 'guide',
     *     'status' => 'draft',
     *     'labels' => ['docs', 'onboarding'],
     *     'metadata' => ['source' => 'internal-wiki'],
     * ]`
     *
     * Example context:
     * `[
     *     'change_scope' => 'sample_records',
     *     'actor_user_id' => '6c9c1f2d-3b98-4c3d-9e74-1f8fef124321',
     *     'reason' => 'Initial import',
     * ]`
     *
     * @param array<string, mixed> $payload Record data to validate and persist.
     * @param array<string, mixed> $context Audit metadata, usually from `DataChangeContext::fromRequest()`.
     * @return array<string, mixed> The created record plus the generated change-log row.
     * @phpstan-param SampleRecordPayload $payload
     * @phpstan-param SampleRecordChangeContext $context
     * @phpstan-return SampleRecordMutationResult
     * @throws RuntimeException When the payload fails model-level validation.
     */
    public function create(array $payload, array $context = []): array
    {
        $db = Database::connection();
        $db->beginTransaction();

        try {
            $record = $this->records->create($payload, (string)($context['actor_user_id'] ?? ''));
            $changeLog = $this->changes->logCreate(self::TABLE, $record, $contextWithMetadata = $this->withMetadata($context, [
                'operation' => 'sample_records.create',
            ]));
            $db->commit();

            return [
                'record' => $record,
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Update one sample record and append an audit log entry for the change.
     *
     * The payload is partial: callers only need to send the keys they want to
     * replace. Validation rules still apply to any provided keys.
     *
     * Example:
     * `update(
     *     '6c9c1f2d-3b98-4c3d-9e74-1f8fef124321',
     *     ['status' => 'active', 'labels' => ['docs', 'public']],
     *     ['actor_user_id' => '6c9c1f2d-3b98-4c3d-9e74-1f8fef124321']
     * )`
     *
     * @param string $id Internal sample record UUID.
     * @param array<string, mixed> $payload Partial field set to persist.
     * @param array<string, mixed> $context Audit metadata, usually from `DataChangeContext::fromRequest()`.
     * @return array<string, mixed>|null Updated record plus change log, or `null` when the UUID does not exist.
     * @phpstan-param SampleRecordPayload $payload
     * @phpstan-param SampleRecordChangeContext $context
     * @phpstan-return SampleRecordMutationResult|null
     * @throws RuntimeException When the payload fails model-level validation.
     */
    public function update(string $id, array $payload, array $context = []): ?array
    {
        $existing = $this->records->findById($id);
        if ($existing === null) {
            return null;
        }

        $db = Database::connection();
        $db->beginTransaction();

        try {
            $record = $this->records->update($id, $payload, (string)($context['actor_user_id'] ?? ''));
            if ($record === null) {
                throw new RuntimeException('Sample record not found.');
            }

            $changeLog = $this->changes->logUpdate(self::TABLE, $existing, $record, $this->withMetadata($context, [
                'operation' => 'sample_records.update',
            ]));
            $db->commit();

            return [
                'record' => $record,
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Delete a sample record while preserving a restorable audit snapshot.
     *
     * Despite the method name, the underlying persistence layer performs a hard
     * delete. The "soft" part is the archived change-log snapshot that allows
     * `restoreFromLog()` to rebuild the row later.
     *
     * Example:
     * `softDelete('6c9c1f2d-3b98-4c3d-9e74-1f8fef124321', ['reason' => 'Duplicate entry'])`
     *
     * @param string $id Internal sample record UUID.
     * @param array<string, mixed> $context Audit metadata, usually from `DataChangeContext::fromRequest()`.
     * @return array<string, mixed>|null Delete result, archived row snapshot, and change log, or `null` when the UUID does not exist.
     * @phpstan-param SampleRecordChangeContext $context
     * @phpstan-return SampleRecordDeleteResult|null
     */
    public function softDelete(string $id, array $context = []): ?array
    {
        $existing = $this->records->findById($id);
        if ($existing === null) {
            return null;
        }

        $db = Database::connection();
        $db->beginTransaction();

        try {
            $changeLog = $this->changes->logDelete(self::TABLE, $existing, $this->withMetadata($context, [
                'operation' => 'sample_records.soft_delete',
            ]));
            $deleted = $this->records->delete($id);
            $db->commit();

            return [
                'deleted' => $deleted,
                'record' => $existing,
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * List archive log rows for the sample record table.
     *
     * Supported filters:
     * - `q`
     * - `action`
     * - `actor_user_id`
     * - `limit`
     * - `offset`
     *
     * Example:
     * `history(['action' => 'delete', 'limit' => 50])`
     *
     * @param array<string, mixed> $filters Change-log filter map.
     * @return array<int, array<string, mixed>> Change-log rows ordered by newest first.
     * @phpstan-param SampleRecordHistoryFilters $filters
     * @phpstan-return list<SampleRecordChangeLog>
     */
    public function history(array $filters = []): array
    {
        return $this->changes->listForTable(self::TABLE, $filters);
    }

    /**
     * List archive log rows for a single sample record UUID.
     *
     * Invalid UUIDs return an empty list instead of throwing, which makes this
     * method safe to call directly from controllers that read route params.
     *
     * Example:
     * `recordHistory('6c9c1f2d-3b98-4c3d-9e74-1f8fef124321', ['limit' => 20])`
     *
     * @param string $recordId Internal sample record UUID.
     * @param array<string, mixed> $filters Change-log filter map.
     * @return array<int, array<string, mixed>> Change-log rows for the requested record.
     * @phpstan-param SampleRecordHistoryFilters $filters
     * @phpstan-return list<SampleRecordChangeLog>
     */
    public function recordHistory(string $recordId, array $filters = []): array
    {
        if (!$this->isUuid($recordId)) {
            return [];
        }

        return $this->changes->listForRecord(self::TABLE, $recordId, $filters);
    }

    /**
     * Restore a deleted or previously updated sample record from one audit log row.
     *
     * Only `update` and `delete` log entries are restorable. `create` logs are
     * ignored because they do not represent a prior state to roll back to.
     *
     * Example:
     * `restoreFromLog(104, ['actor_user_id' => '6c9c1f2d-3b98-4c3d-9e74-1f8fef124321'])`
     *
     * @param int $logId Primary key from `data_change_logs`.
     * @param array<string, mixed> $context Audit metadata, usually from `DataChangeContext::fromRequest()`.
     * @return array<string, mixed>|null Restored record, source log entry, and new restore audit row, or `null` when the log entry is missing or belongs to another table.
     * @phpstan-param SampleRecordChangeContext $context
     * @phpstan-return SampleRecordRestoreResult|null
     * @throws RuntimeException When the selected log row is not restorable.
     */
    public function restoreFromLog(int $logId, array $context = []): ?array
    {
        $log = $this->changes->findById($logId);
        if ($log === null || (string)($log['table_name'] ?? '') !== self::TABLE) {
            return null;
        }
        if (!in_array((string)($log['action'] ?? ''), ['update', 'delete'], true)) {
            throw new RuntimeException('Only update and delete log entries can be restored.');
        }

        $snapshot = is_array($log['restorable_json'] ?? null) ? $log['restorable_json'] : [];
        $recordId = (string)($snapshot['id'] ?? $log['record_id'] ?? '');
        if ($recordId === '' || !$this->isUuid($recordId)) {
            throw new RuntimeException('The selected log entry does not have a restorable record snapshot.');
        }

        $beforeRestore = $this->records->findById($recordId) ?? [];
        $db = Database::connection();
        $db->beginTransaction();

        try {
            $record = $this->records->restoreSnapshot($snapshot, (string)($context['actor_user_id'] ?? ''));
            $changeLog = $this->changes->logRestore(self::TABLE, $beforeRestore, $record, $logId, $this->withMetadata($context, [
                'operation' => 'sample_records.restore',
                'restored_action' => $log['action'] ?? null,
            ]));
            $db->commit();

            return [
                'record' => $record,
                'restored_from' => $log,
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Return the total number of persisted sample records.
     *
     * This count ignores public/admin visibility rules and simply proxies the
     * backing model's aggregate query.
     */
    public function count(): int
    {
        return $this->records->count();
    }

    /**
     * Merge service-level metadata into the caller-provided change context.
     *
     * This helper preserves any existing `metadata` keys while injecting
     * operation-specific values such as `sample_records.create` or
     * `sample_records.restore`.
     *
     * @param array<string, mixed> $context Base audit context from the controller layer.
     * @param array<string, mixed> $extraMetadata Additional keys to append under the `metadata` node.
     * @return array<string, mixed> The merged context ready for `DataChangeLogService`.
     * @phpstan-param SampleRecordChangeContext $context
     * @phpstan-return SampleRecordChangeContext
     */
    private function withMetadata(array $context, array $extraMetadata): array
    {
        $metadata = is_array($context['metadata'] ?? null) ? $context['metadata'] : [];
        $context['metadata'] = array_merge($metadata, $extraMetadata);
        return $context;
    }

    private function isUuid(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1;
    }
}
