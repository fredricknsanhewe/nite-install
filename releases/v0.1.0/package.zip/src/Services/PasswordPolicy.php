<?php
namespace App\Services;

use App\Config\AuthConfig;
use App\Exceptions\ValidationException;

final class PasswordPolicy
{
    public static function assert(string $password, string $field = 'password'): void
    {
        $errors = [];
        $minLength = AuthConfig::passwordMinLength();

        if (mb_strlen($password) < $minLength) {
            $errors[] = 'Password must be at least ' . $minLength . ' characters long.';
        }
        if (AuthConfig::requireUppercase() && preg_match('/[A-Z]/', $password) !== 1) {
            $errors[] = 'Password must include at least one uppercase letter.';
        }
        if (AuthConfig::requireLowercase() && preg_match('/[a-z]/', $password) !== 1) {
            $errors[] = 'Password must include at least one lowercase letter.';
        }
        if (AuthConfig::requireNumber() && preg_match('/\d/', $password) !== 1) {
            $errors[] = 'Password must include at least one number.';
        }
        if (AuthConfig::requireSymbol() && preg_match('/[^a-zA-Z0-9]/', $password) !== 1) {
            $errors[] = 'Password must include at least one symbol.';
        }

        if ($errors !== []) {
            throw new ValidationException([$field => $errors]);
        }
    }
}
