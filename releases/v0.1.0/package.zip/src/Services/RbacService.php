<?php
namespace App\Services;

use App\Config\PermissionCatalog;
use App\Config\Roles;
use App\Models\RbacModel;
use App\Models\UserModel;
use RuntimeException;

final class RbacService
{
    private RbacModel $rbac;
    private UserModel $users;
    /** @var array<string, array<int, string>> */
    private static array $effectivePermissionCache = [];

    public function __construct()
    {
        $this->rbac = new RbacModel();
        $this->users = new UserModel();
    }

    public function bootstrap(): void
    {
        $this->rbac->upsertPermissions(PermissionCatalog::definitions());
    }

    /**
     * @return array<int, string>
     */
    public function roles(): array
    {
        return Roles::all();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function permissions(): array
    {
        $this->bootstrap();
        return PermissionCatalog::definitions();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function matrix(): array
    {
        $this->bootstrap();
        $roleRules = $this->rbac->listAllRoleRuleStates();
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $row = $definition;
            foreach (Roles::all() as $role) {
                $default = PermissionCatalog::isGrantedByDefault($role, (string)$definition['code']);
                $state = $roleRules[$definition['code']][$role] ?? 'inherit';
                $row[$role . '_default'] = $default;
                $row[$role . '_state'] = $state;
                $row[$role] = $this->applyState($default, $state);
            }
            $rows[] = $row;
        }
        return $rows;
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>
     */
    public function setRolePermissions(string $role, array $statesByCode): array
    {
        if (!in_array($role, Roles::all(), true)) {
            throw new RuntimeException('Invalid role supplied.');
        }
        $this->bootstrap();
        $validated = $this->validateStateMap($statesByCode);
        $this->rbac->replaceRoleRules($role, $validated);
        self::$effectivePermissionCache = [];
        return $this->rbac->listRoleRuleStates($role);
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>|null
     */
    public function setUserOverrides(string $userId, array $statesByCode): ?array
    {
        $this->bootstrap();
        if ($this->users->findById($userId) === null) {
            return null;
        }
        $validated = $this->validateStateMap($statesByCode);
        $this->rbac->replaceUserOverrides($userId, $validated);
        self::$effectivePermissionCache = [];
        return $this->rbac->listUserOverrideStates($userId);
    }

    /**
     * @return array{user: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function userOverrides(string $userId): ?array
    {
        $this->bootstrap();
        $user = $this->users->findById($userId);
        if ($user === null) {
            return null;
        }
        $role = (string)$user['role'];
        $roleStates = $this->rbac->listRoleRuleStates($role);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $roleDefault = PermissionCatalog::isGrantedByDefault($role, $code);
            $roleState = $roleStates[$code] ?? 'inherit';
            $roleAllowed = $this->applyState($roleDefault, $roleState);
            $userState = $userStates[$code] ?? 'inherit';
            $rows[] = array_merge($definition, [
                'role_default' => $roleDefault,
                'role_state' => $roleState,
                'role_allowed' => $roleAllowed,
                'user_state' => $userState,
                'effective' => $this->applyState($roleAllowed, $userState),
            ]);
        }
        return [
            'user' => $this->hydrateUserPermissions($user),
            'rows' => $rows,
        ];
    }

    /**
     * @return array<int, string>
     */
    public function effectivePermissionCodesForUser(string $userId, string $role): array
    {
        $this->bootstrap();
        $cacheKey = $userId . ':' . $role;
        if (isset(self::$effectivePermissionCache[$cacheKey])) {
            return self::$effectivePermissionCache[$cacheKey];
        }
        $roleStates = $this->rbac->listRoleRuleStates($role);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $allowed = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $default = PermissionCatalog::isGrantedByDefault($role, $code);
            $roleAllowed = $this->applyState($default, $roleStates[$code] ?? 'inherit');
            $effective = $this->applyState($roleAllowed, $userStates[$code] ?? 'inherit');
            if ($effective) {
                $allowed[] = $code;
            }
        }
        sort($allowed);
        self::$effectivePermissionCache[$cacheKey] = $allowed;
        return $allowed;
    }

    public function hasPermission(string $userId, string $role, string $permissionCode): bool
    {
        return in_array($permissionCode, $this->effectivePermissionCodesForUser($userId, $role), true);
    }

    /**
     * @param array<int, string> $permissionCodes
     */
    public function hasAnyPermission(string $userId, string $role, array $permissionCodes): bool
    {
        $allowed = array_flip($this->effectivePermissionCodesForUser($userId, $role));
        foreach ($permissionCodes as $code) {
            if (isset($allowed[$code])) {
                return true;
            }
        }
        return false;
    }

    public function hydrateUserPermissions(array $user): array
    {
        $user['permissions'] = $this->effectivePermissionCodesForUser(
            (string)($user['id'] ?? ''),
            (string)($user['role'] ?? '')
        );
        return $user;
    }

    private function applyState(bool $base, string $state): bool
    {
        return match ($state) {
            'allow' => true,
            'deny' => false,
            default => $base,
        };
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>
     */
    private function validateStateMap(array $statesByCode): array
    {
        $catalog = PermissionCatalog::indexed();
        $validated = [];
        foreach ($statesByCode as $code => $state) {
            $permissionCode = (string)$code;
            if (!isset($catalog[$permissionCode])) {
                continue;
            }
            $normalized = strtolower(trim((string)$state));
            if ($normalized === '' || $normalized === 'inherit') {
                continue;
            }
            if (!in_array($normalized, ['allow', 'deny'], true)) {
                throw new RuntimeException('Invalid permission state supplied.');
            }
            $validated[$permissionCode] = $normalized;
        }
        return $validated;
    }
}
