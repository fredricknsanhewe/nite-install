<?php
namespace App\Services;

use App\Config\AuthConfig;
use App\Exceptions\ThrottleException;
use App\Models\AuthLoginAttemptModel;

final class AuthThrottleService
{
    private AuthLoginAttemptModel $attempts;

    public function __construct()
    {
        $this->attempts = new AuthLoginAttemptModel();
    }

    public function ensureCanAttempt(string $email, string $ipAddress): void
    {
        if (!AuthConfig::throttleEnabled()) {
            return;
        }

        $this->attempts->deleteExpired(AuthConfig::loginDecaySeconds());
        $record = $this->attempts->findByThrottleKey($this->throttleKey($email, $ipAddress));
        if (!is_array($record)) {
            return;
        }

        $lockedUntil = strtotime((string)($record['locked_until'] ?? '')) ?: 0;
        if ($lockedUntil > time()) {
            throw new ThrottleException(max(1, $lockedUntil - time()));
        }
    }

    public function recordFailure(string $email, string $ipAddress): void
    {
        if (!AuthConfig::throttleEnabled()) {
            return;
        }

        $this->attempts->recordFailure(
            $this->throttleKey($email, $ipAddress),
            $email,
            $ipAddress,
            AuthConfig::maxLoginAttempts(),
            AuthConfig::loginDecaySeconds(),
            AuthConfig::lockoutSeconds()
        );
    }

    public function clear(string $email, string $ipAddress): void
    {
        if (!AuthConfig::throttleEnabled()) {
            return;
        }

        $this->attempts->clear($this->throttleKey($email, $ipAddress));
    }

    private function throttleKey(string $email, string $ipAddress): string
    {
        $normalizedEmail = strtolower(trim($email));
        $normalizedIp = trim($ipAddress);
        return hash('sha256', $normalizedEmail . '|' . $normalizedIp);
    }
}
