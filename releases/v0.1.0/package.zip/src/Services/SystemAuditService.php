<?php
namespace App\Services;

use App\Config\Env;
use App\Http\Request;
use App\Http\Response;
use App\Models\SystemAuditLogModel;

final class SystemAuditService
{
    private ?SystemAuditLogModel $logs = null;

    public function logRequest(Request $request, Response $response, int $durationMs, ?\Throwable $error = null): void
    {
        if (!$this->shouldLog($request, $response, $error)) {
            return;
        }

        try {
            $route = is_array($request->attributes['route'] ?? null) ? $request->attributes['route'] : [];
            $this->logs()->create([
                'scope' => $this->inferScope((string)($route['path'] ?? $request->path)),
                'actor_user_id' => $request->user['id'] ?? null,
                'actor_role' => $request->user['role'] ?? null,
                'method' => $request->method,
                'path' => $request->path,
                'route_path' => $route['path'] ?? null,
                'required_permissions' => is_array($request->attributes['required_permissions'] ?? null) ? $request->attributes['required_permissions'] : [],
                'success' => $response->status >= 200 && $response->status < 400,
                'http_status' => $response->status,
                'duration_ms' => max(0, $durationMs),
                'ip_address' => $request->header('X-Forwarded-For') ?: ($_SERVER['REMOTE_ADDR'] ?? null),
                'user_agent' => $request->header('User-Agent'),
                'request_payload' => $this->sanitize($request->body),
                'response_payload' => $this->sanitizeResponsePayload($response),
                'error_message' => $error?->getMessage(),
            ]);
        } catch (\Throwable) {
            // Audit logging should never break the main response.
        }
    }

    private function logs(): SystemAuditLogModel
    {
        if (!$this->logs instanceof SystemAuditLogModel) {
            $this->logs = new SystemAuditLogModel();
        }
        return $this->logs;
    }

    private function shouldLog(Request $request, Response $response, ?\Throwable $error): bool
    {
        $mode = strtolower(trim((string)Env::get('SYSTEM_AUDIT_LOG_MODE', 'writes')));
        if ($mode === 'off') {
            return false;
        }
        $isWrite = in_array($request->method, ['POST', 'PUT', 'DELETE', 'PATCH'], true);
        $hasError = $error !== null || $response->status >= 400;
        return match ($mode) {
            'all' => true,
            'errors' => $hasError,
            default => $isWrite || $hasError,
        };
    }

    private function inferScope(string $path): string
    {
        $normalized = trim(preg_replace('#^/api/v1/#', '', $path) ?? $path, '/');
        if ($normalized === '') {
            return 'api';
        }
        $parts = explode('/', $normalized);
        if (($parts[0] ?? '') === 'admin' && isset($parts[1])) {
            return 'admin.' . $parts[1];
        }
        return $parts[0] ?? 'api';
    }

    private function sanitize(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }
        $result = [];
        foreach ($value as $key => $item) {
            $normalizedKey = strtolower((string)$key);
            if (str_contains($normalizedKey, 'password') || str_contains($normalizedKey, 'token')) {
                $result[(string)$key] = '[redacted]';
            } else {
                $result[(string)$key] = $item;
            }
        }
        return $result;
    }

    private function sanitizeResponsePayload(Response $response): array
    {
        if ($response->format === 'binary') {
            return [
                'format' => 'binary',
                'content_type' => $response->headers['Content-Type'] ?? 'application/octet-stream',
                'content_length' => $response->headers['Content-Length'] ?? strlen($response->body),
            ];
        }

        $body = $response->body;
        $trimmed = trim($body);
        if ($trimmed === '') {
            return [];
        }
        $decoded = json_decode($trimmed, true);
        return is_array($decoded) ? $decoded : ['body' => substr($trimmed, 0, 500)];
    }
}
