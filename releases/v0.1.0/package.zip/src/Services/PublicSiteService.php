<?php
namespace App\Services;

use App\Models\CourseModel;
use App\Models\GalleryModel;
use App\Models\NewsPostModel;
use App\Models\PageModel;
use App\Models\ResourceModel;
use App\Models\SiteSettingsModel;
use App\Models\TrainingEventModel;

final class PublicSiteService
{
    /**
     * @return array<string, mixed>
     */
    public function bootstrap(): array
    {
        $settings = new SiteSettingsModel();
        $pages = new PageModel();
        $news = new NewsPostModel();
        $events = new TrainingEventModel();
        $resources = new ResourceModel();
        $gallery = new GalleryModel();
        $courses = new CourseModel();

        return [
            'settings' => $settings->all('public'),
            'pages' => $pages->list([], false),
            'featured_news' => $news->list(['featured' => true, 'limit' => 5], false),
            'latest_news' => $news->list(['limit' => 8], false),
            'upcoming_events' => $events->list(['limit' => 8], false),
            'featured_resources' => $resources->list(['featured' => true, 'limit' => 8], false),
            'featured_courses' => $courses->listCourses(['featured' => true], false),
            'gallery_albums' => $gallery->listAlbums([], false),
            'gallery_items' => array_slice($gallery->listItems([], false), 0, 12),
        ];
    }
}
