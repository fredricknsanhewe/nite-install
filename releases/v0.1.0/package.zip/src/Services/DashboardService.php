<?php
namespace App\Services;

use App\Models\ContactMessageModel;
use App\Models\CourseModel;
use App\Models\ExampleEntityModel;
use App\Models\EventRegistrationModel;
use App\Models\NewsPostModel;
use App\Models\TrainingEventModel;
use App\Models\UserModel;

final class DashboardService
{
    /**
     * @return array<string, mixed>
     */
    public function member(string $userId): array
    {
        $courses = new CourseModel();
        $registrations = new EventRegistrationModel();
        $news = new NewsPostModel();

        return [
            'enrollments' => $courses->listEnrollments($userId),
            'event_registrations' => $registrations->listByUser($userId),
            'latest_notices' => $news->list(['type' => 'notice', 'limit' => 5], false),
            'latest_announcements' => $news->list(['type' => 'announcement', 'limit' => 5], false),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function admin(): array
    {
        $users = new UserModel();
        $contacts = new ContactMessageModel();
        $courses = new CourseModel();
        $events = new TrainingEventModel();
        $news = new NewsPostModel();
        $examples = new ExampleEntityModel();

        return [
            'counts' => [
                'users' => $users->count(),
                'open_contacts' => $contacts->countOpen(),
                'course_enrollments' => $courses->countEnrollments(),
                'published_events' => count($events->list(['status' => 'published'], true)),
                'published_news' => count($news->list(['status' => 'published'], true)),
            ],
            'module_examples' => $examples->moduleCounts(),
            'recent_news' => array_slice($news->list(['status' => 'published'], true), 0, 5),
            'upcoming_events' => array_slice($events->list(['status' => 'published'], true), 0, 5),
            'recent_contacts' => array_slice($contacts->list(), 0, 5),
        ];
    }
}
