<?php
namespace App\Services;

use App\Config\AuthConfig;
use App\Config\Env;
use App\Config\Roles;
use App\Exceptions\AuthenticationException;
use App\Exceptions\ValidationException;
use App\Models\UserModel;
use App\Utils\UUID;
use App\Utils\JWT;
use App\Validation\Validator;

final class AuthService
{
    private UserModel $users;
    private RbacService $rbac;
    private AuthThrottleService $throttle;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->rbac = new RbacService();
        $this->throttle = new AuthThrottleService();
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function register(array $data, array $context = []): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'name' => 'required|string|min:2|max:120',
            'password' => 'required|string',
            'profile' => 'nullable|array',
        ]);
        $password = (string)($validated['password'] ?? '');
        PasswordPolicy::assert($password);

        $user = $this->users->create([
            'email' => strtolower(trim((string)($validated['email'] ?? ''))),
            'name' => $validated['name'] ?? null,
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => AuthConfig::bcryptCost()]),
            'role' => Roles::MEMBER,
            'profile' => is_array($validated['profile'] ?? null) ? $validated['profile'] : [],
        ]);

        return $this->tokenPayload($user);
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function login(array $data, array $context = []): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'password' => 'required|string',
        ]);
        $email = strtolower(trim((string)($validated['email'] ?? '')));
        $password = (string)($validated['password'] ?? '');
        $ipAddress = trim((string)($context['ip_address'] ?? '127.0.0.1')) ?: '127.0.0.1';
        $this->throttle->ensureCanAttempt($email, $ipAddress);

        $userRecord = $this->users->findForLogin($email);
        if ($userRecord === null) {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('Invalid login details.');
        }
        if (!password_verify($password, (string)$userRecord['password_hash'])) {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('Invalid login details.');
        }
        if (($userRecord['account_status'] ?? 'inactive') !== 'active') {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('This account is not active.');
        }

        $this->throttle->clear($email, $ipAddress);
        $this->users->touchLogin((string)$userRecord['id']);
        $user = $this->users->findById((string)$userRecord['id']);
        return $this->tokenPayload($user ?? []);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createByAdmin(array $data, string $actorUserId): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'name' => 'required|string|min:2|max:120',
            'password' => 'required|string',
            'role' => 'sometimes|string|in:' . implode(',', Roles::all()),
            'account_status' => 'sometimes|string|in:active,inactive,suspended',
            'profile' => 'nullable|array',
        ]);
        $password = (string)($validated['password'] ?? '');
        PasswordPolicy::assert($password);
        $user = $this->users->create([
            'email' => strtolower(trim((string)($validated['email'] ?? ''))),
            'name' => $validated['name'] ?? null,
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => AuthConfig::bcryptCost()]),
            'role' => $validated['role'] ?? Roles::MEMBER,
            'account_status' => $validated['account_status'] ?? 'active',
            'profile' => is_array($validated['profile'] ?? null) ? $validated['profile'] : [],
            'created_by_user_id' => $actorUserId,
            'updated_by_user_id' => $actorUserId,
        ]);

        return $this->rbac->hydrateUserPermissions($user);
    }

    public function updateByAdmin(string $userId, array $data, string $actorUserId): ?array
    {
        $payload = Validator::validate($data, [
            'email' => 'sometimes|string|email|max:255',
            'name' => 'sometimes|string|min:2|max:120',
            'password' => 'sometimes|string',
            'role' => 'sometimes|string|in:' . implode(',', Roles::all()),
            'account_status' => 'sometimes|string|in:active,inactive,suspended',
            'profile' => 'sometimes|array',
        ]);

        if (array_key_exists('password', $payload)) {
            $password = (string)$payload['password'];
            if ($password !== '') {
                PasswordPolicy::assert($password);
                $payload['password_hash'] = password_hash($password, PASSWORD_BCRYPT, ['cost' => AuthConfig::bcryptCost()]);
            }
            unset($payload['password']);
        }
        $payload['updated_by_user_id'] = $actorUserId;
        $user = $this->users->update($userId, $payload);
        return $user ? $this->rbac->hydrateUserPermissions($user) : null;
    }

    public function me(string $userId): ?array
    {
        $user = $this->users->findById($userId);
        return $user ? $this->rbac->hydrateUserPermissions($user) : null;
    }

    /**
     * @param array<string, mixed> $user
     * @return array<string, mixed>
     */
    private function tokenPayload(array $user): array
    {
        $this->rbac->bootstrap();
        $user = $this->rbac->hydrateUserPermissions($user);
        $issuedAt = time();
        $ttl = max(900, (int)Env::get('JWT_TTL_SECONDS', '28800'));
        $payload = [
            'sub' => (string)($user['id'] ?? ''),
            'email' => (string)($user['email'] ?? ''),
            'name' => (string)($user['name'] ?? ''),
            'role' => (string)($user['role'] ?? ''),
            'jti' => UUID::v4(),
            'iat' => $issuedAt,
            'nbf' => $issuedAt,
            'exp' => $issuedAt + $ttl,
        ];
        if (AuthConfig::tokenIssuer() !== null) {
            $payload['iss'] = AuthConfig::tokenIssuer();
        }
        if (AuthConfig::tokenAudience() !== null) {
            $payload['aud'] = AuthConfig::tokenAudience();
        }

        $token = JWT::encode($payload, (string)Env::get('JWT_SECRET', 'unsafe-default'));

        return [
            'token' => $token,
            'expires_in' => $ttl,
            'user' => $user,
        ];
    }
}
