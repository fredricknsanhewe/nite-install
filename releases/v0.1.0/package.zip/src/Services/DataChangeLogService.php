<?php
namespace App\Services;

use App\Models\DataChangeLogModel;

final class DataChangeLogService
{
    private DataChangeLogModel $logs;

    public function __construct()
    {
        $this->logs = new DataChangeLogModel();
    }

    public function logCreate(string $tableName, array $after, array $context = []): array
    {
        return $this->write($tableName, 'create', [], $after, $context, $after);
    }

    public function logUpdate(string $tableName, array $before, array $after, array $context = []): array
    {
        return $this->write($tableName, 'update', $before, $after, $context, $before);
    }

    public function logDelete(string $tableName, array $before, array $context = []): array
    {
        return $this->write($tableName, 'delete', $before, [], $context, $before);
    }

    public function logRestore(string $tableName, array $before, array $after, int $restoredFromLogId, array $context = []): array
    {
        $context['restored_from_log_id'] = $restoredFromLogId;
        return $this->write($tableName, 'restore', $before, $after, $context, $after);
    }

    public function findById(int $id): ?array
    {
        return $this->logs->findById($id);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listForTable(string $tableName, array $filters = []): array
    {
        $filters['table_name'] = $tableName;
        return $this->logs->list($filters);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listForRecord(string $tableName, string $recordId, array $filters = []): array
    {
        $filters['table_name'] = $tableName;
        $filters['record_id'] = $recordId;
        return $this->logs->list($filters);
    }

    public function latestDeleteLog(string $tableName, string $recordId): ?array
    {
        $rows = $this->listForRecord($tableName, $recordId, [
            'action' => 'delete',
            'limit' => 1,
        ]);

        return $rows[0] ?? null;
    }

    /**
     * @param array<string, mixed> $context
     */
    private function write(string $tableName, string $action, array $before, array $after, array $context, array $restorable): array
    {
        $before = $this->sanitizeSnapshot($before);
        $after = $this->sanitizeSnapshot($after);
        $restorable = $this->sanitizeSnapshot($restorable);
        $diff = $this->diff($before, $after);
        $metadata = is_array($context['metadata'] ?? null) ? $context['metadata'] : [];

        return $this->logs->create([
            'table_name' => $tableName,
            'record_id' => (string)($after['id'] ?? $before['id'] ?? ''),
            'record_slug' => (string)($after['slug'] ?? $before['slug'] ?? ''),
            'record_title' => (string)($after['title'] ?? $before['title'] ?? ''),
            'action' => $action,
            'change_scope' => $context['change_scope'] ?? 'data',
            'actor_user_id' => $context['actor_user_id'] ?? null,
            'actor_role' => $context['actor_role'] ?? null,
            'request_method' => $context['request_method'] ?? null,
            'request_path' => $context['request_path'] ?? null,
            'route_path' => $context['route_path'] ?? null,
            'ip_address' => $context['ip_address'] ?? null,
            'user_agent' => $context['user_agent'] ?? null,
            'reason' => $context['reason'] ?? null,
            'before_json' => $before,
            'after_json' => $after,
            'diff_json' => $diff,
            'metadata_json' => array_merge($metadata, [
                'changed_fields' => array_keys($diff),
                'changed_count' => count($diff),
                'record_label' => $after['title'] ?? $before['title'] ?? null,
            ]),
            'restorable_json' => $restorable,
            'restored_from_log_id' => $context['restored_from_log_id'] ?? null,
        ]);
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     * @return array<string, array<string, mixed>>
     */
    private function diff(array $before, array $after): array
    {
        $keys = array_unique(array_merge(array_keys($before), array_keys($after)));
        sort($keys);

        $diff = [];
        foreach ($keys as $key) {
            $beforeValue = $before[$key] ?? null;
            $afterValue = $after[$key] ?? null;
            if ($this->sameValue($beforeValue, $afterValue)) {
                continue;
            }

            $diff[(string)$key] = [
                'before' => $beforeValue,
                'after' => $afterValue,
            ];
        }

        return $diff;
    }

    private function sameValue(mixed $left, mixed $right): bool
    {
        return json_encode($left, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE)
            === json_encode($right, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    }

    /**
     * @param array<string, mixed> $snapshot
     * @return array<string, mixed>
     */
    private function sanitizeSnapshot(array $snapshot): array
    {
        $clean = [];
        foreach ($snapshot as $key => $value) {
            $normalizedKey = strtolower((string)$key);
            if (str_contains($normalizedKey, 'password') || str_contains($normalizedKey, 'token') || str_contains($normalizedKey, 'secret')) {
                $clean[(string)$key] = '[redacted]';
                continue;
            }

            if (is_array($value)) {
                $clean[(string)$key] = $this->sanitizeSnapshot($value);
                continue;
            }

            $clean[(string)$key] = $value;
        }

        return $clean;
    }
}
