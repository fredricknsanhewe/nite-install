<?php
namespace App\Services;

use App\Models\ExampleEntityModel;
use App\Models\ExampleEntryModel;
use App\Support\NiteModuleCatalog;
use RuntimeException;

final class ExampleModuleService
{
    private ExampleEntityModel $entities;
    private ExampleEntryModel $entries;

    public function __construct()
    {
        $this->entities = new ExampleEntityModel();
        $this->entries = new ExampleEntryModel();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(string $moduleKey, string $entityType, array $filters = []): array
    {
        $this->assertModuleEntity($moduleKey, $entityType);
        return $this->entities->list($moduleKey, $entityType, $filters);
    }

    public function show(string $moduleKey, string $entityType, string $id): ?array
    {
        $this->assertModuleEntity($moduleKey, $entityType);
        $row = $this->entities->find($id);
        if ($row === null || (string)$row['module_key'] !== $moduleKey || (string)$row['entity_type'] !== $entityType) {
            return null;
        }
        $row['entries'] = $this->entries->listByEntity((string)$row['id']);
        return $row;
    }

    public function create(string $moduleKey, string $entityType, array $payload, ?string $actorUserId = null): array
    {
        $this->assertModuleEntity($moduleKey, $entityType);
        return $this->entities->create($moduleKey, $entityType, $payload, $actorUserId);
    }

    public function update(string $moduleKey, string $entityType, string $id, array $payload, ?string $actorUserId = null): ?array
    {
        $this->assertModuleEntity($moduleKey, $entityType);
        $existing = $this->show($moduleKey, $entityType, $id);
        if ($existing === null) {
            return null;
        }
        return $this->entities->update($id, $payload, $actorUserId);
    }

    public function delete(string $moduleKey, string $entityType, string $id): bool
    {
        $this->assertModuleEntity($moduleKey, $entityType);
        $existing = $this->show($moduleKey, $entityType, $id);
        if ($existing === null) {
            return false;
        }
        return $this->entities->delete($id);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function entries(string $moduleKey, string $entityType, string $id): array
    {
        $row = $this->show($moduleKey, $entityType, $id);
        return $row['entries'] ?? [];
    }

    public function addEntry(string $moduleKey, string $entityType, string $id, array $payload, ?string $actorUserId = null): array
    {
        $existing = $this->show($moduleKey, $entityType, $id);
        if ($existing === null) {
            throw new RuntimeException('Example entity not found.');
        }
        return $this->entries->create($id, $payload, $actorUserId);
    }

    /**
     * @return array<string, mixed>
     */
    public function catalog(): array
    {
        return [
            'modules' => NiteModuleCatalog::modules(),
            'counts' => $this->entities->moduleCounts(),
        ];
    }

    private function assertModuleEntity(string $moduleKey, string $entityType): void
    {
        if (!NiteModuleCatalog::hasModule($moduleKey)) {
            throw new RuntimeException('Unknown module key.');
        }
        if (!NiteModuleCatalog::hasEntity($moduleKey, $entityType)) {
            throw new RuntimeException('Unknown entity type for selected module.');
        }
    }
}
