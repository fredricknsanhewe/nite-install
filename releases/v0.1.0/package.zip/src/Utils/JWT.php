<?php
namespace App\Utils;

final class JWT
{
    public static function encode(array $payload, string $secret): string
    {
        $header = ['alg' => 'HS256', 'typ' => 'JWT'];
        $segments = [
            self::b64((string)json_encode($header)),
            self::b64((string)json_encode($payload)),
        ];
        $signature = hash_hmac('sha256', implode('.', $segments), $secret, true);
        $segments[] = self::b64($signature);
        return implode('.', $segments);
    }

    /**
     * @param array<string, string> $options
     */
    public static function decode(string $token, string $secret, array $options = []): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }

        [$encodedHeader, $encodedPayload, $encodedSignature] = $parts;
        $expected = self::b64(hash_hmac('sha256', $encodedHeader . '.' . $encodedPayload, $secret, true));
        if (!hash_equals($expected, $encodedSignature)) {
            return null;
        }

        $payload = json_decode(self::ub64($encodedPayload), true);
        if (!is_array($payload)) {
            return null;
        }

        if (isset($payload['exp']) && time() > (int)$payload['exp']) {
            return null;
        }
        if (isset($payload['nbf']) && time() < (int)$payload['nbf']) {
            return null;
        }
        if (isset($options['issuer']) && (string)($payload['iss'] ?? '') !== (string)$options['issuer']) {
            return null;
        }
        if (isset($options['audience']) && (string)($payload['aud'] ?? '') !== (string)$options['audience']) {
            return null;
        }

        return $payload;
    }

    private static function b64(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function ub64(string $data): string
    {
        $remainder = strlen($data) % 4;
        if ($remainder !== 0) {
            $data .= str_repeat('=', 4 - $remainder);
        }

        return base64_decode(strtr($data, '-_', '+/')) ?: '';
    }
}
