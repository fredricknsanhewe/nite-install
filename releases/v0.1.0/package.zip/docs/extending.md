# Extending Nite

## Add a new concrete module

Prefer the console first:

```bash
php nite create resource Report
```

1. Add new tables to `database/schema.sql` and `database/schema.mysql.sql`.
2. Add a model under `src/Models`.
3. Add a service under `src/Services`.
4. Add a controller under `src/Controllers`.
5. Let console-generated resources auto-load from `routes/generated/`, or register custom manual routes in `public/index.php`.
6. Add seed data and request examples.

Use the sample CRUD module as the reference implementation:

- `src/Controllers/SampleRecordsController.php`
- `src/Services/SampleRecordService.php`
- `src/Models/SampleRecordModel.php`
- `src/Services/DataChangeLogService.php`
- `src/Models/DataChangeLogModel.php`

See [Sample CRUD Module](sample-crud.md) for the full archive-delete and restore flow.

## Replace a generic example module

If `example_entities` is too generic for your product:

1. keep the module key and route pattern
2. add dedicated tables for that module family
3. replace the service logic behind the existing controller
4. keep docs and example requests updated

That approach lets teams start broad and specialize later without rewriting the whole runtime.
