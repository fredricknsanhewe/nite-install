# Sample CRUD Module

The `sample_records` module is the reference implementation for:

- controller -> service -> model layering
- public and admin endpoints
- create, read, update, archive-delete, history, and restore
- JSON archive logs with field-level diffs and restore snapshots

## Files

- `src/Controllers/SampleRecordsController.php`
- `src/Services/SampleRecordService.php`
- `src/Models/SampleRecordModel.php`
- `src/Services/DataChangeLogService.php`
- `src/Models/DataChangeLogModel.php`
- `src/Support/DataChangeContext.php`

## Live table

- `sample_records`
  - stores the current live record only
  - deleted rows are removed from this table

## Archive table

- `data_change_logs`
  - stores `before_json`, `after_json`, `diff_json`, `metadata_json`, and `restorable_json`
  - captures actor, request path, route path, IP, user agent, reason, and timestamp
  - supports restoring deleted rows and rolling back updated rows

## Routes

- `GET /api/v1/sample-records`
- `GET /api/v1/sample-records/{slug}`
- `GET /api/v1/admin/sample-records`
- `POST /api/v1/admin/sample-records`
- `GET /api/v1/admin/sample-records/{id}`
- `PUT /api/v1/admin/sample-records/{id}`
- `PATCH /api/v1/admin/sample-records/{id}`
- `DELETE /api/v1/admin/sample-records/{id}`
- `GET /api/v1/admin/sample-records/history`
- `GET /api/v1/admin/sample-records/{id}/history`
- `POST /api/v1/admin/sample-records/history/{logId}/restore`

## Flow

1. The controller builds request context with `DataChangeContext`.
2. The service opens a transaction and calls the model.
3. The service writes a restorable archive log in the same transaction.
4. Delete removes the live row after the archive snapshot is written.
5. Restore reads `restorable_json` and upserts the row back into `sample_records`.

## Copy pattern

When building a new module:

0. prefer `php nite create resource YourThing` as the starting point
1. create a dedicated table for live data
2. keep write orchestration in a service
3. write archive log entries inside the same transaction
4. expose history and restore routes for admins
5. register the resource in `ApiExplorerCatalog`
