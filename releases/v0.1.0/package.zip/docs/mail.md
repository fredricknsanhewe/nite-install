# Mail

Nite ships with an env-driven outbound mail subsystem built on Symfony Mailer. It supports immediate delivery, a database-backed queue, trusted sender enforcement, recipient override safety, optional DKIM signing, and console workers.

## Quick setup

Minimal local setup using a Mailpit-style SMTP catcher:

```dotenv
MAIL_ENABLED=true
MAIL_TRANSPORT=smtp
MAIL_HOST=127.0.0.1
MAIL_PORT=1025
MAIL_ENCRYPTION=
MAIL_FROM_ADDRESS=no-reply@example.test
MAIL_FROM_NAME=Example App
MAIL_QUEUE_MODE=database
MAIL_ADMIN_TO=ops@example.test
```

When running the bundled Docker stack, use:

```dotenv
MAIL_ENABLED=true
MAIL_TRANSPORT=smtp
MAIL_HOST=mailpit
MAIL_PORT=1025
MAIL_FROM_ADDRESS=no-reply@example.test
MAIL_FROM_NAME=Example App
MAIL_QUEUE_MODE=database
```

## Core env keys

- `MAIL_ENABLED=true|false`: hard switch for all outbound delivery
- `MAIL_TRANSPORT=smtp|sendmail|native|null`: simple transport mode when `MAIL_DSN` is not set
- `MAIL_DSN=`: advanced raw Symfony DSN for failover, round-robin, or provider-specific setups
- `MAIL_FROM_ADDRESS`, `MAIL_FROM_NAME`: default visible sender
- `MAIL_SENDER_ADDRESS` or `MAIL_RETURN_PATH`: envelope sender / bounce address
- `MAIL_REPLY_TO=`: default reply-to list for system mail
- `MAIL_ADMIN_TO=`: comma-separated admin recipients for built-in notifications such as contact submissions
- `MAIL_QUEUE_MODE=sync|database`: send inline or enqueue into `mail_queue`
- `MAIL_QUEUE_BATCH_SIZE=25`: default queue worker batch size
- `MAIL_QUEUE_SLEEP_SECONDS=3`: poll interval for daemon workers
- `MAIL_QUEUE_MAX_RUNTIME_SECONDS=0`: optional self-rotation timeout for long-running workers
- `MAIL_QUEUE_MAX_ATTEMPTS=3`: permanent failure threshold
- `MAIL_QUEUE_RETRY_DELAY_SECONDS=60`: base delay before retrying a failed send
- `MAIL_OVERRIDE_TO=`: force all outbound mail to a safe inbox in staging
- `MAIL_ENFORCE_TRUSTED_FROM=true`: rewrite untrusted custom `From` values back to the framework sender
- `MAIL_ALLOWED_FROM_DOMAINS=example.com`: optional allow-list for explicit `From` domains
- `MAIL_ALLOWED_FROM_ADDRESSES=no-reply@example.com`: optional allow-list for exact `From` addresses
- `MAIL_ALLOWED_REPLY_TO_DOMAINS=`: optional reply-to restriction
- `MAIL_DKIM_*`: optional DKIM signing settings

## Console commands

Send a direct or queued test email:

```bash
php nite mail:test --to=dev@example.com
php nite mail:test --to=dev@example.com --queue
```

Inspect the queue:

```bash
php nite mail:queue:list
php nite mail:queue:list --status=failed
php nite mail:queue:list --message-type=contact_admin_alert --json
```

Process ready queue items:

```bash
php nite mail:queue:work
php nite mail:queue:work --limit=50
php nite queue:work --daemon --sleep=3
php nite queue:stats
```

Retry failed items:

```bash
php nite mail:queue:retry --all
php nite mail:queue:retry --id=<queue-item-uuid>
```

## Anti-spoof behavior

Nite treats the configured framework sender as authoritative.

- If app code tries to send from an untrusted `From` address and `MAIL_ENFORCE_TRUSTED_FROM=true`, Nite rewrites the message back to `MAIL_FROM_ADDRESS`.
- When possible, the original address is preserved as `Reply-To` instead of being sent as the visible sender.
- If `MAIL_OVERRIDE_TO` is set, all real recipients are replaced with the override inboxes. This is meant for staging, demos, and QA.

This keeps the framework safer with DMARC/SPF/SMTP policies while still allowing application code to expose external user addresses as reply targets.

## DKIM

Optional DKIM signing is enabled when these keys are all set:

```dotenv
MAIL_DKIM_DOMAIN=example.com
MAIL_DKIM_SELECTOR=default
MAIL_DKIM_PRIVATE_KEY_PATH=/absolute/path/to/dkim-private.pem
MAIL_DKIM_PASSPHRASE=
MAIL_DKIM_BODY_LENGTH=false
```

The `openssl` PHP extension must be available for DKIM signing.

## Built-in workflow hooks

The framework can send mail automatically for contact submissions:

```dotenv
MAIL_CONTACT_NOTIFICATION_ENABLED=true
MAIL_CONTACT_AUTO_REPLY_ENABLED=true
MAIL_ADMIN_TO=ops@example.com,support@example.com
```

With those enabled:

- `POST /api/v1/contact/messages` stores the contact message as before
- admin recipients receive a notification
- the sender can receive an acknowledgement

Notification failures do not block contact message storage.

## Advanced DSN examples

Raw DSN mode lets you use Symfony Mailer features directly:

```dotenv
MAIL_DSN=failover(smtp://user:pass@mail1.example.com:587 smtp://user:pass@mail2.example.com:587)
```

```dotenv
MAIL_DSN=roundrobin(smtp://user:pass@mail1.example.com:587 smtp://user:pass@mail2.example.com:587)
```

Use raw DSNs when you need transport-level behavior that goes beyond the simple `MAIL_HOST`/`MAIL_PORT` settings.
