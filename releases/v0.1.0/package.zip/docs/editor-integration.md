# Editor Integration

This document describes the machine-readable API contract that advanced editors, agents, IDE plugins, and code assistants can use to inspect Nite, build autofill forms, suggest request shapes, and highlight request errors before sending traffic.

## Discovery Order

Use this sequence:

1. `GET /api/v1?format=json`
2. `GET /api/v1/meta/routes?format=json`
3. `GET /api/v1/meta/resources?format=json`
4. `OPTIONS <target-endpoint>?format=json`

The API root provides top-level discovery links. The route catalog tells editors which paths and methods exist. The resource catalog exposes normalized field definitions. `OPTIONS` gives per-endpoint request metadata for the exact route the user wants to call.

## Response Envelope

Most JSON endpoints return this envelope:

```json
{
  "status": "success",
  "code": 200,
  "message": "Request completed successfully",
  "data": {},
  "errors": null,
  "meta": {}
}
```

For error responses:

```json
{
  "status": "error",
  "code": 422,
  "message": "Validation failed",
  "data": null,
  "errors": {
    "field_name": ["Message"]
  },
  "meta": {}
}
```

Editor guidance:

- Use `code` and `message` for the primary diagnostic.
- Use `errors` for field-level highlighting.
- Use `meta.allowed_methods` or the `Allow` header when a user chose the wrong method.
- Keep the raw response body available for debugging because some endpoints also return domain-specific metadata in `meta`.

## Route Catalog

`GET /api/v1/meta/routes?format=json`

Returns a route array under `data`. Each route item includes:

- `method`
- `path`
- `summary`
- `resource_key`
- `resource_label`
- `auth_required`
- `permissions`
- `request`
- `response`

Important `request` keys:

- `path_params`
- `query`
- `body`
- `content_type`

Important `response` keys:

- `success_status`
- `content_type`
- `return_type`

Editor guidance:

- Group routes by exact `path`.
- Treat `GET` + `POST` on the same path as one collection resource.
- Treat `GET` + `PUT`/`PATCH`/`DELETE` on a parameterized path as one item resource.
- Prefer the admin item `GET` route for admin CRUD flows.
- Prefer the public item `GET` route only when the current user is not in an admin flow.

## Resource Catalog

`GET /api/v1/meta/resources?format=json`

Returns one entry per resource. Each item includes:

- `key`
- `label`
- `group`
- `item_type`
- `table`
- `summary`
- `fields`
- `routes`
- `default_data_path`
- `default_data_auth_required`

Use the resource catalog when:

- the user asks for model fields
- an editor wants stronger autocomplete for a known resource
- a route response needs to be linked back to a canonical resource definition

## OPTIONS Contract

`OPTIONS <endpoint>?format=json`

This is the primary per-endpoint editor contract. The payload includes:

- `name`
- `description`
- `renders`
- `parses`
- `allowed_methods`
- `actions`
- `query_actions`
- `path_actions`
- `method_details`

Field entries in `actions`, `query_actions`, and `path_actions` can include:

- `name`
- `type`
- `data_type`
- `format`
- `required`
- `required_on_create`
- `required_on_update`
- `label`
- `help_text`
- `description`
- `nullable`
- `choices`
- `default`
- `relation`
- `media_upload`

Editor guidance:

- Use `actions[POST]`, `actions[PUT]`, or `actions[PATCH]` to build request-body forms.
- Use `query_actions[GET]` for query builders and filter sidebars.
- Use `path_actions[*]` for URL parameter completion and validation.
- Use `method_details` to drive method switching without losing endpoint context.

## Relation Autofill

When a field references another resource, the metadata can include relation details such as:

- `resource_key`
- `list_path`
- `value_field`
- `label_field`
- `search_param`
- `limit_param`
- `multiple`

Editor guidance:

- Render a picker instead of a plain text box when relation metadata exists.
- Use `list_path` to populate choices.
- If `search_param` exists, use it for incremental search.
- Use `value_field` for the actual submitted value.
- Use `label_field` for display text.
- If `multiple` is true, use a multi-select control.

## Media Upload Hints

Media-aware body fields include a `media_upload` block. Use it to:

- render a file picker
- upload to the media endpoint first
- write back the returned asset id or URL into the actual target field

Typical target fields include:

- `media_asset_id`
- `media_url`
- `thumbnail_url`
- `hero_image_url`
- `featured_image_url`
- `cover_image_url`

## REST Semantics

Nite now follows these rules for resource endpoints:

- Collection routes use `GET` and `POST`.
- Item routes use `GET`, `PUT`, `PATCH`, and `DELETE`.
- `PUT`, `PATCH`, and `DELETE` are not registered on collection-only paths.
- Writable resources expose a canonical item `GET`.
- `HEAD` is available anywhere `GET` exists.
- `PATCH` is available anywhere `PUT` exists.
- `OPTIONS` is available anywhere the path exists.

Creation responses return `201`. Where a canonical detail route exists, the response also includes a `Location` header pointing at the created resource.

## Auth Handling

For browser-based tooling:

- the browsable API stores the bearer token in local storage
- it also mirrors the token into the `nite_browsable_api_token` cookie
- normal browser navigation promotes that cookie back into `Authorization: Bearer ...`

For non-browser editors:

- send `Authorization: Bearer <token>`
- use `POST /api/v1/auth/login`
- persist the token from the returned session payload

## Error Highlighting

Use these mappings:

- `400`: malformed request
- `401`: missing or invalid token
- `403`: authenticated but not allowed
- `404`: resource or route not found
- `405`: wrong method
- `422`: request shape or domain validation error
- `500`: server failure

Editor guidance:

- Highlight body, query, and path fields from `errors`.
- If the response only contains `message`, surface it as a form-level error.
- For `405`, offer one of `allowed_methods`.
- For `403`, show required permissions if they are present in `meta.required_permissions`.

## Live Verification

Static contract audit:

```bash
php nite app:doctor
```

Live HTTP audit against a running server:

```bash
php scripts/rest-audit.php --api-base=http://127.0.0.1:8185
```

Light smoke test:

```bash
php scripts/smoke-test.php --api-base=http://127.0.0.1:8185
```

Extended smoke test with DB-backed public data routes:

```bash
php scripts/smoke-test.php --api-base=http://127.0.0.1:8185 --include-data
```

## Recommended Editor Strategy

- Cache `meta/routes` and `meta/resources`.
- Refresh `OPTIONS` lazily for the active endpoint.
- Build forms from `OPTIONS`, not from guesswork.
- Use relation metadata for pickers and search.
- Use `422` errors to mark invalid fields inline.
- Use `Location` after `201` responses to navigate to the created item.
- Keep a fallback raw JSON editor for unknown or generated resources.
