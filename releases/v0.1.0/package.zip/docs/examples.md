# Examples

## HTTP examples

See [examples/http/nite.http](../examples/http/nite.http) for ready-to-run requests.

The sample CRUD module is available at `/api/v1/sample-records` and the admin archive history routes under `/api/v1/admin/sample-records/*`.

## Database examples

See [database/examples/module-playbook.sql](../database/examples/module-playbook.sql) for starter queries covering:

- content
- learning
- workflow
- messaging
- payments
- subscriptions
- trust
- chatbot
- analytics
- recruitment
