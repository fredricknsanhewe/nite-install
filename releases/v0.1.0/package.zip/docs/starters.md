# Starter Apps

Starter apps are the product-shaped layer on top of Nite's lower-level presets.

Presets answer:

- how broad the app should be
- which module families it should lean on
- how much baseline operational surface it should generate

Starter apps answer:

- what kind of system the developer is trying to build
- which resources should exist on day one
- which example/sample packs should be generated
- how much ready-made context admins, developers, and AI tools should have

That is what lets Nite act like a framework generator instead of only a CRUD scaffold.

## Built-in starters

Nite currently ships with these built-in starters:

- `website-management`
- `inventory-management`
- `point-of-sale`
- `crm-sales`
- `helpdesk-support`
- `learning-platform`
- `clinic-management`
- `school-management`

Inspect them with:

```bash
php nite starter:list
php nite starter:show inventory-management
php nite starter:show point-of-sale --json
```

## Common bootstrap flows

Single root app:

```bash
php nite app:bootstrap "Acme Inventory" \
  --starter=inventory-management \
  --sample-count=240 \
  --db-driver=pgsql \
  --db-name=acme_inventory \
  --seed
```

Multi-project app:

```bash
php nite app:bootstrap "Client Website" \
  --project=client-website \
  --starter=website-management \
  --port=8286 \
  --sample-count=120 \
  --seed
```

Large AI/admin starter bundle:

```bash
php nite app:bootstrap "Retail Ops" \
  --starter=point-of-sale \
  --sample-packs=pos-retail,pos-payments,pos-operations \
  --sample-count=1000 \
  --no-install-samples \
  --no-migrate \
  --no-seed
```

The last pattern is useful when you want a large machine-readable starter dataset for planning, AI prompting, prototype walkthroughs, or later selective import.

## What gets generated

When a starter app is bootstrapped, Nite can generate:

- env files for host and Docker runtimes
- app blueprints in JSON and Markdown
- controller, service, model, migration, and route scaffolds for the starter resources
- starter sample bundle files
- optional `example_entities` records when `--install-samples` is enabled

Sample bundle outputs:

- root mode: `blueprints/starters/generated/starter-samples.json` and `docs/starter-samples.md`
- project mode: `projects/<slug>/starter-samples.json` and `projects/<slug>/starter-samples.md`

## Sample packs

Starter sample packs are reusable themed bundles. A starter can point at one or more packs, and bootstrap can override them with `--sample-packs=...`.

Examples:

- `inventory-core`
- `inventory-procurement`
- `inventory-analytics`
- `pos-retail`
- `pos-payments`
- `pos-operations`
- `website-core`
- `content-marketing`
- `team-directory`

These packs are generated against the existing `example_entities` module families, so the sample data stays readable through the rest of the framework instead of living in a disconnected starter-only store.

## Custom starter apps

Starter apps are data-driven. Put JSON files in:

- `blueprints/starters/apps/`
- `blueprints/starters/samples/`

Starter app example:

```json
{
  "key": "field-service-suite",
  "title": "Field Service Suite",
  "summary": "Dispatch, technicians, job tracking, inventory, and invoicing for field operations.",
  "preset": "advanced",
  "modules": ["workflow", "messaging", "analytics", "payments", "governance"],
  "operations": [
    "Dispatch and route field staff",
    "Track service jobs and SLA commitments",
    "Handle job-linked parts, billing, and customer follow-up"
  ],
  "resources": [
    {
      "name": "DispatchBoard",
      "label": "Dispatch Board",
      "summary": "Live board for technician dispatch and route balancing.",
      "group": "operations"
    },
    {
      "name": "FieldWorkOrder",
      "label": "Field Work Order",
      "summary": "Tracked service visits, site jobs, and completion evidence.",
      "group": "operations"
    }
  ],
  "sample_packs": ["field-service-core", "field-service-finance"],
  "default_sample_count": 240,
  "tags": ["field-service", "dispatch", "operations"]
}
```

Sample pack example:

```json
{
  "key": "field-service-core",
  "title": "Field Service Core Samples",
  "summary": "Dispatch and service operation examples for field teams.",
  "entities": [
    {
      "module_key": "workflow",
      "entity_type": "work_items",
      "label": "Dispatch Task",
      "subjects": ["North Zone", "Emergency Call", "Maintenance Visit"],
      "contexts": ["dispatch", "onsite", "follow-up"]
    },
    {
      "module_key": "messaging",
      "entity_type": "notifications",
      "label": "Service Alert",
      "subjects": ["Arrival Update", "Delay Notice", "Completion Summary"],
      "contexts": ["customer", "technician", "operations"]
    }
  ]
}
```

Runnable copies of those examples are included here:

- [custom-starter-app.json](examples/custom-starter-app.json)
- [custom-starter-sample-pack.json](examples/custom-starter-sample-pack.json)

## Recommended workflow

1. Run `php nite starter:list`.
2. Inspect a candidate with `php nite starter:show <key>`.
3. Bootstrap with `app:bootstrap --starter=...`.
4. Review `app.blueprint.json` and `starter-samples.json`.
5. Adjust generated controllers, services, models, and migrations.
6. Use `schema:apply` or `create resource` for any extra domain pieces.

## AI and admin use

The starter bundle is useful for more than scaffolding code:

- admins can seed example browsing surfaces with realistic starter data
- developers can see a coherent domain shape before writing custom logic
- AI tools can read the generated blueprints and starter sample JSON to extend the app faster and with less guesswork

That is the main reason the starter system writes both code scaffolds and large structured sample bundles.
