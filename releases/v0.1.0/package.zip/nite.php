#!/usr/bin/env php
<?php

use App\Config\Env;
use App\Console\ConsoleApplication;
use App\Support\ProjectRegistry;

$rootPath = require __DIR__ . '/bootstrap/autoload.php';

Env::loadFirstAvailable([
    $rootPath . '/.env',
    $rootPath . '/.env.example',
]);
(new ProjectRegistry($rootPath))->bootstrapActiveFromEnvironment();

$application = new ConsoleApplication($rootPath);
exit($application->run($argv));
