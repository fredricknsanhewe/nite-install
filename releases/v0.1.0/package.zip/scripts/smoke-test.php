<?php

$apiBase = 'http://127.0.0.1:8185';
$includeData = false;
foreach ($argv as $arg) {
    if (str_starts_with($arg, '--api-base=')) {
        $apiBase = substr($arg, 11);
    }
    if ($arg === '--include-data') {
        $includeData = true;
    }
}

$targets = [
    '/api/v1/health',
    '/api/v1/framework',
    '/api/v1/framework/modules',
    '/api/v1/meta/resources?format=json',
    '/api/v1/meta/routes?format=json',
];

if ($includeData) {
    $targets[] = '/api/v1/site/bootstrap';
    $targets[] = '/api/v1/sample-records';
}

foreach ($targets as $path) {
    $url = rtrim($apiBase, '/') . $path;
    $response = @file_get_contents($url);
    if ($response === false) {
        fwrite(STDERR, "Failed: {$url}\n");
        exit(1);
    }
    echo "OK {$url}\n";
}

echo "Smoke test complete.\n";
