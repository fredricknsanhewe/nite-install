<?php

use App\Config\Env;
use App\Console\FrameworkInspector;
use App\Support\ProjectRegistry;

$rootPath = require dirname(__DIR__) . '/bootstrap/autoload.php';

Env::loadFirstAvailable([
    $rootPath . '/.env',
    $rootPath . '/.env.example',
]);
(new ProjectRegistry($rootPath))->bootstrapActiveFromEnvironment();

$apiBase = null;
$jsonOutput = false;
foreach ($argv as $arg) {
    if (str_starts_with($arg, '--api-base=')) {
        $apiBase = rtrim(substr($arg, 11), '/');
    }
    if ($arg === '--json') {
        $jsonOutput = true;
    }
}

$inspector = new FrameworkInspector($rootPath);
$doctor = $inspector->doctor();
$contractChecks = array_values(array_filter(
    array_values(is_array($doctor['checks'] ?? null) ? $doctor['checks'] : []),
    static fn (array $check): bool => in_array((string)($check['group'] ?? ''), ['rest', 'metadata'], true)
));

$liveChecks = [];
if (is_string($apiBase) && $apiBase !== '') {
    $liveChecks = runLiveChecks($apiBase);
}

$result = [
    'summary' => [
        'static_errors' => count(array_filter($contractChecks, static fn (array $check): bool => (string)($check['status'] ?? '') === 'error')),
        'live_errors' => count(array_filter($liveChecks, static fn (array $check): bool => (string)($check['status'] ?? '') === 'error')),
    ],
    'static_checks' => $contractChecks,
    'live_checks' => $liveChecks,
];

if ($jsonOutput) {
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;
} else {
    echo 'REST/editor contract checks:' . PHP_EOL;
    foreach ($contractChecks as $check) {
        echo strtoupper((string)$check['status']) . ' [' . $check['group'] . '/' . $check['name'] . '] ' . $check['detail'] . PHP_EOL;
    }

    if ($liveChecks !== []) {
        echo PHP_EOL . 'Live HTTP checks:' . PHP_EOL;
        foreach ($liveChecks as $check) {
            echo strtoupper((string)$check['status']) . ' [' . $check['name'] . '] ' . $check['detail'] . PHP_EOL;
        }
    }
}

$hasErrors = $result['summary']['static_errors'] > 0 || $result['summary']['live_errors'] > 0;
exit($hasErrors ? 1 : 0);

/**
 * @return array{status: int, headers: array<string, string>, body: string}
 */
function httpRequest(string $method, string $url, array $headers = []): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('curl is required for live HTTP audit checks.');
    }

    $responseHeaders = [];
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_HEADERFUNCTION => static function ($curl, string $headerLine) use (&$responseHeaders): int {
            $trimmed = trim($headerLine);
            if ($trimmed !== '' && str_contains($trimmed, ':')) {
                [$name, $value] = explode(':', $trimmed, 2);
                $responseHeaders[trim($name)] = trim($value);
            }

            return strlen($headerLine);
        },
    ]);
    if (strtoupper($method) === 'HEAD') {
        curl_setopt($curl, CURLOPT_NOBODY, true);
    }

    $body = curl_exec($curl);
    if (!is_string($body)) {
        $error = curl_error($curl);
        curl_close($curl);
        throw new RuntimeException($error !== '' ? $error : 'Unknown HTTP request failure.');
    }

    $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    curl_close($curl);

    return [
        'status' => $status,
        'headers' => $responseHeaders,
        'body' => $body,
    ];
}

/**
 * @return array<int, array<string, string>>
 */
function runLiveChecks(string $apiBase): array
{
    $checks = [];

    $root = httpRequest('GET', $apiBase . '/', ['Accept: text/html']);
    $checks[] = [
        'name' => 'root_redirect',
        'status' => ($root['status'] === 302 && ($root['headers']['Location'] ?? '') === '/api/v1/meta/routes') ? 'ok' : 'error',
        'detail' => 'GET / with Accept:text/html should redirect to /api/v1/meta/routes',
    ];

    $routes = httpRequest('GET', $apiBase . '/api/v1/meta/routes?format=json');
    $routesPayload = json_decode($routes['body'], true);
    $routeCount = is_array($routesPayload['data'] ?? null) ? count($routesPayload['data']) : 0;
    $checks[] = [
        'name' => 'routes_json',
        'status' => ($routes['status'] === 200 && $routeCount > 0) ? 'ok' : 'error',
        'detail' => 'GET /api/v1/meta/routes?format=json should return route metadata',
    ];

    $head = httpRequest('HEAD', $apiBase . '/api/v1/meta/routes?format=json');
    $checks[] = [
        'name' => 'routes_head',
        'status' => ($head['status'] === 200 && $head['body'] === '') ? 'ok' : 'error',
        'detail' => 'HEAD /api/v1/meta/routes?format=json should return 200 with no body',
    ];

    $options = httpRequest('OPTIONS', $apiBase . '/api/v1/admin/users?format=json');
    $optionsPayload = json_decode($options['body'], true);
    $optionsData = is_array($optionsPayload['data'] ?? null) ? $optionsPayload['data'] : [];
    $allowedMethods = array_values(is_array($optionsData['allowed_methods'] ?? null) ? $optionsData['allowed_methods'] : []);
    $methodDetails = is_array($optionsData['method_details'] ?? null) ? $optionsData['method_details'] : [];
    $checks[] = [
        'name' => 'users_options',
        'status' => (
            $options['status'] === 200
            && in_array('GET', $allowedMethods, true)
            && in_array('POST', $allowedMethods, true)
            && in_array('OPTIONS', $allowedMethods, true)
            && isset($methodDetails['GET'])
        ) ? 'ok' : 'error',
        'detail' => 'OPTIONS /api/v1/admin/users?format=json should expose editor-friendly method metadata',
    ];

    $apiRoot = httpRequest('GET', $apiBase . '/api/v1?format=json');
    $apiRootPayload = json_decode($apiRoot['body'], true);
    $apiRootData = is_array($apiRootPayload['data'] ?? null) ? $apiRootPayload['data'] : [];
    $checks[] = [
        'name' => 'api_root_json',
        'status' => ($apiRoot['status'] === 200 && isset($apiRootData['routes'])) ? 'ok' : 'error',
        'detail' => 'GET /api/v1?format=json should return discovery links with routes metadata',
    ];

    return $checks;
}
