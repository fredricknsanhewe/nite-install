<?php

use App\Config\Database;
use App\Config\Env;
use App\Models\CourseModel;
use App\Models\NewsPostModel;
use App\Models\PageModel;
use App\Models\ResourceModel;
use App\Models\SampleRecordModel;
use App\Models\SiteSettingsModel;
use App\Models\TrainingEventModel;
use App\Models\UserModel;
use App\Services\AuthService;
use App\Services\ExampleModuleService;
use App\Services\RbacService;
use App\Services\SampleRecordService;
use App\Support\DatabaseSchemaRunner;
use App\Support\ProjectRegistry;

$rootPath = require dirname(__DIR__) . '/bootstrap/autoload.php';

Env::loadFirstAvailable([
    $rootPath . '/.env',
    $rootPath . '/.env.example',
]);
(new ProjectRegistry($rootPath))->bootstrapActiveFromEnvironment();

function scalarCount(\PDO $connection, string $table): int
{
    $statement = $connection->query('SELECT COUNT(*) AS total FROM ' . $table);
    $row = $statement ? $statement->fetch() : null;
    return (int)($row['total'] ?? 0);
}

try {
    $connection = Database::connection();
    DatabaseSchemaRunner::apply($connection);

    $rbac = new RbacService();
    $rbac->bootstrap();
    $auth = new AuthService();
    $users = new UserModel();
    $settings = new SiteSettingsModel();
    $pages = new PageModel();
    $news = new NewsPostModel();
    $events = new TrainingEventModel();
    $resources = new ResourceModel();
    $courses = new CourseModel();
    $examples = new ExampleModuleService();
    $sampleRecordModel = new SampleRecordModel();
    $sampleRecords = new SampleRecordService();

    $admin = $users->findByEmail('admin@nite.local');
    if ($admin === null) {
        $admin = $auth->createByAdmin([
            'email' => 'admin@nite.local',
            'name' => 'Nite Administrator',
            'password' => 'Passw0rd!',
            'role' => 'admin',
            'account_status' => 'active',
            'profile' => [
                'bio' => 'Starter administrative account for the Nite framework.',
            ],
        ], '');
    }
    $adminId = (string)($admin['id'] ?? $users->findByEmail('admin@nite.local')['id'] ?? '');

    $editor = $users->findByEmail('editor@nite.local');
    if ($editor === null) {
        $auth->createByAdmin([
            'email' => 'editor@nite.local',
            'name' => 'Nite Editor',
            'password' => 'Passw0rd!',
            'role' => 'editor',
            'account_status' => 'active',
        ], $adminId);
    }

    $member = $users->findByEmail('member@nite.local');
    if ($member === null) {
        $auth->createByAdmin([
            'email' => 'member@nite.local',
            'name' => 'Nite Member',
            'password' => 'Passw0rd!',
            'role' => 'member',
            'account_status' => 'active',
        ], $adminId);
    }
    $memberId = (string)($users->findByEmail('member@nite.local')['id'] ?? '');

    $settings->upsert('global', 'public', [
    'site_name' => 'Nite',
    'site_short_name' => 'Nite',
    'tagline' => 'A custom PHP starter framework with working modules and reusable examples.',
    'support_email' => 'support@nite.local',
    'support_phone' => '+263000000000',
    ], $adminId);

    $settings->upsert('navigation', 'public', [
    'items' => [
        ['label' => 'Framework', 'route' => '/api/v1/framework'],
        ['label' => 'Pages', 'route' => '/api/v1/pages'],
        ['label' => 'News', 'route' => '/api/v1/news'],
        ['label' => 'Events', 'route' => '/api/v1/events'],
        ['label' => 'Resources', 'route' => '/api/v1/resources'],
        ['label' => 'Courses', 'route' => '/api/v1/courses'],
    ],
    ], $adminId);

$seedPages = [
    [
        'slug' => 'home',
        'title' => 'Home',
        'summary' => 'Framework landing content example.',
        'hero_title' => 'Build Faster With Nite',
        'hero_summary' => 'Nite gives you a custom modular PHP starter with content, learning, workflow, messaging, payments, and governance patterns already wired.',
        'status' => 'published',
        'content' => [
            'sections' => [
                ['title' => 'Core Runtime', 'body' => 'Request, response, router, middleware, auth, RBAC, and audit logging.'],
                ['title' => 'Starter Modules', 'body' => 'Concrete content and learning modules plus reusable example families for broader product capabilities.'],
            ],
        ],
    ],
    [
        'slug' => 'getting-started',
        'title' => 'Getting Started',
        'summary' => 'Starter documentation page content.',
        'status' => 'published',
        'content' => [
            'sections' => [
                ['title' => 'Run Migrations', 'body' => 'Use scripts/migrate.php or scripts/seed.php to initialize the database.'],
                ['title' => 'Explore Examples', 'body' => 'Use /api/v1/framework and /api/v1/examples/{module}/{entity} to inspect starter data.'],
            ],
        ],
    ],
];
    foreach ($seedPages as $page) {
        if ($pages->findBySlug((string)$page['slug'], true) === null) {
            $pages->create($page, $adminId);
        }
    }

$seedPosts = [
    [
        'slug' => 'welcome-to-nite',
        'post_type' => 'announcement',
        'title' => 'Welcome To Nite',
        'summary' => 'Initial announcement in the starter content module.',
        'body' => 'Nite is a reusable backend starter that packages patterns proven in a larger production-style codebase.',
        'status' => 'published',
        'is_featured' => true,
        'published_at' => gmdate('c'),
    ],
    [
        'slug' => 'framework-release-notes',
        'post_type' => 'news',
        'title' => 'Framework Release Notes',
        'summary' => 'Example release notes post.',
        'body' => 'This starter ships with auth, RBAC, audit logs, content, learning, and generic feature-family example modules.',
        'status' => 'published',
        'published_at' => gmdate('c'),
    ],
];
    foreach ($seedPosts as $post) {
        if ($news->findBySlug((string)$post['slug'], true) === null) {
            $news->create($post, $adminId);
        }
    }

    if ($events->findBySlug('starter-architecture-walkthrough', true) === null) {
        $events->create([
        'slug' => 'starter-architecture-walkthrough',
        'title' => 'Starter Architecture Walkthrough',
        'summary' => 'Example event for onboarding new users to Nite.',
        'description' => 'Covers routing, modules, RBAC, example entities, and starter deployment.',
        'event_format' => 'online',
        'meeting_url' => 'https://example.local/walkthrough',
        'starts_at' => gmdate('c', strtotime('+7 days')),
        'ends_at' => gmdate('c', strtotime('+7 days +2 hours')),
        'registration_open' => true,
        'status' => 'published',
        'is_featured' => true,
        ], $adminId);
    }

    if ($resources->findBySlug('nite-module-playbook', true) === null) {
        $resources->create([
        'slug' => 'nite-module-playbook',
        'title' => 'Nite Module Playbook',
        'summary' => 'Starter module design and extension guide.',
        'description' => 'Explains how the content, learning, workflow, messaging, payments, subscriptions, trust, chatbot, analytics, and recruitment examples fit together.',
        'resource_type' => 'guideline',
        'status' => 'published',
        'is_featured' => true,
        'published_at' => gmdate('c'),
        ], $adminId);
    }

    $course = $courses->findCourseBySlug('nite-starter-fundamentals', true);
    if ($course === null) {
        $course = $courses->createCourse([
        'slug' => 'nite-starter-fundamentals',
        'title' => 'Nite Starter Fundamentals',
        'summary' => 'Quick introduction to the Nite runtime and module patterns.',
        'description' => 'Learn the architecture, routing, database layout, permissions, and example module conventions.',
        'delivery_mode' => 'self_paced',
        'certificate_enabled' => true,
        'status' => 'published',
        'is_featured' => true,
        ], $adminId);
    }
    $courseId = (string)($course['id'] ?? '');
    if ($courseId !== '' && count($courses->listModules($courseId, true)) === 0) {
        $courses->createModule($courseId, [
        'title' => 'Runtime Overview',
        'summary' => 'Autoloading, routing, middleware, and response flow.',
        'content_type' => 'document',
        'status' => 'published',
        'sort_order' => 1,
        ], $adminId);
        $courses->createModule($courseId, [
        'title' => 'Module Examples',
        'summary' => 'How the generic example module store represents broad feature families.',
        'content_type' => 'document',
        'status' => 'published',
        'sort_order' => 2,
        ], $adminId);
    }
    if ($courseId !== '' && $memberId !== '' && $courses->findEnrollment($courseId, $memberId) === null) {
        $courses->enroll($courseId, $memberId);
    }

$seedSampleRecords = [
    [
        'slug' => 'sample-crud-guide',
        'title' => 'Sample CRUD Guide',
        'summary' => 'Demonstrates the full controller, service, model, archive, and restore flow.',
        'record_type' => 'guide',
        'status' => 'active',
        'labels' => ['crud', 'example', 'restore'],
        'metadata' => [
            'audience' => 'developers',
            'copy_pattern' => 'controller-service-model',
        ],
        'change_reason' => 'seed data',
    ],
    [
        'slug' => 'sample-archive-workflow',
        'title' => 'Archive Workflow Example',
        'summary' => 'Shows how delete operations move live data into the JSON archive log.',
        'record_type' => 'workflow',
        'status' => 'active',
        'labels' => ['audit', 'archive', 'history'],
        'metadata' => [
            'restorable' => true,
            'log_table' => 'data_change_logs',
        ],
        'change_reason' => 'seed data',
    ],
];

    foreach ($seedSampleRecords as $sampleRecord) {
        if ($sampleRecordModel->findBySlug((string)$sampleRecord['slug'], true) === null) {
            $sampleRecords->create($sampleRecord, [
            'change_scope' => 'seed',
            'actor_user_id' => $adminId,
            'actor_role' => 'admin',
            'request_method' => 'SEED',
            'request_path' => 'scripts/seed.php',
            'route_path' => 'scripts/seed.php',
            'reason' => 'Seeded sample CRUD records.',
            'metadata' => [
                'seeded_at' => gmdate('c'),
            ],
            ]);
        }
    }

$exampleSeeds = [
    ['catalog', 'categories', 'Trades Catalog', 'Example tree for broad service categories.', ['tree' => [['name' => 'Home Services'], ['name' => 'Technology']]]],
    ['catalog', 'service_areas', 'Service Areas', 'Example coverage map for region and city hierarchies.', ['countries' => ['Zimbabwe', 'South Africa']]],
    ['catalog', 'tags', 'Search Tags', 'Example tagging taxonomy.', ['tags' => ['verified', 'priority', 'nearby']]],

    ['workflow', 'work_items', 'Starter Work Item', 'Example request lifecycle record.', ['status_flow' => ['draft', 'open', 'assigned', 'completed']]],
    ['workflow', 'offers', 'Offer Negotiation Example', 'Counter-offer lifecycle example.', ['actions' => ['accept', 'deny', 'counter', 'skip']]],
    ['workflow', 'ratings', 'Ratings Example', 'Reputation and sentiment scoring example.', ['metrics' => ['score' => 4.8, 'sentiment' => 0.91]]],
    ['workflow', 'favorites', 'Favorites Example', 'Bookmarks for preferred items or providers.', ['type' => 'user_preference']],
    ['workflow', 'milestones', 'Milestone Example', 'Timeline checkpoints for a managed workflow.', ['items' => ['deposit', 'inspection', 'completion']]],
    ['workflow', 'reports', 'Workflow Report Example', 'Dispute or exception report example.', ['severity' => 'medium']],

    ['messaging', 'notifications', 'Notification Example', 'Cross-channel notification delivery example.', ['channels' => ['email', 'whatsapp']]],
    ['messaging', 'conversations', 'Conversation Example', 'Support or participant conversation thread example.', ['participants' => ['member', 'support']]],
    ['messaging', 'webhooks', 'Webhook Example', 'Inbound webhook verification and processing example.', ['providers' => ['whatsapp', 'messenger']]],
    ['messaging', 'outbound_queue', 'Outbound Queue Example', 'Queued outbound delivery retry example.', ['retry_strategy' => 'exponential_backoff']],
    ['messaging', 'integrations', 'Messaging Integration Example', 'Messaging bridge configuration example.', ['bridge' => 'official_api']],

    ['payments', 'integrations', 'Payment Integration Example', 'Integration profile for an external payment provider.', ['provider' => 'paynow']],
    ['payments', 'currencies', 'Currency Example', 'Supported payment currency example.', ['code' => 'USD']],
    ['payments', 'transactions', 'Transaction Example', 'Payment initiation and polling example.', ['state' => 'pending']],
    ['payments', 'escrows', 'Escrow Example', 'Dual-confirmation escrow release example.', ['release_mode' => 'dual_confirmation']],
    ['payments', 'disputes', 'Payment Dispute Example', 'Payment dispute and resolution queue example.', ['status' => 'open']],
    ['payments', 'callback_queue', 'Callback Queue Example', 'Async callback processing example.', ['worker' => 'poller']],

    ['subscriptions', 'plans', 'Subscription Plan Example', 'Feature plan and billing cycle example.', ['billing_cycle' => 'monthly']],
    ['subscriptions', 'features', 'Subscription Feature Example', 'Feature toggle example tied to plans.', ['feature_code' => 'priority_ranking']],
    ['subscriptions', 'invoices', 'Subscription Invoice Example', 'Invoice lifecycle example.', ['invoice_state' => 'issued']],
    ['subscriptions', 'activations', 'Activation Example', 'Manual or automated plan activation example.', ['activated_by' => 'system']],

    ['trust', 'reports', 'Trust Report Example', 'Fraud or abuse report example.', ['priority' => 'high']],
    ['trust', 'blocks', 'Block Example', 'Direct account block example.', ['scope' => 'conversation']],
    ['trust', 'moderation_actions', 'Moderation Example', 'Moderation decision log example.', ['action' => 'hide_item']],

    ['chatbot', 'config', 'Chatbot Config Example', 'Assistant runtime configuration example.', ['enabled' => true]],
    ['chatbot', 'knowledge', 'Knowledge Example', 'Knowledge base article example.', ['source' => 'manual']],
    ['chatbot', 'conversations', 'Chatbot Conversation Example', 'Assistant conversation review example.', ['sentiment' => 'neutral']],

    ['analytics', 'tracking_events', 'Tracking Event Example', 'Product telemetry event example.', ['event' => 'page_view']],
    ['analytics', 'dashboards', 'Dashboard Example', 'Summary metric and chart example.', ['tiles' => ['active_users', 'open_reports']]],
    ['analytics', 'anomalies', 'Anomaly Example', 'Anomaly detection and review example.', ['score' => 0.72]],
    ['analytics', 'rules', 'Analytics Rule Example', 'Anomaly rule definition example.', ['window' => '7d']],

    ['recruitment', 'programs', 'Recruitment Program Example', 'Referral or partner recruitment programme example.', ['payout_model' => 'tiered']],
    ['recruitment', 'activation_rules', 'Activation Rule Example', 'Programme activation rule example.', ['condition' => 'verified_signup']],
    ['recruitment', 'bonuses', 'Bonus Example', 'Regional or field bonus example.', ['amount' => 10]],
    ['recruitment', 'tiers', 'Tier Example', 'Recruitment tier example.', ['threshold' => 50]],
    ['recruitment', 'cashouts', 'Cashout Example', 'Recruitment cashout request example.', ['status' => 'pending']],
];

    foreach ($exampleSeeds as [$moduleKey, $entityType, $title, $summary, $payload]) {
        if ($examples->list($moduleKey, $entityType) === []) {
            $row = $examples->create($moduleKey, $entityType, [
            'slug' => strtolower(str_replace(' ', '-', preg_replace('/[^a-zA-Z0-9 ]+/', '', $title) ?: $title)),
            'title' => $title,
            'summary' => $summary,
            'status' => 'active',
            'payload' => $payload,
            'owner_user_id' => $memberId !== '' ? $memberId : null,
            ], $adminId);
            $examples->addEntry($moduleKey, $entityType, (string)$row['id'], [
            'entry_type' => 'timeline',
            'body' => 'Starter example created by seed script.',
            'payload' => ['seeded_at' => gmdate('c')],
            ], $adminId);
        }
    }

    echo "Nite seed complete.\n";
    echo 'Driver: ' . Database::driver() . "\n";
    echo 'Database: ' . trim((string)Env::get('DB_NAME', 'nite')) . "\n";
    foreach ([
        'users',
        'pages',
        'news_posts',
        'training_events',
        'resources',
        'courses',
        'sample_records',
        'example_entities',
        'data_change_logs',
    ] as $table) {
        echo $table . ': ' . scalarCount($connection, $table) . "\n";
    }
} catch (\Throwable $e) {
    fwrite(STDERR, 'Seed failed: ' . $e->getMessage() . "\n");
    exit(1);
}
