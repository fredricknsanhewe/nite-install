# Nite Admin

`/admin` is the standalone management frontend for Nite apps. It is not the API explorer. It signs in through the same auth endpoints, reads the same route/resource metadata, and hides sections/actions that the logged-in user cannot access.

## What It Auto-Provides

- Application/model groups similar to Django admin.
- Changelists with search, filters, sorting, bulk export, bulk delete, and API-backed pagination when a resource supports `limit` and `offset`.
- Add/change forms generated from route body metadata.
- Relation pickers for documented foreign-key style fields.
- Media upload widgets for documented media fields.
- Date and datetime inputs for date metadata.
- Object history pages when a resource exposes `GET /api/v1/admin/.../{id}/history`.
- Restore buttons when a resource exposes a matching `POST /api/v1/admin/.../history/{logId}/restore`.
- Related child panels when a resource exposes nested admin routes such as `/api/v1/admin/courses/{id}/modules`.
- Switchable built-in themes.

## RBAC

Nite evaluates permissions in this order:

1. Role defaults from `PermissionCatalog`.
2. Role permission rules from `role_permission_rules`.
3. Active group permission rules from `rbac_group_permission_rules`.
4. User permission overrides from `user_permission_overrides`.

Later layers override earlier layers. This means groups are useful for team-level access, while user overrides remain the final precise control.

## Group Management

Admins with `admin.rbac.view` can view:

- `/api/v1/admin/rbac/groups`
- `/api/v1/admin/rbac/groups/{id}`
- `/api/v1/admin/rbac/groups/{id}/members`
- `/api/v1/admin/rbac/groups/{id}/permissions`

Admins with `admin.rbac.manage` can create/update/delete groups, assign members, and save group permission states.

## Generated Apps

Generated resources plug into `/admin` when their manifest exposes admin routes and permissions. For best results, generated resources should include:

- list route: `GET /api/v1/admin/<resource>`
- create route: `POST /api/v1/admin/<resource>`
- detail route: `GET /api/v1/admin/<resource>/{id}`
- update route: `PUT` or `PATCH /api/v1/admin/<resource>/{id}`
- delete route: `DELETE /api/v1/admin/<resource>/{id}`
- query metadata for `q`, filters, `limit`, and `offset`
- relation metadata for fields that should become pickers
- media metadata for fields that should upload files

Run `php nite db:migrate` after upgrading an existing app so RBAC group tables are present.
