<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\RbacService;
use RuntimeException;

final class RbacController
{
    private RbacService $rbac;

    public function __construct()
    {
        $this->rbac = new RbacService();
    }

    public function roles(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->roles()]);
    }

    public function permissions(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->permissions()]);
    }

    public function matrix(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->matrix()]);
    }

    public function groups(Request $request): Response
    {
        return Response::json(['data' => $this->rbac->groups($request->query)]);
    }

    public function createGroup(Request $request): Response
    {
        try {
            return Response::json([
                'data' => $this->rbac->createGroup($request->body, (string)($request->user['id'] ?? '')),
            ], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create RBAC group.'], 500);
        }
    }

    public function group(Request $request): Response
    {
        $payload = $this->rbac->group((string)($request->params['id'] ?? ''));
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
    }

    public function updateGroup(Request $request): Response
    {
        try {
            $payload = $this->rbac->updateGroup(
                (string)($request->params['id'] ?? ''),
                $request->body,
                (string)($request->user['id'] ?? '')
            );
            return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update RBAC group.'], 500);
        }
    }

    public function deleteGroup(Request $request): Response
    {
        return $this->rbac->deleteGroup((string)($request->params['id'] ?? ''))
            ? Response::json(['data' => ['deleted' => true]])
            : Response::json(['error' => 'RBAC group not found.'], 404);
    }

    public function groupMembers(Request $request): Response
    {
        $payload = $this->rbac->groupMembers((string)($request->params['id'] ?? ''));
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
    }

    public function setGroupMembers(Request $request): Response
    {
        $userIds = $this->extractUserIds($request->body);
        $payload = $this->rbac->setGroupMembers((string)($request->params['id'] ?? ''), $userIds);
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
    }

    public function groupPermissions(Request $request): Response
    {
        $payload = $this->rbac->groupPermissions((string)($request->params['id'] ?? ''));
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
    }

    public function setGroupPermissions(Request $request): Response
    {
        try {
            $states = is_array($request->body['states'] ?? null) ? $request->body['states'] : $request->body;
            $payload = $this->rbac->setGroupPermissions((string)($request->params['id'] ?? ''), $states);
            return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'RBAC group not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update group permissions.'], 500);
        }
    }

    public function userOverrides(Request $request): Response
    {
        $payload = $this->rbac->userOverrides((string)($request->params['id'] ?? ''));
        return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'User not found.'], 404);
    }

    public function setRolePermissions(Request $request): Response
    {
        try {
            $states = is_array($request->body['states'] ?? null) ? $request->body['states'] : $request->body;
            return Response::json([
                'data' => $this->rbac->setRolePermissions((string)($request->params['role'] ?? ''), $states),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update role permissions.'], 500);
        }
    }

    public function setUserOverrides(Request $request): Response
    {
        try {
            $states = is_array($request->body['states'] ?? null) ? $request->body['states'] : $request->body;
            $payload = $this->rbac->setUserOverrides((string)($request->params['id'] ?? ''), $states);
            return $payload ? Response::json(['data' => $payload]) : Response::json(['error' => 'User not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update user overrides.'], 500);
        }
    }

    /**
     * @param array<string, mixed> $body
     * @return array<int, string>
     */
    private function extractUserIds(array $body): array
    {
        $source = $body['user_ids'] ?? $body['users'] ?? $body['members'] ?? [];
        if (!is_array($source)) {
            return [];
        }

        return array_values(array_filter(array_map(static function (mixed $item): string {
            if (is_array($item)) {
                return trim((string)($item['id'] ?? ''));
            }
            return trim((string)$item);
        }, $source), static fn (string $id): bool => $id !== ''));
    }
}
