<?php
namespace App\Support;

use App\Config\Env;
use App\Config\PermissionCatalog;

final class ApiExplorerCatalog
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function resources(): array
    {
        static $resources = null;
        if ($resources !== null) {
            return $resources;
        }

        $resources = [];
        foreach ([
            self::pagesResource(),
            self::newsResource(),
            self::eventsResource(),
            self::eventRegistrationsResource(),
            self::resourcesResource(),
            self::galleryAlbumsResource(),
            self::galleryItemsResource(),
            self::contactMessagesResource(),
            self::coursesResource(),
            self::courseModulesResource(),
            self::courseEnrollmentsResource(),
            self::sampleRecordsResource(),
            self::dataChangeLogsResource(),
            self::exampleEntitiesResource(),
            self::exampleEntriesResource(),
            self::usersResource(),
            self::siteSettingsResource(),
            self::mediaAssetVersionsResource(),
            self::mediaAssetsResource(),
            self::auditLogsResource(),
        ] as $resource) {
            $resources[$resource['key']] = $resource;
        }

        foreach (GeneratedResourceRegistry::manifests() as $resource) {
            $resources[$resource['key']] = self::generatedResourceDoc($resource);
        }

        return $resources;
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function resource(string $key): ?array
    {
        return self::resources()[trim($key)] ?? null;
    }

    public static function resourceKeyForAdminSelection(string $selection): ?string
    {
        $normalized = trim(str_replace('\\', '/', $selection), '/');
        if ($normalized === '') {
            return null;
        }

        $normalizedKey = str_replace('-', '_', strtolower($normalized));
        foreach (self::resources() as $resource) {
            $key = strtolower((string)($resource['key'] ?? ''));
            if ($key !== '' && $key === $normalizedKey) {
                return (string)$resource['key'];
            }

            $surfacePath = trim((string)($resource['admin_surface_path'] ?? ''), '/');
            if ($surfacePath !== '' && $surfacePath === 'admin/' . $normalized) {
                return (string)$resource['key'];
            }
        }

        return null;
    }

    /**
     * @return array<string, mixed>
     */
    public static function summary(): array
    {
        $projectSlug = trim((string)Env::get('NITE_PROJECT', ''));
        return [
            'name' => 'Nite',
            'api_version' => 'v1',
            'resource_count' => count(self::resources()),
            'route_count' => count(self::routeDocsMap()),
            'api_root_path' => '/api/v1',
            'admin_root_path' => '/admin',
            'project' => $projectSlug === '' ? null : [
                'slug' => $projectSlug,
                'name' => trim((string)Env::get('NITE_PROJECT_NAME', $projectSlug)),
                'app_url' => trim((string)Env::get('APP_URL', '')),
            ],
            'meta_paths' => [
                'root' => '/api/v1',
                'routes' => '/api/v1/meta/routes',
                'resources' => '/api/v1/meta/resources',
            ],
        ];
    }

    /**
     * @param array<int, object> $routes
     * @return array<int, array<string, mixed>>
     */
    public static function documentRoutes(array $routes): array
    {
        $docsMap = self::routeDocsMap();
        $docs = [];

        foreach ($routes as $route) {
            $key = $route->method . ' ' . $route->rawPath;
            $doc = $docsMap[$key] ?? self::fallbackRouteDoc($route->method, $route->rawPath);
            $doc['method'] = $route->method;
            $doc['path'] = $route->rawPath;
            $doc['name'] = $route->name;
            $docs[] = $doc;
        }

        $existing = [];
        foreach ($docs as $doc) {
            $existing[strtoupper((string)($doc['method'] ?? 'GET')) . ' ' . (string)($doc['path'] ?? '')] = true;
        }

        $synthetic = [];
        foreach ($docs as $doc) {
            $method = strtoupper((string)($doc['method'] ?? 'GET'));
            $path = (string)($doc['path'] ?? '');
            if ($method === 'GET' && !isset($existing['HEAD ' . $path])) {
                $head = $doc;
                $head['method'] = 'HEAD';
                $head['summary'] = 'Read headers for this endpoint without returning a response body.';
                $head['name'] = trim((string)($doc['name'] ?? '')) !== '' ? (string)$doc['name'] : 'head';
                $synthetic[] = $head;
                $existing['HEAD ' . $path] = true;
            }

            if ($method === 'PUT' && !isset($existing['PATCH ' . $path])) {
                $patch = $doc;
                $patch['method'] = 'PATCH';
                $patch['summary'] = 'Partially update this endpoint.';
                $patch['name'] = trim((string)($doc['name'] ?? '')) !== '' ? (string)$doc['name'] : 'patch';
                $synthetic[] = $patch;
                $existing['PATCH ' . $path] = true;
            }
        }

        if ($synthetic !== []) {
            $docs = array_merge($docs, $synthetic);
        }

        usort($docs, function (array $left, array $right): int {
            return [$left['path'], $left['method']] <=> [$right['path'], $right['method']];
        });

        return $docs;
    }

    /**
     * @param array<int, array<string, mixed>> $routes
     */
    public static function renderHtml(array $routes, ?string $selectedResource = null): string
    {
        $payload = [
            'summary' => self::summary(),
            'resources' => array_values(self::resources()),
            'routes' => array_values($routes),
            'selected_resource' => $selectedResource,
            'admin_base_path' => '/admin',
            'generated_at' => gmdate('c'),
        ];

        $encoded = json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if (!is_string($encoded)) {
            $encoded = '{}';
        }

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nite Admin</title>
    <style>
        :root {
            color-scheme: light;
            --bg: #eef2f7;
            --bg-strong: #e5ebf4;
            --sidebar: #1f2d44;
            --sidebar-line: rgba(255, 255, 255, 0.10);
            --sidebar-text: #f6f8fc;
            --sidebar-muted: #aab7d1;
            --surface: #ffffff;
            --surface-soft: #f8fafc;
            --surface-strong: #f3f6fa;
            --line: #d8e0ea;
            --line-strong: #c4d0de;
            --text: #172235;
            --muted: #607086;
            --accent: #295fb8;
            --accent-strong: #1f4b91;
            --accent-soft: #e7eefb;
            --success: #2d7d4f;
            --success-soft: #e9f6ee;
            --warn: #9a6b08;
            --warn-soft: #fff4d6;
            --danger: #b34139;
            --danger-soft: #fdecea;
            --shadow: 0 18px 42px rgba(26, 41, 68, 0.10);
            --radius: 14px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Aptos", "Segoe UI Variable Text", "Segoe UI", sans-serif;
            color: var(--text);
            background:
                linear-gradient(180deg, var(--bg) 0%, #f7f9fc 100%);
        }

        .layout {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 300px minmax(0, 1fr);
        }

        .sidebar {
            border-right: 1px solid var(--sidebar-line);
            background:
                linear-gradient(180deg, rgba(255, 255, 255, 0.03), rgba(255, 255, 255, 0)),
                var(--sidebar);
            color: var(--sidebar-text);
            padding: 24px 18px;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow: auto;
        }

        .brand {
            padding-bottom: 18px;
            border-bottom: 1px solid var(--sidebar-line);
            margin-bottom: 18px;
        }

        .eyebrow {
            text-transform: uppercase;
            letter-spacing: 0.12em;
            font-size: 0.72rem;
            color: var(--sidebar-muted);
            margin-bottom: 8px;
        }

        .brand h1 {
            margin: 0 0 6px;
            font-size: 1.85rem;
            letter-spacing: -0.04em;
        }

        .brand p {
            margin: 0;
            color: var(--sidebar-muted);
            line-height: 1.45;
        }

        .sidebar-tools {
            margin-bottom: 18px;
        }

        .search,
        .text-input,
        .select-input,
        textarea {
            width: 100%;
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 10px 12px;
            background: var(--surface);
            color: var(--text);
            font: inherit;
        }

        .search {
            background: rgba(255, 255, 255, 0.12);
            color: var(--sidebar-text);
            border-color: rgba(255, 255, 255, 0.12);
            margin-bottom: 12px;
        }

        .search::placeholder {
            color: #c4cede;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px;
        }

        .stat {
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 12px;
            padding: 12px;
        }

        .stat strong {
            display: block;
            font-size: 1.15rem;
            margin-bottom: 4px;
        }

        .stat span {
            color: var(--sidebar-muted);
            font-size: 0.88rem;
        }

        .group {
            margin-top: 18px;
        }

        .group h2 {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--sidebar-muted);
            margin: 0 0 8px;
        }

        .resource-link {
            display: block;
            width: 100%;
            text-align: left;
            border: 1px solid transparent;
            background: transparent;
            border-radius: 12px;
            padding: 11px 12px;
            cursor: pointer;
            color: inherit;
            font: inherit;
            transition: background 140ms ease, border-color 140ms ease, transform 140ms ease;
        }

        .resource-link:hover {
            background: rgba(255, 255, 255, 0.07);
            border-color: rgba(255, 255, 255, 0.08);
            transform: translateX(2px);
        }

        .resource-link.active {
            background: rgba(255, 255, 255, 0.12);
            border-color: rgba(255, 255, 255, 0.18);
        }

        .resource-link small {
            display: block;
            color: var(--sidebar-muted);
            margin-top: 3px;
        }

        .main {
            padding: 24px;
        }

        .stack {
            display: grid;
            gap: 18px;
        }

        .panel {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .hero {
            padding: 20px 22px;
            margin-bottom: 18px;
        }

        .hero-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            flex-wrap: wrap;
        }

        .breadcrumbs {
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--muted);
            font-size: 0.76rem;
            margin-bottom: 6px;
        }

        .hero h2 {
            margin: 0 0 8px;
            font-size: 2rem;
            letter-spacing: -0.04em;
        }

        .hero p {
            margin: 0;
            max-width: 70ch;
            color: var(--muted);
            line-height: 1.55;
        }

        .badges {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 14px;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 6px 11px;
            background: var(--accent-soft);
            color: var(--accent-strong);
            font-size: 0.82rem;
            font-weight: 600;
        }

        .hero-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .overview-grid,
        .content-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .overview-grid {
            margin-bottom: 18px;
        }

        .overview-card {
            padding: 16px 18px;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .overview-card span {
            display: block;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--muted);
            font-size: 0.74rem;
            margin-bottom: 8px;
        }

        .overview-card strong {
            display: block;
            font-size: 1.05rem;
            line-height: 1.45;
        }

        .panel {
            padding: 18px;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
        }

        .panel h3,
        .request-section h4 {
            margin: 0;
            font-size: 1rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.92rem;
        }

        th,
        td {
            padding: 10px 8px;
            border-bottom: 1px solid var(--line);
            text-align: left;
            vertical-align: top;
        }

        th {
            font-size: 0.74rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--muted);
            background: var(--surface-soft);
        }

        code,
        pre {
            font-family: "Cascadia Code", Consolas, monospace;
        }

        .cell-sub,
        .helper,
        .panel-meta,
        .meta-text {
            color: var(--muted);
            line-height: 1.45;
            font-size: 0.86rem;
        }

        .segmented {
            display: inline-flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .segmented button,
        .btn,
        .mini-btn {
            border: 1px solid var(--line-strong);
            background: var(--surface);
            color: var(--text);
            border-radius: 10px;
            cursor: pointer;
            font: inherit;
            transition: background 140ms ease, border-color 140ms ease, color 140ms ease;
        }

        .segmented button {
            padding: 7px 10px;
            font-size: 0.88rem;
        }

        .segmented button.active {
            background: var(--accent-soft);
            border-color: #b6cbf0;
            color: var(--accent-strong);
        }

        .btn {
            padding: 10px 14px;
            font-size: 0.93rem;
        }

        .btn:hover,
        .mini-btn:hover,
        .segmented button:hover {
            background: var(--surface-strong);
        }

        .btn.primary {
            background: var(--accent);
            border-color: var(--accent);
            color: white;
        }

        .btn.primary:hover {
            background: var(--accent-strong);
        }

        .btn.subtle {
            background: var(--surface-soft);
        }

        .mini-btn {
            padding: 6px 10px;
            font-size: 0.82rem;
        }

        .method-badge,
        .state-pill,
        .status-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 4px 9px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.02em;
        }

        .method-get,
        .state-public,
        .status-success {
            background: var(--success-soft);
            color: var(--success);
        }

        .method-post,
        .status-pending {
            background: var(--accent-soft);
            color: var(--accent-strong);
        }

        .method-put {
            background: #efe9fb;
            color: #6e46ba;
        }

        .method-delete,
        .status-error {
            background: var(--danger-soft);
            color: var(--danger);
        }

        .state-auth {
            background: var(--warn-soft);
            color: var(--warn);
        }

        .status-idle {
            background: var(--surface-strong);
            color: var(--muted);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
            margin-bottom: 12px;
        }

        .span-2 {
            grid-column: span 2;
        }

        .field {
            display: grid;
            gap: 6px;
        }

        .field label,
        .field strong {
            font-size: 0.83rem;
            color: var(--muted);
        }

        .request-sections {
            display: grid;
            gap: 16px;
            margin-top: 12px;
        }

        .request-section {
            border: 1px solid var(--line);
            border-radius: 12px;
            background: var(--surface-soft);
            padding: 14px;
        }

        .section-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }

        .inline-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .shortcut-strip {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 12px 0 8px;
        }

        .shortcut-note {
            margin-bottom: 4px;
        }

        .param-grid {
            display: grid;
            gap: 10px;
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .param-card {
            display: grid;
            gap: 6px;
            padding: 10px;
            border: 1px solid var(--line);
            background: white;
            border-radius: 10px;
        }

        .param-head {
            display: grid;
            gap: 4px;
        }

        .param-head small {
            color: var(--muted);
            line-height: 1.35;
        }

        textarea {
            min-height: 200px;
            resize: vertical;
            background: #fdfefe;
        }

        .toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 14px;
        }

        .advanced-disclosure {
            margin-top: 14px;
            border: 1px solid var(--line);
            border-radius: 12px;
            background: var(--surface-soft);
            overflow: hidden;
        }

        .advanced-disclosure summary {
            list-style: none;
            cursor: pointer;
            padding: 12px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            font-weight: 600;
        }

        .advanced-disclosure summary::-webkit-details-marker {
            display: none;
        }

        .advanced-disclosure[open] summary {
            border-bottom: 1px solid var(--line);
        }

        .advanced-disclosure > :not(summary) {
            padding: 14px;
        }

        .advanced-grid,
        .advanced-disclosure .toolbar:first-of-type {
            margin-top: 0;
        }

        pre {
            margin: 0;
            border-radius: 12px;
            padding: 14px;
            overflow: auto;
            background: #1f2328;
            color: #e8edf3;
            min-height: 180px;
        }

        .table-wrap tr:last-child td {
            border-bottom: 0;
        }

        .empty {
            color: var(--muted);
            padding: 6px 0;
        }

        .response-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .response-summary {
            margin-bottom: 12px;
        }

        .response-structured[hidden],
        pre[hidden],
        .response-actions[hidden] {
            display: none;
        }

        .response-actions {
            display: grid;
            gap: 10px;
            margin-bottom: 12px;
        }

        .action-card {
            border: 1px solid var(--line);
            border-radius: 12px;
            background: var(--surface-soft);
            padding: 12px;
        }

        .action-card h4 {
            margin: 0 0 6px;
            font-size: 0.9rem;
        }

        .action-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .table-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .identifier-chip {
            display: inline-flex;
            align-items: center;
            max-width: 100%;
            padding: 0;
            border: 0;
            background: transparent;
            color: var(--accent-strong);
            cursor: pointer;
            font: inherit;
            text-align: left;
            text-decoration: underline;
            text-decoration-style: dotted;
            text-underline-offset: 2px;
        }

        .identifier-chip code {
            color: inherit;
            background: rgba(32, 80, 103, 0.08);
            border-radius: 6px;
            padding: 2px 6px;
            word-break: break-all;
        }

        .identifier-chip:hover,
        .identifier-chip:focus-visible {
            color: var(--accent);
            outline: none;
        }

        .key-value-grid {
            display: grid;
            gap: 8px;
        }

        .key-value-row {
            display: grid;
            grid-template-columns: minmax(140px, 220px) minmax(0, 1fr);
            gap: 12px;
            align-items: start;
            padding: 10px 12px;
            border: 1px solid var(--line);
            border-radius: 10px;
            background: var(--surface-soft);
        }

        .key-value-row strong {
            font-size: 0.83rem;
            color: var(--muted);
            word-break: break-word;
        }

        .scalar-card {
            border: 1px solid var(--line);
            border-radius: 12px;
            background: var(--surface-soft);
            padding: 14px;
        }

        :root {
            --bg: #f3f5f7;
            --bg-strong: #edf1f4;
            --sidebar: #f8f8f8;
            --sidebar-line: #d5d9dd;
            --sidebar-text: #2b2b2b;
            --sidebar-muted: #5f6b74;
            --surface: #ffffff;
            --surface-soft: #f8f8f8;
            --surface-strong: #eef3f6;
            --line: #d5d9dd;
            --line-strong: #c4ccd3;
            --text: #222222;
            --muted: #666666;
            --accent: #417690;
            --accent-strong: #205067;
            --accent-soft: #e7f0f5;
            --success: #205067;
            --success-soft: #e7f0f5;
            --warn: #9b6d00;
            --warn-soft: #fff4d4;
            --danger: #ba2121;
            --danger-soft: #fdeaea;
            --shadow: none;
            --radius: 4px;
        }

        body[data-theme="forest"] {
            --bg: #eef4ef;
            --bg-strong: #e4ece4;
            --sidebar: #f6faf6;
            --sidebar-line: #d6dfd6;
            --sidebar-text: #223327;
            --sidebar-muted: #55705b;
            --surface: #ffffff;
            --surface-soft: #f5faf5;
            --surface-strong: #ebf3ec;
            --line: #d6dfd6;
            --line-strong: #bfcbbe;
            --text: #203026;
            --muted: #5f7064;
            --accent: #2d6a4f;
            --accent-strong: #1f4f3a;
            --accent-soft: #e7f2ec;
            --success: #2d6a4f;
            --success-soft: #e7f2ec;
            --warn: #8c6b12;
            --warn-soft: #f7efd7;
            --danger: #a3423a;
            --danger-soft: #fae9e6;
        }

        body[data-theme="graphite"] {
            --bg: #eef1f6;
            --bg-strong: #e3e7ef;
            --sidebar: #f7f8fb;
            --sidebar-line: #d5dae4;
            --sidebar-text: #212833;
            --sidebar-muted: #607086;
            --surface: #ffffff;
            --surface-soft: #f7f9fc;
            --surface-strong: #edf1f7;
            --line: #d5dae4;
            --line-strong: #bec6d4;
            --text: #202733;
            --muted: #687384;
            --accent: #4d5d95;
            --accent-strong: #33416f;
            --accent-soft: #eaedf7;
            --success: #3c6c5c;
            --success-soft: #e9f3ef;
            --warn: #8f6716;
            --warn-soft: #faefd9;
            --danger: #a5444d;
            --danger-soft: #fbeaec;
        }

        body[data-theme="sunrise"] {
            --bg: #f9f0ea;
            --bg-strong: #f4e6de;
            --sidebar: #fdf7f2;
            --sidebar-line: #e2d4ca;
            --sidebar-text: #372622;
            --sidebar-muted: #7a6258;
            --surface: #fffdfa;
            --surface-soft: #fff8f3;
            --surface-strong: #f9efe7;
            --line: #e2d4ca;
            --line-strong: #d1c0b3;
            --text: #352320;
            --muted: #7a635b;
            --accent: #b65b34;
            --accent-strong: #874021;
            --accent-soft: #f6e6dc;
            --success: #4d7557;
            --success-soft: #eaf3ec;
            --warn: #93670d;
            --warn-soft: #fbefd6;
            --danger: #b14a41;
            --danger-soft: #fbe8e5;
        }

        body {
            background: var(--bg);
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
            line-height: 1.45;
        }

        .theme-picker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 10px;
            background: rgba(255, 255, 255, 0.16);
            border-radius: 999px;
            color: rgba(255, 255, 255, 0.92);
            font-size: 0.85rem;
        }

        .theme-picker select {
            border: 0;
            background: transparent;
            color: #ffffff;
            font: inherit;
            outline: none;
        }

        .theme-picker option {
            color: #222222;
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            padding: 10px 24px;
            background: var(--accent);
            color: #ffffff;
            border-bottom: 1px solid #2c5569;
        }

        .admin-branding,
        .admin-tools {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .admin-branding strong {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .admin-branding span,
        .admin-stamp {
            color: rgba(255, 255, 255, 0.85);
            font-size: 0.92rem;
        }

        .admin-link {
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.4);
        }

        .admin-link-button {
            border: 0;
            padding: 0;
            background: transparent;
            cursor: pointer;
            font: inherit;
        }

        .layout {
            grid-template-columns: 270px minmax(0, 1fr);
            gap: 18px;
            padding: 18px 24px 24px;
        }

        .sidebar {
            position: sticky;
            top: 18px;
            height: calc(100vh - 36px);
            padding: 0;
            background: transparent;
            color: var(--text);
            border-right: 0;
        }

        .brand,
        .sidebar-tools,
        #resourceGroups {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 14px;
            margin-bottom: 12px;
        }

        .eyebrow,
        .group h2,
        .breadcrumbs {
            color: #5b80b2;
            letter-spacing: 0;
            text-transform: none;
            font-weight: 700;
        }

        .brand h1 {
            font-size: 1.5rem;
            letter-spacing: 0;
        }

        .search {
            background: #ffffff;
            color: var(--text);
            border-color: var(--line);
        }

        .search::placeholder {
            color: #7a8791;
        }

        .stats {
            grid-template-columns: 1fr 1fr;
        }

        .stat {
            background: var(--surface-soft);
            border-color: var(--line);
        }

        .resource-link {
            border-radius: var(--radius);
            color: var(--text);
        }

        .resource-link.locked strong::after {
            content: "Protected";
            display: inline-flex;
            margin-left: 8px;
            padding: 2px 7px;
            border-radius: 999px;
            background: var(--warn-soft);
            color: var(--warn);
            font-size: 0.68rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }

        .resource-link:hover,
        .resource-link.active {
            background: #eaf2f6;
            border-color: #c4ccd3;
            transform: none;
        }

        .resource-link small {
            color: var(--muted);
        }

        .resource-state {
            display: block;
            margin-top: 6px;
            color: var(--muted);
            font-size: 0.78rem;
        }

        .main {
            padding: 0;
        }

        .hero {
            padding: 18px;
            margin-bottom: 18px;
            background: var(--surface);
        }

        .hero h2 {
            font-size: 1.8rem;
            letter-spacing: 0;
        }

        .breadcrumbs {
            margin-bottom: 10px;
            font-size: 0.84rem;
        }

        .badge {
            background: #eaf2f6;
            color: #205067;
            font-weight: 700;
            border-radius: 999px;
        }

        .panel {
            padding: 14px;
            background: var(--surface);
            border-radius: var(--radius);
        }

        .crumb-button {
            border: 0;
            padding: 0;
            background: transparent;
            color: inherit;
            cursor: pointer;
            font: inherit;
        }

        .panel-header {
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--line);
        }

        .panel h3,
        .request-section h4 {
            color: var(--accent);
            font-size: 1.05rem;
        }

        .hero-actions,
        .toolbar,
        .shortcut-strip,
        .inline-actions,
        .action-list,
        .table-actions {
            gap: 6px;
        }

        .btn,
        .mini-btn,
        .segmented button {
            border-radius: var(--radius);
        }

        .btn.primary {
            background: #79aec8;
            border-color: #79aec8;
            color: #ffffff;
        }

        .btn.primary:hover {
            background: #609ab6;
            border-color: #609ab6;
        }

        .response-topbar {
            justify-content: flex-end;
        }

        .dashboard-panel {
            margin-bottom: 18px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }

        .dashboard-stat {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--surface-soft);
            padding: 14px;
        }

        .dashboard-stat span {
            display: block;
            color: var(--muted);
            margin-bottom: 8px;
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .dashboard-stat strong {
            display: block;
            font-size: 1.2rem;
        }

        .dashboard-groups {
            display: grid;
            gap: 18px;
        }

        .dashboard-group h4 {
            margin: 0 0 10px;
            color: var(--accent);
            font-size: 0.96rem;
        }

        .dashboard-group-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
        }

        .dashboard-card {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: linear-gradient(180deg, var(--surface) 0%, var(--surface-soft) 100%);
            padding: 14px;
            display: grid;
            gap: 10px;
        }

        .dashboard-card h5 {
            margin: 0;
            font-size: 1rem;
        }

        .dashboard-card p {
            margin: 0;
            color: var(--muted);
            line-height: 1.45;
        }

        .dashboard-card-meta,
        .dashboard-card-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .dashboard-card-meta {
            color: var(--muted);
            font-size: 0.82rem;
        }

        .dashboard-card.locked {
            border-style: dashed;
        }

        .dashboard-card.locked h5::after {
            content: "Protected";
            display: inline-flex;
            margin-left: 8px;
            padding: 2px 7px;
            border-radius: 999px;
            background: var(--warn-soft);
            color: var(--warn);
            font-size: 0.68rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }

        .workspace-hidden {
            display: none !important;
        }

        .content-grid {
            grid-template-columns: minmax(0, 1.45fr) minmax(320px, 0.9fr);
        }

        th {
            background: #79aec8;
            color: #ffffff;
            font-size: 0.78rem;
            letter-spacing: 0.02em;
        }

        td {
            background: #ffffff;
        }

        .request-section,
        .param-card,
        .action-card,
        .key-value-row,
        .scalar-card {
            border-radius: var(--radius);
            background: var(--surface-soft);
        }

        pre {
            border-radius: var(--radius);
        }

        @media (max-width: 1080px) {
            .admin-header {
                padding: 12px 16px;
            }

            .layout {
                grid-template-columns: 1fr;
                padding: 16px;
            }

            .sidebar {
                position: static;
                height: auto;
            }

            .overview-grid,
            .content-grid,
            .form-grid,
            .param-grid,
            .dashboard-stats,
            .dashboard-group-grid {
                grid-template-columns: 1fr;
            }

            .span-2 {
                grid-column: auto;
            }
        }
    </style>
</head>
<body data-theme="classic">
    <header class="admin-header">
        <div class="admin-branding">
            <strong>Nite Admin</strong>
            <span>universal administration for any Nite app</span>
        </div>
        <div class="admin-tools">
            <button class="admin-link admin-link-button" id="dashboardAction" type="button">Dashboard</button>
            <a href="/" class="admin-link">Website</a>
            <a href="/api/v1/meta/routes" class="admin-link">API docs</a>
            <label class="theme-picker" for="themeSelect">
                <span>Theme</span>
                <select id="themeSelect">
                    <option value="classic">Classic</option>
                    <option value="forest">Forest</option>
                    <option value="graphite">Graphite</option>
                    <option value="sunrise">Sunrise</option>
                </select>
            </label>
            <span class="admin-stamp">Universal workspace</span>
        </div>
    </header>
    <div class="layout">
        <aside class="sidebar">
            <div class="brand">
                <div class="eyebrow">Management</div>
                <h1>Site Administration</h1>
                <p>Plug this admin into any Nite app to manage content, media, users, workflows, and generated modules from one consistent workspace.</p>
            </div>
            <div class="sidebar-tools">
                <input class="search" id="resourceSearch" type="search" placeholder="Search sections">
                <div class="stats">
                    <div class="stat"><strong id="resourceCount">0</strong><span>sections</span></div>
                    <div class="stat"><strong id="routeCount">0</strong><span>actions</span></div>
                </div>
            </div>
            <div id="resourceGroups"></div>
        </aside>

        <main class="main">
            <section class="hero panel">
                <div class="hero-header">
                    <div>
                        <div class="breadcrumbs"><button class="crumb-button" id="dashboardCrumb" type="button">Home</button> / <span id="resourceGroupLabel">Dashboard</span> / <span id="resourceCrumbLabel">Overview</span></div>
                        <h2 id="resourceTitle">Administration Dashboard</h2>
                        <p id="resourceSummary">Choose a section from the left to manage records, or stay here for a cross-system overview of the app structure, available sections, and current access.</p>
                        <div class="badges" id="resourceBadges"></div>
                    </div>
                    <div class="hero-actions">
                        <button class="btn primary" id="useDefaultAction" type="button">Open list</button>
                        <button class="btn" id="loadDefaultAction" type="button">Refresh list</button>
                        <button class="btn" id="addObjectAction" type="button">New record</button>
                        <button class="btn" id="historyViewAction" type="button">History</button>
                        <button class="btn" id="resourceMetaAction" type="button">Fields</button>
                        <button class="btn" id="routesMetaAction" type="button">Actions</button>
                    </div>
                </div>
            </section>

            <section class="overview-grid" id="overviewCards"></section>

            <section class="panel dashboard-panel" id="dashboardPanel" hidden>
                <div class="panel-header">
                    <h3>Admin Home</h3>
                    <span class="panel-meta">All sections generated by this Nite application, grouped and ready for management.</span>
                </div>
                <div class="dashboard-stats" id="dashboardStats"></div>
                <div class="dashboard-groups" id="dashboardGroups"></div>
            </section>

            <div class="content-grid" id="resourceWorkspace">
                <div class="stack">
                    <section class="panel" id="recordsPanel">
                        <div class="panel-header">
                            <h3>Records</h3>
                            <div class="response-topbar">
                                <div class="segmented" id="responseViewTabs"></div>
                                <span class="status-pill status-idle" id="fetchStatus">Idle</span>
                            </div>
                        </div>
                        <div class="helper" id="responseMeta">The current list or selected response will appear here.</div>
                        <div class="helper response-summary" id="responseSummary">No response yet.</div>
                        <div id="responseActions" class="response-actions" hidden></div>
                        <div id="responseStructured" class="table-wrap response-structured"></div>
                        <pre id="jsonOutput" hidden>{}</pre>
                    </section>

                    <section class="panel" id="selectedRecordPanel">
                        <div class="panel-header">
                            <h3>Selected record</h3>
                            <span class="panel-meta" id="selectedRecordMeta">Select a row from the list.</span>
                        </div>
                        <div id="selectedRecordActions" class="response-actions" hidden></div>
                        <div id="selectedRecordFields" class="table-wrap"></div>
                    </section>

                    <section class="panel" id="fieldGuidePanel">
                        <div class="panel-header">
                            <h3>Field guide</h3>
                            <div class="segmented" id="fieldTabs"></div>
                        </div>
                        <div class="helper" style="margin-bottom: 12px;">Switch between response, create, update, and filter field definitions.</div>
                        <div id="fieldTable" class="table-wrap"></div>
                    </section>

                    <section class="panel" id="actionsPanel">
                        <div class="panel-header">
                            <h3>Available actions</h3>
                            <span class="panel-meta" id="routeCountLabel"></span>
                        </div>
                        <div class="helper" style="margin-bottom: 12px;">Use these actions to move between list, detail, create, update, and history flows.</div>
                        <div id="resourceRoutes" class="table-wrap"></div>
                    </section>
                </div>

                <div class="stack">
                    <section class="panel" id="filtersPanel">
                        <div class="panel-header">
                            <h3>Filter</h3>
                            <span class="panel-meta">Apply to the current list.</span>
                        </div>
                        <div id="adminFilterFields" class="param-grid"></div>
                        <div class="toolbar">
                            <button class="btn primary" id="applyFiltersAction" type="button">Apply filters</button>
                            <button class="btn subtle" id="resetFiltersAction" type="button">Reset</button>
                        </div>
                    </section>

                    <section class="panel" id="sessionPanel">
                        <div class="panel-header">
                            <h3>Sign in</h3>
                            <span class="panel-meta" id="authMeta">Sign in to unlock protected management actions.</span>
                        </div>
                        <div class="form-grid">
                            <div class="field">
                                <strong>Email</strong>
                                <input id="loginEmail" class="text-input" type="email" placeholder="you@example.com">
                            </div>
                            <div class="field">
                                <strong>Password</strong>
                                <input id="loginPassword" class="text-input" type="password" placeholder="Enter your password">
                            </div>
                        </div>
                        <div class="toolbar">
                            <button class="btn primary" id="signInAction" type="button">Sign in</button>
                            <button class="btn" id="loadProfileAction" type="button">Refresh profile</button>
                            <button class="btn subtle" id="signOutAction" type="button">Sign out</button>
                        </div>
                        <div class="helper" id="authMessage">Use your normal account credentials. Seeded demo shortcuts remain available below for test installs.</div>
                        <div class="shortcut-strip">
                            <button class="mini-btn" id="loginAdminAction" type="button">Use demo admin</button>
                            <button class="mini-btn" id="loginEditorAction" type="button">Use demo editor</button>
                            <button class="mini-btn" id="loginMemberAction" type="button">Use demo member</button>
                            <button class="mini-btn" id="whoAmIAction" type="button">Open my profile</button>
                            <button class="mini-btn" id="registerAction" type="button">Member signup template</button>
                        </div>
                        <div class="helper shortcut-note">Seeded access: <code>admin@nite.local</code>, <code>editor@nite.local</code>, <code>member@nite.local</code> with password <code>Passw0rd!2026</code>.</div>
                        <details class="advanced-disclosure">
                            <summary>Advanced session tools</summary>
                            <div class="form-grid advanced-grid">
                                <div class="field span-2">
                                    <strong>Bearer Token</strong>
                                    <input id="bearerToken" class="text-input" type="password" placeholder="Paste token for protected endpoints">
                                </div>
                            </div>
                            <div class="toolbar">
                                <button class="btn subtle" id="clearToken" type="button">Clear token</button>
                            </div>
                        </details>
                    </section>

                    <section class="panel" id="advancedPanel">
                        <details class="advanced-disclosure">
                            <summary>
                                <span>Advanced request tools</span>
                                <span class="panel-meta" id="requestSummary">Choose an operation.</span>
                            </summary>
                            <div class="form-grid">
                                <div class="field">
                                    <strong>Route</strong>
                                    <select id="routeSelect" class="select-input"></select>
                                </div>
                                <div class="field">
                                    <strong>Method</strong>
                                    <select id="methodSelect" class="select-input">
                                        <option value="GET">GET</option>
                                        <option value="HEAD">HEAD</option>
                                        <option value="POST">POST</option>
                                        <option value="PUT">PUT</option>
                                        <option value="PATCH">PATCH</option>
                                        <option value="DELETE">DELETE</option>
                                        <option value="OPTIONS">OPTIONS</option>
                                    </select>
                                </div>
                                <div class="field span-2">
                                    <strong>Endpoint</strong>
                                    <input id="endpointPath" class="text-input" type="text" placeholder="/api/v1/pages">
                                </div>
                            </div>
                            <div class="helper" id="routeHint">Select a route to build a request.</div>

                            <div class="request-sections">
                                <section class="request-section">
                                    <div class="section-head">
                                        <h4>Path Parameters</h4>
                                        <div class="inline-actions">
                                            <button class="mini-btn" id="seedPathParams" type="button">Use defaults</button>
                                        </div>
                                    </div>
                                    <div id="pathParams" class="param-grid"></div>
                                </section>

                                <section class="request-section">
                                    <div class="section-head">
                                        <h4>Query Parameters</h4>
                                        <div class="inline-actions">
                                            <button class="mini-btn" id="clearQuery" type="button">Clear</button>
                                        </div>
                                    </div>
                                    <div id="queryParams" class="param-grid"></div>
                                </section>

                                <section class="request-section">
                                    <div class="section-head">
                                        <h4>Request Body</h4>
                                        <div class="inline-actions">
                                            <button class="mini-btn" id="fillRouteBody" type="button">Use route schema</button>
                                            <button class="mini-btn" id="fillCreateBody" type="button">Create template</button>
                                            <button class="mini-btn" id="fillUpdateBody" type="button">Update template</button>
                                            <button class="mini-btn" id="clearBody" type="button">Clear</button>
                                        </div>
                                    </div>
                                    <div id="requestBodyFields" class="table-wrap" style="margin-bottom: 12px;"></div>
                                    <textarea id="requestBody" placeholder="{ }"></textarea>
                                </section>
                            </div>

                            <div class="toolbar">
                                <button class="btn primary" id="sendRequest" type="button">Send request</button>
                                <button class="btn" id="openEndpoint" type="button">Open endpoint</button>
                                <button class="btn" id="copyCurl" type="button">Copy cURL</button>
                            </div>
                        </details>
                    </section>
                </div>
            </div>
        </main>
    </div>

    <script id="niteExplorerData" type="application/json">{$encoded}</script>
    <script>
        const payload = JSON.parse(document.getElementById('niteExplorerData').textContent || '{}');
        const summary = payload.summary || {};
        const resources = Array.isArray(payload.resources) ? payload.resources : [];
        const routes = Array.isArray(payload.routes) ? payload.routes : [];
        const selectedKey = payload.selected_resource;
        const adminBasePath = String(payload.admin_base_path || '/admin');
        const byKey = Object.fromEntries(resources.map(resource => [resource.key, resource]));
        const bodyNode = document.body;
        const themeSelect = document.getElementById('themeSelect');
        const dashboardAction = document.getElementById('dashboardAction');
        const dashboardCrumb = document.getElementById('dashboardCrumb');
        const dashboardPanelNode = document.getElementById('dashboardPanel');
        const dashboardStatsNode = document.getElementById('dashboardStats');
        const dashboardGroupsNode = document.getElementById('dashboardGroups');
        const resourceWorkspaceNode = document.getElementById('resourceWorkspace');
        const recordsPanelNode = document.getElementById('recordsPanel');
        const selectedRecordPanelNode = document.getElementById('selectedRecordPanel');
        const fieldGuidePanelNode = document.getElementById('fieldGuidePanel');
        const actionsPanelNode = document.getElementById('actionsPanel');
        const filtersPanelNode = document.getElementById('filtersPanel');
        const advancedPanelNode = document.getElementById('advancedPanel');
        const overviewCardsNode = document.getElementById('overviewCards');
        const fieldTabsNode = document.getElementById('fieldTabs');
        const fieldTableNode = document.getElementById('fieldTable');
        const groupLabelNode = document.getElementById('resourceGroupLabel');
        const crumbLabelNode = document.getElementById('resourceCrumbLabel');
        const routeCountLabelNode = document.getElementById('routeCountLabel');
        const routeSelect = document.getElementById('routeSelect');
        const methodSelect = document.getElementById('methodSelect');
        const tokenInput = document.getElementById('bearerToken');
        const searchInput = document.getElementById('resourceSearch');
        const endpointInput = document.getElementById('endpointPath');
        const statusNode = document.getElementById('fetchStatus');
        const responseMetaNode = document.getElementById('responseMeta');
        const responseSummaryNode = document.getElementById('responseSummary');
        const routeHintNode = document.getElementById('routeHint');
        const outputNode = document.getElementById('jsonOutput');
        const responseViewTabsNode = document.getElementById('responseViewTabs');
        const responseStructuredNode = document.getElementById('responseStructured');
        const responseActionsNode = document.getElementById('responseActions');
        const selectedRecordMetaNode = document.getElementById('selectedRecordMeta');
        const selectedRecordFieldsNode = document.getElementById('selectedRecordFields');
        const selectedRecordActionsNode = document.getElementById('selectedRecordActions');
        const adminFilterFieldsNode = document.getElementById('adminFilterFields');
        const groupNode = document.getElementById('resourceGroups');
        const routeTableNode = document.getElementById('resourceRoutes');
        const pathParamsNode = document.getElementById('pathParams');
        const queryParamsNode = document.getElementById('queryParams');
        const requestBodyFieldsNode = document.getElementById('requestBodyFields');
        const requestBodyNode = document.getElementById('requestBody');
        const requestSummaryNode = document.getElementById('requestSummary');
        const authMetaNode = document.getElementById('authMeta');
        const authMessageNode = document.getElementById('authMessage');
        const loginEmailNode = document.getElementById('loginEmail');
        const loginPasswordNode = document.getElementById('loginPassword');
        const signInAction = document.getElementById('signInAction');
        const signOutAction = document.getElementById('signOutAction');
        const loadProfileAction = document.getElementById('loadProfileAction');
        const useDefaultAction = document.getElementById('useDefaultAction');
        const loadDefaultAction = document.getElementById('loadDefaultAction');
        const addObjectAction = document.getElementById('addObjectAction');
        const historyViewAction = document.getElementById('historyViewAction');
        const resourceMetaAction = document.getElementById('resourceMetaAction');
        const routesMetaAction = document.getElementById('routesMetaAction');
        const applyFiltersAction = document.getElementById('applyFiltersAction');
        const resetFiltersAction = document.getElementById('resetFiltersAction');
        const seedPathParamsAction = document.getElementById('seedPathParams');
        const clearQueryAction = document.getElementById('clearQuery');
        const fillRouteBodyAction = document.getElementById('fillRouteBody');
        const fillCreateBodyAction = document.getElementById('fillCreateBody');
        const fillUpdateBodyAction = document.getElementById('fillUpdateBody');
        const clearBodyAction = document.getElementById('clearBody');
        const sendRequestAction = document.getElementById('sendRequest');
        const openEndpointAction = document.getElementById('openEndpoint');
        const copyCurlAction = document.getElementById('copyCurl');
        const clearTokenAction = document.getElementById('clearToken');
        const loginAdminAction = document.getElementById('loginAdminAction');
        const loginEditorAction = document.getElementById('loginEditorAction');
        const loginMemberAction = document.getElementById('loginMemberAction');
        const whoAmIAction = document.getElementById('whoAmIAction');
        const registerAction = document.getElementById('registerAction');
        const fieldViews = [
            { key: 'response', label: 'Response', source: 'fields' },
            { key: 'create', label: 'Create', source: 'create_fields' },
            { key: 'update', label: 'Update', source: 'update_fields' },
            { key: 'query', label: 'Query', source: 'query_options' },
        ];
        const responseViews = [
            { key: 'table', label: 'Table' },
            { key: 'json', label: 'JSON' },
        ];
        const authPresets = {
            admin: { email: 'admin@nite.local', password: 'Passw0rd!2026' },
            editor: { email: 'editor@nite.local', password: 'Passw0rd!2026' },
            member: { email: 'member@nite.local', password: 'Passw0rd!2026' },
        };
        const customRouteValue = '__custom__';
        const themeStorageKey = 'nite_admin_theme';
        let preferredKey = selectedKey || null;
        let currentKey = null;
        let currentFieldView = 'response';
        let currentRouteIndex = 0;
        let currentRoute = null;
        let currentResponseView = 'table';
        let currentResponsePayload = null;
        let currentResponseFocus = null;
        let currentSelectedRecord = null;
        let currentSelectedRecordKey = '';
        let currentSelectedRecordField = '';
        const resourceCountNode = document.getElementById('resourceCount');
        const routeCountNode = document.getElementById('routeCount');
        const sessionStorageKey = 'nite_explorer_session';

        tokenInput.value = localStorage.getItem('nite_explorer_token') || '';
        applyTheme(localStorage.getItem(themeStorageKey) || 'classic');
        const initialSession = readStoredSession();
        if (loginEmailNode && initialSession && typeof initialSession.email === 'string' && initialSession.email !== '') {
            loginEmailNode.value = initialSession.email;
        }

        function escapeHtml(value) {
            return String(value ?? '')
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#39;');
        }

        function statusClass(tone) {
            if (tone === 'success') return 'status-pill status-success';
            if (tone === 'pending') return 'status-pill status-pending';
            if (tone === 'error') return 'status-pill status-error';
            return 'status-pill status-idle';
        }

        function applyTheme(theme) {
            const value = ['classic', 'forest', 'graphite', 'sunrise'].includes(String(theme || ''))
                ? String(theme)
                : 'classic';
            bodyNode.setAttribute('data-theme', value);
            localStorage.setItem(themeStorageKey, value);
            if (themeSelect) {
                themeSelect.value = value;
            }
        }

        function methodClass(method) {
            const lowered = String(method || '').toLowerCase();
            if (lowered === 'get') return 'method-badge method-get';
            if (lowered === 'head') return 'method-badge method-get';
            if (lowered === 'post') return 'method-badge method-post';
            if (lowered === 'put') return 'method-badge method-put';
            if (lowered === 'patch') return 'method-badge method-put';
            if (lowered === 'delete') return 'method-badge method-delete';
            if (lowered === 'options') return 'method-badge';
            return 'method-badge';
        }

        function statePill(authRequired) {
            return authRequired
                ? '<span class="state-pill state-auth">auth</span>'
                : '<span class="state-pill state-public">public</span>';
        }

        function fieldTypeLabel(field) {
            return String(field.data_type || 'string') + (field.format ? ':' + field.format : '');
        }

        function fieldFlagsLabel(field) {
            const flags = [];
            if (field.required_on_create) flags.push('create required');
            if (field.required_on_update) flags.push('update required');
            if (field.read_only) flags.push('read only');
            if (field.write_only) flags.push('write only');
            if (field.nullable) flags.push('nullable');
            return flags.length > 0 ? escapeHtml(flags.join(', ')) : '<span class="meta-text">optional</span>';
        }

        function renderTable(rows, columns, emptyMessage) {
            if (!Array.isArray(rows) || rows.length === 0) {
                return '<div class="empty">' + escapeHtml(emptyMessage) + '</div>';
            }

            const head = columns.map(column => '<th>' + escapeHtml(column.label) + '</th>').join('');
            const body = rows.map((row, index) => {
                const cells = columns.map(column => {
                    const value = typeof column.render === 'function' ? column.render(row, index) : row[column.key];
                    return '<td>' + value + '</td>';
                }).join('');
                return '<tr>' + cells + '</tr>';
            }).join('');

            return '<table><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table>';
        }

        function findRouteDoc(method, path) {
            return routes.find(route => route.method === method && route.path === path) || null;
        }

        function routeHintText(route) {
            const authText = route.auth_required
                ? 'Auth required'
                : 'Public';
            const permissions = Array.isArray(route.permissions) && route.permissions.length > 0
                ? ' | ' + route.permissions.join(', ')
                : '';
            return authText + permissions;
        }

        function normalizeKey(value) {
            return String(value || '').replaceAll('-', '_').toLowerCase();
        }

        function normalizeRole(value) {
            return normalizeKey(value);
        }

        function normalizedTokenValue(value) {
            return String(value || '').trim().replace(/^Bearer\s+/i, '');
        }

        function decodeBase64Url(value) {
            const normalized = String(value || '').replaceAll('-', '+').replaceAll('_', '/');
            const padded = normalized + '==='.slice((normalized.length + 3) % 4);
            const decoded = atob(padded);
            const bytes = Uint8Array.from(decoded, char => char.charCodeAt(0));
            return new TextDecoder().decode(bytes);
        }

        function jwtPayload(token) {
            const normalized = normalizedTokenValue(token);
            if (normalized === '') {
                return null;
            }

            const parts = normalized.split('.');
            if (parts.length < 2) {
                return null;
            }

            try {
                const payload = JSON.parse(decodeBase64Url(parts[1]));
                return payload && typeof payload === 'object' ? payload : null;
            } catch {
                return null;
            }
        }

        function normalizePermissions(value) {
            if (!Array.isArray(value)) {
                return [];
            }

            return value
                .map(permission => String(permission || '').trim())
                .filter(Boolean)
                .filter(function (permission, index, list) {
                    return list.indexOf(permission) === index;
                });
        }

        function readStoredSession() {
            try {
                const stored = JSON.parse(localStorage.getItem(sessionStorageKey) || 'null');
                return stored && typeof stored === 'object' ? stored : null;
            } catch {
                return null;
            }
        }

        function writeStoredSession(session) {
            const token = normalizedTokenValue(session && session.token ? session.token : currentToken());
            if (token === '') {
                localStorage.removeItem(sessionStorageKey);
                return;
            }

            localStorage.setItem(sessionStorageKey, JSON.stringify({
                token: token,
                authenticated: !!(session && session.authenticated),
                sub: String(session && session.sub ? session.sub : ''),
                email: String(session && session.email ? session.email : ''),
                name: String(session && session.name ? session.name : ''),
                role: String(session && session.role ? session.role : ''),
                permissions: normalizePermissions(session && session.permissions),
                permissions_known: !!(session && session.permissions_known),
            }));
        }

        function sessionFromToken(token) {
            const payloadValue = jwtPayload(token);
            if (!payloadValue) {
                return {
                    token: normalizedTokenValue(token),
                    authenticated: false,
                    sub: '',
                    email: '',
                    name: '',
                    role: '',
                    permissions: [],
                    permissions_known: false,
                };
            }

            return {
                token: normalizedTokenValue(token),
                authenticated: true,
                sub: String(payloadValue.sub || ''),
                email: String(payloadValue.email || ''),
                name: String(payloadValue.name || ''),
                role: String(payloadValue.role || ''),
                permissions: [],
                permissions_known: false,
            };
        }

        function currentToken() {
            return tokenInput.value.trim();
        }

        function adminSurfaceUrl(resource) {
            if (!resource || typeof resource !== 'object') {
                return adminBasePath;
            }

            const surfacePath = String(resource.admin_surface_path || '').trim();
            if (surfacePath !== '') {
                return surfacePath;
            }

            return adminBasePath + '?resource=' + encodeURIComponent(String(resource.key || ''));
        }

        function currentSession() {
            const derived = sessionFromToken(currentToken());
            const stored = readStoredSession();
            if (!stored || String(stored.token || '') !== derived.token) {
                return derived;
            }
            if (!sessionProfileMatchesToken({
                sub: String(stored.sub || ''),
                email: String(stored.email || ''),
            }, derived.token)) {
                return derived;
            }

            return {
                token: derived.token,
                authenticated: !!(stored.authenticated || derived.authenticated),
                sub: String(stored.sub || derived.sub || ''),
                email: String(stored.email || derived.email || ''),
                name: String(stored.name || derived.name || ''),
                role: String(stored.role || derived.role || ''),
                permissions: normalizePermissions(stored.permissions),
                permissions_known: !!stored.permissions_known,
            };
        }

        function updateAuthPanel() {
            const session = currentSession();
            if (loginEmailNode && session.email && loginEmailNode.value.trim() === '') {
                loginEmailNode.value = session.email;
            }
            if (authMetaNode) {
                if (session.authenticated) {
                    const label = session.name || session.email || session.role || 'Authenticated';
                    authMetaNode.textContent = 'Signed in as ' + label;
                } else {
                    authMetaNode.textContent = 'Sign in to unlock protected management actions.';
                }
            }

            if (authMessageNode) {
                if (session.authenticated) {
                    const role = session.role ? ' (' + session.role + ')' : '';
                    authMessageNode.textContent = 'Current session: ' + (session.email || session.name || 'authenticated user') + role + '.';
                } else {
                    authMessageNode.textContent = 'Use your normal account credentials. Seeded demo shortcuts remain available below for test installs.';
                }
            }
        }

        async function performLogin(credentials) {
            const email = String(credentials && credentials.email ? credentials.email : '').trim();
            const password = String(credentials && credentials.password ? credentials.password : '');

            if (email === '' || password === '') {
                setConsoleStatus('Missing credentials', 'error');
                if (authMessageNode) {
                    authMessageNode.textContent = 'Enter both email and password before signing in.';
                }
                return;
            }

            setConsoleStatus('Signing in', 'pending');
            if (authMessageNode) {
                authMessageNode.textContent = 'Signing in as ' + email + '...';
            }

            try {
                const response = await fetch('/api/v1/auth/login', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email: email, password: password }),
                });
                const text = await response.text();
                let parsed = {};
                try {
                    parsed = JSON.parse(text);
                } catch {
                    parsed = {};
                }

                if (!response.ok) {
                    const message = parsed && typeof parsed === 'object' && parsed.message
                        ? String(parsed.message)
                        : ('Sign-in failed with HTTP ' + response.status);
                    setConsoleStatus('Sign-in failed', 'error');
                    if (authMessageNode) {
                        authMessageNode.textContent = message;
                    }
                    return;
                }

                const discoveredToken = tokenFromResponse(parsed);
                if (!discoveredToken) {
                    setConsoleStatus('Missing token', 'error');
                    if (authMessageNode) {
                        authMessageNode.textContent = 'Sign-in succeeded but no bearer token was returned.';
                    }
                    return;
                }

                tokenInput.value = discoveredToken;
                persistSessionToken();
                persistSessionFromPayload(parsed, discoveredToken, 'POST', '/api/v1/auth/login');
                refreshRouteVisibility();
                updateAuthPanel();
                if (loginPasswordNode) {
                    loginPasswordNode.value = '';
                }
                setConsoleStatus('Signed in', 'success');
                if (authMessageNode) {
                    authMessageNode.textContent = 'Signed in successfully. Protected sections and actions are now available.';
                }
            } catch (error) {
                setConsoleStatus('Sign-in failed', 'error');
                if (authMessageNode) {
                    authMessageNode.textContent = String(error && error.message ? error.message : error);
                }
            }
        }

        function sessionProfileFromPayload(payloadValue) {
            if (!payloadValue || typeof payloadValue !== 'object') {
                return null;
            }

            const candidates = [
                payloadValue.user,
                payloadValue.data && payloadValue.data.user ? payloadValue.data.user : null,
                payloadValue.data,
            ];
            const profile = candidates.find(candidate => {
                if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) {
                    return false;
                }

                return Boolean(
                    candidate.id
                    || candidate.email
                    || candidate.name
                    || candidate.role
                    || Array.isArray(candidate.permissions)
                );
            });

            if (!profile || typeof profile !== 'object' || Array.isArray(profile)) {
                return null;
            }

            return {
                sub: String(profile.id || profile.sub || ''),
                email: String(profile.email || ''),
                name: String(profile.name || ''),
                role: String(profile.role || ''),
                permissions: normalizePermissions(profile.permissions),
                permissions_known: Array.isArray(profile.permissions),
            };
        }

        function persistSessionFromPayload(payloadValue, preferredToken = '', method = 'GET', path = '') {
            const token = normalizedTokenValue(preferredToken || currentToken());
            if (token === '') {
                return;
            }

            const profile = sessionProfileFromPayload(payloadValue);
            if (profile && !isAuthenticationRoute(method, path) && !sessionProfileMatchesToken(profile, token)) {
                return;
            }
            const session = profile
                ? Object.assign({}, currentSession(), profile, { token: token, authenticated: true })
                : Object.assign({}, currentSession(), { token: token, authenticated: currentSession().authenticated });
            writeStoredSession(session);
        }

        function persistSessionToken() {
            const token = currentToken();
            if (token === '') {
                localStorage.removeItem('nite_explorer_token');
                localStorage.removeItem(sessionStorageKey);
                return;
            }

            localStorage.setItem('nite_explorer_token', token);
            const derived = sessionFromToken(token);
            const stored = readStoredSession();
            if (stored && String(stored.token || '') === derived.token) {
                writeStoredSession(Object.assign({}, derived, stored, {
                    token: derived.token,
                    authenticated: !!(stored.authenticated || derived.authenticated),
                    permissions: normalizePermissions(stored.permissions),
                    permissions_known: !!stored.permissions_known,
                }));
                return;
            }

            writeStoredSession(derived);
        }

        function routeVisibleToSession(route, session = currentSession()) {
            if (!route || typeof route !== 'object') {
                return false;
            }

            const method = String(route.method || 'GET').toUpperCase();
            const authRequired = !!route.auth_required;
            const permissions = normalizePermissions(route.permissions);

            if (!session.authenticated) {
                if (authRequired) {
                    return false;
                }
                if (['GET', 'HEAD', 'OPTIONS'].includes(method)) {
                    return true;
                }
                return method === 'POST' && permissions.length === 0;
            }

            if (!authRequired) {
                return true;
            }
            if (permissions.length === 0) {
                return true;
            }
            if (session.permissions_known) {
                return permissions.some(permission => session.permissions.includes(permission));
            }

            const role = normalizeRole(session.role);
            if (role === '') {
                return false;
            }

            const fallbackRoles = Array.isArray(route.permission_default_roles)
                ? route.permission_default_roles.map(normalizeRole)
                : [];
            return fallbackRoles.includes(role);
        }

        function visibleRouteEntries(resource, session = currentSession()) {
            if (!resource || !Array.isArray(resource.routes)) {
                return [];
            }

            return resource.routes
                .map((route, index) => ({ route, index }))
                .filter(entry => routeVisibleToSession(entry.route, session));
        }

        function hasVisibleRoutes(resource, session = currentSession()) {
            return visibleRouteEntries(resource, session).length > 0;
        }

        function resourceAccessState(resource, session = currentSession()) {
            const visibleCount = visibleRouteEntries(resource, session).length;
            if (visibleCount > 0) {
                return {
                    state: 'available',
                    label: visibleCount + ' visible action' + (visibleCount === 1 ? '' : 's'),
                };
            }

            if (resource && resource.default_data_auth_required) {
                return {
                    state: 'locked',
                    label: 'Sign in to unlock',
                };
            }

            return {
                state: 'unavailable',
                label: 'No live actions in this session',
            };
        }

        function updateDiscoveryCounts() {
            const session = currentSession();
            const routeCount = resources.reduce(function (total, resource) {
                return total + visibleRouteEntries(resource, session).length;
            }, 0);

            resourceCountNode.textContent = String(resources.length);
            routeCountNode.textContent = String(routeCount);
        }

        function rowValue(row, key) {
            if (!row || typeof row !== 'object') {
                return undefined;
            }
            if (Object.prototype.hasOwnProperty.call(row, key)) {
                return row[key];
            }

            const target = normalizeKey(key);
            const entry = Object.keys(row).find(candidate => normalizeKey(candidate) === target);
            return entry ? row[entry] : undefined;
        }

        function lookupRowValue(row, fieldName) {
            const candidates = [
                fieldName,
                fieldName.replace(/Id$/, '_id'),
                fieldName.replace(/_id$/, 'Id'),
                fieldName + '_key',
                fieldName + '_type',
                fieldName + '_code',
            ];

            if (fieldName === 'logId') {
                candidates.push('id', 'log_id');
            }
            if (fieldName === 'resource') {
                candidates.push('key', 'resource_key');
            }
            if (fieldName === 'role') {
                candidates.push('role_code');
            }
            if (fieldName.toLowerCase().endsWith('id')) {
                candidates.push('id');
            }

            for (const candidate of candidates) {
                const value = rowValue(row, candidate);
                if (value !== undefined && value !== null && String(value) !== '') {
                    return value;
                }
            }

            return '';
        }

        function fieldNameVariants(fieldName) {
            const raw = String(fieldName || '').trim();
            if (raw === '') {
                return [];
            }

            const snake = raw
                .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
                .replace(/[\s-]+/g, '_')
                .toLowerCase();
            const camel = snake.replace(/_([a-z])/g, function (_, letter) {
                return letter.toUpperCase();
            });
            const variants = new Set([raw, snake, camel, raw.replace(/[\s-]+/g, '_')]);
            const normalized = normalizeKey(raw);

            ['_key', '_type', '_code'].forEach(function (suffix) {
                if (snake.endsWith(suffix)) {
                    variants.add(snake.slice(0, -suffix.length));
                } else if (!snake.includes('_')) {
                    variants.add(snake + suffix);
                }
            });

            if (normalized === 'resource') {
                variants.add('key');
                variants.add('resource_key');
            }
            if (normalized === 'resource_key' || normalized === 'key') {
                variants.add('resource');
            }
            if (normalized === 'role') {
                variants.add('role_code');
            }
            if (normalized === 'role_code') {
                variants.add('role');
            }

            return Array.from(variants).map(normalizeKey);
        }

        function fieldMatchesPathParam(fieldName, paramName) {
            const fieldVariants = fieldNameVariants(fieldName);
            const paramVariants = fieldNameVariants(paramName);
            return fieldVariants.some(function (variant) {
                return paramVariants.includes(variant);
            });
        }

        function resolveRouteValues(route, row) {
            const values = {};
            const fields = route && route.request ? (route.request.path_params || []) : [];

            for (const field of fields) {
                const value = lookupRowValue(row, field.name);
                if (value === '') {
                    return null;
                }
                values[field.name] = value;
            }

            return values;
        }

        function setScopedValues(scope, values) {
            document.querySelectorAll('[data-param-scope="' + scope + '"]').forEach(input => {
                const key = input.getAttribute('data-param-name');
                if (!key) {
                    return;
                }
                input.value = values[key] !== undefined && values[key] !== null ? String(values[key]) : '';
            });
        }

        function bodyFromRow(fields, row, fallbackReason = 'manual request') {
            const payload = {};
            (fields || []).forEach(field => {
                const value = rowValue(row, field.name);
                if (value !== undefined && !field.read_only) {
                    payload[field.name] = value;
                }
            });

            if (Object.keys(payload).length === 0) {
                return JSON.stringify(buildTemplate(fields || []), null, 2);
            }

            if (Object.prototype.hasOwnProperty.call(payload, 'change_reason') && String(payload.change_reason || '').trim() === '') {
                payload.change_reason = fallbackReason;
            }

            return JSON.stringify(payload, null, 2);
        }

        function responseFocus(payloadValue) {
            if (Array.isArray(payloadValue)) {
                return { source: 'root', value: payloadValue };
            }
            if (payloadValue && typeof payloadValue === 'object') {
                if (Array.isArray(payloadValue.data) || (payloadValue.data && typeof payloadValue.data === 'object')) {
                    return { source: 'data', value: payloadValue.data };
                }
                if (Array.isArray(payloadValue.items) || (payloadValue.items && typeof payloadValue.items === 'object')) {
                    return { source: 'items', value: payloadValue.items };
                }
                return { source: 'root', value: payloadValue };
            }

            return { source: 'scalar', value: payloadValue };
        }

        function previewText(value) {
            if (value === null) {
                return 'null';
            }
            if (value === undefined) {
                return 'undefined';
            }
            if (typeof value === 'string') {
                return value;
            }
            if (typeof value === 'number' || typeof value === 'boolean') {
                return String(value);
            }
            try {
                const encoded = JSON.stringify(value);
                return encoded.length > 140 ? encoded.slice(0, 137) + '...' : encoded;
            } catch {
                return String(value);
            }
        }

        function previewHtml(value) {
            if (value === null) {
                return '<span class="meta-text">null</span>';
            }
            if (value === undefined) {
                return '<span class="meta-text">undefined</span>';
            }
            if (typeof value === 'object') {
                return '<code>' + escapeHtml(previewText(value)) + '</code>';
            }
            if (typeof value === 'boolean') {
                return value ? 'true' : 'false';
            }
            if (typeof value === 'string' && value === '') {
                return '<span class="meta-text">empty</span>';
            }
            return escapeHtml(String(value));
        }

        function responseShapeLabel(value) {
            if (Array.isArray(value)) {
                return value.length + ' row' + (value.length === 1 ? '' : 's');
            }
            if (value && typeof value === 'object') {
                const fieldCount = Object.keys(value).length;
                return fieldCount + ' field' + (fieldCount === 1 ? '' : 's');
            }
            return typeof value;
        }

        function routeActionLabel(route) {
            const path = String(route.path || '');
            if (route.method === 'POST' && path.includes('/restore')) {
                return 'Restore';
            }
            if (route.method === 'GET' && path.includes('/history')) {
                return 'History';
            }
            if (route.method === 'GET') {
                return 'View';
            }
            if (route.method === 'PUT') {
                return 'Edit';
            }
            if (route.method === 'PATCH') {
                return 'Patch';
            }
            if (route.method === 'DELETE') {
                return 'Delete';
            }
            return 'Use';
        }

        function routeActionPriority(route) {
            const label = routeActionLabel(route);
            if (label === 'Restore') return 1;
            if (label === 'View') return 2;
            if (label === 'History') return 3;
            if (label === 'Edit') return 4;
            if (label === 'Patch') return 5;
            if (label === 'Delete') return 6;
            return 9;
        }

        function rowActionsForResource(resource, row, fieldName = '', limit = 4) {
            if (!resource || !row || typeof row !== 'object') {
                return [];
            }

            const narrowedField = String(fieldName || '').trim();
            const actions = visibleRouteEntries(resource)
                .map(entry => {
                    const route = entry.route;
                    const pathParams = route && route.request ? (route.request.path_params || []) : [];
                    if (pathParams.length === 0) {
                        return null;
                    }

                    if (narrowedField !== '') {
                        const matchesField = pathParams.some(field => fieldMatchesPathParam(narrowedField, field.name || ''));
                        if (!matchesField) {
                            return null;
                        }
                    }

                    const values = resolveRouteValues(route, row);
                    if (!values) {
                        return null;
                    }

                    return {
                        index: entry.index,
                        route,
                        label: routeActionLabel(route),
                        values,
                    };
                })
                .filter(Boolean)
                .sort((left, right) => routeActionPriority(left.route) - routeActionPriority(right.route));

            if (typeof limit === 'number' && limit >= 0) {
                return actions.slice(0, limit);
            }

            return actions;
        }

        function recordKey(row) {
            if (!row || typeof row !== 'object') {
                return '';
            }

            return String(
                row.id
                ?? row.slug
                ?? row.key
                ?? row.email
                ?? row.code
                ?? ''
            );
        }

        function identifierValueHtml(value) {
            if (value === null) {
                return '<span class="meta-text">null</span>';
            }
            if (value === undefined) {
                return '<span class="meta-text">undefined</span>';
            }

            const text = String(value);
            if (text === '') {
                return '<span class="meta-text">empty</span>';
            }

            return '<code>' + escapeHtml(text) + '</code>';
        }

        function previewFieldHtml(resource, row, fieldName) {
            const value = rowValue(row, fieldName);
            const rowKey = recordKey(row);
            if (rowKey === '' || value === undefined || value === null || typeof value === 'object') {
                return previewHtml(value);
            }

            const actions = rowActionsForResource(resource, row, fieldName, null);
            if (actions.length === 0) {
                return previewHtml(value);
            }

            const actionLabel = actions.map(function (action) {
                return action.label;
            }).join(', ');

            return '<button class="identifier-chip" data-select-record="' + escapeHtml(rowKey) + '" data-select-record-field="' + escapeHtml(fieldName) + '" data-select-record-scroll="true" title="' + escapeHtml('Actions: ' + actionLabel) + '" type="button">' +
                identifierValueHtml(value) +
            '</button>';
        }

        function renderSelectedRecord(row, fieldName = '') {
            if (!row || typeof row !== 'object') {
                currentSelectedRecord = null;
                currentSelectedRecordKey = '';
                currentSelectedRecordField = '';
                selectedRecordMetaNode.textContent = 'Select a row from the list.';
                selectedRecordFieldsNode.innerHTML = '<div class="empty">Load a list or object response to inspect one record in change-form style.</div>';
                selectedRecordActionsNode.hidden = true;
                selectedRecordActionsNode.innerHTML = '';
                return;
            }

            currentSelectedRecord = row;
            currentSelectedRecordKey = recordKey(row);
            const resource = currentResource();
            const requestedField = String(fieldName || currentSelectedRecordField || '').trim();
            const filteredActions = requestedField !== ''
                ? rowActionsForResource(resource, row, requestedField, null)
                : [];
            const activeField = filteredActions.length > 0 ? requestedField : '';
            const actions = activeField !== ''
                ? filteredActions
                : rowActionsForResource(resource, row, '', null);
            currentSelectedRecordField = activeField;
            const label = row.title ?? row.name ?? row.slug ?? row.email ?? row.id ?? (resource ? resource.label : 'record');
            selectedRecordMetaNode.textContent = activeField === ''
                ? String(label)
                : String(label) + ' | ' + humanizeToken(activeField);
            selectedRecordFieldsNode.innerHTML = renderKeyValueGrid(row, resource);

            if (actions.length === 0) {
                selectedRecordActionsNode.hidden = true;
                selectedRecordActionsNode.innerHTML = '';
                return;
            }

            const refreshFieldAttr = activeField === ''
                ? ''
                : ' data-select-record-field="' + escapeHtml(activeField) + '"';
            const heading = activeField === ''
                ? 'Record actions'
                : 'Actions for ' + humanizeToken(activeField);
            selectedRecordActionsNode.hidden = false;
            selectedRecordActionsNode.innerHTML = '<div class="action-card">' +
                '<h4>' + escapeHtml(heading) + '</h4>' +
                (activeField === ''
                    ? ''
                    : '<div class="helper">Showing routes keyed by <code>' + escapeHtml(activeField) + '</code>.</div>') +
                '<div class="action-list">' +
                '<button class="mini-btn" data-select-record="' + escapeHtml(currentSelectedRecordKey) + '"' + refreshFieldAttr + ' type="button">Refresh selection</button>' +
                actions.map(action => {
                    const loadNow = action.label === 'View' || action.label === 'History';
                    return '<button class="mini-btn" data-response-action="' + action.index + '" data-response-row="selected" data-response-action-mode="' + (loadNow ? 'load' : 'prepare') + '" type="button">' + escapeHtml(action.label) + '</button>';
                }).join('') +
                '</div>' +
            '</div>';
        }

        function syncSelectedRecord(focus) {
            if (Array.isArray(focus)) {
                const rows = focus.filter(row => row && typeof row === 'object' && !Array.isArray(row));
                if (rows.length === 0) {
                    renderSelectedRecord(null);
                    return;
                }

                const selected = rows.find(row => recordKey(row) !== '' && recordKey(row) === currentSelectedRecordKey) || rows[0];
                renderSelectedRecord(selected, currentSelectedRecordField);
                return;
            }

            if (focus && typeof focus === 'object') {
                renderSelectedRecord(focus, currentSelectedRecordField);
                return;
            }

            renderSelectedRecord(null);
        }

        function findRouteIndex(resource, predicate) {
            const entry = visibleRouteEntries(resource).find(candidate => predicate(candidate.route));
            return entry ? entry.index : -1;
        }

        function createRouteIndex(resource) {
            return findRouteIndex(resource, route => route.method === 'POST' && !String(route.path || '').includes('/restore') && !String(route.path || '').includes('/login') && !String(route.path || '').includes('/register'));
        }

        function historyRouteIndex(resource) {
            return findRouteIndex(resource, route => route.method === 'GET' && String(route.path || '').includes('/history'));
        }

        function renderAdminFilters(resource) {
            const canFilter = defaultReadRouteIndex(resource) >= 0;
            const fields = resource && Array.isArray(resource.query_options) ? resource.query_options : [];
            if (!canFilter || fields.length === 0) {
                adminFilterFieldsNode.innerHTML = '<div class="empty">No accessible list filters are available for this session.</div>';
                return;
            }

            adminFilterFieldsNode.innerHTML = fields.map(field => {
                return '<label class="param-card">' +
                    '<span class="param-head">' +
                        '<code>' + escapeHtml(field.name) + '</code>' +
                        '<small>' + escapeHtml(field.description || '') + '</small>' +
                    '</span>' +
                    controlHtml(field, 'admin-filter', '') +
                '</label>';
            }).join('');
        }

        function readAdminFilters() {
            return readScopedValues('admin-filter');
        }

        function resetAdminFilters() {
            document.querySelectorAll('[data-param-scope="admin-filter"]').forEach(input => {
                input.value = '';
            });
        }

        function applyAdminFilters(loadImmediately = true) {
            const resource = currentResource();
            if (!resource) {
                return;
            }

            const routeIndex = defaultReadRouteIndex(resource);
            if (routeIndex < 0) {
                setConsoleStatus('No list route', 'error');
                return;
            }

            applyRoute(routeIndex);
            setScopedValues('query', readAdminFilters());
            updateEndpointFromRoute();

            if (loadImmediately) {
                sendRequest();
            }
        }

        function renderResponseViewTabs() {
            responseViewTabsNode.innerHTML = responseViews.map(view => {
                const active = view.key === currentResponseView ? ' active' : '';
                return '<button class="' + active.trim() + '" data-response-view="' + escapeHtml(view.key) + '">' +
                    escapeHtml(view.label) +
                '</button>';
            }).join('');

            responseViewTabsNode.querySelectorAll('[data-response-view]').forEach(button => {
                button.addEventListener('click', function () {
                    currentResponseView = button.getAttribute('data-response-view') || 'table';
                    renderResponseViewTabs();
                    renderResponse();
                });
            });
        }

        function renderKeyValueGrid(value, resource = null) {
            if (!value || typeof value !== 'object') {
                return '<div class="scalar-card">' + previewHtml(value) + '</div>';
            }

            const rows = Object.keys(value).map(key => {
                const renderedValue = resource && value && typeof value === 'object'
                    ? previewFieldHtml(resource, value, key)
                    : previewHtml(value[key]);
                return '<div class="key-value-row">' +
                    '<strong><code>' + escapeHtml(key) + '</code></strong>' +
                    '<div>' + renderedValue + '</div>' +
                '</div>';
            }).join('');

            return rows === '' ? '<div class="empty">No fields in this object.</div>' : '<div class="key-value-grid">' + rows + '</div>';
        }

        function responseColumns(resource, rows) {
            const names = [];
            const seen = new Set();
            const add = name => {
                if (seen.has(name)) {
                    return;
                }
                seen.add(name);
                names.push(name);
            };

            if (resource && Array.isArray(resource.fields)) {
                resource.fields.forEach(field => {
                    if (rows.some(row => row && typeof row === 'object' && Object.prototype.hasOwnProperty.call(row, field.name))) {
                        add(field.name);
                    }
                });
            }

            rows.slice(0, 5).forEach(row => {
                Object.keys(row || {}).forEach(add);
            });

            return names.slice(0, 12);
        }

        function useRouteDoc(route, bodyText = null, pathValues = {}, queryValues = {}, autoSend = false) {
            if (!route) {
                return;
            }

            currentRoute = route;
            currentRouteIndex = -1;
            routeSelect.value = customRouteValue;
            if (!Array.from(methodSelect.options).some(option => option.value === route.method)) {
                methodSelect.innerHTML = '<option value="' + escapeHtml(route.method) + '">' + escapeHtml(route.method) + '</option>' + methodSelect.innerHTML;
            }
            methodSelect.value = route.method;
            requestSummaryNode.textContent = route.summary || routeLabel(route);
            routeHintNode.textContent = routeHintText(route);
            renderParamFields(pathParamsNode, route.request.path_params || [], 'path', pathValues);
            renderParamFields(queryParamsNode, route.request.query || [], 'query', queryValues);
            renderRequestBodyFields(route.request.body || []);
            updateEndpointFromRoute();

            if (bodyText !== null) {
                requestBodyNode.value = bodyText;
            } else if ((route.request.body || []).length > 0) {
                fillBodyFromFields(route.request.body || []);
            } else {
                requestBodyNode.value = '';
            }

            setConsoleStatus('Ready', 'idle');
            responseMetaNode.textContent = 'Console prepared for ' + routeLabel(route) + '.';

            if (autoSend) {
                sendRequest();
            }
        }

        function useRouteForRow(actionIndex, row, autoSend = false) {
            const resource = currentResource();
            if (!resource || !resource.routes || !resource.routes[actionIndex]) {
                return;
            }

            const route = resource.routes[actionIndex];
            applyRoute(actionIndex);
            const pathValues = resolveRouteValues(route, row) || {};
            setScopedValues('path', pathValues);
            updateEndpointFromRoute();

            if (route.method === 'PUT' || route.method === 'PATCH') {
                requestBodyNode.value = bodyFromRow(route.request.body || [], row, 'update from explorer');
            } else if (route.method === 'POST' && String(route.path || '').includes('/restore')) {
                requestBodyNode.value = JSON.stringify({ change_reason: 'restore from explorer' }, null, 2);
            } else if (route.method === 'DELETE') {
                requestBodyNode.value = '';
            }

            if (autoSend) {
                sendRequest();
            }
        }

        function renderResponseActions(focusValue) {
            const resource = currentResource();

            if (Array.isArray(focusValue)) {
                const firstObject = focusValue.find(row => row && typeof row === 'object' && !Array.isArray(row));
                if (!firstObject) {
                    responseActionsNode.hidden = true;
                    responseActionsNode.innerHTML = '';
                    return;
                }

                const actions = rowActionsForResource(resource, firstObject);
                if (actions.length === 0) {
                    responseActionsNode.hidden = true;
                    responseActionsNode.innerHTML = '';
                    return;
                }

                responseActionsNode.hidden = false;
                responseActionsNode.innerHTML = '<div class="action-card">' +
                    '<h4>Quick actions from the first row</h4>' +
                    '<div class="helper">Inline actions are also available per row in the table view.</div>' +
                    '<div class="action-list">' +
                    actions.map(action => {
                        const loadNow = action.label === 'View' || action.label === 'History';
                        return '<button class="mini-btn" data-response-action="' + action.index + '" data-response-row="first" data-response-action-mode="' + (loadNow ? 'load' : 'prepare') + '" type="button">' + escapeHtml(action.label) + '</button>';
                    }).join('') +
                    '</div>' +
                '</div>';
                return;
            }

            if (!focusValue || typeof focusValue !== 'object') {
                responseActionsNode.hidden = true;
                responseActionsNode.innerHTML = '';
                return;
            }

            const actions = rowActionsForResource(resource, focusValue);
            if (actions.length === 0) {
                responseActionsNode.hidden = true;
                responseActionsNode.innerHTML = '';
                return;
            }

            responseActionsNode.hidden = false;
            responseActionsNode.innerHTML = '<div class="action-card">' +
                '<h4>Direct actions for this response</h4>' +
                '<div class="action-list">' +
                actions.map(action => {
                    const loadNow = action.label === 'View' || action.label === 'History';
                    return '<button class="mini-btn" data-response-action="' + action.index + '" data-response-row="single" data-response-action-mode="' + (loadNow ? 'load' : 'prepare') + '" type="button">' + escapeHtml(action.label) + '</button>';
                }).join('') +
                '</div>' +
            '</div>';
        }

        function isRouteCatalogRow(value) {
            return !!value
                && typeof value === 'object'
                && !Array.isArray(value)
                && typeof value.method === 'string'
                && typeof value.path === 'string'
                && value.request
                && value.response;
        }

        function visibleResponseFocus(focusValue) {
            if (!Array.isArray(focusValue) || focusValue.length === 0) {
                return focusValue;
            }

            if (!focusValue.every(isRouteCatalogRow)) {
                return focusValue;
            }

            return focusValue.filter(routeVisibleToSession);
        }

        function renderResponse() {
            const focus = visibleResponseFocus(currentResponseFocus ? currentResponseFocus.value : null);
            const source = currentResponseFocus ? currentResponseFocus.source : 'none';

            responseSummaryNode.textContent = currentResponsePayload === null
                ? 'No response yet.'
                : 'Viewing ' + responseShapeLabel(focus) + ' from ' + source + '.';

            renderResponseActions(focus);
            syncSelectedRecord(focus);

            if (currentResponseView === 'json') {
                responseStructuredNode.hidden = true;
                outputNode.hidden = false;
                return;
            }

            outputNode.hidden = true;
            responseStructuredNode.hidden = false;

            if (focus === null || focus === undefined) {
                responseStructuredNode.innerHTML = '<div class="empty">No response body to render.</div>';
                return;
            }

            if (Array.isArray(focus)) {
                if (focus.length === 0) {
                    responseStructuredNode.innerHTML = '<div class="empty">The response array is empty.</div>';
                    return;
                }

                if (focus.some(row => !row || typeof row !== 'object' || Array.isArray(row))) {
                    responseStructuredNode.innerHTML = renderTable(
                        focus.map(value => ({ value })),
                        [{ label: 'Value', render: row => previewHtml(row.value) }],
                        'The response array is empty.'
                    );
                    return;
                }

                const resource = currentResource();
                const columns = responseColumns(resource, focus).map(name => ({
                    label: name,
                    render: row => previewFieldHtml(resource, row, name),
                }));
                columns.push({
                    label: 'Actions',
                    render: (row) => {
                        const actions = rowActionsForResource(resource, row);
                        const rowKey = row.id !== undefined && row.id !== null
                            ? String(row.id)
                            : String(row.slug ?? row.key ?? row.email ?? '');
                        const inspect = rowKey !== ''
                            ? '<button class="mini-btn" data-select-record="' + escapeHtml(rowKey) + '" type="button">Open</button>'
                            : '';
                        if (actions.length === 0) {
                            return inspect || '<span class="meta-text">none</span>';
                        }
                        return '<div class="table-actions">' +
                            inspect +
                            actions.map(action => {
                                const loadNow = action.label === 'View' || action.label === 'History';
                                return '<button class="mini-btn" data-response-action="' + action.index + '" data-response-row-id="' + escapeHtml(rowKey) + '" data-response-action-mode="' + (loadNow ? 'load' : 'prepare') + '" type="button">' + escapeHtml(action.label) + '</button>';
                            }).join('') +
                        '</div>';
                    },
                });
                responseStructuredNode.innerHTML = renderTable(focus, columns, 'The response array is empty.');
                return;
            }

            if (focus && typeof focus === 'object') {
                responseStructuredNode.innerHTML = renderKeyValueGrid(focus, currentResource());
                return;
            }

            responseStructuredNode.innerHTML = '<div class="scalar-card">' + previewHtml(focus) + '</div>';
        }

        function currentResource() {
            return byKey[currentKey] || null;
        }

        function renderResourceList(filter = '') {
            const lowered = filter.trim().toLowerCase();
            const grouped = new Map();
            const session = currentSession();

            updateDiscoveryCounts();

            resources.forEach(resource => {
                const haystack = (resource.label + ' ' + resource.summary + ' ' + resource.key).toLowerCase();
                if (lowered !== '' && !haystack.includes(lowered)) {
                    return;
                }
                const list = grouped.get(resource.group) || [];
                list.push(resource);
                grouped.set(resource.group, list);
            });

            const sections = Array.from(grouped.entries()).map(([group, items]) => {
                const buttons = items.map(resource => {
                    const active = resource.key === currentKey ? ' active' : '';
                    const access = resourceAccessState(resource, session);
                    const lockedClass = access.state === 'locked' ? ' locked' : '';
                    return '<button class="resource-link' + active + lockedClass + '" data-resource-key="' + escapeHtml(resource.key) + '">' +
                        '<strong>' + escapeHtml(resource.label) + '</strong>' +
                        '<small>' + escapeHtml(resource.item_type) + '</small>' +
                        '<span class="resource-state">' + escapeHtml(access.label) + '</span>' +
                    '</button>';
                }).join('');
                return '<section class="group"><h2>' + escapeHtml(group) + '</h2>' + buttons + '</section>';
            }).join('');

            groupNode.innerHTML = sections || '<p class="empty">No resources match this filter.</p>';
            groupNode.querySelectorAll('[data-resource-key]').forEach(button => {
                button.addEventListener('click', () => selectResource(button.getAttribute('data-resource-key')));
            });
        }

        function defaultReadRouteIndex(resource) {
            const visibleEntries = visibleRouteEntries(resource);
            if (visibleEntries.length === 0) {
                return -1;
            }

            const exactDefault = visibleEntries.find(entry => entry.route.method === 'GET' && entry.route.path === resource.default_data_path);
            if (exactDefault) {
                return exactDefault.index;
            }

            const firstGet = visibleEntries.find(entry => entry.route.method === 'GET');
            return firstGet ? firstGet.index : -1;
        }

        function defaultRouteIndex(resource) {
            const readIndex = defaultReadRouteIndex(resource);
            if (readIndex >= 0) {
                return readIndex;
            }

            const firstVisible = visibleRouteEntries(resource)[0];
            return firstVisible ? firstVisible.index : -1;
        }

        function visibleMethodChoices(resource) {
            const methods = new Set();

            visibleRouteEntries(resource).forEach(function (entry) {
                methods.add(String(entry.route.method || 'GET').toUpperCase());
            });

            if (methods.has('GET')) {
                methods.add('HEAD');
            }
            if (methods.size > 0) {
                methods.add('OPTIONS');
            }

            return ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'].filter(method => methods.has(method));
        }

        function populateMethodSelect(resource, preferredMethod = '') {
            const methods = visibleMethodChoices(resource);
            const fallbackMethods = methods.length > 0 ? methods : ['GET'];
            methodSelect.innerHTML = fallbackMethods.map(method => {
                return '<option value="' + escapeHtml(method) + '">' + escapeHtml(method) + '</option>';
            }).join('');

            const targetMethod = fallbackMethods.includes(String(preferredMethod || '').toUpperCase())
                ? String(preferredMethod || '').toUpperCase()
                : fallbackMethods[0];
            methodSelect.value = targetMethod;
        }

        function updateResourceActions(resource) {
            const canLoadDefault = defaultReadRouteIndex(resource) >= 0;
            const canCreate = createRouteIndex(resource) >= 0;
            const canViewHistory = historyRouteIndex(resource) >= 0;
            const canFilter = canLoadDefault && Array.isArray(resource && resource.query_options) && resource.query_options.length > 0;

            loadDefaultAction.hidden = !canLoadDefault;
            addObjectAction.hidden = !canCreate;
            historyViewAction.hidden = !canViewHistory;
            applyFiltersAction.hidden = !canFilter;
            resetFiltersAction.hidden = !canFilter;
        }

        function fallbackResourceKey(preferredKey = null) {
            const preferred = preferredKey ? byKey[preferredKey] : null;
            if (preferred) {
                return preferred.key;
            }

            const firstVisible = resources.find(resource => hasVisibleRoutes(resource));
            if (firstVisible) {
                return firstVisible.key;
            }

            return preferred ? preferred.key : (resources[0] ? resources[0].key : null);
        }

        function defaultFieldValue(field) {
            if (Array.isArray(field.options) && field.options.length > 0) {
                return field.options[0];
            }
            if (field.format === 'uuid') {
                return '00000000-0000-0000-0000-000000000000';
            }
            if (field.format === 'email') {
                return 'name@example.com';
            }
            if (field.format === 'date-time') {
                return new Date().toISOString();
            }
            if (field.data_type === 'boolean') {
                return false;
            }
            if (field.data_type === 'integer' || field.data_type === 'number') {
                return 0;
            }
            if (field.data_type === 'array') {
                return [];
            }
            if (field.data_type === 'object') {
                return {};
            }
            if (field.data_type === 'file') {
                return '[binary]';
            }
            if (field.name === 'change_reason') {
                return 'manual request';
            }
            return '';
        }

        function matchTemplateToConcretePath(templatePath, concretePath) {
            const templateParts = String(templatePath || '').split('/').filter(Boolean);
            const concreteParts = String(concretePath || '').split('/').filter(Boolean);
            if (templateParts.length !== concreteParts.length) {
                return {};
            }

            const values = {};
            for (let index = 0; index < templateParts.length; index += 1) {
                const templatePart = templateParts[index];
                const concretePart = concreteParts[index];
                if (templatePart.startsWith('{') && templatePart.endsWith('}')) {
                    values[templatePart.slice(1, -1)] = concretePart;
                    continue;
                }
                if (templatePart !== concretePart) {
                    return {};
                }
            }

            return values;
        }

        function getRoutePathSeeds(resource, route) {
            if (!resource || !route) {
                return {};
            }

            const matched = matchTemplateToConcretePath(route.path, resource.default_data_path || '');
            const values = {};
            (route.request.path_params || []).forEach(field => {
                values[field.name] = matched[field.name] || (field.options && field.options[0] ? field.options[0] : '');
            });
            return values;
        }

        function renderFieldTabs(resource) {
            fieldTabsNode.innerHTML = fieldViews.map(view => {
                const count = Array.isArray(resource[view.source]) ? resource[view.source].length : 0;
                const active = view.key === currentFieldView ? ' active' : '';
                return '<button class="' + active.trim() + '" data-field-view="' + escapeHtml(view.key) + '">' +
                    escapeHtml(view.label) + ' (' + count + ')' +
                '</button>';
            }).join('');

            fieldTabsNode.querySelectorAll('[data-field-view]').forEach(button => {
                button.addEventListener('click', function () {
                    currentFieldView = button.getAttribute('data-field-view') || 'response';
                    renderFieldTabs(resource);
                    renderFieldTable(resource);
                });
            });
        }

        function renderFieldTable(resource) {
            const view = fieldViews.find(candidate => candidate.key === currentFieldView) || fieldViews[0];
            const rows = Array.isArray(resource[view.source]) ? resource[view.source] : [];

            fieldTableNode.innerHTML = renderTable(rows, [
                { label: 'Field', render: row => '<code>' + escapeHtml(row.name) + '</code>' + (row.description ? '<div class="cell-sub">' + escapeHtml(row.description) + '</div>' : '') },
                { label: 'Type', render: row => '<code>' + escapeHtml(fieldTypeLabel(row)) + '</code>' },
                { label: 'Flags', render: row => fieldFlagsLabel(row) },
                { label: 'Options', render: row => Array.isArray(row.options) && row.options.length > 0 ? escapeHtml(row.options.join(', ')) : '<span class="meta-text">none</span>' },
                { label: 'Default', render: row => row.default !== null && row.default !== undefined ? '<code>' + escapeHtml(String(row.default)) + '</code>' : '<span class="meta-text">none</span>' },
            ], 'No fields documented for this view.');
        }

        function renderOverview(resource) {
            const fieldCount = Array.isArray(resource.fields) ? resource.fields.length : 0;
            const routeCount = visibleRouteEntries(resource).length;
            const defaultPath = resource.default_data_path || 'No default path';

            groupLabelNode.textContent = resource.group || 'Framework';
            crumbLabelNode.textContent = resource.label;
            document.getElementById('resourceTitle').textContent = resource.label;
            document.getElementById('resourceSummary').textContent = resource.summary;
            routeCountLabelNode.textContent = routeCount + ' action' + (routeCount === 1 ? '' : 's');

            document.getElementById('resourceBadges').innerHTML = [
                '<span class="badge">' + escapeHtml(resource.group) + '</span>',
                '<span class="badge">' + escapeHtml(resource.item_type) + '</span>',
                '<span class="badge"><code>' + escapeHtml(resource.table) + '</code></span>',
                resource.default_data_auth_required ? '<span class="badge">' + escapeHtml('default route requires auth') + '</span>' : '',
            ].filter(Boolean).join('');

            overviewCardsNode.innerHTML = [
                '<article class="overview-card"><span>Primary list</span><strong><code>' + escapeHtml(defaultPath) + '</code></strong></article>',
                '<article class="overview-card"><span>Access</span><strong>' + (resource.default_data_auth_required ? 'Protected section' : 'Public section') + '</strong></article>',
                '<article class="overview-card"><span>Field guide</span><strong>' + escapeHtml(resource.item_type) + ' | ' + fieldCount + ' documented fields</strong></article>',
                '<article class="overview-card"><span>Available actions</span><strong>' + routeCount + ' actions visible in this session</strong></article>',
            ].join('');
        }

        function setResourceWorkspaceVisible(visible) {
            const className = 'workspace-hidden';
            [
                recordsPanelNode,
                selectedRecordPanelNode,
                fieldGuidePanelNode,
                actionsPanelNode,
                filtersPanelNode,
                advancedPanelNode,
            ].forEach(function (node) {
                if (!node) {
                    return;
                }
                node.classList.toggle(className, !visible);
            });

            if (dashboardPanelNode) {
                dashboardPanelNode.hidden = visible;
            }
        }

        function renderDashboardHome() {
            currentKey = null;
            preferredKey = null;
            history.replaceState({}, '', adminBasePath);
            renderResourceList(searchInput.value);
            setResourceWorkspaceVisible(false);

            const session = currentSession();
            const groupCount = new Set(resources.map(resource => String(resource.group || 'general'))).size;
            const protectedCount = resources.filter(resource => !!resource.default_data_auth_required).length;
            const publicCount = resources.length - protectedCount;
            const visibleActionCount = resources.reduce(function (total, resource) {
                return total + visibleRouteEntries(resource, session).length;
            }, 0);

            groupLabelNode.textContent = 'Dashboard';
            crumbLabelNode.textContent = 'Overview';
            document.getElementById('resourceTitle').textContent = 'Administration Dashboard';
            document.getElementById('resourceSummary').textContent = 'Browse every section generated by the framework, switch themes, sign in, and then step into the specific area you want to manage.';
            routeCountLabelNode.textContent = visibleActionCount + ' visible actions';
            document.getElementById('resourceBadges').innerHTML = [
                '<span class="badge">Universal admin</span>',
                '<span class="badge">' + escapeHtml(summary.project && summary.project.name ? summary.project.name : 'root application') + '</span>',
                '<span class="badge theme-badge">' + escapeHtml(bodyNode.getAttribute('data-theme') || 'classic') + ' theme</span>',
            ].join('');

            overviewCardsNode.innerHTML = [
                '<article class="overview-card"><span>Sections</span><strong>' + resources.length + ' registered sections</strong></article>',
                '<article class="overview-card"><span>Groups</span><strong>' + groupCount + ' admin groups</strong></article>',
                '<article class="overview-card"><span>Protected</span><strong>' + protectedCount + ' sign-in protected sections</strong></article>',
                '<article class="overview-card"><span>Public</span><strong>' + publicCount + ' public or mixed sections</strong></article>',
            ].join('');

            if (dashboardStatsNode) {
                dashboardStatsNode.innerHTML = [
                    ['Visible actions', visibleActionCount + ' available now'],
                    ['Project', String(summary.project && summary.project.name ? summary.project.name : 'Root application')],
                    ['API version', String(summary.api_version || 'v1')],
                    ['Theme', String(bodyNode.getAttribute('data-theme') || 'classic')],
                ].map(function (entry) {
                    return '<article class="dashboard-stat"><span>' + escapeHtml(entry[0]) + '</span><strong>' + escapeHtml(entry[1]) + '</strong></article>';
                }).join('');
            }

            if (dashboardGroupsNode) {
                const lowered = searchInput.value.trim().toLowerCase();
                const grouped = new Map();
                resources.forEach(function (resource) {
                    const haystack = (resource.label + ' ' + resource.summary + ' ' + resource.key).toLowerCase();
                    if (lowered !== '' && !haystack.includes(lowered)) {
                        return;
                    }
                    const list = grouped.get(resource.group) || [];
                    list.push(resource);
                    grouped.set(resource.group, list);
                });

                dashboardGroupsNode.innerHTML = Array.from(grouped.entries()).map(function (entry) {
                    const group = entry[0];
                    const items = entry[1];
                    const cards = items.map(function (resource) {
                        const access = resourceAccessState(resource, session);
                        const lockedClass = access.state === 'locked' ? ' locked' : '';
                        const canCreate = createRouteIndex(resource) >= 0 && access.state === 'available';
                        const canHistory = historyRouteIndex(resource) >= 0 && access.state === 'available';
                        return '<article class="dashboard-card' + lockedClass + '">' +
                            '<div><h5>' + escapeHtml(resource.label) + '</h5><p>' + escapeHtml(resource.summary || 'Section generated by Nite.') + '</p></div>' +
                            '<div class="dashboard-card-meta"><span>' + escapeHtml(resource.item_type) + '</span><span>' + escapeHtml(access.label) + '</span></div>' +
                            '<div class="dashboard-card-actions">' +
                                '<button class="mini-btn" data-dashboard-open="' + escapeHtml(resource.key) + '" type="button">Open section</button>' +
                                '<button class="mini-btn" data-dashboard-create="' + escapeHtml(resource.key) + '" type="button"' + (canCreate ? '' : ' disabled') + '>New</button>' +
                                '<button class="mini-btn" data-dashboard-history="' + escapeHtml(resource.key) + '" type="button"' + (canHistory ? '' : ' disabled') + '>History</button>' +
                            '</div>' +
                        '</article>';
                    }).join('');

                    return '<section class="dashboard-group"><h4>' + escapeHtml(group) + '</h4><div class="dashboard-group-grid">' + cards + '</div></section>';
                }).join('') || '<div class="empty">No sections match this filter.</div>';

                dashboardGroupsNode.querySelectorAll('[data-dashboard-open]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        selectResource(button.getAttribute('data-dashboard-open') || '');
                    });
                });
                dashboardGroupsNode.querySelectorAll('[data-dashboard-create]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        const key = button.getAttribute('data-dashboard-create') || '';
                        if (button.hasAttribute('disabled')) {
                            return;
                        }
                        selectResource(key);
                        addObjectAction.click();
                    });
                });
                dashboardGroupsNode.querySelectorAll('[data-dashboard-history]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        const key = button.getAttribute('data-dashboard-history') || '';
                        if (button.hasAttribute('disabled')) {
                            return;
                        }
                        selectResource(key);
                        historyViewAction.click();
                    });
                });
            }
        }

        function routeLabel(route) {
            return String(route.method || 'GET') + ' ' + String(route.path || '');
        }

        function populateRouteSelect(resource) {
            const options = [
                '<option value="' + customRouteValue + '">Custom request</option>',
            ];

            visibleRouteEntries(resource).forEach(entry => {
                options.push('<option value="' + entry.index + '">' + escapeHtml(routeLabel(entry.route)) + '</option>');
            });

            routeSelect.innerHTML = options.join('');
        }

        function controlHtml(field, scope, value) {
            const safeValue = value === null || value === undefined ? '' : String(value);
            const attr = 'data-param-scope="' + escapeHtml(scope) + '" data-param-name="' + escapeHtml(field.name) + '"';

            if (Array.isArray(field.options) && field.options.length > 0) {
                const options = ['<option value=""></option>'].concat(field.options.map(option => {
                    const selected = String(option) === safeValue ? ' selected' : '';
                    return '<option value="' + escapeHtml(option) + '"' + selected + '>' + escapeHtml(option) + '</option>';
                }));
                return '<select class="select-input" ' + attr + '>' + options.join('') + '</select>';
            }

            if (field.data_type === 'boolean') {
                return '<select class="select-input" ' + attr + '>' +
                    '<option value=""></option>' +
                    '<option value="true"' + (safeValue === 'true' ? ' selected' : '') + '>true</option>' +
                    '<option value="false"' + (safeValue === 'false' ? ' selected' : '') + '>false</option>' +
                '</select>';
            }

            const type = field.data_type === 'integer' || field.data_type === 'number' ? 'number' : 'text';
            return '<input class="text-input" type="' + type + '" ' + attr + ' value="' + escapeHtml(safeValue) + '">';
        }

        function renderParamFields(node, fields, scope, values) {
            if (!Array.isArray(fields) || fields.length === 0) {
                node.innerHTML = '<div class="empty">No ' + escapeHtml(scope) + ' parameters for this route.</div>';
                return;
            }

            node.innerHTML = fields.map(field => {
                const value = values[field.name] !== undefined ? values[field.name] : '';
                return '<label class="param-card">' +
                    '<span class="param-head">' +
                        '<code>' + escapeHtml(field.name) + '</code>' +
                        '<small>' + escapeHtml(field.description || '') + '</small>' +
                    '</span>' +
                    controlHtml(field, scope, value) +
                '</label>';
            }).join('');

            node.querySelectorAll('[data-param-scope="' + scope + '"]').forEach(input => {
                input.addEventListener('input', updateEndpointFromRoute);
                input.addEventListener('change', updateEndpointFromRoute);
            });
        }

        function readScopedValues(scope) {
            const values = {};
            document.querySelectorAll('[data-param-scope="' + scope + '"]').forEach(input => {
                const key = input.getAttribute('data-param-name');
                if (!key) {
                    return;
                }
                values[key] = input.value;
            });
            return values;
        }

        function updateEndpointFromRoute() {
            if (!currentRoute) {
                return;
            }

            const pathValues = readScopedValues('path');
            const queryValues = readScopedValues('query');
            let resolved = currentRoute.path;

            Object.keys(pathValues).forEach(key => {
                const value = String(pathValues[key] || '').trim();
                if (value !== '') {
                    resolved = resolved.replace('{' + key + '}', encodeURIComponent(value));
                }
            });

            const queryEntries = [];
            Object.keys(queryValues).forEach(key => {
                const value = String(queryValues[key] || '').trim();
                if (value !== '') {
                    queryEntries.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
                }
            });

            endpointInput.value = resolved + (queryEntries.length > 0 ? '?' + queryEntries.join('&') : '');
        }

        function renderRequestBodyFields(fields) {
            requestBodyFieldsNode.innerHTML = renderTable(fields || [], [
                { label: 'Field', render: row => '<code>' + escapeHtml(row.name) + '</code>' },
                { label: 'Type', render: row => '<code>' + escapeHtml(fieldTypeLabel(row)) + '</code>' },
                { label: 'Required', render: row => row.required_on_create ? 'yes' : 'no' },
                { label: 'Options', render: row => Array.isArray(row.options) && row.options.length > 0 ? escapeHtml(row.options.join(', ')) : '<span class="meta-text">none</span>' },
            ], 'No request body fields for this route.');
        }

        function buildTemplate(fields) {
            const template = {};
            (fields || []).forEach(field => {
                template[field.name] = defaultFieldValue(field);
            });
            return template;
        }

        function fillBodyFromFields(fields) {
            requestBodyNode.value = JSON.stringify(buildTemplate(fields || []), null, 2);
        }

        function setConsoleStatus(text, tone) {
            statusNode.className = statusClass(tone);
            statusNode.textContent = text;
        }

        function setCustomRequest(method, path, bodyText = '') {
            currentRoute = null;
            routeSelect.value = customRouteValue;
            if (!Array.from(methodSelect.options).some(option => option.value === method)) {
                methodSelect.innerHTML = '<option value="' + escapeHtml(method) + '">' + escapeHtml(method) + '</option>' + methodSelect.innerHTML;
            }
            methodSelect.value = method;
            endpointInput.value = path;
            routeHintNode.textContent = 'Custom request mode. Enter any route path directly.';
            requestSummaryNode.textContent = method + ' ' + path;
            pathParamsNode.innerHTML = '<div class="empty">No automatic path parameters in custom mode.</div>';
            queryParamsNode.innerHTML = '<div class="empty">No automatic query helpers in custom mode.</div>';
            renderRequestBodyFields([]);
            requestBodyNode.value = bodyText;
        }

        function applyRoute(index) {
            const resource = currentResource();
            if (
                !resource
                || !Array.isArray(resource.routes)
                || resource.routes[index] === undefined
                || !routeVisibleToSession(resource.routes[index])
            ) {
                setCustomRequest(methodSelect.value || 'GET', endpointInput.value.trim() || '/api/v1/');
                return;
            }

            currentRouteIndex = index;
            currentRoute = resource.routes[index];
            routeSelect.value = String(index);
            methodSelect.value = currentRoute.method;
            requestSummaryNode.textContent = currentRoute.summary || routeLabel(currentRoute);
            routeHintNode.textContent = routeHintText(currentRoute);

            renderParamFields(pathParamsNode, currentRoute.request.path_params || [], 'path', getRoutePathSeeds(resource, currentRoute));
            renderParamFields(queryParamsNode, currentRoute.request.query || [], 'query', {});
            renderRequestBodyFields(currentRoute.request.body || []);
            updateEndpointFromRoute();

            if ((currentRoute.request.body || []).length > 0 && requestBodyNode.value.trim() === '') {
                fillBodyFromFields(currentRoute.request.body || []);
            }

            setConsoleStatus('Ready', 'idle');
            responseMetaNode.textContent = 'Console prepared for ' + routeLabel(currentRoute) + '.';
        }

        function useDefaultRoute(loadImmediately) {
            const resource = currentResource();
            if (!resource) {
                return;
            }

            const routeIndex = defaultRouteIndex(resource);
            const exactDefault = routeIndex >= 0 && resource.routes[routeIndex] && resource.routes[routeIndex].path === resource.default_data_path;
            const needsConcreteDefault = !!resource.default_data_path && !exactDefault;

            if (needsConcreteDefault) {
                setCustomRequest('GET', resource.default_data_path, '');
            } else if (routeIndex >= 0) {
                applyRoute(routeIndex);
            } else {
                setCustomRequest('GET', resource.default_data_path || '/api/v1/', '');
            }

            if (loadImmediately) {
                const method = String(currentRoute && currentRoute.method ? currentRoute.method : methodSelect.value || 'GET').toUpperCase();
                if (['GET', 'HEAD', 'OPTIONS'].includes(method)) {
                    sendRequest();
                } else {
                    setConsoleStatus('Prepared', 'idle');
                    responseMetaNode.textContent = 'Prepared ' + method + ' request. Send it manually to avoid unintended writes.';
                }
            }
        }

        function renderRoutes(resource) {
            const entries = visibleRouteEntries(resource);
            routeTableNode.innerHTML = renderTable(entries, [
                { label: 'Method', render: row => '<span class="' + methodClass(row.route.method) + '">' + escapeHtml(row.route.method) + '</span>' },
                { label: 'Path', render: row => '<code>' + escapeHtml(row.route.path) + '</code><div class="cell-sub">' + escapeHtml(row.route.summary || '') + '</div>' },
                { label: 'Request', render: row => '<code>' + escapeHtml(row.route.request.content_type || 'none') + '</code><div class="cell-sub">' + escapeHtml(String((row.route.request.body || []).length)) + ' body fields</div>' },
                { label: 'Returns', render: row => '<code>' + escapeHtml(row.route.response.return_type || 'json') + '</code><div class="cell-sub">' + escapeHtml(String(row.route.response.success_status || 200)) + '</div>' },
                { label: 'Access', render: row => statePill(row.route.auth_required) },
                { label: 'Use', render: row => '<button class="mini-btn" data-route-index="' + row.index + '" type="button">Use</button>' },
            ], 'No routes are visible for this session on this resource.');

            routeTableNode.querySelectorAll('[data-route-index]').forEach(button => {
                button.addEventListener('click', function () {
                    const index = parseInt(button.getAttribute('data-route-index') || '0', 10);
                    applyRoute(index);
                });
            });
        }

        function selectResource(resourceKey) {
            preferredKey = resourceKey || preferredKey;
            const resolvedKey = fallbackResourceKey(resourceKey);
            const resource = resolvedKey ? (byKey[resolvedKey] || resources[0] || null) : (resources[0] || null);
            if (!resource) {
                return;
            }

            currentKey = resource.key;
            history.replaceState({}, '', adminSurfaceUrl(resource));
            renderResourceList(searchInput.value);
            setResourceWorkspaceVisible(true);
            renderOverview(resource);
            renderFieldTabs(resource);
            renderFieldTable(resource);
            renderAdminFilters(resource);
            populateMethodSelect(resource, methodSelect.value || 'GET');
            populateRouteSelect(resource);
            renderRoutes(resource);
            updateResourceActions(resource);
            currentSelectedRecord = null;
            currentSelectedRecordKey = '';
            currentSelectedRecordField = '';
            if (visibleRouteEntries(resource).length > 0) {
                currentResponsePayload = null;
                currentResponseFocus = null;
                outputNode.textContent = '{}';
                useDefaultRoute(false);
                responseStructuredNode.innerHTML = '<div class="empty">Run a request to render live data here.</div>';
            } else {
                currentRoute = null;
                routeSelect.value = customRouteValue;
                endpointInput.value = resource.default_data_path || '';
                currentResponsePayload = {
                    message: resource.default_data_auth_required
                        ? 'Sign in to unlock live actions for this section.'
                        : 'No live routes are currently visible for this section.',
                    section: resource.label,
                };
                currentResponseFocus = responseFocus(currentResponsePayload);
                outputNode.textContent = JSON.stringify(currentResponsePayload, null, 2);
                setConsoleStatus(resource.default_data_auth_required ? 'Sign in required' : 'Unavailable', resource.default_data_auth_required ? 'pending' : 'idle');
                responseMetaNode.textContent = resource.default_data_auth_required
                    ? 'Sign in to unlock live actions for this section.'
                    : 'No live routes are currently visible for this section.';
            }
            responseActionsNode.hidden = true;
            responseActionsNode.innerHTML = '';
            renderSelectedRecord(null);
            renderResponse();
        }

        function refreshRouteVisibility() {
            updateAuthPanel();
            if (!preferredKey && !currentKey) {
                renderDashboardHome();
                return;
            }

            const resolvedKey = fallbackResourceKey(preferredKey || currentKey);
            if (!resolvedKey) {
                renderDashboardHome();
                return;
            }

            if (resolvedKey !== currentKey) {
                selectResource(resolvedKey);
                return;
            }

            const resource = currentResource();
            if (!resource) {
                renderDashboardHome();
                return;
            }

            renderResourceList(searchInput.value);
            renderOverview(resource);
            renderAdminFilters(resource);
            populateMethodSelect(resource, currentRoute ? currentRoute.method : (methodSelect.value || 'GET'));
            populateRouteSelect(resource);
            renderRoutes(resource);
            updateResourceActions(resource);

            const currentIndex = currentRoute && Array.isArray(resource.routes)
                ? resource.routes.findIndex(route => route === currentRoute || (route.method === currentRoute.method && route.path === currentRoute.path))
                : -1;

            if (currentIndex >= 0 && routeVisibleToSession(resource.routes[currentIndex])) {
                applyRoute(currentIndex);
            } else {
                useDefaultRoute(false);
            }

            renderResponse();
        }

        function tokenFromResponse(payloadValue) {
            if (!payloadValue || typeof payloadValue !== 'object') {
                return null;
            }

            if (typeof payloadValue.token === 'string' && payloadValue.token !== '') {
                return payloadValue.token;
            }
            if (typeof payloadValue.access_token === 'string' && payloadValue.access_token !== '') {
                return payloadValue.access_token;
            }
            if (payloadValue.data && typeof payloadValue.data === 'object') {
                if (typeof payloadValue.data.token === 'string' && payloadValue.data.token !== '') {
                    return payloadValue.data.token;
                }
                if (typeof payloadValue.data.access_token === 'string' && payloadValue.data.access_token !== '') {
                    return payloadValue.data.access_token;
                }
            }

            return null;
        }

        function normalizedRoutePath(path) {
            const value = String(path || '').trim();
            if (value === '') {
                return '';
            }

            try {
                return new URL(value, window.location.origin).pathname;
            } catch {
                return value.split('?')[0];
            }
        }

        function isAuthenticationRoute(method, path) {
            return String(method || 'GET').toUpperCase() === 'POST'
                && normalizedRoutePath(path).startsWith('/api/v1/auth/');
        }

        function sessionProfileMatchesToken(profile, token) {
            if (!profile || typeof profile !== 'object') {
                return false;
            }

            const derived = sessionFromToken(token);
            if (!derived.authenticated) {
                return false;
            }

            const profileSub = String(profile.sub || '').trim();
            const derivedSub = String(derived.sub || '').trim();
            if (profileSub !== '' && derivedSub !== '') {
                return profileSub === derivedSub;
            }

            const profileEmail = String(profile.email || '').trim().toLowerCase();
            const derivedEmail = String(derived.email || '').trim().toLowerCase();
            if (profileEmail !== '' && derivedEmail !== '') {
                return profileEmail === derivedEmail;
            }

            return false;
        }

        function normalizeUrl(path) {
            if (/^https?:\/\//i.test(path)) {
                return path;
            }
            if (path.startsWith('/')) {
                return window.location.origin + path;
            }
            return window.location.origin + '/' + path.replace(/^\/+/, '');
        }

        function shellEscape(value) {
            return "'" + String(value).replaceAll("'", "'\"'\"'") + "'";
        }

        function buildCurlCommand() {
            const method = methodSelect.value || 'GET';
            const path = endpointInput.value.trim();
            if (path === '') {
                return '';
            }

            const parts = ['curl', '-X', method, shellEscape(normalizeUrl(path)), '-H', shellEscape('Accept: application/json')];
            const token = tokenInput.value.trim();
            if (token !== '') {
                parts.push('-H', shellEscape('Authorization: ' + (token.startsWith('Bearer ') ? token : 'Bearer ' + token)));
            }

            const bodyText = requestBodyNode.value.trim();
            if (bodyText !== '' && method !== 'GET') {
                parts.push('-H', shellEscape('Content-Type: application/json'));
                parts.push('--data', shellEscape(bodyText));
            }

            return parts.join(' ');
        }

        async function sendRequest() {
            const method = methodSelect.value || 'GET';
            const path = endpointInput.value.trim();
            if (path === '') {
                setConsoleStatus('Missing path', 'error');
                responseMetaNode.textContent = 'Enter a concrete endpoint path before sending.';
                return;
            }

            const headers = { 'Accept': 'application/json' };
            const token = currentToken();
            if (token !== '') {
                headers['Authorization'] = token.startsWith('Bearer ') ? token : 'Bearer ' + token;
                persistSessionToken();
            }

            const bodyText = requestBodyNode.value.trim();
            const options = { method, headers };
            if (bodyText !== '' && method !== 'GET') {
                headers['Content-Type'] = 'application/json';
                options.body = bodyText;
            }

            setConsoleStatus('Loading', 'pending');
            responseMetaNode.textContent = 'Sending ' + method + ' ' + path;
            const startedAt = performance.now();
            try {
                const response = await fetch(path, options);
                const text = await response.text();
                const contentType = response.headers.get('content-type') || 'unknown';
                const duration = Math.round(performance.now() - startedAt);
                let parsed;
                try {
                    parsed = JSON.parse(text);
                } catch {
                    parsed = text;
                }

                const tone = response.ok ? 'success' : 'error';
                setConsoleStatus(String(response.status) + ' ' + response.statusText, tone);
                responseMetaNode.textContent = method + ' ' + path + ' | ' + contentType + ' | ' + duration + 'ms';
                currentResponsePayload = parsed;
                currentResponseFocus = responseFocus(parsed);
                outputNode.textContent = typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 2);
                renderResponse();

                const discoveredToken = tokenFromResponse(parsed);
                if (discoveredToken && isAuthenticationRoute(method, path)) {
                    tokenInput.value = discoveredToken;
                    persistSessionToken();
                    responseMetaNode.textContent += ' | bearer token saved';
                }
                persistSessionFromPayload(parsed, discoveredToken || token, method, path);
                refreshRouteVisibility();
                updateAuthPanel();
            } catch (error) {
                setConsoleStatus('Request failed', 'error');
                responseMetaNode.textContent = 'Network or runtime error while requesting ' + path;
                currentResponsePayload = { error: String(error && error.message ? error.message : error) };
                currentResponseFocus = responseFocus(currentResponsePayload);
                outputNode.textContent = String(error && error.message ? error.message : error);
                renderResponse();
            }
        }

        routeSelect.addEventListener('change', function () {
            const value = routeSelect.value;
            if (value === customRouteValue) {
                setCustomRequest(methodSelect.value || 'GET', endpointInput.value.trim() || '/api/v1/');
                return;
            }
            applyRoute(parseInt(value || '0', 10));
        });

        methodSelect.addEventListener('change', function () {
            if (currentRoute && methodSelect.value !== currentRoute.method) {
                routeSelect.value = customRouteValue;
                currentRoute = null;
                routeHintNode.textContent = 'Custom request mode. Route docs remain visible above.';
            }
        });

        tokenInput.addEventListener('input', function () {
            persistSessionToken();
            refreshRouteVisibility();
            updateAuthPanel();
        });

        sendRequestAction.addEventListener('click', sendRequest);
        clearTokenAction.addEventListener('click', () => {
            tokenInput.value = '';
            persistSessionToken();
            refreshRouteVisibility();
            updateAuthPanel();
        });
        signInAction.addEventListener('click', function () {
            performLogin({
                email: loginEmailNode ? loginEmailNode.value : '',
                password: loginPasswordNode ? loginPasswordNode.value : '',
            });
        });
        signOutAction.addEventListener('click', function () {
            tokenInput.value = '';
            if (loginPasswordNode) {
                loginPasswordNode.value = '';
            }
            persistSessionToken();
            refreshRouteVisibility();
            updateAuthPanel();
            setConsoleStatus('Signed out', 'idle');
        });
        loadProfileAction.addEventListener('click', function () {
            const route = findRouteDoc('GET', '/api/v1/me');
            useRouteDoc(route, '', {}, {}, true);
        });
        if (loginPasswordNode) {
            loginPasswordNode.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    signInAction.click();
                }
            });
        }
        if (themeSelect) {
            themeSelect.addEventListener('change', function () {
                applyTheme(themeSelect.value);
                if (currentKey) {
                    renderOverview(currentResource());
                    return;
                }
                renderDashboardHome();
            });
        }
        if (dashboardAction) {
            dashboardAction.addEventListener('click', function () {
                renderDashboardHome();
            });
        }
        if (dashboardCrumb) {
            dashboardCrumb.addEventListener('click', function () {
                renderDashboardHome();
            });
        }
        openEndpointAction.addEventListener('click', function () {
            const path = endpointInput.value.trim();
            if (path !== '') {
                window.open(path, '_blank', 'noopener');
            }
        });
        copyCurlAction.addEventListener('click', async function () {
            const command = buildCurlCommand();
            if (command === '') {
                setConsoleStatus('Nothing to copy', 'error');
                return;
            }
            try {
                await navigator.clipboard.writeText(command);
                setConsoleStatus('cURL copied', 'success');
            } catch {
                setConsoleStatus('Clipboard blocked', 'error');
            }
        });
        useDefaultAction.addEventListener('click', function () { useDefaultRoute(false); });
        loadDefaultAction.addEventListener('click', function () { useDefaultRoute(true); });
        addObjectAction.addEventListener('click', function () {
            const resource = currentResource();
            if (!resource) {
                return;
            }

            const routeIndex = createRouteIndex(resource);
            if (routeIndex < 0) {
                setConsoleStatus('No add route', 'error');
                responseMetaNode.textContent = 'This section has no documented create route.';
                return;
            }

            applyRoute(routeIndex);
            fillBodyFromFields(resource.create_fields || []);
        });
        historyViewAction.addEventListener('click', function () {
            const resource = currentResource();
            if (!resource) {
                return;
            }

            const routeIndex = historyRouteIndex(resource);
            if (routeIndex < 0) {
                setConsoleStatus('No history route', 'error');
                responseMetaNode.textContent = 'This section has no documented history route.';
                return;
            }

            applyRoute(routeIndex);
            sendRequest();
        });
        resourceMetaAction.addEventListener('click', function () {
            fieldTableNode.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        routesMetaAction.addEventListener('click', function () {
            routeTableNode.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        applyFiltersAction.addEventListener('click', function () {
            applyAdminFilters(true);
        });
        resetFiltersAction.addEventListener('click', function () {
            resetAdminFilters();
            applyAdminFilters(true);
        });
        seedPathParamsAction.addEventListener('click', function () {
            const resource = currentResource();
            if (!resource || !currentRoute) {
                return;
            }
            renderParamFields(pathParamsNode, currentRoute.request.path_params || [], 'path', getRoutePathSeeds(resource, currentRoute));
            updateEndpointFromRoute();
        });
        clearQueryAction.addEventListener('click', function () {
            document.querySelectorAll('[data-param-scope="query"]').forEach(input => {
                input.value = '';
            });
            updateEndpointFromRoute();
        });
        fillRouteBodyAction.addEventListener('click', function () {
            fillBodyFromFields(currentRoute ? (currentRoute.request.body || []) : []);
        });
        fillCreateBodyAction.addEventListener('click', function () {
            const resource = currentResource();
            if (resource) {
                fillBodyFromFields(resource.create_fields || []);
            }
        });
        fillUpdateBodyAction.addEventListener('click', function () {
            const resource = currentResource();
            if (resource) {
                fillBodyFromFields(resource.update_fields || []);
            }
        });
        loginAdminAction.addEventListener('click', function () {
            if (loginEmailNode) {
                loginEmailNode.value = authPresets.admin.email;
            }
            if (loginPasswordNode) {
                loginPasswordNode.value = authPresets.admin.password;
            }
            performLogin(authPresets.admin);
        });
        loginEditorAction.addEventListener('click', function () {
            if (loginEmailNode) {
                loginEmailNode.value = authPresets.editor.email;
            }
            if (loginPasswordNode) {
                loginPasswordNode.value = authPresets.editor.password;
            }
            performLogin(authPresets.editor);
        });
        loginMemberAction.addEventListener('click', function () {
            if (loginEmailNode) {
                loginEmailNode.value = authPresets.member.email;
            }
            if (loginPasswordNode) {
                loginPasswordNode.value = authPresets.member.password;
            }
            performLogin(authPresets.member);
        });
        whoAmIAction.addEventListener('click', function () {
            const route = findRouteDoc('GET', '/api/v1/me');
            useRouteDoc(route, '', {}, {}, true);
        });
        registerAction.addEventListener('click', function () {
            const route = findRouteDoc('POST', '/api/v1/auth/register');
            useRouteDoc(route, JSON.stringify({
                email: 'new.user@nite.local',
                name: 'New User',
                password: 'Passw0rd!2026',
                profile: {},
            }, null, 2));
        });
        clearBodyAction.addEventListener('click', function () {
            requestBodyNode.value = '';
        });
        searchInput.addEventListener('input', function () {
            if (currentKey) {
                renderResourceList(searchInput.value);
                return;
            }
            renderDashboardHome();
        });
        const handleResponseAction = function (event) {
            const selectButton = event.target.closest('[data-select-record]');
            if (selectButton) {
                const targetKey = selectButton.getAttribute('data-select-record') || '';
                const targetField = selectButton.getAttribute('data-select-record-field') || '';
                const focus = currentResponseFocus ? currentResponseFocus.value : null;
                const rows = Array.isArray(focus)
                    ? focus
                    : (focus && typeof focus === 'object' ? [focus] : []);
                const targetRow = rows.find(row => row && typeof row === 'object' && recordKey(row) === targetKey) || currentSelectedRecord;
                renderSelectedRecord(targetRow || null, targetField);
                if (targetRow && selectButton.getAttribute('data-select-record-scroll') === 'true') {
                    selectedRecordFieldsNode.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                return;
            }

            const button = event.target.closest('[data-response-action]');
            if (!button) {
                return;
            }

            const actionIndex = parseInt(button.getAttribute('data-response-action') || '-1', 10);
            if (actionIndex < 0) {
                return;
            }

            const mode = button.getAttribute('data-response-action-mode') || 'prepare';
            const focus = currentResponseFocus ? currentResponseFocus.value : null;
            let targetRow = null;

            if (button.getAttribute('data-response-row') === 'first' && Array.isArray(focus)) {
                targetRow = focus.find(row => row && typeof row === 'object' && !Array.isArray(row)) || null;
            } else if (button.getAttribute('data-response-row') === 'single' && focus && typeof focus === 'object' && !Array.isArray(focus)) {
                targetRow = focus;
            } else if (button.getAttribute('data-response-row') === 'selected' && currentSelectedRecord) {
                targetRow = currentSelectedRecord;
            } else if (Array.isArray(focus)) {
                const targetId = button.getAttribute('data-response-row-id') || '';
                targetRow = focus.find(row => {
                    if (!row || typeof row !== 'object') {
                        return false;
                    }
                    return targetId !== '' && recordKey(row) === targetId;
                }) || null;
            }

            if (!targetRow) {
                setConsoleStatus('No row context', 'error');
                return;
            }

            useRouteForRow(actionIndex, targetRow, mode === 'load');
        };
        responseActionsNode.addEventListener('click', handleResponseAction);
        responseStructuredNode.addEventListener('click', handleResponseAction);
        selectedRecordActionsNode.addEventListener('click', handleResponseAction);
        selectedRecordFieldsNode.addEventListener('click', handleResponseAction);

        renderResponseViewTabs();
        updateAuthPanel();
        if (selectedKey && byKey[selectedKey]) {
            selectResource(selectedKey);
        } else {
            renderDashboardHome();
        }
    </script>
</body>
</html>
HTML;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public static function routeDocsMap(): array
    {
        static $docs = null;
        if ($docs !== null) {
            return $docs;
        }

        $docs = [];
        foreach (self::resources() as $resource) {
            foreach ($resource['routes'] as $route) {
                $docs[$route['method'] . ' ' . $route['path']] = $route;
            }
        }

        foreach (self::customRoutes() as $route) {
            $docs[$route['method'] . ' ' . $route['path']] = $route;
        }

        foreach ($docs as $key => $route) {
            $docs[$key] = self::decorateRouteDoc($route);
        }

        return $docs;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function customRoutes(): array
    {
        return [
            self::endpointDoc('GET', '/api/v1', 'Default JSON API root with starter links for discovery clients.', [
                'return_type' => '{ health: string, framework: string, routes: string, resources: string }',
            ]),
            self::endpointDoc('GET', '/api/v1/health', 'Framework health probe.', [
                'return_type' => '{ status: string, time: string }',
            ]),
            self::endpointDoc('GET', '/api/v1/meta/routes', 'Full route list with request and return metadata.', [
                'return_type' => 'RouteDoc[]',
            ]),
            self::endpointDoc('GET', '/api/v1/meta/resources', 'Resource schema catalog for API discovery.', [
                'return_type' => 'ResourceDoc[]',
            ]),
            self::endpointDoc('GET', '/api/v1/meta/resources/{resource}', 'Schema details for one resource.', [
                'path_params' => [self::fieldDoc('resource', 'string', 'Catalog resource key.', true)],
                'return_type' => 'ResourceDoc',
            ]),
            self::endpointDoc('POST', '/api/v1/auth/register', 'Create a member account and receive a bearer token.', [
                'body' => [
                    self::fieldDoc('email', 'string:email', 'Account email address.', true),
                    self::fieldDoc('name', 'string', 'Display name.', true),
                    self::fieldDoc('password', 'string', 'Plain text password, minimum 8 characters.', true),
                    self::fieldDoc('profile', 'object', 'Optional profile payload.'),
                ],
                'status' => 201,
                'return_type' => 'AuthSession',
            ]),
            self::endpointDoc('POST', '/api/v1/auth/login', 'Validate credentials and return a bearer token.', [
                'body' => [
                    self::fieldDoc('email', 'string:email', 'Account email address.', true),
                    self::fieldDoc('password', 'string', 'Plain text password.', true),
                ],
                'return_type' => 'AuthSession',
            ]),
            self::endpointDoc('GET', '/api/v1/framework', 'Framework overview, starter endpoints, and module counts.', [
                'return_type' => 'FrameworkOverview',
            ]),
            self::endpointDoc('GET', '/api/v1/framework/modules', 'Module family catalog.', [
                'return_type' => 'ModuleMap',
            ]),
            self::endpointDoc('GET', '/api/v1/framework/modules/{module}', 'One module family definition.', [
                'path_params' => [self::fieldDoc('module', 'string', 'Module key.', true, array_keys(NiteModuleCatalog::modules()))],
                'return_type' => 'Module',
            ]),
            self::endpointDoc('GET', '/api/v1/search/global', 'Cross-resource full text lookup.', [
                'query' => [self::fieldDoc('q', 'string', 'Search term.', true)],
                'return_type' => '{ pages: Page[], news: NewsPost[], resources: Resource[], courses: Course[], sample_records: SampleRecord[], examples: ExampleEntity[] }',
            ]),
            self::endpointDoc('GET', '/api/v1/site/bootstrap', 'Public bootstrap payload for site shells.', [
                'return_type' => 'SiteBootstrap',
            ]),
            self::endpointDoc('GET', '/api/v1/gallery', 'Published albums and items bundled for a gallery page.', [
                'query' => [self::fieldDoc('album_id', 'string:uuid', 'Restrict items to one album.')],
                'return_type' => '{ albums: GalleryAlbum[], items: GalleryItem[] }',
            ]),
            self::endpointDoc('GET', '/api/v1/me', 'Authenticated user profile plus permissions.', [
                'auth_required' => true,
                'return_type' => 'User',
            ]),
            self::endpointDoc('GET', '/api/v1/dashboard/me', 'Authenticated dashboard summary for the current user.', [
                'auth_required' => true,
                'permissions' => ['module.member_dashboard.access'],
                'return_type' => 'DashboardSummary',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/dashboard', 'Administrative dashboard summary.', [
                'auth_required' => true,
                'permissions' => ['module.admin_dashboard.access'],
                'return_type' => 'AdminDashboardSummary',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/roles', 'Role catalog.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'return_type' => 'Role[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/permissions', 'Permission catalog.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'return_type' => 'Permission[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/matrix', 'Role-to-permission matrix.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'return_type' => 'RolePermissionMatrix',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/groups', 'RBAC group catalog.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'query' => [
                    self::fieldDoc('q', 'string', 'Search code, name, or description.'),
                    self::fieldDoc('is_active', 'boolean', 'Filter active or inactive groups.'),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                    self::fieldDoc('offset', 'integer', 'Rows to skip.'),
                ],
                'return_type' => 'RbacGroup[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/rbac/groups', 'Create an RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'body' => [
                    self::fieldDoc('name', 'string', 'Human-readable group name.', true),
                    self::fieldDoc('code', 'string', 'Stable group code. Generated from name when omitted.'),
                    self::fieldDoc('description', 'string', 'Administrative notes for this group.'),
                    self::fieldDoc('is_active', 'boolean', 'Inactive groups do not affect permissions.'),
                ],
                'return_type' => 'RbacGroup',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/groups/{id}', 'RBAC group detail.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'return_type' => 'RbacGroup',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/rbac/groups/{id}', 'Update an RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'body' => [
                    self::fieldDoc('name', 'string', 'Human-readable group name.'),
                    self::fieldDoc('code', 'string', 'Stable group code.'),
                    self::fieldDoc('description', 'string', 'Administrative notes for this group.'),
                    self::fieldDoc('is_active', 'boolean', 'Inactive groups do not affect permissions.'),
                ],
                'return_type' => 'RbacGroup',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/rbac/groups/{id}', 'Delete an RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'return_type' => '{ deleted: true }',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/groups/{id}/members', 'Members assigned to one RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'return_type' => 'RbacGroupMembers',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/rbac/groups/{id}/members', 'Replace members assigned to one RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'body' => [
                    self::fieldDoc('user_ids', 'array', 'User identifiers that should belong to this group.', true),
                ],
                'return_type' => 'RbacGroupMembers',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/groups/{id}/permissions', 'Permission states for one RBAC group.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'return_type' => 'RbacGroupPermissions',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/rbac/groups/{id}/permissions', 'Replace one group permission state map.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Group identifier.', true)],
                'body' => [
                    self::fieldDoc('states', 'object', 'Permission code to inherit, allow, or deny state map.', true),
                ],
                'return_type' => 'RbacGroupPermissions',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/rbac/users/{id}/overrides', 'Permission overrides for one user.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'User identifier.', true)],
                'return_type' => 'UserPermissionOverrides',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/rbac/roles/{role}/permissions', 'Replace the role permission state map.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('role', 'string', 'Role code.', true, ['member', 'trainer', 'editor', 'support', 'admin'])],
                'body' => [
                    self::fieldDoc('states', 'object', 'Permission code to allow or deny state map.', true),
                ],
                'return_type' => 'RolePermissionMatrix',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/rbac/users/{id}/overrides', 'Replace one user override state map.', [
                'auth_required' => true,
                'permissions' => ['admin.rbac.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'User identifier.', true)],
                'body' => [
                    self::fieldDoc('states', 'object', 'Permission code to allow or deny state map.', true),
                ],
                'return_type' => 'UserPermissionOverrides',
            ]),
        ];
    }

    /**
     * @param array<string, mixed> $route
     * @return array<string, mixed>
     */
    private static function decorateRouteDoc(array $route): array
    {
        $resource = self::resource((string)($route['resource_key'] ?? ''));
        $request = is_array($route['request'] ?? null) ? $route['request'] : [];
        $permissions = array_values(array_filter(
            is_array($route['permissions'] ?? null) ? $route['permissions'] : [],
            static fn (mixed $value): bool => is_string($value) && trim($value) !== ''
        ));

        foreach (['path_params', 'query', 'body'] as $section) {
            $request[$section] = self::decorateRouteFields(
                is_array($request[$section] ?? null) ? $request[$section] : [],
                $resource,
                $route
            );
        }

        $route['permissions'] = $permissions;
        $route['permission_default_roles'] = self::permissionDefaultRoles($permissions);
        $route['request'] = $request;
        return $route;
    }

    /**
     * @param array<int, string> $permissions
     * @return array<int, string>
     */
    private static function permissionDefaultRoles(array $permissions): array
    {
        $catalog = PermissionCatalog::indexed();
        $roles = [];

        foreach ($permissions as $permissionCode) {
            $definition = $catalog[$permissionCode] ?? null;
            if (!is_array($definition)) {
                continue;
            }

            foreach (is_array($definition['default_roles'] ?? null) ? $definition['default_roles'] : [] as $role) {
                $normalized = trim((string)$role);
                if ($normalized === '' || in_array($normalized, $roles, true)) {
                    continue;
                }
                $roles[] = $normalized;
            }
        }

        return $roles;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed>|null $resource
     * @param array<string, mixed> $route
     * @return array<int, array<string, mixed>>
     */
    private static function decorateRouteFields(array $fields, ?array $resource, array $route): array
    {
        foreach ($fields as &$field) {
            if (!is_array($field)) {
                continue;
            }

            $resourceField = $resource !== null
                ? self::resourceField($resource, (string)($field['name'] ?? ''))
                : null;
            if (is_array($resourceField)) {
                $seedKeys = [(string)($field['name'] ?? '')];
                $databaseColumn = trim((string)($resourceField['database_column'] ?? ''));
                if ($databaseColumn !== '' && !in_array($databaseColumn, $seedKeys, true)) {
                    $seedKeys[] = $databaseColumn;
                }
                if (count($seedKeys) > 1) {
                    $field['seed_keys'] = array_values($seedKeys);
                }
            }

            $relation = self::pickerRelationForField($field, $resource, $route);
            if ($relation !== null) {
                $field['relation'] = $relation;
            }
        }
        unset($field);

        return $fields;
    }

    /**
     * @param array<string, mixed> $field
     * @param array<string, mixed>|null $resource
     * @param array<string, mixed> $route
     * @return array<string, mixed>|null
     */
    private static function pickerRelationForField(array $field, ?array $resource, array $route): ?array
    {
        $reference = null;

        if (is_array($field['relation'] ?? null)) {
            $reference = [
                'table' => (string)($field['relation']['table'] ?? ''),
                'column' => (string)($field['relation']['column'] ?? 'id'),
            ];
        }

        if ($reference === null && $resource !== null) {
            $resourceField = self::resourceField($resource, (string)($field['name'] ?? ''));
            if (is_array($resourceField['relation'] ?? null)) {
                $reference = [
                    'table' => (string)($resourceField['relation']['table'] ?? ''),
                    'column' => (string)($resourceField['relation']['column'] ?? 'id'),
                ];
            }
        }

        if ($reference === null) {
            $table = self::inferRelationTableFromFieldName((string)($field['name'] ?? ''));
            if ($table !== null) {
                $reference = [
                    'table' => $table,
                    'column' => 'id',
                ];
            }
        }

        if ($reference === null || trim((string)($reference['table'] ?? '')) === '') {
            return null;
        }

        return self::pickerRelationForReference($reference, (bool)($route['auth_required'] ?? false));
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, mixed>|null
     */
    private static function resourceField(array $resource, string $fieldName): ?array
    {
        $name = trim($fieldName);
        if ($name === '') {
            return null;
        }

        foreach (array_values(array_filter([
            $resource['fields'] ?? null,
            $resource['create_fields'] ?? null,
            $resource['update_fields'] ?? null,
            $resource['query_options'] ?? null,
        ], 'is_array')) as $collection) {
            foreach ($collection as $field) {
                if (is_array($field) && (string)($field['name'] ?? '') === $name) {
                    return $field;
                }
            }
        }

        return null;
    }

    private static function inferRelationTableFromFieldName(string $fieldName): ?string
    {
        $normalized = strtolower(trim($fieldName));
        if ($normalized === '') {
            return null;
        }

        $map = [
            'assigned_to_user_id' => 'users',
            'actor_user_id' => 'users',
            'created_by_user_id' => 'users',
            'updated_by_user_id' => 'users',
            'registered_by_user_id' => 'users',
            'owner_user_id' => 'users',
            'allowed_user_ids' => 'users',
            'user_id' => 'users',
            'users' => 'users',
            'event_id' => 'training_events',
            'album_id' => 'gallery_albums',
            'media_asset_id' => 'media_assets',
            'source_version_id' => 'media_asset_versions',
            'version_id' => 'media_asset_versions',
            'versionid' => 'media_asset_versions',
            'course_id' => 'courses',
            'module_id' => 'course_modules',
            'permission_id' => 'permissions',
            'entity_id' => 'example_entities',
            'log_id' => 'data_change_logs',
            'logid' => 'data_change_logs',
        ];

        if (isset($map[$normalized])) {
            return $map[$normalized];
        }

        if (str_ends_with($normalized, '_user_ids')) {
            return 'users';
        }

        if (str_ends_with($normalized, '_user_id')) {
            return 'users';
        }

        if (str_ends_with($normalized, '_id')) {
            $base = substr($normalized, 0, -3);
            if (isset($map[$base . '_id'])) {
                return $map[$base . '_id'];
            }
        }

        return null;
    }

    /**
     * @param array<string, string> $reference
     * @return array<string, mixed>|null
     */
    private static function pickerRelationForReference(array $reference, bool $preferAuth): ?array
    {
        $table = strtolower(trim((string)($reference['table'] ?? '')));
        if ($table === '') {
            return null;
        }

        $resource = self::resourceForTable($table);
        if ($resource === null) {
            return null;
        }

        $listRoute = self::relationListRoute($resource, $preferAuth);
        $listPath = is_array($listRoute) ? (string)($listRoute['path'] ?? '') : trim((string)($resource['default_data_path'] ?? ''));
        if ($listPath === '') {
            return null;
        }

        $queryFields = is_array($listRoute['request']['query'] ?? null) ? $listRoute['request']['query'] : [];
        $searchParam = self::relationQueryFieldName($queryFields, ['q', 'search']);
        $limitParam = self::relationQueryFieldName($queryFields, ['limit']);
        $offsetParam = self::relationQueryFieldName($queryFields, ['offset']);

        return [
            'table' => $table,
            'column' => (string)($reference['column'] ?? 'id'),
            'resource_key' => (string)($resource['key'] ?? ''),
            'resource_label' => (string)($resource['label'] ?? $resource['key'] ?? $table),
            'list_path' => $listPath,
            'auth_required' => is_array($listRoute)
                ? (bool)($listRoute['auth_required'] ?? false)
                : (bool)($resource['default_data_auth_required'] ?? false),
            'value_field' => (string)($reference['column'] ?? 'id'),
            'label_fields' => self::relationLabelFields($resource, (string)($reference['column'] ?? 'id')),
            'search_param' => $searchParam,
            'limit_param' => $limitParam,
            'offset_param' => $offsetParam,
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function resourceForTable(string $table): ?array
    {
        foreach (self::resources() as $resource) {
            if ((string)($resource['table'] ?? '') === $table) {
                return $resource;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, mixed>|null
     */
    private static function relationListRoute(array $resource, bool $preferAuth): ?array
    {
        $candidates = array_values(array_filter(
            is_array($resource['routes'] ?? null) ? $resource['routes'] : [],
            static function (mixed $route): bool {
                if (!is_array($route) || strtoupper((string)($route['method'] ?? '')) !== 'GET') {
                    return false;
                }

                $request = is_array($route['request'] ?? null) ? $route['request'] : [];
                if ((is_array($request['path_params'] ?? null) ? $request['path_params'] : []) !== []) {
                    return false;
                }

                $path = (string)($route['path'] ?? '');
                return !str_contains($path, '/history')
                    && !str_contains($path, '/download')
                    && !str_contains($path, '/meta/')
                    && !str_contains($path, '/framework');
            }
        ));

        if ($candidates === []) {
            return null;
        }

        usort($candidates, static function (array $left, array $right) use ($preferAuth): int {
            $leftAuth = (bool)($left['auth_required'] ?? false);
            $rightAuth = (bool)($right['auth_required'] ?? false);
            $leftAdmin = str_contains((string)($left['path'] ?? ''), '/admin/');
            $rightAdmin = str_contains((string)($right['path'] ?? ''), '/admin/');

            $leftScore = [
                $preferAuth === $leftAuth ? 0 : 1,
                $preferAuth === $leftAdmin ? 0 : 1,
                strlen((string)($left['path'] ?? '')),
            ];
            $rightScore = [
                $preferAuth === $rightAuth ? 0 : 1,
                $preferAuth === $rightAdmin ? 0 : 1,
                strlen((string)($right['path'] ?? '')),
            ];

            return $leftScore <=> $rightScore;
        });

        return $candidates[0] ?? null;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, string> $candidates
     */
    private static function relationQueryFieldName(array $fields, array $candidates): ?string
    {
        foreach ($candidates as $candidate) {
            foreach ($fields as $field) {
                if ((string)($field['name'] ?? '') === $candidate) {
                    return $candidate;
                }
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<int, string>
     */
    private static function relationLabelFields(array $resource, string $valueField): array
    {
        $available = array_values(array_map(
            static fn (array $field): string => (string)($field['name'] ?? ''),
            is_array($resource['fields'] ?? null) ? $resource['fields'] : []
        ));

        $preferred = [
            'name',
            'title',
            'original_name',
            'email',
            'slug',
            'code',
            'config_key',
            'key',
            'role',
            'mime_type',
            'alt_text',
            'summary',
            'status',
        ];

        $labels = [];
        foreach ($preferred as $candidate) {
            if ($candidate !== $valueField && in_array($candidate, $available, true)) {
                $labels[] = $candidate;
            }
            if (count($labels) >= 3) {
                return $labels;
            }
        }

        foreach ($available as $candidate) {
            if ($candidate === '' || $candidate === $valueField) {
                continue;
            }
            if (in_array($candidate, ['created_at', 'updated_at', 'password_hash', 'storage_path'], true)) {
                continue;
            }
            $labels[] = $candidate;
            if (count($labels) >= 3) {
                break;
            }
        }

        return array_values(array_unique($labels));
    }

    /**
     * @return array<string, mixed>
     */
    private static function pagesResource(): array
    {
        $fields = self::fields('pages', [
            'aliases' => ['content_json' => 'content', 'seo_json' => 'seo'],
            'optional_on_create' => ['content', 'seo'],
        ]);
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, or slug.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'published', 'archived']),
        ];

        return self::resourceDoc('pages', 'Pages', 'content', 'Page', 'pages', 'Structured website pages exposed as JSON resources.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/pages', 'List published pages.', [
                'resource_key' => 'pages',
                'query' => [self::fieldDoc('q', 'string', 'Search title, summary, or slug.')],
                'return_type' => 'Page[]',
            ]),
            self::endpointDoc('GET', '/api/v1/pages/{slug}', 'Get one published page by slug.', [
                'resource_key' => 'pages',
                'path_params' => [self::fieldDoc('slug', 'string', 'Page slug.', true)],
                'return_type' => 'Page',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/pages', 'List pages for administration.', [
                'resource_key' => 'pages',
                'auth_required' => true,
                'permissions' => ['admin.pages.manage'],
                'query' => $query,
                'return_type' => 'Page[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/pages/{id}', 'Get one page for administration.', [
                'resource_key' => 'pages',
                'auth_required' => true,
                'permissions' => ['admin.pages.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Page identifier.', true)],
                'return_type' => 'Page',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/pages', 'Create a page.', [
                'resource_key' => 'pages',
                'auth_required' => true,
                'permissions' => ['admin.pages.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'Page',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/pages/{id}', 'Update a page.', [
                'resource_key' => 'pages',
                'auth_required' => true,
                'permissions' => ['admin.pages.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Page identifier.', true)],
                'body' => $update,
                'return_type' => 'Page',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/pages/{id}', 'Delete a page.', [
                'resource_key' => 'pages',
                'auth_required' => true,
                'permissions' => ['admin.pages.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Page identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/pages');
    }

    /**
     * @return array<string, mixed>
     */
    private static function newsResource(): array
    {
        $fields = self::fields('news_posts', [
            'aliases' => ['meta_json' => 'meta'],
            'optional_on_create' => ['body', 'meta'],
        ]);
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, or body.'),
            self::fieldDoc('post_type', 'string', 'Filter by post type.', false, ['news', 'announcement', 'notice']),
            self::fieldDoc('featured', 'boolean', 'Filter featured items.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'published', 'archived']),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
        ];

        return self::resourceDoc('news_posts', 'News Posts', 'content', 'NewsPost', 'news_posts', 'News, notices, and announcement entries.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/news', 'List published news posts.', [
                'resource_key' => 'news_posts',
                'query' => array_values(array_filter($query, fn (array $field): bool => $field['name'] !== 'status')),
                'return_type' => 'NewsPost[]',
            ]),
            self::endpointDoc('GET', '/api/v1/news/{slug}', 'Get one published news post by slug.', [
                'resource_key' => 'news_posts',
                'path_params' => [self::fieldDoc('slug', 'string', 'Post slug.', true)],
                'return_type' => 'NewsPost',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/news', 'List news posts for administration.', [
                'resource_key' => 'news_posts',
                'auth_required' => true,
                'permissions' => ['admin.news.manage'],
                'query' => $query,
                'return_type' => 'NewsPost[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/news/{id}', 'Get one news post for administration.', [
                'resource_key' => 'news_posts',
                'auth_required' => true,
                'permissions' => ['admin.news.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Post identifier.', true)],
                'return_type' => 'NewsPost',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/news', 'Create a news post.', [
                'resource_key' => 'news_posts',
                'auth_required' => true,
                'permissions' => ['admin.news.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'NewsPost',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/news/{id}', 'Update a news post.', [
                'resource_key' => 'news_posts',
                'auth_required' => true,
                'permissions' => ['admin.news.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Post identifier.', true)],
                'body' => $update,
                'return_type' => 'NewsPost',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/news/{id}', 'Delete a news post.', [
                'resource_key' => 'news_posts',
                'auth_required' => true,
                'permissions' => ['admin.news.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Post identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/news');
    }

    /**
     * @return array<string, mixed>
     */
    private static function eventsResource(): array
    {
        $fields = self::fields('training_events', [
            'aliases' => ['meta_json' => 'meta'],
            'optional_on_create' => ['description', 'meta'],
        ]);
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, description, or location.'),
            self::fieldDoc('featured', 'boolean', 'Filter featured events.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'published', 'cancelled', 'completed']),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
        ];

        return self::resourceDoc('training_events', 'Events', 'learning', 'TrainingEvent', 'training_events', 'Training and webinar event records.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/events', 'List published events.', [
                'resource_key' => 'training_events',
                'query' => array_values(array_filter($query, fn (array $field): bool => $field['name'] !== 'status')),
                'return_type' => 'TrainingEvent[]',
            ]),
            self::endpointDoc('GET', '/api/v1/events/{id}', 'Get one published event by identifier.', [
                'resource_key' => 'training_events',
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'return_type' => 'TrainingEvent',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/events', 'List events for administration.', [
                'resource_key' => 'training_events',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'query' => $query,
                'return_type' => 'TrainingEvent[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/events/{id}', 'Get one event for administration.', [
                'resource_key' => 'training_events',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'return_type' => 'TrainingEvent',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/events', 'Create an event.', [
                'resource_key' => 'training_events',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'TrainingEvent',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/events/{id}', 'Update an event.', [
                'resource_key' => 'training_events',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'body' => $update,
                'return_type' => 'TrainingEvent',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/events/{id}', 'Delete an event.', [
                'resource_key' => 'training_events',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/events');
    }

    /**
     * @return array<string, mixed>
     */
    private static function eventRegistrationsResource(): array
    {
        $fields = self::fields('event_registrations');
        $create = self::bodyFields($fields, true, ['event_id', 'registered_by_user_id', 'status', 'attended', 'created_at', 'updated_at']);
        $update = self::bodyFields($fields, false, ['event_id', 'registered_by_user_id', 'full_name', 'email', 'phone', 'organisation', 'role_title', 'notes', 'created_at']);
        $query = [
            self::fieldDoc('event_id', 'string:uuid', 'Filter by event identifier.'),
        ];

        return self::resourceDoc('event_registrations', 'Event Registrations', 'learning', 'EventRegistration', 'event_registrations', 'Registrations collected for events.', $fields, $create, $update, $query, [
            self::endpointDoc('POST', '/api/v1/events/{id}/registrations', 'Register an attendee for an event.', [
                'resource_key' => 'event_registrations',
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'body' => $create,
                'status' => 201,
                'return_type' => 'EventRegistration',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/events/{id}/registrations', 'List registrations for one event.', [
                'resource_key' => 'event_registrations',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Event identifier.', true)],
                'return_type' => 'EventRegistration[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/registrations/{id}', 'Get one event registration.', [
                'resource_key' => 'event_registrations',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Registration identifier.', true)],
                'return_type' => 'EventRegistration',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/registrations/{id}', 'Update a registration status or attendance state.', [
                'resource_key' => 'event_registrations',
                'auth_required' => true,
                'permissions' => ['admin.events.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Registration identifier.', true)],
                'body' => $update,
                'return_type' => 'EventRegistration',
            ]),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private static function resourcesResource(): array
    {
        $fields = self::fields('resources', [
            'aliases' => ['meta_json' => 'meta'],
            'optional_on_create' => ['description', 'meta'],
        ]);
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, or description.'),
            self::fieldDoc('resource_type', 'string', 'Filter by resource type.', false, ['manual', 'guideline', 'publication', 'report', 'research', 'multimedia', 'link']),
            self::fieldDoc('featured', 'boolean', 'Filter featured resources.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'published', 'archived']),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
        ];

        return self::resourceDoc('resources', 'Resources', 'content', 'Resource', 'resources', 'Documents, links, and knowledge assets.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/resources', 'List published resources.', [
                'resource_key' => 'resources',
                'query' => array_values(array_filter($query, fn (array $field): bool => $field['name'] !== 'status')),
                'return_type' => 'Resource[]',
            ]),
            self::endpointDoc('GET', '/api/v1/resources/{slug}', 'Get one published resource by slug.', [
                'resource_key' => 'resources',
                'path_params' => [self::fieldDoc('slug', 'string', 'Resource slug.', true)],
                'return_type' => 'Resource',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/resources', 'List resources for administration.', [
                'resource_key' => 'resources',
                'auth_required' => true,
                'permissions' => ['admin.resources.manage'],
                'query' => $query,
                'return_type' => 'Resource[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/resources/{id}', 'Get one resource for administration.', [
                'resource_key' => 'resources',
                'auth_required' => true,
                'permissions' => ['admin.resources.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Resource identifier.', true)],
                'return_type' => 'Resource',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/resources', 'Create a resource.', [
                'resource_key' => 'resources',
                'auth_required' => true,
                'permissions' => ['admin.resources.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'Resource',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/resources/{id}', 'Update a resource.', [
                'resource_key' => 'resources',
                'auth_required' => true,
                'permissions' => ['admin.resources.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Resource identifier.', true)],
                'body' => $update,
                'return_type' => 'Resource',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/resources/{id}', 'Delete a resource.', [
                'resource_key' => 'resources',
                'auth_required' => true,
                'permissions' => ['admin.resources.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Resource identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/resources');
    }

    /**
     * @return array<string, mixed>
     */
    private static function galleryAlbumsResource(): array
    {
        $fields = self::fields('gallery_albums');
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);

        return self::resourceDoc('gallery_albums', 'Gallery Albums', 'content', 'GalleryAlbum', 'gallery_albums', 'Album containers for published gallery items.', $fields, $create, $update, [
            self::fieldDoc('status', 'string', 'Filter by album status.', false, ['draft', 'published', 'archived']),
        ], [
            self::endpointDoc('GET', '/api/v1/admin/gallery/albums', 'List gallery albums.', [
                'resource_key' => 'gallery_albums',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'query' => [self::fieldDoc('status', 'string', 'Filter by album status.', false, ['draft', 'published', 'archived'])],
                'return_type' => 'GalleryAlbum[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/gallery/albums/{id}', 'Get one gallery album.', [
                'resource_key' => 'gallery_albums',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Album identifier.', true)],
                'return_type' => 'GalleryAlbum',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/gallery/albums', 'Create a gallery album.', [
                'resource_key' => 'gallery_albums',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'GalleryAlbum',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/gallery/albums/{id}', 'Update a gallery album.', [
                'resource_key' => 'gallery_albums',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Album identifier.', true)],
                'body' => $update,
                'return_type' => 'GalleryAlbum',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/gallery/albums/{id}', 'Delete a gallery album.', [
                'resource_key' => 'gallery_albums',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Album identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/admin/gallery/albums', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function galleryItemsResource(): array
    {
        $fields = self::fields('gallery_items');
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('status', 'string', 'Filter by item status.', false, ['draft', 'published', 'archived']),
            self::fieldDoc('album_id', 'string:uuid', 'Restrict items to one album.'),
        ];

        return self::resourceDoc('gallery_items', 'Gallery Items', 'content', 'GalleryItem', 'gallery_items', 'Images and videos published in gallery albums.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/admin/gallery/items', 'List gallery items.', [
                'resource_key' => 'gallery_items',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'query' => $query,
                'return_type' => 'GalleryItem[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/gallery/items/{id}', 'Get one gallery item.', [
                'resource_key' => 'gallery_items',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Item identifier.', true)],
                'return_type' => 'GalleryItem',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/gallery/items', 'Create a gallery item.', [
                'resource_key' => 'gallery_items',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'GalleryItem',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/gallery/items/{id}', 'Update a gallery item.', [
                'resource_key' => 'gallery_items',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Item identifier.', true)],
                'body' => $update,
                'return_type' => 'GalleryItem',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/gallery/items/{id}', 'Delete a gallery item.', [
                'resource_key' => 'gallery_items',
                'auth_required' => true,
                'permissions' => ['admin.gallery.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Item identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/admin/gallery/items', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function contactMessagesResource(): array
    {
        $fields = self::fields('contact_messages');
        $create = self::bodyFields($fields, true, ['status', 'assigned_to_user_id', 'created_at', 'updated_at']);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search full name, email, subject, or message.'),
            self::fieldDoc('status', 'string', 'Filter by processing state.', false, ['new', 'in_progress', 'resolved', 'closed', 'spam']),
        ];

        return self::resourceDoc('contact_messages', 'Contact Messages', 'content', 'ContactMessage', 'contact_messages', 'Inbound contact submissions and support queue entries.', $fields, $create, $update, $query, [
            self::endpointDoc('POST', '/api/v1/contact/messages', 'Create a contact message.', [
                'resource_key' => 'contact_messages',
                'body' => $create,
                'status' => 201,
                'return_type' => 'ContactMessage',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/contact/messages', 'List contact messages.', [
                'resource_key' => 'contact_messages',
                'auth_required' => true,
                'permissions' => ['admin.contacts.view'],
                'query' => $query,
                'return_type' => 'ContactMessage[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/contact/messages/{id}', 'Get one contact message.', [
                'resource_key' => 'contact_messages',
                'auth_required' => true,
                'permissions' => ['admin.contacts.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Message identifier.', true)],
                'return_type' => 'ContactMessage',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/contact/messages/{id}', 'Update a contact message.', [
                'resource_key' => 'contact_messages',
                'auth_required' => true,
                'permissions' => ['admin.contacts.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Message identifier.', true)],
                'body' => $update,
                'return_type' => 'ContactMessage',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/contact/messages/{id}', 'Delete a contact message.', [
                'resource_key' => 'contact_messages',
                'auth_required' => true,
                'permissions' => ['admin.contacts.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Message identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/admin/contact/messages', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function coursesResource(): array
    {
        $fields = self::fields('courses', [
            'aliases' => ['meta_json' => 'meta'],
            'optional_on_create' => ['description', 'meta'],
        ]);
        $create = self::bodyFields($fields);
        $update = self::bodyFields($fields, false);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, or description.'),
            self::fieldDoc('featured', 'boolean', 'Filter featured courses.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'published', 'archived']),
        ];

        return self::resourceDoc('courses', 'Courses', 'learning', 'Course', 'courses', 'Courses with modules, enrollments, and progress tracking.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/courses', 'List published courses.', [
                'resource_key' => 'courses',
                'query' => array_values(array_filter($query, fn (array $field): bool => $field['name'] !== 'status')),
                'return_type' => 'Course[]',
            ]),
            self::endpointDoc('GET', '/api/v1/courses/{slug}', 'Get one course with published modules.', [
                'resource_key' => 'courses',
                'path_params' => [self::fieldDoc('slug', 'string', 'Course slug.', true)],
                'return_type' => 'Course',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/courses', 'List courses for administration.', [
                'resource_key' => 'courses',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'query' => $query,
                'return_type' => 'Course[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/courses/{id}', 'Get one course for administration.', [
                'resource_key' => 'courses',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'return_type' => 'Course',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/courses', 'Create a course.', [
                'resource_key' => 'courses',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'Course',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/courses/{id}', 'Update a course.', [
                'resource_key' => 'courses',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'body' => $update,
                'return_type' => 'Course',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/courses/{id}', 'Delete a course.', [
                'resource_key' => 'courses',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/courses');
    }

    /**
     * @return array<string, mixed>
     */
    private static function courseModulesResource(): array
    {
        $fields = self::fields('course_modules');
        $create = self::bodyFields($fields, true, ['course_id', 'created_at', 'updated_at']);
        $update = self::bodyFields($fields, false, ['course_id', 'created_at']);

        return self::resourceDoc('course_modules', 'Course Modules', 'learning', 'CourseModule', 'course_modules', 'Course lesson and content unit records.', $fields, $create, $update, [], [
            self::endpointDoc('GET', '/api/v1/admin/courses/{id}/modules', 'List modules for one course.', [
                'resource_key' => 'course_modules',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'return_type' => 'CourseModule[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/modules/{id}', 'Get one course module.', [
                'resource_key' => 'course_modules',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Module identifier.', true)],
                'return_type' => 'CourseModule',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/courses/{id}/modules', 'Create a module under one course.', [
                'resource_key' => 'course_modules',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'body' => $create,
                'status' => 201,
                'return_type' => 'CourseModule',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/modules/{id}', 'Update a course module.', [
                'resource_key' => 'course_modules',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Module identifier.', true)],
                'body' => $update,
                'return_type' => 'CourseModule',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/modules/{id}', 'Delete a course module.', [
                'resource_key' => 'course_modules',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Module identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private static function courseEnrollmentsResource(): array
    {
        $fields = self::fields('course_enrollments');
        $create = [];
        $update = self::bodyFields($fields, false, ['course_id', 'user_id', 'enrolled_at', 'created_at']);

        return self::resourceDoc('course_enrollments', 'Course Enrollments', 'learning', 'CourseEnrollment', 'course_enrollments', 'Course membership and completion state records.', $fields, $create, $update, [], [
            self::endpointDoc('GET', '/api/v1/courses/me/enrollments', 'List the current user enrollments.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['courses.catalog.view'],
                'return_type' => 'CourseEnrollment[]',
            ]),
            self::endpointDoc('POST', '/api/v1/courses/{id}/enroll', 'Enroll the current user into a course.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['courses.enroll'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'status' => 201,
                'return_type' => 'CourseEnrollment',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/courses/{id}/enrollments', 'List enrollments for one course.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'return_type' => 'CourseEnrollment[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/enrollments/{id}', 'Get one course enrollment.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Enrollment identifier.', true)],
                'return_type' => 'CourseEnrollment',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/enrollments/{id}', 'Update enrollment completion or certificate state.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['admin.courses.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Enrollment identifier.', true)],
                'body' => $update,
                'return_type' => 'CourseEnrollment',
            ]),
            self::endpointDoc('PUT', '/api/v1/courses/{id}/progress', 'Update the current user module progress inside a course.', [
                'resource_key' => 'course_enrollments',
                'auth_required' => true,
                'permissions' => ['courses.progress.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Course identifier.', true)],
                'body' => [
                    self::fieldDoc('module_id', 'string:uuid', 'Course module identifier.', true),
                    self::fieldDoc('status', 'string', 'Progress state.', false, ['not_started', 'in_progress', 'completed']),
                    self::fieldDoc('progress_percent', 'number', 'Percent complete from 0 to 100.'),
                ],
                'return_type' => '{ progress: CourseProgress, enrollment: CourseEnrollment }',
            ]),
        ], '/api/v1/courses/me/enrollments', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function sampleRecordsResource(): array
    {
        $fields = self::withFieldOverrides(self::fields('sample_records', [
            'aliases' => [
                'labels_json' => 'labels',
                'metadata_json' => 'metadata',
            ],
            'optional_on_create' => ['labels', 'metadata'],
        ]), [
            'labels' => [
                'data_type' => 'array',
                'format' => null,
                'description' => 'Ordered labels that help categorize the sample record.',
            ],
            'metadata' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Flexible JSON metadata stored with the sample record.',
            ],
        ]);
        $create = array_merge(
            self::bodyFields($fields),
            [self::fieldDoc('change_reason', 'string', 'Optional audit reason recorded in the archive log.')]
        );
        $update = array_merge(
            self::bodyFields($fields, false),
            [self::fieldDoc('change_reason', 'string', 'Optional audit reason recorded in the archive log.')]
        );
        $query = [
            self::fieldDoc('q', 'string', 'Search slug, title, or summary.'),
            self::fieldDoc('record_type', 'string', 'Filter by sample record type.', false, ['guide', 'workflow', 'policy', 'dataset']),
            self::fieldDoc('owner_user_id', 'string:uuid', 'Filter by owner user identifier.'),
            self::fieldDoc('status', 'string', 'Admin-only status filter.', false, ['draft', 'active', 'archived']),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
        ];

        return self::resourceDoc('sample_records', 'Sample Records', 'framework', 'SampleRecord', 'sample_records', 'Concrete example module showing full CRUD, archive-based soft delete, and restore flows.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/sample-records', 'List public sample records.', [
                'resource_key' => 'sample_records',
                'query' => [
                    self::fieldDoc('q', 'string', 'Search slug, title, or summary.'),
                    self::fieldDoc('record_type', 'string', 'Filter by sample record type.', false, ['guide', 'workflow', 'policy', 'dataset']),
                    self::fieldDoc('owner_user_id', 'string:uuid', 'Filter by owner user identifier.'),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                ],
                'return_type' => 'SampleRecord[]',
            ]),
            self::endpointDoc('GET', '/api/v1/sample-records/{slug}', 'Get one public sample record by slug.', [
                'resource_key' => 'sample_records',
                'path_params' => [self::fieldDoc('slug', 'string', 'Sample record slug.', true)],
                'return_type' => 'SampleRecord',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/sample-records', 'List live sample records for administration.', [
                'resource_key' => 'sample_records',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.view'],
                'query' => $query,
                'return_type' => 'SampleRecord[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/sample-records', 'Create a sample record.', [
                'resource_key' => 'sample_records',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'SampleRecord',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/sample-records/{id}', 'Get one live sample record by identifier.', [
                'resource_key' => 'sample_records',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Sample record identifier.', true)],
                'return_type' => 'SampleRecord',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/sample-records/{id}', 'Update a sample record and archive the previous version.', [
                'resource_key' => 'sample_records',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Sample record identifier.', true)],
                'body' => $update,
                'return_type' => 'SampleRecord',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/sample-records/{id}', 'Archive-delete a sample record and remove it from the live table.', [
                'resource_key' => 'sample_records',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Sample record identifier.', true)],
                'return_type' => '{ deleted: boolean, record_id: string, archive_log_id: integer }',
            ]),
        ], '/api/v1/sample-records');
    }

    /**
     * @return array<string, mixed>
     */
    private static function dataChangeLogsResource(): array
    {
        $fields = self::withFieldOverrides(self::fields('data_change_logs'), [
            'record_id' => [
                'data_type' => 'string',
                'format' => null,
                'description' => 'Primary record identifier captured at the time of change.',
            ],
            'before_json' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Live row snapshot before the change.',
            ],
            'after_json' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Live row snapshot after the change.',
            ],
            'diff_json' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Per-field before and after diff.',
            ],
            'metadata_json' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Extra archive metadata including route, reason, and changed fields.',
            ],
            'restorable_json' => [
                'data_type' => 'object',
                'format' => 'json',
                'description' => 'Snapshot used to restore the record later.',
            ],
            'restored_from_log_id' => [
                'data_type' => 'integer',
                'format' => null,
                'description' => 'Original archive log that a restore action used.',
            ],
        ]);
        $restoreBody = [
            self::fieldDoc('change_reason', 'string', 'Optional audit reason recorded for the restore action.'),
        ];
        $query = [
            self::fieldDoc('q', 'string', 'Search title, path, or reason.'),
            self::fieldDoc('record_id', 'string:uuid', 'Filter by sample record identifier.'),
            self::fieldDoc('action', 'string', 'Filter by change action.', false, ['create', 'update', 'delete', 'restore']),
            self::fieldDoc('actor_user_id', 'string:uuid', 'Filter by actor user identifier.'),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
            self::fieldDoc('offset', 'integer', 'Row offset.'),
        ];

        return self::resourceDoc('data_change_logs', 'Data Change Logs', 'governance', 'DataChangeLog', 'data_change_logs', 'Restorable JSON archive logs for update, delete, and restore operations.', $fields, [], [], $query, [
            self::endpointDoc('GET', '/api/v1/admin/sample-records/history', 'List archive log rows for the sample record module.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.view'],
                'query' => $query,
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/sample-records/{id}/history', 'List archive log rows for one sample record.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Sample record identifier.', true)],
                'query' => [
                    self::fieldDoc('action', 'string', 'Filter by change action.', false, ['create', 'update', 'delete', 'restore']),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                    self::fieldDoc('offset', 'integer', 'Row offset.'),
                ],
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/sample-records/history/{logId}/restore', 'Restore a sample record from a delete or update archive entry.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.sample_records.manage'],
                'path_params' => [self::fieldDoc('logId', 'integer', 'Archive log identifier.', true)],
                'body' => $restoreBody,
                'return_type' => 'SampleRecord',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media/history', 'List archive log rows for the media library.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'query' => $query,
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media/{id}/history', 'List archive log rows for one media asset.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Media asset identifier.', true)],
                'query' => [
                    self::fieldDoc('action', 'string', 'Filter by change action.', false, ['create', 'update', 'delete', 'restore']),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                    self::fieldDoc('offset', 'integer', 'Row offset.'),
                ],
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/media/history/{logId}/restore', 'Restore a media asset from an archived JSON change log row.', [
                'resource_key' => 'data_change_logs',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'path_params' => [self::fieldDoc('logId', 'integer', 'Archive log identifier.', true)],
                'body' => $restoreBody,
                'return_type' => 'MediaAsset',
            ]),
        ], '/api/v1/admin/sample-records/history', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function exampleEntitiesResource(): array
    {
        $moduleOptions = array_keys(NiteModuleCatalog::modules());
        $fields = self::fields('example_entities', [
            'aliases' => ['payload_json' => 'payload'],
            'read_only' => ['module_key', 'entity_type'],
            'optional_on_create' => ['payload'],
        ]);
        $create = self::bodyFields($fields, true, ['module_key', 'entity_type', 'created_at', 'updated_at']);
        $update = self::bodyFields($fields, false, ['module_key', 'entity_type', 'created_at']);
        $query = [
            self::fieldDoc('q', 'string', 'Search title, summary, or slug.'),
            self::fieldDoc('status', 'string', 'Filter by entity state.', false, ['draft', 'active', 'published', 'archived', 'disabled']),
        ];

        return self::resourceDoc('example_entities', 'Example Entities', 'generic', 'ExampleEntity', 'example_entities', 'Generic JSON-backed entities used for starter modules and prototypes.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/examples/{module}/{entity}', 'List example entities for a module and entity type.', [
                'resource_key' => 'example_entities',
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, $moduleOptions),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                ],
                'query' => $query,
                'return_type' => 'ExampleEntity[]',
            ]),
            self::endpointDoc('GET', '/api/v1/examples/{module}/{entity}/{id}', 'Get one example entity.', [
                'resource_key' => 'example_entities',
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, $moduleOptions),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                    self::fieldDoc('id', 'string:uuid', 'Entity identifier.', true),
                ],
                'return_type' => 'ExampleEntity',
            ]),
            self::endpointDoc('POST', '/api/v1/examples/{module}/{entity}', 'Create an example entity.', [
                'resource_key' => 'example_entities',
                'auth_required' => true,
                'permissions' => ['framework.examples.manage'],
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, $moduleOptions),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                ],
                'body' => $create,
                'status' => 201,
                'return_type' => 'ExampleEntity',
            ]),
            self::endpointDoc('PUT', '/api/v1/examples/{module}/{entity}/{id}', 'Update an example entity.', [
                'resource_key' => 'example_entities',
                'auth_required' => true,
                'permissions' => ['framework.examples.manage'],
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, $moduleOptions),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                    self::fieldDoc('id', 'string:uuid', 'Entity identifier.', true),
                ],
                'body' => $update,
                'return_type' => 'ExampleEntity',
            ]),
            self::endpointDoc('DELETE', '/api/v1/examples/{module}/{entity}/{id}', 'Delete an example entity.', [
                'resource_key' => 'example_entities',
                'auth_required' => true,
                'permissions' => ['framework.examples.manage'],
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, $moduleOptions),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                    self::fieldDoc('id', 'string:uuid', 'Entity identifier.', true),
                ],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/examples/workflow/work_items');
    }

    /**
     * @return array<string, mixed>
     */
    private static function exampleEntriesResource(): array
    {
        $fields = self::fields('example_entries', [
            'aliases' => ['payload_json' => 'payload'],
            'read_only' => ['entity_id'],
            'optional_on_create' => ['payload'],
        ]);
        $create = self::bodyFields($fields, true, ['entity_id', 'created_at']);

        return self::resourceDoc('example_entries', 'Example Entries', 'generic', 'ExampleEntry', 'example_entries', 'Supplementary note, timeline, and audit records for example entities.', $fields, $create, [], [], [
            self::endpointDoc('GET', '/api/v1/examples/{module}/{entity}/{id}/entries', 'List entries for one example entity.', [
                'resource_key' => 'example_entries',
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, array_keys(NiteModuleCatalog::modules())),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                    self::fieldDoc('id', 'string:uuid', 'Entity identifier.', true),
                ],
                'return_type' => 'ExampleEntry[]',
            ]),
            self::endpointDoc('POST', '/api/v1/examples/{module}/{entity}/{id}/entries', 'Create an entry under one example entity.', [
                'resource_key' => 'example_entries',
                'auth_required' => true,
                'permissions' => ['framework.examples.manage'],
                'path_params' => [
                    self::fieldDoc('module', 'string', 'Module key.', true, array_keys(NiteModuleCatalog::modules())),
                    self::fieldDoc('entity', 'string', 'Entity type inside the selected module.', true),
                    self::fieldDoc('id', 'string:uuid', 'Entity identifier.', true),
                ],
                'body' => $create,
                'status' => 201,
                'return_type' => 'ExampleEntry',
            ]),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private static function usersResource(): array
    {
        $fields = self::fields('users', [
            'hidden' => ['password_hash'],
            'aliases' => ['profile_json' => 'profile'],
            'optional_on_create' => ['profile'],
            'virtual_fields' => [
                array_merge(self::fieldDoc('permissions', 'array', 'Hydrated permission codes.', false), ['read_only' => true]),
            ],
        ]);
        $create = self::bodyFields($fields, true, ['last_login_at', 'created_at', 'updated_at']);
        $create[] = self::fieldDoc('password', 'string', 'Plain text password, minimum 8 characters.', true);
        $update = self::bodyFields($fields, false, ['last_login_at', 'created_at']);
        $update[] = self::fieldDoc('password', 'string', 'Optional replacement password, minimum 8 characters.');
        $query = [
            self::fieldDoc('q', 'string', 'Search display name or email.'),
            self::fieldDoc('role', 'string', 'Filter by role.', false, ['member', 'trainer', 'editor', 'support', 'admin']),
            self::fieldDoc('account_status', 'string', 'Filter by account status.', false, ['active', 'inactive', 'suspended']),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
            self::fieldDoc('offset', 'integer', 'Row offset.'),
        ];

        return self::resourceDoc('users', 'Users', 'governance', 'User', 'users', 'Users with profile payloads and effective permissions.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/admin/users', 'List users.', [
                'resource_key' => 'users',
                'auth_required' => true,
                'permissions' => ['admin.users.view'],
                'query' => $query,
                'return_type' => 'User[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/users', 'Create a user.', [
                'resource_key' => 'users',
                'auth_required' => true,
                'permissions' => ['admin.users.manage'],
                'body' => $create,
                'status' => 201,
                'return_type' => 'User',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/users/{id}', 'Get one user.', [
                'resource_key' => 'users',
                'auth_required' => true,
                'permissions' => ['admin.users.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'User identifier.', true)],
                'return_type' => 'User',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/users/{id}', 'Update a user.', [
                'resource_key' => 'users',
                'auth_required' => true,
                'permissions' => ['admin.users.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'User identifier.', true)],
                'body' => $update,
                'return_type' => 'User',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/users/{id}', 'Delete a user.', [
                'resource_key' => 'users',
                'auth_required' => true,
                'permissions' => ['admin.users.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'User identifier.', true)],
                'return_type' => '{ deleted: boolean }',
            ]),
        ], '/api/v1/admin/users', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function siteSettingsResource(): array
    {
        $fields = self::fields('site_settings');
        $create = [];
        $update = [
            self::fieldDoc('visibility', 'string', 'Visibility scope for the setting bucket.', false, ['public', 'admin']),
            self::fieldDoc('settings', 'object', 'JSON payload stored under the selected key.', true),
        ];

        return self::resourceDoc('site_settings', 'Site Settings', 'content', 'SiteSetting', 'site_settings', 'Named JSON configuration buckets for public and administrative site settings.', $fields, $create, $update, [], [
            self::endpointDoc('GET', '/api/v1/site/settings', 'List public settings buckets.', [
                'resource_key' => 'site_settings',
                'return_type' => 'Record<string, SiteSetting>',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/site-settings', 'List all settings buckets.', [
                'resource_key' => 'site_settings',
                'auth_required' => true,
                'permissions' => ['admin.site_settings.manage'],
                'return_type' => 'Record<string, SiteSetting>',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/site-settings/{key}', 'Get one settings bucket.', [
                'resource_key' => 'site_settings',
                'auth_required' => true,
                'permissions' => ['admin.site_settings.manage'],
                'path_params' => [self::fieldDoc('key', 'string', 'Config key.', true)],
                'return_type' => 'SiteSetting',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/site-settings/{key}', 'Create or replace one settings bucket.', [
                'resource_key' => 'site_settings',
                'auth_required' => true,
                'permissions' => ['admin.site_settings.manage'],
                'path_params' => [self::fieldDoc('key', 'string', 'Config key.', true)],
                'body' => $update,
                'return_type' => 'SiteSetting',
            ]),
        ], '/api/v1/site/settings');
    }

    /**
     * @return array<string, mixed>
     */
    private static function mediaAssetVersionsResource(): array
    {
        $fields = self::withFieldOverrides(self::fields('media_asset_versions', [
            'hidden' => ['storage_path'],
            'descriptions' => [
                'media_asset_id' => 'Parent media asset identifier.',
                'public_url' => 'Public download URL for this specific version when the asset is public.',
                'checksum_sha1' => 'Checksum fingerprint used to confirm version integrity.',
                'change_notes' => 'Optional notes recorded when this version was uploaded or restored.',
                'action' => 'How the version entered history.',
                'source_version_id' => 'Previous version row referenced when this version was created from a restore.',
            ],
        ]), [
            'action' => [
                'options' => ['create', 'replace', 'restore'],
            ],
        ]);
        $upload = [
            self::fieldDoc('file', 'file', 'Replacement file to store as a new asset version.', true),
            self::fieldDoc('alt_text', 'string', 'Optional alternative text for the new current version.'),
            self::fieldDoc('access_scope', 'string', 'Visibility rule to apply after the new version becomes current.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
            self::fieldDoc('allowed_roles', 'array:json', 'Role codes allowed when access_scope is roles.'),
            self::fieldDoc('allowed_user_ids', 'array:json', 'User identifiers allowed when access_scope is users.'),
            self::fieldDoc('status', 'string', 'Current asset state after replacement.', false, ['active', 'archived']),
            self::fieldDoc('change_notes', 'string', 'Version notes recorded with this file replacement.'),
            self::fieldDoc('change_reason', 'string', 'Optional audit reason captured in the change log.'),
        ];
        $restore = [
            self::fieldDoc('alt_text', 'string', 'Optional alternative text for the restored current version.'),
            self::fieldDoc('access_scope', 'string', 'Visibility rule to apply after restore.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
            self::fieldDoc('allowed_roles', 'array:json', 'Role codes allowed when access_scope is roles.'),
            self::fieldDoc('allowed_user_ids', 'array:json', 'User identifiers allowed when access_scope is users.'),
            self::fieldDoc('status', 'string', 'Current asset state after restore.', false, ['active', 'archived']),
            self::fieldDoc('change_notes', 'string', 'Version notes recorded with this restore.'),
            self::fieldDoc('change_reason', 'string', 'Optional audit reason captured in the change log.'),
        ];

        return self::resourceDoc('media_asset_versions', 'Media Asset Versions', 'content', 'MediaAssetVersion', 'media_asset_versions', 'Immutable file history rows for each media asset version.', $fields, [], [], [], [
            self::endpointDoc('GET', '/api/v1/admin/media/{id}/versions', 'List stored versions for a media asset.', [
                'resource_key' => 'media_asset_versions',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Media asset identifier.', true)],
                'return_type' => 'MediaAssetVersion[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/media/{id}/versions', 'Upload a replacement file and create a new current version.', [
                'resource_key' => 'media_asset_versions',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'content_type' => 'multipart/form-data',
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Media asset identifier.', true)],
                'body' => $upload,
                'status' => 201,
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/media/{id}/versions/{versionId}/restore', 'Restore a previous file version as the new current version.', [
                'resource_key' => 'media_asset_versions',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'path_params' => [
                    self::fieldDoc('id', 'string:uuid', 'Media asset identifier.', true),
                    self::fieldDoc('versionId', 'string:uuid', 'Version identifier to restore.', true),
                ],
                'body' => $restore,
                'return_type' => 'MediaAsset',
            ]),
        ], '/api/v1/admin/media/{id}/versions', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function mediaAssetsResource(): array
    {
        $fields = self::withFieldOverrides(self::fields('media_assets', [
            'aliases' => [
                'allowed_roles_json' => 'allowed_roles',
                'allowed_user_ids_json' => 'allowed_user_ids',
            ],
            'hidden' => ['storage_path'],
            'descriptions' => [
                'public_url' => 'Direct download URL exposed only when the asset is public.',
                'alt_text' => 'Accessible description used when the asset is rendered.',
                'access_scope' => 'Visibility rule applied when developers or users fetch the asset.',
                'allowed_roles' => 'Role codes allowed when access_scope is roles.',
                'allowed_user_ids' => 'User identifiers allowed when access_scope is users.',
                'checksum_sha1' => 'Checksum fingerprint used to confirm file integrity.',
                'current_version_number' => 'Current live version number served for downloads.',
                'version_count' => 'Total stored versions retained for this asset.',
            ],
        ]), [
            'allowed_roles' => [
                'data_type' => 'array',
                'format' => 'json',
            ],
            'allowed_user_ids' => [
                'data_type' => 'array',
                'format' => 'json',
            ],
        ]);
        $create = [
            self::fieldDoc('file', 'file', 'Uploaded binary file stream.', true),
            self::fieldDoc('alt_text', 'string', 'Optional accessible description.'),
            self::fieldDoc('access_scope', 'string', 'Visibility rule to apply to the uploaded asset.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
            self::fieldDoc('allowed_roles', 'array:json', 'Role codes allowed when access_scope is roles.'),
            self::fieldDoc('allowed_user_ids', 'array:json', 'User identifiers allowed when access_scope is users.'),
            self::fieldDoc('status', 'string', 'Current asset state.', false, ['active', 'archived']),
            self::fieldDoc('change_notes', 'string', 'Optional notes recorded on the first version row.'),
            self::fieldDoc('change_reason', 'string', 'Optional audit reason captured in the change log.'),
        ];
        $update = [
            self::fieldDoc('alt_text', 'string', 'Optional accessible description.'),
            self::fieldDoc('access_scope', 'string', 'Visibility rule to apply to the current asset.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
            self::fieldDoc('allowed_roles', 'array:json', 'Role codes allowed when access_scope is roles.'),
            self::fieldDoc('allowed_user_ids', 'array:json', 'User identifiers allowed when access_scope is users.'),
            self::fieldDoc('status', 'string', 'Current asset state.', false, ['active', 'archived']),
            self::fieldDoc('change_reason', 'string', 'Optional audit reason captured in the change log.'),
        ];
        $historyQuery = [
            self::fieldDoc('q', 'string', 'Search title, path, or reason.'),
            self::fieldDoc('action', 'string', 'Filter by change action.', false, ['create', 'update', 'delete', 'restore']),
            self::fieldDoc('actor_user_id', 'string:uuid', 'Filter by actor user identifier.'),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
            self::fieldDoc('offset', 'integer', 'Row offset.'),
        ];

        return self::resourceDoc('media_assets', 'Media Assets', 'content', 'MediaAsset', 'media_assets', 'Uploaded files with asset-level access control, restoreable audit logs, and explicit file versions.', $fields, $create, $update, [
            self::fieldDoc('q', 'string', 'Search original name, MIME type, or public URL.'),
            self::fieldDoc('status', 'string', 'Filter by asset status.', false, ['active', 'archived']),
            self::fieldDoc('access_scope', 'string', 'Filter by asset visibility rule.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
            self::fieldDoc('created_by_user_id', 'string:uuid', 'Filter by asset owner or uploader.'),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
            self::fieldDoc('offset', 'integer', 'Row offset.'),
        ], [
            self::endpointDoc('GET', '/api/v1/media/{id}', 'Read access-controlled media metadata.', [
                'resource_key' => 'media_assets',
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('GET', '/api/v1/media/{id}/download', 'Download or inline-render the current media file when access rules allow it.', [
                'resource_key' => 'media_assets',
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'response_content_type' => 'application/octet-stream',
                'return_type' => 'binary',
                'envelope' => 'raw',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media/history', 'List archive log rows for media asset changes.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'query' => $historyQuery,
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/media/history/{logId}/restore', 'Restore a media asset from an archived JSON change log row.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'path_params' => [self::fieldDoc('logId', 'integer', 'Archive log identifier.', true)],
                'body' => [
                    self::fieldDoc('change_reason', 'string', 'Optional audit reason captured in the change log.'),
                ],
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media', 'List uploaded media assets.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'query' => [
                    self::fieldDoc('q', 'string', 'Search original name, MIME type, or public URL.'),
                    self::fieldDoc('status', 'string', 'Filter by asset status.', false, ['active', 'archived']),
                    self::fieldDoc('access_scope', 'string', 'Filter by asset visibility rule.', false, ['public', 'authenticated', 'roles', 'users', 'private']),
                    self::fieldDoc('created_by_user_id', 'string:uuid', 'Filter by asset owner or uploader.'),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                    self::fieldDoc('offset', 'integer', 'Row offset.'),
                ],
                'return_type' => 'MediaAsset[]',
            ]),
            self::endpointDoc('POST', '/api/v1/admin/media', 'Upload a media asset.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'content_type' => 'multipart/form-data',
                'body' => $create,
                'status' => 201,
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media/{id}/history', 'List archive log rows for one media asset.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'query' => [
                    self::fieldDoc('action', 'string', 'Filter by change action.', false, ['create', 'update', 'delete', 'restore']),
                    self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
                    self::fieldDoc('offset', 'integer', 'Row offset.'),
                ],
                'return_type' => 'DataChangeLog[]',
            ]),
            self::endpointDoc('GET', '/api/v1/admin/media/{id}', 'Read one media asset with current access and version details.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.view'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('PUT', '/api/v1/admin/media/{id}', 'Update media access rules, alt text, or status.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'body' => $update,
                'return_type' => 'MediaAsset',
            ]),
            self::endpointDoc('DELETE', '/api/v1/admin/media/{id}', 'Delete a media asset.', [
                'resource_key' => 'media_assets',
                'auth_required' => true,
                'permissions' => ['admin.media.manage'],
                'path_params' => [self::fieldDoc('id', 'string:uuid', 'Asset identifier.', true)],
                'return_type' => '{ deleted: boolean, record_id: string, archive_log_id: integer }',
            ]),
        ], '/api/v1/admin/media', true);
    }

    /**
     * @return array<string, mixed>
     */
    private static function auditLogsResource(): array
    {
        $fields = self::fields('system_audit_logs', [
            'aliases' => [
                'required_permissions' => 'required_permissions',
                'request_payload' => 'request_payload',
                'response_payload' => 'response_payload',
            ],
        ]);
        $create = [];
        $update = [];
        $query = [
            self::fieldDoc('q', 'string', 'Search path, route path, or error message.'),
            self::fieldDoc('scope', 'string', 'Filter by audit scope.'),
            self::fieldDoc('actor_user_id', 'string:uuid', 'Filter by actor user identifier.'),
            self::fieldDoc('limit', 'integer', 'Maximum rows to return.'),
            self::fieldDoc('offset', 'integer', 'Row offset.'),
        ];

        return self::resourceDoc('system_audit_logs', 'Audit Logs', 'governance', 'SystemAuditLog', 'system_audit_logs', 'Request and response audit trail rows.', $fields, $create, $update, $query, [
            self::endpointDoc('GET', '/api/v1/admin/audit-logs', 'List audit log rows.', [
                'resource_key' => 'system_audit_logs',
                'auth_required' => true,
                'permissions' => ['admin.audit_logs.view'],
                'query' => $query,
                'return_type' => 'SystemAuditLog[]',
            ]),
        ], '/api/v1/admin/audit-logs', true);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $createFields
     * @param array<int, array<string, mixed>> $updateFields
     * @param array<int, array<string, mixed>> $queryOptions
     * @param array<int, array<string, mixed>> $routes
     * @return array<string, mixed>
     */
    private static function resourceDoc(
        string $key,
        string $label,
        string $group,
        string $itemType,
        string $table,
        string $summary,
        array $fields,
        array $createFields,
        array $updateFields,
        array $queryOptions,
        array $routes,
        ?string $defaultDataPath = null,
        bool $defaultDataAuthRequired = false
    ): array {
        return [
            'key' => $key,
            'label' => $label,
            'group' => $group,
            'item_type' => $itemType,
            'table' => $table,
            'summary' => $summary,
            'default_data_path' => $defaultDataPath,
            'default_data_auth_required' => $defaultDataAuthRequired,
            'admin_surface_path' => self::adminSurfacePath($key, $routes),
            'fields' => array_values($fields),
            'create_fields' => array_values($createFields),
            'update_fields' => array_values($updateFields),
            'query_options' => array_values($queryOptions),
            'routes' => self::withSyntheticRoutes($routes),
        ];
    }

    /**
     * @param array<string, mixed> $resource
     * @return array<string, mixed>
     */
    private static function generatedResourceDoc(array $resource): array
    {
        $routes = [];
        foreach (array_values(is_array($resource['routes'] ?? null) ? $resource['routes'] : []) as $route) {
            if (!is_array($route)) {
                continue;
            }
            $route['resource_key'] = (string)($route['resource_key'] ?? $resource['key'] ?? '');
            $routes[] = $route;
        }

        return [
            'key' => (string)($resource['key'] ?? ''),
            'label' => (string)($resource['label'] ?? 'Generated Resource'),
            'group' => (string)($resource['group'] ?? 'generated'),
            'item_type' => (string)($resource['item_type'] ?? 'GeneratedResource'),
            'table' => (string)($resource['table'] ?? ''),
            'summary' => (string)($resource['summary'] ?? 'Generated starter resource.'),
            'default_data_path' => (string)($resource['default_data_path'] ?? ''),
            'default_data_auth_required' => (bool)($resource['default_data_auth_required'] ?? false),
            'admin_surface_path' => self::adminSurfacePath((string)($resource['key'] ?? ''), $routes),
            'fields' => array_values(is_array($resource['fields'] ?? null) ? $resource['fields'] : []),
            'create_fields' => array_values(is_array($resource['create_fields'] ?? null) ? $resource['create_fields'] : []),
            'update_fields' => array_values(is_array($resource['update_fields'] ?? null) ? $resource['update_fields'] : []),
            'query_options' => array_values(is_array($resource['query_options'] ?? null) ? $resource['query_options'] : []),
            'routes' => self::withSyntheticRoutes($routes),
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $routes
     */
    private static function adminSurfacePath(string $key, array $routes): string
    {
        foreach ($routes as $route) {
            if (!is_array($route) || strtoupper((string)($route['method'] ?? 'GET')) !== 'GET') {
                continue;
            }

            $request = is_array($route['request'] ?? null) ? $route['request'] : [];
            $pathParams = is_array($request['path_params'] ?? null) ? $request['path_params'] : [];
            if ($pathParams !== []) {
                continue;
            }

            $path = (string)($route['path'] ?? '');
            if (!str_starts_with($path, '/api/v1/admin/')) {
                continue;
            }
            if (str_contains($path, '/history') || str_contains($path, '/versions')) {
                continue;
            }

            return '/admin/' . ltrim(substr($path, strlen('/api/v1/admin/')), '/');
        }

        return '/admin?resource=' . rawurlencode($key);
    }

    /**
     * @param array<int, array<string, mixed>> $routes
     * @return array<int, array<string, mixed>>
     */
    private static function withSyntheticRoutes(array $routes): array
    {
        $output = array_values($routes);
        $existing = [];

        foreach ($output as $route) {
            $existing[strtoupper((string)($route['method'] ?? 'GET')) . ' ' . (string)($route['path'] ?? '')] = true;
        }

        $synthetic = [];
        foreach ($output as $route) {
            $method = strtoupper((string)($route['method'] ?? 'GET'));
            $path = (string)($route['path'] ?? '');
            if ($method === 'PUT' && !isset($existing['PATCH ' . $path])) {
                $patch = $route;
                $patch['method'] = 'PATCH';
                $patch['summary'] = self::patchSummary((string)($route['summary'] ?? ''));
                $synthetic[] = $patch;
                $existing['PATCH ' . $path] = true;
            }
        }

        return array_values(array_merge($output, $synthetic));
    }

    private static function patchSummary(string $summary): string
    {
        $clean = trim($summary);
        if ($clean === '') {
            return 'Partially update this endpoint.';
        }

        $updated = preg_replace('/^Update\s+/i', 'Partially update ', $clean, 1);
        if (is_string($updated) && $updated !== '') {
            return $updated;
        }

        return 'Partially update ' . lcfirst(rtrim($clean, '.')) . '.';
    }

    /**
     * @param array<string, mixed> $config
     * @return array<int, array<string, mixed>>
     */
    private static function fields(string $table, array $config = []): array
    {
        return DatabaseSchemaCatalog::apiFields($table, $config);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, string> $exclude
     * @return array<int, array<string, mixed>>
     */
    private static function bodyFields(array $fields, bool $create = true, array $exclude = []): array
    {
        $excluded = array_fill_keys($exclude, true);
        $body = [];

        foreach ($fields as $field) {
            if (($field['read_only'] ?? false) || isset($excluded[$field['name']])) {
                continue;
            }

            $body[] = self::decorateBodyField(self::fieldDoc(
                (string)$field['name'],
                self::fieldTypeLabel($field),
                (string)($field['description'] ?? ''),
                $create ? (bool)($field['required_on_create'] ?? false) : (bool)($field['required_on_update'] ?? false),
                is_array($field['options'] ?? null) ? $field['options'] : []
            ));
        }

        return $body;
    }

    /**
     * @param array<string, mixed> $field
     * @return array<string, mixed>
     */
    private static function decorateBodyField(array $field): array
    {
        $name = (string)($field['name'] ?? '');
        if ($name === '' || (string)($field['data_type'] ?? 'string') === 'file') {
            return $field;
        }

        $target = self::mediaUploadTargetForField($name);
        if ($target === null) {
            return $field;
        }

        $field['media_upload'] = [
            'endpoint' => '/api/v1/admin/media',
            'target' => $target,
            'default_access_scope' => 'public',
        ];

        return $field;
    }

    private static function mediaUploadTargetForField(string $fieldName): ?string
    {
        $normalized = strtolower(trim($fieldName));
        if ($normalized === 'media_asset_id' || str_ends_with($normalized, '_asset_id')) {
            return 'asset_id';
        }

        if (in_array($normalized, [
            'file_url',
            'media_url',
            'thumbnail_url',
            'cover_image_url',
            'featured_image_url',
            'hero_image_url',
        ], true)) {
            return 'asset_url';
        }

        return null;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, array<string, mixed>> $overrides
     * @return array<int, array<string, mixed>>
     */
    private static function withFieldOverrides(array $fields, array $overrides): array
    {
        foreach ($fields as &$field) {
            $name = (string)($field['name'] ?? '');
            if ($name !== '' && isset($overrides[$name])) {
                $field = array_merge($field, $overrides[$name]);
            }
        }
        unset($field);

        return $fields;
    }

    /**
     * @param array<string, mixed> $field
     */
    private static function fieldTypeLabel(array $field): string
    {
        $type = (string)($field['data_type'] ?? 'string');
        $format = $field['format'] ?? null;
        return $format ? $type . ':' . $format : $type;
    }

    /**
     * @param array<string, mixed> $config
     * @return array<string, mixed>
     */
    private static function endpointDoc(string $method, string $path, string $summary, array $config = []): array
    {
        $requestContentType = $config['content_type'] ?? (in_array($method, ['POST', 'PUT', 'PATCH'], true) ? 'application/json' : null);
        $responseContentType = $config['response_content_type'] ?? 'application/json; charset=UTF-8';
        $successStatus = (int)($config['status'] ?? ($method === 'POST' ? 201 : 200));
        $returnType = (string)($config['return_type'] ?? 'object');
        $envelope = (string)($config['envelope'] ?? ($responseContentType === 'application/json; charset=UTF-8' ? '{ data: ' . $returnType . ' }' : 'raw'));

        return [
            'method' => $method,
            'path' => $path,
            'summary' => $summary,
            'resource_key' => $config['resource_key'] ?? null,
            'auth_required' => (bool)($config['auth_required'] ?? false),
            'permissions' => array_values($config['permissions'] ?? []),
            'request' => [
                'content_type' => $requestContentType,
                'path_params' => array_values($config['path_params'] ?? []),
                'query' => array_values($config['query'] ?? []),
                'body' => array_values($config['body'] ?? []),
            ],
            'response' => [
                'content_type' => $responseContentType,
                'success_status' => $successStatus,
                'return_type' => $returnType,
                'envelope' => $envelope,
                'error_type' => '{ error: string }',
            ],
        ];
    }

    /**
     * @param array<int, string> $options
     * @return array<string, mixed>
     */
    private static function fieldDoc(string $name, string $type, string $description = '', bool $required = false, array $options = []): array
    {
        [$dataType, $format] = array_pad(explode(':', $type, 2), 2, null);
        return [
            'name' => $name,
            'data_type' => $dataType,
            'format' => $format,
            'required_on_create' => $required,
            'required_on_update' => false,
            'nullable' => !$required,
            'read_only' => false,
            'write_only' => false,
            'options' => array_values($options),
            'description' => $description,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function fallbackRouteDoc(string $method, string $path): array
    {
        return self::endpointDoc($method, $path, 'JSON endpoint.', [
            'auth_required' => str_contains($path, '/admin/') || str_contains($path, '/me'),
            'return_type' => 'json',
        ]);
    }
}
