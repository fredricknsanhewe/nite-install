<?php
namespace App\Console;

use App\Config\Env;
use App\Support\AppPresetCatalog;
use App\Support\EnvFileEditor;
use App\Support\NiteModuleCatalog;
use App\Support\ProjectRegistry;
use App\Support\StarterAppCatalog;
use App\Support\StarterSampleCatalog;
use App\Support\StarterSampleManager;
use PDO;
use RuntimeException;

final class AppBootstrapper
{
    private const ROOT_APP_BLUEPRINT_JSON = 'app.blueprint.json';
    private const ROOT_APP_BLUEPRINT_MD = 'docs/app-blueprint.md';

    public function __construct(
        private readonly string $rootPath,
        private readonly ConsoleIO $io,
        private readonly ProjectRegistry $projects,
        private readonly ScaffoldGenerator $scaffolds,
        private readonly MigrationManager $migrations
    ) {
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function bootstrap(?string $name, array $options = []): array
    {
        $withModules = $this->csvOption($options, 'with');
        $withoutModules = $this->csvOption($options, 'without');
        $extraResources = $this->csvOption($options, 'resources');
        $starterKey = trim((string)($options['starter'] ?? ''));
        $project = $this->resolveProject($name, $options);
        $starter = $starterKey !== ''
            ? StarterAppCatalog::resolve($starterKey, $withModules, $withoutModules, $extraResources, $this->rootPath)
            : null;
        $preset = $starter !== null
            ? [
                'key' => (string)($starter['preset'] ?? 'standard'),
                'title' => (string)($starter['preset_title'] ?? ''),
                'summary' => (string)($starter['preset_summary'] ?? ''),
                'modules' => array_values(is_array($starter['modules'] ?? null) ? $starter['modules'] : []),
                'operations' => array_values(is_array($starter['operations'] ?? null) ? $starter['operations'] : []),
                'resources' => array_values(is_array($starter['resources'] ?? null) ? $starter['resources'] : []),
            ]
            : AppPresetCatalog::resolve(
                (string)($options['preset'] ?? 'standard'),
                $withModules,
                $withoutModules,
                $extraResources
            );

        $runtimePaths = $this->runtimePaths($project);
        $hostEnvPath = (string)$runtimePaths['host_env'];
        $hostTemplatePath = (string)($runtimePaths['host_template'] ?? '');
        $dockerEnvPath = (string)$runtimePaths['docker_env'];
        $dockerTemplatePath = (string)($runtimePaths['docker_template'] ?? '');

        EnvFileEditor::ensureFile($hostEnvPath, $hostTemplatePath !== '' ? $hostTemplatePath : null);
        if ($dockerEnvPath !== '') {
            EnvFileEditor::ensureFile($dockerEnvPath, $dockerTemplatePath !== '' ? $dockerTemplatePath : null);
        }

        $currentHostEnv = EnvFileEditor::read($hostEnvPath);
        $currentDockerEnv = $dockerEnvPath !== '' ? EnvFileEditor::read($dockerEnvPath) : [];
        $runtime = $this->buildRuntimeConfig($name, $options, $project, $currentHostEnv, $currentDockerEnv, $preset);

        EnvFileEditor::upsert($hostEnvPath, $runtime['host_env']);
        if ($dockerEnvPath !== '') {
            EnvFileEditor::upsert($dockerEnvPath, $runtime['docker_env']);
        }

        if ($project !== null) {
            $project = $this->updateProjectManifest($project, $runtime, $name);
            $this->projects->apply((string)$project['slug']);
        } else {
            Env::apply($runtime['host_env'], true);
        }

        $resourceResults = $this->scaffoldPresetResources($preset, $options);
        $databaseProvision = $this->provisionDatabase($runtime['database'], $options);
        $databaseWork = $this->runDatabaseBootstrap($options);
        $samples = $this->prepareSamples($starter, $project, $options);

        $summary = [
            'generated_at' => gmdate('c'),
            'mode' => $project === null ? 'root' : 'project',
            'application' => [
                'name' => (string)$runtime['app_name'],
                'url' => (string)$runtime['app_url'],
                'project' => $project === null ? null : [
                    'slug' => (string)($project['slug'] ?? ''),
                    'name' => (string)($project['name'] ?? ''),
                    'port' => (int)($project['port'] ?? 0),
                    'manifest' => (string)($project['paths']['manifest'] ?? ''),
                ],
            ],
            'preset' => [
                'key' => (string)($preset['key'] ?? 'standard'),
                'title' => (string)($preset['title'] ?? ''),
                'summary' => (string)($preset['summary'] ?? ''),
                'operations' => array_values(is_array($preset['operations'] ?? null) ? $preset['operations'] : []),
            ],
            'starter' => $starter === null ? null : [
                'key' => (string)($starter['key'] ?? ''),
                'title' => (string)($starter['title'] ?? ''),
                'summary' => (string)($starter['summary'] ?? ''),
                'tags' => array_values(is_array($starter['tags'] ?? null) ? $starter['tags'] : []),
                'default_sample_count' => (int)($starter['default_sample_count'] ?? 0),
                'sample_packs' => array_values(array_map(
                    static fn (array $pack): array => [
                        'key' => (string)($pack['key'] ?? ''),
                        'title' => (string)($pack['title'] ?? ''),
                    ],
                    array_values(is_array($samples['packs'] ?? null) ? $samples['packs'] : [])
                )),
            ],
            'focus_modules' => $this->moduleBlueprint((array)($preset['modules'] ?? [])),
            'generated_resources' => $resourceResults,
            'samples' => [
                'count' => (int)($samples['count'] ?? 0),
                'packs' => array_values(is_array($samples['packs'] ?? null) ? $samples['packs'] : []),
                'files' => is_array($samples['files'] ?? null) ? $samples['files'] : [],
                'install' => is_array($samples['install'] ?? null) ? $samples['install'] : ['status' => 'skipped', 'detail' => 'No starter samples were installed.'],
            ],
            'environment' => [
                'host_env' => $hostEnvPath,
                'docker_env' => $dockerEnvPath,
                'host_keys' => array_keys($runtime['host_env']),
                'docker_keys' => array_keys($runtime['docker_env']),
            ],
            'database' => $runtime['database'] + [
                'provision' => $databaseProvision,
                'bootstrap' => $databaseWork,
            ],
            'storage' => [
                'driver' => (string)($runtime['host_env']['MEDIA_STORAGE_DRIVER'] ?? 'local'),
                'root' => (string)($runtime['host_env']['MEDIA_STORAGE_ROOT'] ?? ''),
                'prefix' => (string)($runtime['host_env']['MEDIA_STORAGE_PREFIX'] ?? ''),
            ],
            'security' => [
                'jwt_secret_generated' => (bool)($runtime['jwt_secret_generated'] ?? false),
                'app_debug' => (string)($runtime['host_env']['APP_DEBUG'] ?? 'true'),
                'browsable_api' => (string)($runtime['host_env']['NITE_BROWSABLE_API'] ?? 'true'),
                'html_interface' => (string)($runtime['host_env']['NITE_HTML_INTERFACE_ENABLED'] ?? 'true'),
                'audit_mode' => (string)($runtime['host_env']['SYSTEM_AUDIT_LOG_MODE'] ?? 'writes'),
            ],
            'recommended_commands' => $this->recommendedCommands($project),
            'notes' => [
                'Framework built-ins remain available even when this preset focuses on a smaller module subset.',
                'Generated resources live in src/Controllers, src/Services, src/Models, database/migrations, examples/generated, and routes/generated.',
                $starter !== null
                    ? 'Starter app `' . (string)($starter['key'] ?? '') . '` was resolved on top of preset `' . (string)($starter['preset'] ?? '') . '`.'
                    : '',
                (int)($samples['count'] ?? 0) > 0
                    ? 'Starter sample bundle generated with ' . (string)($samples['count'] ?? 0) . ' items for example browsing and AI context.'
                    : '',
                'Use OPTIONS and /api/v1/meta/routes?format=json for machine-readable route metadata.',
                (string)($runtime['docker_note'] ?? ''),
            ],
        ];

        $summary['notes'] = array_values(array_filter(
            array_map('strval', is_array($summary['notes'] ?? null) ? $summary['notes'] : []),
            static fn (string $value): bool => trim($value) !== ''
        ));

        $summary['blueprint_files'] = $this->writeBlueprintFiles($summary, $project);

        return $summary;
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>|null
     */
    private function resolveProject(?string $name, array $options): ?array
    {
        $slug = trim((string)($options['project'] ?? $options['slug'] ?? ''));
        if ($slug === '') {
            return null;
        }

        $project = $this->projects->find($slug);
        if ($project !== null) {
            if (array_key_exists('port', $options) || array_key_exists('host', $options)) {
                $this->io->warn('Existing project host and port remain controlled by projects/' . $slug . '/project.json.');
            }
            return $project;
        }

        $displayName = trim((string)($name ?? ''));
        if ($displayName === '') {
            $displayName = $this->humanize(ConsoleSupport::kebab($slug));
        }

        $projectOptions = [];
        foreach (['slug', 'host', 'port', 'app-url', 'db-name', 'media-root'] as $key) {
            if (array_key_exists($key, $options)) {
                $projectOptions[$key] = $options[$key];
            }
        }

        return $this->projects->create($displayName, $projectOptions);
    }

    /**
     * @param array<string, mixed>|null $project
     * @return array<string, string>
     */
    private function runtimePaths(?array $project): array
    {
        if ($project === null) {
            return [
                'host_env' => $this->rootPath . '/.env',
                'host_template' => $this->rootPath . '/.env.example',
                'docker_env' => $this->rootPath . '/.env.docker',
                'docker_template' => $this->rootPath . '/.env.docker.example',
            ];
        }

        $paths = is_array($project['paths'] ?? null) ? $project['paths'] : [];
        return [
            'host_env' => (string)($paths['env'] ?? ''),
            'host_template' => (string)($paths['env_example'] ?? ''),
            'docker_env' => (string)($paths['docker_env'] ?? ''),
            'docker_template' => (string)($paths['docker_env_example'] ?? ''),
        ];
    }

    /**
     * @param array<string, string> $currentHostEnv
     * @param array<string, string> $currentDockerEnv
     * @param array<string, mixed> $preset
     * @param array<string, mixed> $options
     * @param array<string, mixed>|null $project
     * @return array<string, mixed>
     */
    private function buildRuntimeConfig(
        ?string $name,
        array $options,
        ?array $project,
        array $currentHostEnv,
        array $currentDockerEnv,
        array $preset
    ): array {
        $appName = trim((string)($name ?? ''));
        if ($appName === '') {
            if ($project !== null) {
                $appName = trim((string)($project['name'] ?? ''));
            }
        }
        if ($appName === '') {
            $appName = $this->humanize(basename($this->rootPath));
        }
        if ($appName === '') {
            $appName = 'Nite Application';
        }

        $projectSlug = $project === null ? '' : (string)($project['slug'] ?? '');
        $projectPort = $project === null ? 0 : (int)($project['port'] ?? 0);
        $serverPort = $projectPort > 0 ? $projectPort : (int)($options['port'] ?? (int)($currentDockerEnv['APP_PORT'] ?? 8185));

        $appUrl = trim((string)($options['app-url'] ?? ''));
        if ($appUrl === '') {
            $appUrl = trim((string)($currentHostEnv['APP_URL'] ?? ''));
        }
        if ($appUrl === '') {
            if ($project !== null) {
                $appUrl = trim((string)($project['app_url'] ?? ''));
            }
        }
        if ($appUrl === '') {
            $appUrl = 'http://127.0.0.1:' . max(1, $serverPort);
        }

        $dbDriver = strtolower(trim((string)($options['db-driver'] ?? ($currentHostEnv['DB_DRIVER'] ?? 'pgsql'))));
        if (!in_array($dbDriver, ['pgsql', 'mysql'], true)) {
            throw new RuntimeException('Unsupported DB driver: ' . $dbDriver . '. Supported drivers: pgsql, mysql.');
        }

        $defaultDbPort = $dbDriver === 'mysql' ? '3306' : '5432';
        $dbNameDefault = $projectSlug !== ''
            ? ('nite_' . str_replace('-', '_', $projectSlug))
            : 'nite';
        $mediaRootDefault = $projectSlug !== ''
            ? ('storage/projects/' . $projectSlug . '/media')
            : 'storage/media';

        $jwtSecret = trim((string)($options['jwt-secret'] ?? ($currentHostEnv['JWT_SECRET'] ?? '')));
        $jwtGenerated = false;
        if ($jwtSecret === '' || in_array($jwtSecret, ['change-me', 'unsafe-default'], true)) {
            $jwtSecret = bin2hex(random_bytes(32));
            $jwtGenerated = true;
        }

        $hostEnv = [
            'APP_ENV' => trim((string)($currentHostEnv['APP_ENV'] ?? 'local')) ?: 'local',
            'APP_DEBUG' => $this->boolString($this->boolOption($options, 'debug', $this->envBool($currentHostEnv, 'APP_DEBUG', true))),
            'APP_URL' => $appUrl,
            'NITE_BROWSABLE_API' => $this->boolString($this->envBool($currentHostEnv, 'NITE_BROWSABLE_API', true)),
            'NITE_HTML_INTERFACE_ENABLED' => $this->boolString($this->envBool($currentHostEnv, 'NITE_HTML_INTERFACE_ENABLED', true)),
            'JWT_SECRET' => $jwtSecret,
            'JWT_TTL_SECONDS' => trim((string)($currentHostEnv['JWT_TTL_SECONDS'] ?? '28800')) ?: '28800',
            'DB_DRIVER' => $dbDriver,
            'DB_HOST' => trim((string)($options['db-host'] ?? ($currentHostEnv['DB_HOST'] ?? '127.0.0.1'))) ?: '127.0.0.1',
            'DB_PORT' => trim((string)($options['db-port'] ?? ($currentHostEnv['DB_PORT'] ?? $defaultDbPort))) ?: $defaultDbPort,
            'DB_NAME' => trim((string)($options['db-name'] ?? ($currentHostEnv['DB_NAME'] ?? $dbNameDefault))) ?: $dbNameDefault,
            'DB_USER' => trim((string)($options['db-user'] ?? ($currentHostEnv['DB_USER'] ?? ($dbDriver === 'mysql' ? 'root' : 'postgres'))))
                ?: ($dbDriver === 'mysql' ? 'root' : 'postgres'),
            'DB_PASSWORD' => (string)($options['db-password'] ?? ($currentHostEnv['DB_PASSWORD'] ?? ($dbDriver === 'pgsql' ? 'postgres' : ''))),
            'DB_TIMEOUT_SECONDS' => trim((string)($currentHostEnv['DB_TIMEOUT_SECONDS'] ?? '5')) ?: '5',
            'CORS_ALLOWED_ORIGINS' => trim((string)($currentHostEnv['CORS_ALLOWED_ORIGINS'] ?? 'http://localhost:4200,http://127.0.0.1:4200'))
                ?: 'http://localhost:4200,http://127.0.0.1:4200',
            'SYSTEM_AUDIT_LOG_MODE' => trim((string)($currentHostEnv['SYSTEM_AUDIT_LOG_MODE'] ?? 'writes')) ?: 'writes',
            'UPLOAD_PUBLIC_BASE' => trim((string)($currentHostEnv['UPLOAD_PUBLIC_BASE'] ?? '/uploads')) ?: '/uploads',
            'MEDIA_STORAGE_DRIVER' => strtolower(trim((string)($options['media-driver'] ?? ($currentHostEnv['MEDIA_STORAGE_DRIVER'] ?? 'local')))) ?: 'local',
            'MEDIA_STORAGE_ROOT' => trim((string)($options['media-root'] ?? ($currentHostEnv['MEDIA_STORAGE_ROOT'] ?? $mediaRootDefault))) ?: $mediaRootDefault,
            'MEDIA_STORAGE_PREFIX' => trim((string)($options['media-prefix'] ?? ($currentHostEnv['MEDIA_STORAGE_PREFIX'] ?? $projectSlug))),
        ];

        if ($projectSlug !== '') {
            $hostEnv['NITE_PROJECT'] = $projectSlug;
            $hostEnv['NITE_PROJECT_NAME'] = $appName;
        }

        $dockerEnv = [
            'APP_ENV' => $hostEnv['APP_ENV'],
            'APP_DEBUG' => $hostEnv['APP_DEBUG'],
            'APP_URL' => $appUrl,
            'NITE_BROWSABLE_API' => $hostEnv['NITE_BROWSABLE_API'],
            'NITE_HTML_INTERFACE_ENABLED' => $hostEnv['NITE_HTML_INTERFACE_ENABLED'],
            'JWT_SECRET' => $jwtSecret,
            'APP_PORT' => (string)max(1, $serverPort),
            'MEDIA_STORAGE_ROOT' => $hostEnv['MEDIA_STORAGE_ROOT'],
        ];

        if ($projectSlug !== '') {
            $dockerEnv['NITE_PROJECT'] = $projectSlug;
            $dockerEnv['NITE_PROJECT_NAME'] = $appName;
            $dockerEnv['NITE_DOCKER_RUNTIME'] = 'true';
        }

        $dockerDbConfigured = false;
        $dockerNote = '';
        if ($dbDriver === 'pgsql') {
            $postgresHostPort = trim((string)($currentDockerEnv['POSTGRES_HOST_PORT'] ?? ($project['docker']['postgres_host_port'] ?? '55440')));
            $dockerEnv += [
                'DB_DRIVER' => 'pgsql',
                'DB_HOST' => 'postgres',
                'DB_PORT' => '5432',
                'DB_NAME' => $hostEnv['DB_NAME'],
                'DB_USER' => $hostEnv['DB_USER'],
                'DB_PASSWORD' => $hostEnv['DB_PASSWORD'],
                'POSTGRES_DB' => $hostEnv['DB_NAME'],
                'POSTGRES_USER' => $hostEnv['DB_USER'],
                'POSTGRES_PASSWORD' => $hostEnv['DB_PASSWORD'],
                'POSTGRES_HOST_PORT' => $postgresHostPort !== '' ? $postgresHostPort : '55440',
            ];
            $dockerDbConfigured = true;
        } else {
            $dockerNote = 'Docker env database values were left as-is because the bundled compose templates are PostgreSQL-first. Host runtime is fully configured for ' . $dbDriver . '.';
        }

        return [
            'app_name' => $appName,
            'app_url' => $appUrl,
            'preset' => $preset,
            'host_env' => $hostEnv,
            'docker_env' => $dockerEnv,
            'docker_db_configured' => $dockerDbConfigured,
            'docker_note' => $dockerNote,
            'jwt_secret_generated' => $jwtGenerated,
            'database' => [
                'driver' => $dbDriver,
                'host' => $hostEnv['DB_HOST'],
                'port' => $hostEnv['DB_PORT'],
                'name' => $hostEnv['DB_NAME'],
                'user' => $hostEnv['DB_USER'],
                'docker_db_configured' => $dockerDbConfigured,
            ],
        ];
    }

    /**
     * @param array<string, mixed> $project
     * @param array<string, mixed> $runtime
     * @return array<string, mixed>
     */
    private function updateProjectManifest(array $project, array $runtime, ?string $name): array
    {
        $manifestPath = (string)($project['paths']['manifest'] ?? '');
        if ($manifestPath === '' || !is_file($manifestPath)) {
            return $project;
        }

        $decoded = json_decode((string)file_get_contents($manifestPath), true);
        if (!is_array($decoded)) {
            return $project;
        }

        $hostEnv = is_array($runtime['host_env'] ?? null) ? $runtime['host_env'] : [];
        $displayName = trim((string)($name ?? ''));
        if ($displayName === '') {
            $displayName = (string)($project['name'] ?? '');
        }
        if ($displayName !== '') {
            $decoded['name'] = $displayName;
        }

        if (($hostEnv['APP_URL'] ?? '') !== '') {
            $decoded['app_url'] = (string)$hostEnv['APP_URL'];
        }

        $decoded['env'] = is_array($decoded['env'] ?? null) ? $decoded['env'] : [];
        foreach (['NITE_PROJECT', 'NITE_PROJECT_NAME', 'APP_URL', 'DB_NAME', 'MEDIA_STORAGE_ROOT'] as $key) {
            if (($hostEnv[$key] ?? '') === '') {
                continue;
            }
            $decoded['env'][$key] = (string)$hostEnv[$key];
        }

        $encoded = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode updated project manifest: ' . $manifestPath);
        }
        if (file_put_contents($manifestPath, $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write updated project manifest: ' . $manifestPath);
        }

        return $this->projects->require((string)($project['slug'] ?? ''));
    }

    /**
     * @param array<string, mixed> $preset
     * @param array<string, mixed> $options
     * @return array<int, array<string, mixed>>
     */
    private function scaffoldPresetResources(array $preset, array $options): array
    {
        $results = [];
        $force = $this->boolOption($options, 'force', false);
        $backup = $this->boolOption($options, 'backup', false);

        foreach (array_values(is_array($preset['resources'] ?? null) ? $preset['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }

            $name = trim((string)($resource['name'] ?? ''));
            if ($name === '') {
                continue;
            }

            $scaffoldOptions = array_merge($options, [
                'label' => trim((string)($resource['label'] ?? '')),
                'group' => trim((string)($resource['group'] ?? 'generated')) ?: 'generated',
                'item-type' => trim((string)($resource['item_type'] ?? ConsoleSupport::studly($name))) ?: ConsoleSupport::studly($name),
                'summary' => trim((string)($resource['summary'] ?? 'Generated starter resource scaffolded during app bootstrap.')),
            ]);

            $conflicts = $this->scaffolds->conflictPaths('resource', $name, isset($scaffoldOptions['table']) ? (string)$scaffoldOptions['table'] : null);
            if ($conflicts !== [] && !$force && !$backup) {
                $results[] = $this->resourceDescriptor($resource, 'existing', $conflicts);
                continue;
            }

            $result = $this->scaffolds->create('resource', $name, $scaffoldOptions);
            $results[] = $this->resourceDescriptor($resource, 'created', array_values(is_array($result['written'] ?? null) ? $result['written'] : []));
        }

        return $results;
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<int, string> $paths
     * @return array<string, mixed>
     */
    private function resourceDescriptor(array $resource, string $status, array $paths): array
    {
        $name = ConsoleSupport::studly((string)($resource['name'] ?? ''));
        $table = ConsoleSupport::pluralize(ConsoleSupport::snake($name));
        $routeSegment = ConsoleSupport::kebab($table);

        return [
            'name' => $name,
            'label' => trim((string)($resource['label'] ?? '')) ?: $this->humanize($name),
            'summary' => trim((string)($resource['summary'] ?? '')),
            'status' => $status,
            'table' => $table,
            'route_segment' => $routeSegment,
            'public_path' => '/api/v1/' . $routeSegment,
            'admin_path' => '/api/v1/admin/' . $routeSegment,
            'paths' => $paths,
        ];
    }

    /**
     * @param array<string, mixed> $database
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function provisionDatabase(array $database, array $options): array
    {
        $enabled = $this->boolOption($options, 'provision-db', true);
        if (!$enabled) {
            return ['status' => 'skipped', 'detail' => 'Database provisioning was disabled.'];
        }

        $driver = strtolower(trim((string)($database['driver'] ?? '')));
        $host = trim((string)($database['host'] ?? ''));
        $port = trim((string)($database['port'] ?? ''));
        $name = trim((string)($database['name'] ?? ''));
        $user = trim((string)($options['db-admin-user'] ?? ($database['user'] ?? '')));
        $password = (string)($options['db-admin-password'] ?? ($options['db-password'] ?? ''));

        if ($driver === '' || $host === '' || $port === '' || $name === '' || $user === '') {
            return ['status' => 'skipped', 'detail' => 'Database provisioning skipped because the effective connection settings are incomplete.'];
        }

        try {
            if ($driver === 'pgsql') {
                $adminDb = trim((string)($options['db-admin-name'] ?? 'postgres')) ?: 'postgres';
                $pdo = new PDO(
                    'pgsql:host=' . $host . ';port=' . $port . ';dbname=' . $adminDb,
                    $user,
                    $password,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                $statement = $pdo->prepare('SELECT 1 FROM pg_database WHERE datname = :name LIMIT 1');
                $statement->execute([':name' => $name]);
                if ($statement->fetchColumn() !== false) {
                    return ['status' => 'exists', 'detail' => 'PostgreSQL database already exists.'];
                }

                $pdo->exec('CREATE DATABASE "' . str_replace('"', '""', $name) . '"');
                return ['status' => 'created', 'detail' => 'PostgreSQL database created.'];
            }

            if ($driver === 'mysql') {
                $pdo = new PDO(
                    'mysql:host=' . $host . ';port=' . $port . ';charset=utf8mb4',
                    $user,
                    $password,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '``', $name) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                return ['status' => 'created_or_exists', 'detail' => 'MySQL database ensured.'];
            }

            return ['status' => 'skipped', 'detail' => 'Unsupported driver for provisioning: ' . $driver];
        } catch (\Throwable $e) {
            return ['status' => 'warning', 'detail' => 'Database provisioning could not complete: ' . $e->getMessage()];
        }
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function runDatabaseBootstrap(array $options): array
    {
        $migrate = $this->boolOption($options, 'migrate', true);
        $seed = $this->boolOption($options, 'seed', true);

        if (!$migrate && !$seed) {
            return [
                'migrated' => false,
                'seeded' => false,
                'detail' => 'Database migrations and seeds were skipped.',
            ];
        }

        if ($seed) {
            $result = $this->migrations->seed($migrate);
            return [
                'migrated' => (bool)$migrate,
                'seeded' => true,
                'detail' => 'Seed script completed.',
                'result' => $result,
            ];
        }

        $result = $this->migrations->migrate(true);
        return [
            'migrated' => true,
            'seeded' => false,
            'detail' => 'Migrations completed.',
            'result' => $result,
        ];
    }

    /**
     * @param array<string, mixed>|null $starter
     * @param array<string, mixed>|null $project
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function prepareSamples(?array $starter, ?array $project, array $options): array
    {
        if ($starter === null) {
            return [
                'count' => 0,
                'packs' => [],
                'files' => [],
                'install' => ['status' => 'skipped', 'detail' => 'No starter app selected, so no starter samples were generated.'],
            ];
        }

        $requestedPacks = $this->csvOption($options, 'sample-packs');
        $requestedCount = array_key_exists('sample-count', $options) ? max(0, (int)$options['sample-count']) : null;
        $bundle = StarterSampleCatalog::generateBundle($starter, $requestedPacks, $requestedCount, $this->rootPath);

        if ((int)($bundle['count'] ?? 0) < 1) {
            return [
                'count' => 0,
                'packs' => array_values(is_array($bundle['packs'] ?? null) ? $bundle['packs'] : []),
                'files' => [],
                'install' => ['status' => 'skipped', 'detail' => 'Starter sample generation returned no items.'],
            ];
        }

        $manager = new StarterSampleManager($this->rootPath);
        $files = $manager->writeBundle($bundle, $project);

        $installSamples = $this->boolOption(
            $options,
            'install-samples',
            $this->boolOption($options, 'seed', true)
        );
        if (!$installSamples) {
            return [
                'count' => (int)($bundle['count'] ?? 0),
                'packs' => array_values(is_array($bundle['packs'] ?? null) ? $bundle['packs'] : []),
                'files' => $files,
                'install' => ['status' => 'skipped', 'detail' => 'Starter samples were generated to files only.'],
            ];
        }

        try {
            $install = $manager->installBundle($bundle);
        } catch (\Throwable $e) {
            $install = [
                'status' => 'warning',
                'detail' => 'Starter samples could not be installed into the database: ' . $e->getMessage(),
                'installed' => 0,
            ];
        }

        return [
            'count' => (int)($bundle['count'] ?? 0),
            'packs' => array_values(is_array($bundle['packs'] ?? null) ? $bundle['packs'] : []),
            'files' => $files,
            'install' => $install,
        ];
    }

    /**
     * @param array<int, string> $modules
     * @return array<int, array<string, mixed>>
     */
    private function moduleBlueprint(array $modules): array
    {
        $items = [];
        foreach ($modules as $moduleKey) {
            $module = NiteModuleCatalog::moduleByKey($moduleKey);
            if ($module === null) {
                continue;
            }
            $items[] = [
                'key' => $moduleKey,
                'title' => trim((string)($module['title'] ?? $moduleKey)),
                'summary' => trim((string)($module['summary'] ?? '')),
                'entities' => array_values(is_array($module['entities'] ?? null) ? $module['entities'] : []),
            ];
        }

        return $items;
    }

    /**
     * @param array<string, mixed> $summary
     * @param array<string, mixed>|null $project
     * @return array<string, string>
     */
    private function writeBlueprintFiles(array $summary, ?array $project): array
    {
        if ($project === null) {
            $jsonPath = $this->rootPath . '/' . self::ROOT_APP_BLUEPRINT_JSON;
            $markdownPath = $this->rootPath . '/' . self::ROOT_APP_BLUEPRINT_MD;
        } else {
            $directory = (string)($project['paths']['directory'] ?? '');
            $jsonPath = $directory . '/app.blueprint.json';
            $markdownPath = $directory . '/app-blueprint.md';
        }

        ConsoleSupport::ensureDirectory(dirname($jsonPath));
        ConsoleSupport::ensureDirectory(dirname($markdownPath));

        $encoded = json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode app blueprint JSON.');
        }

        if (file_put_contents($jsonPath, $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write app blueprint JSON: ' . $jsonPath);
        }
        if (file_put_contents($markdownPath, $this->renderBlueprintMarkdown($summary)) === false) {
            throw new RuntimeException('Failed to write app blueprint markdown: ' . $markdownPath);
        }

        return [
            'json' => $jsonPath,
            'markdown' => $markdownPath,
        ];
    }

    /**
     * @param array<string, mixed> $summary
     */
    private function renderBlueprintMarkdown(array $summary): string
    {
        $application = is_array($summary['application'] ?? null) ? $summary['application'] : [];
        $preset = is_array($summary['preset'] ?? null) ? $summary['preset'] : [];
        $starter = is_array($summary['starter'] ?? null) ? $summary['starter'] : [];
        $database = is_array($summary['database'] ?? null) ? $summary['database'] : [];
        $storage = is_array($summary['storage'] ?? null) ? $summary['storage'] : [];
        $samples = is_array($summary['samples'] ?? null) ? $summary['samples'] : [];
        $project = is_array($application['project'] ?? null) ? $application['project'] : [];

        $lines = [
            '# App Blueprint',
            '',
            'Generated: ' . (string)($summary['generated_at'] ?? ''),
            '',
            '## Identity',
            '',
            '- Name: ' . (string)($application['name'] ?? 'Nite Application'),
            '- Mode: ' . (string)($summary['mode'] ?? 'root'),
            '- URL: ' . (string)($application['url'] ?? ''),
            '- Preset: ' . (string)($preset['title'] ?? '') . ' (`' . (string)($preset['key'] ?? '') . '`)',
            '- Preset summary: ' . (string)($preset['summary'] ?? ''),
        ];

        if ($starter !== []) {
            $lines[] = '- Starter app: ' . (string)($starter['title'] ?? '') . ' (`' . (string)($starter['key'] ?? '') . '`)';
            $lines[] = '- Starter summary: ' . (string)($starter['summary'] ?? '');
        }

        if ($project !== []) {
            $lines[] = '- Project slug: ' . (string)($project['slug'] ?? '');
            $lines[] = '- Project port: ' . (string)($project['port'] ?? '');
            $lines[] = '- Project manifest: `' . (string)($project['manifest'] ?? '') . '`';
        }

        $lines[] = '';
        $lines[] = '## Focus Modules';
        $lines[] = '';
        foreach (array_values(is_array($summary['focus_modules'] ?? null) ? $summary['focus_modules'] : []) as $module) {
            if (!is_array($module)) {
                continue;
            }
            $lines[] = '- `' . (string)($module['key'] ?? '') . '` ' . (string)($module['title'] ?? '') . ': ' . (string)($module['summary'] ?? '');
        }

        $lines[] = '';
        $lines[] = '## Generated Resources';
        $lines[] = '';
        foreach (array_values(is_array($summary['generated_resources'] ?? null) ? $summary['generated_resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $lines[] = '- `' . (string)($resource['name'] ?? '') . '` [' . (string)($resource['status'] ?? '') . '] '
                . (string)($resource['summary'] ?? '')
                . ' Public: `' . (string)($resource['public_path'] ?? '') . '` Admin: `' . (string)($resource['admin_path'] ?? '') . '`';
        }

        $lines[] = '';
        $lines[] = '## Starter Samples';
        $lines[] = '';
        $lines[] = '- Count: ' . (string)($samples['count'] ?? 0);
        if ((int)($samples['count'] ?? 0) > 0) {
            foreach (array_values(is_array($samples['packs'] ?? null) ? $samples['packs'] : []) as $pack) {
                if (!is_array($pack)) {
                    continue;
                }
                $lines[] = '- Pack: `' . (string)($pack['key'] ?? '') . '` ' . (string)($pack['title'] ?? '');
            }

            $files = is_array($samples['files'] ?? null) ? $samples['files'] : [];
            if ($files !== []) {
                $lines[] = '- Sample JSON: `' . (string)($files['json'] ?? '') . '`';
                $lines[] = '- Sample Markdown: `' . (string)($files['markdown'] ?? '') . '`';
            }

            $install = is_array($samples['install'] ?? null) ? $samples['install'] : [];
            if ($install !== []) {
                $lines[] = '- Install: ' . (string)($install['status'] ?? '') . ' - ' . (string)($install['detail'] ?? '');
            }
        }

        $lines[] = '';
        $lines[] = '## Runtime';
        $lines[] = '';
        $lines[] = '- Host env: `' . (string)((is_array($summary['environment'] ?? null) ? $summary['environment']['host_env'] : '') ?? '') . '`';
        $lines[] = '- Docker env: `' . (string)((is_array($summary['environment'] ?? null) ? $summary['environment']['docker_env'] : '') ?? '') . '`';
        $lines[] = '- Database: `' . (string)($database['driver'] ?? '') . '` on `' . (string)($database['host'] ?? '') . ':' . (string)($database['port'] ?? '') . '` using database `' . (string)($database['name'] ?? '') . '`';
        $lines[] = '- Storage: `' . (string)($storage['driver'] ?? 'local') . '` at `' . (string)($storage['root'] ?? '') . '`';

        $lines[] = '';
        $lines[] = '## Commands';
        $lines[] = '';
        foreach (array_values(is_array($summary['recommended_commands'] ?? null) ? $summary['recommended_commands'] : []) as $command) {
            $lines[] = '- `' . (string)$command . '`';
        }

        $lines[] = '';
        $lines[] = '## Notes';
        $lines[] = '';
        foreach (array_values(is_array($summary['notes'] ?? null) ? $summary['notes'] : []) as $note) {
            $lines[] = '- ' . (string)$note;
        }

        $lines[] = '';
        return implode(PHP_EOL, $lines);
    }

    /**
     * @param array<string, mixed>|null $project
     * @return array<int, string>
     */
    private function recommendedCommands(?array $project): array
    {
        if ($project !== null) {
            $slug = (string)($project['slug'] ?? '');
            return [
                'php nite starter:list',
                'php nite app:doctor --project=' . $slug,
                'php nite route:list --project=' . $slug,
                'php nite app:serve --project=' . $slug,
                'php nite db:migrate --project=' . $slug,
                'php nite db:seed --project=' . $slug,
            ];
        }

        return [
            'php nite starter:list',
            'php nite app:doctor',
            'php nite route:list',
            'php nite app:serve --host=127.0.0.1 --port=8185',
            'php nite db:migrate',
            'php nite db:seed',
        ];
    }

    /**
     * @param array<string, mixed> $options
     * @return array<int, string>
     */
    private function csvOption(array $options, string $key): array
    {
        $value = trim((string)($options[$key] ?? ''));
        if ($value === '') {
            return [];
        }

        return array_values(array_filter(
            array_map(static fn (string $item): string => trim($item), explode(',', $value)),
            static fn (string $item): bool => $item !== ''
        ));
    }

    /**
     * @param array<string, mixed> $options
     */
    private function boolOption(array $options, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $options)) {
            return $default;
        }

        return (bool)$options[$key];
    }

    /**
     * @param array<string, string> $values
     */
    private function envBool(array $values, string $key, bool $default): bool
    {
        $value = strtolower(trim((string)($values[$key] ?? '')));
        if ($value === '') {
            return $default;
        }

        return in_array($value, ['1', 'true', 'yes', 'on'], true);
    }

    private function boolString(bool $value): string
    {
        return $value ? 'true' : 'false';
    }

    private function humanize(string $value): string
    {
        $parts = array_values(array_filter(
            preg_split('/[^a-z0-9]+/i', trim($value)) ?: [],
            static fn (string $part): bool => $part !== ''
        ));

        return implode(' ', array_map(static fn (string $part): string => ucfirst(strtolower($part)), $parts));
    }
}
