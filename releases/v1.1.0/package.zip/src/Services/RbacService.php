<?php
namespace App\Services;

use App\Config\PermissionCatalog;
use App\Config\Roles;
use App\Models\RbacModel;
use App\Models\UserModel;
use RuntimeException;

final class RbacService
{
    private RbacModel $rbac;
    private UserModel $users;
    /** @var array<string, array<int, string>> */
    private static array $effectivePermissionCache = [];

    public function __construct()
    {
        $this->rbac = new RbacModel();
        $this->users = new UserModel();
    }

    public function bootstrap(): void
    {
        $this->rbac->upsertPermissions(PermissionCatalog::definitions());
    }

    /**
     * @return array<int, string>
     */
    public function roles(): array
    {
        return Roles::all();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function permissions(): array
    {
        $this->bootstrap();
        return PermissionCatalog::definitions();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function matrix(): array
    {
        $this->bootstrap();
        $roleRules = $this->rbac->listAllRoleRuleStates();
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $row = $definition;
            foreach (Roles::all() as $role) {
                $default = PermissionCatalog::isGrantedByDefault($role, (string)$definition['code']);
                $state = $roleRules[$definition['code']][$role] ?? 'inherit';
                $row[$role . '_default'] = $default;
                $row[$role . '_state'] = $state;
                $row[$role] = $this->applyState($default, $state);
            }
            $rows[] = $row;
        }
        return $rows;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function groups(array $filters = []): array
    {
        $this->bootstrap();
        return $this->rbac->listGroups($filters);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function group(string $groupId): ?array
    {
        $this->bootstrap();
        return $this->rbac->findGroupById($groupId);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createGroup(array $data, string $actorUserId = ''): array
    {
        $this->bootstrap();
        $payload = $this->normalizeGroupPayload($data, true);
        if ($actorUserId !== '') {
            $payload['created_by_user_id'] = $actorUserId;
            $payload['updated_by_user_id'] = $actorUserId;
        }
        self::$effectivePermissionCache = [];
        return $this->rbac->createGroup($payload);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>|null
     */
    public function updateGroup(string $groupId, array $data, string $actorUserId = ''): ?array
    {
        $this->bootstrap();
        $payload = $this->normalizeGroupPayload($data, false, $groupId);
        if ($actorUserId !== '') {
            $payload['updated_by_user_id'] = $actorUserId;
        }
        $group = $this->rbac->updateGroup($groupId, $payload);
        self::$effectivePermissionCache = [];
        return $group;
    }

    public function deleteGroup(string $groupId): bool
    {
        $this->bootstrap();
        $deleted = $this->rbac->deleteGroup($groupId);
        if ($deleted) {
            self::$effectivePermissionCache = [];
        }
        return $deleted;
    }

    /**
     * @return array{group: array<string, mixed>, members: array<int, array<string, mixed>>}|null
     */
    public function groupMembers(string $groupId): ?array
    {
        $this->bootstrap();
        $group = $this->rbac->findGroupById($groupId);
        if ($group === null) {
            return null;
        }

        return [
            'group' => $group,
            'members' => $this->rbac->listGroupMembers($groupId),
        ];
    }

    /**
     * @param array<int, string> $userIds
     * @return array{group: array<string, mixed>, members: array<int, array<string, mixed>>}|null
     */
    public function setGroupMembers(string $groupId, array $userIds): ?array
    {
        $this->bootstrap();
        if (!$this->rbac->replaceGroupMembers($groupId, $userIds)) {
            return null;
        }
        self::$effectivePermissionCache = [];
        return $this->groupMembers($groupId);
    }

    /**
     * @return array{group: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function groupPermissions(string $groupId): ?array
    {
        $this->bootstrap();
        $group = $this->rbac->findGroupById($groupId);
        if ($group === null) {
            return null;
        }

        $states = $this->rbac->listGroupRuleStates($groupId);
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $rows[] = array_merge($definition, [
                'group_state' => $states[$code] ?? 'inherit',
            ]);
        }

        return [
            'group' => $group,
            'rows' => $rows,
        ];
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array{group: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function setGroupPermissions(string $groupId, array $statesByCode): ?array
    {
        $this->bootstrap();
        $validated = $this->validateStateMap($statesByCode);
        if (!$this->rbac->replaceGroupRules($groupId, $validated)) {
            return null;
        }
        self::$effectivePermissionCache = [];
        return $this->groupPermissions($groupId);
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>
     */
    public function setRolePermissions(string $role, array $statesByCode): array
    {
        if (!in_array($role, Roles::all(), true)) {
            throw new RuntimeException('Invalid role supplied.');
        }
        $this->bootstrap();
        $validated = $this->validateStateMap($statesByCode);
        $this->rbac->replaceRoleRules($role, $validated);
        self::$effectivePermissionCache = [];
        return $this->rbac->listRoleRuleStates($role);
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>|null
     */
    public function setUserOverrides(string $userId, array $statesByCode): ?array
    {
        $this->bootstrap();
        if ($this->users->findById($userId) === null) {
            return null;
        }
        $validated = $this->validateStateMap($statesByCode);
        $this->rbac->replaceUserOverrides($userId, $validated);
        self::$effectivePermissionCache = [];
        return $this->rbac->listUserOverrideStates($userId);
    }

    /**
     * @return array{user: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function userOverrides(string $userId): ?array
    {
        $this->bootstrap();
        $user = $this->users->findById($userId);
        if ($user === null) {
            return null;
        }
        $role = (string)$user['role'];
        $roleStates = $this->rbac->listRoleRuleStates($role);
        $groupStates = $this->rbac->listUserGroupRuleStates($userId);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $roleDefault = PermissionCatalog::isGrantedByDefault($role, $code);
            $roleState = $roleStates[$code] ?? 'inherit';
            $roleAllowed = $this->applyState($roleDefault, $roleState);
            $groupState = $groupStates[$code] ?? 'inherit';
            $groupAllowed = $this->applyState($roleAllowed, $groupState);
            $userState = $userStates[$code] ?? 'inherit';
            $rows[] = array_merge($definition, [
                'role_default' => $roleDefault,
                'role_state' => $roleState,
                'role_allowed' => $roleAllowed,
                'group_state' => $groupState,
                'group_allowed' => $groupAllowed,
                'user_state' => $userState,
                'effective' => $this->applyState($groupAllowed, $userState),
            ]);
        }
        return [
            'user' => $this->hydrateUserPermissions($user),
            'rows' => $rows,
        ];
    }

    /**
     * @return array<int, string>
     */
    public function effectivePermissionCodesForUser(string $userId, string $role): array
    {
        $this->bootstrap();
        $cacheKey = $userId . ':' . $role;
        if (isset(self::$effectivePermissionCache[$cacheKey])) {
            return self::$effectivePermissionCache[$cacheKey];
        }
        $roleStates = $this->rbac->listRoleRuleStates($role);
        $groupStates = $this->rbac->listUserGroupRuleStates($userId);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $allowed = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $default = PermissionCatalog::isGrantedByDefault($role, $code);
            $roleAllowed = $this->applyState($default, $roleStates[$code] ?? 'inherit');
            $groupAllowed = $this->applyState($roleAllowed, $groupStates[$code] ?? 'inherit');
            $effective = $this->applyState($groupAllowed, $userStates[$code] ?? 'inherit');
            if ($effective) {
                $allowed[] = $code;
            }
        }
        sort($allowed);
        self::$effectivePermissionCache[$cacheKey] = $allowed;
        return $allowed;
    }

    public function hasPermission(string $userId, string $role, string $permissionCode): bool
    {
        return in_array($permissionCode, $this->effectivePermissionCodesForUser($userId, $role), true);
    }

    /**
     * @param array<int, string> $permissionCodes
     */
    public function hasAnyPermission(string $userId, string $role, array $permissionCodes): bool
    {
        $allowed = array_flip($this->effectivePermissionCodesForUser($userId, $role));
        foreach ($permissionCodes as $code) {
            if (isset($allowed[$code])) {
                return true;
            }
        }
        return false;
    }

    public function hydrateUserPermissions(array $user): array
    {
        $user['permissions'] = $this->effectivePermissionCodesForUser(
            (string)($user['id'] ?? ''),
            (string)($user['role'] ?? '')
        );
        $user['groups'] = $this->rbac->listUserGroups((string)($user['id'] ?? ''));
        return $user;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeGroupPayload(array $data, bool $creating, ?string $existingGroupId = null): array
    {
        $payload = [];

        if ($creating || array_key_exists('name', $data)) {
            $name = trim((string)($data['name'] ?? ''));
            if ($name === '') {
                throw new RuntimeException('Group name is required.');
            }
            $payload['name'] = $name;
        }

        if ($creating || array_key_exists('code', $data) || array_key_exists('name', $data)) {
            $source = trim((string)($data['code'] ?? ''));
            if ($source === '' && isset($payload['name'])) {
                $source = (string)$payload['name'];
            }
            $code = strtolower(trim((string)preg_replace('/[^a-zA-Z0-9_.-]+/', '_', $source), '_-.'));
            if ($code === '' || preg_match('/^[a-z][a-z0-9_.-]{0,79}$/', $code) !== 1) {
                throw new RuntimeException('Group code must start with a letter and contain only letters, numbers, underscores, dots, or dashes.');
            }
            $owner = $this->rbac->findGroupByCode($code);
            if ($owner !== null && (string)$owner['id'] !== (string)$existingGroupId) {
                throw new RuntimeException('That group code is already in use.');
            }
            $payload['code'] = $code;
        }

        if ($creating || array_key_exists('description', $data)) {
            $payload['description'] = trim((string)($data['description'] ?? ''));
        }
        if ($creating || array_key_exists('is_active', $data)) {
            $payload['is_active'] = filter_var($data['is_active'] ?? true, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) ?? true;
        }

        return $payload;
    }

    private function applyState(bool $base, string $state): bool
    {
        return match ($state) {
            'allow' => true,
            'deny' => false,
            default => $base,
        };
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>
     */
    private function validateStateMap(array $statesByCode): array
    {
        $catalog = PermissionCatalog::indexed();
        $validated = [];
        foreach ($statesByCode as $code => $state) {
            $permissionCode = (string)$code;
            if (!isset($catalog[$permissionCode])) {
                continue;
            }
            $normalized = strtolower(trim((string)$state));
            if ($normalized === '' || $normalized === 'inherit') {
                continue;
            }
            if (!in_array($normalized, ['allow', 'deny'], true)) {
                throw new RuntimeException('Invalid permission state supplied.');
            }
            $validated[$permissionCode] = $normalized;
        }
        return $validated;
    }
}
