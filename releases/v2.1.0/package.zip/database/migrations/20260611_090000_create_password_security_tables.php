<?php

return [
    'name' => 'create_password_security_tables',
    'version' => '1.0.0',
    'up' => [
        'pgsql' => [
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMPTZ NULL",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS force_password_change BOOLEAN NOT NULL DEFAULT FALSE",
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS user_password_history (
                id UUID PRIMARY KEY,
                user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                password_hash TEXT NOT NULL,
                changed_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                change_source VARCHAR(40) NOT NULL DEFAULT 'user_change',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            SQL,
            'CREATE INDEX IF NOT EXISTS idx_user_password_history_user_created ON user_password_history (user_id, created_at DESC)',
            'CREATE INDEX IF NOT EXISTS idx_user_password_history_changed_by ON user_password_history (changed_by_user_id)',
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id UUID PRIMARY KEY,
                user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                email VARCHAR(255) NOT NULL,
                token_hash CHAR(64) NOT NULL UNIQUE,
                expires_at TIMESTAMPTZ NOT NULL,
                used_at TIMESTAMPTZ NULL,
                requested_ip VARCHAR(64) NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            SQL,
            'CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_email ON password_reset_tokens (email)',
            'CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_created ON password_reset_tokens (user_id, created_at DESC)',
        ],
        'mysql' => [
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS user_password_history (
                id CHAR(36) PRIMARY KEY,
                user_id CHAR(36) NOT NULL,
                password_hash TEXT NOT NULL,
                changed_by_user_id CHAR(36) NULL,
                change_source VARCHAR(40) NOT NULL DEFAULT 'user_change',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_user_password_history_user_created (user_id, created_at),
                KEY idx_user_password_history_changed_by (changed_by_user_id),
                CONSTRAINT user_password_history_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT user_password_history_changed_by_fk FOREIGN KEY (changed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL,
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id CHAR(36) PRIMARY KEY,
                user_id CHAR(36) NOT NULL,
                email VARCHAR(255) NOT NULL,
                token_hash CHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                requested_ip VARCHAR(64) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY idx_password_reset_tokens_hash (token_hash),
                KEY idx_password_reset_tokens_email (email),
                KEY idx_password_reset_tokens_user_created (user_id, created_at),
                CONSTRAINT password_reset_tokens_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL,
        ],
    ],
    'down' => [
        'pgsql' => [
            'DROP TABLE IF EXISTS password_reset_tokens',
            'DROP TABLE IF EXISTS user_password_history',
            'ALTER TABLE users DROP COLUMN IF EXISTS force_password_change',
            'ALTER TABLE users DROP COLUMN IF EXISTS password_changed_at',
        ],
        'mysql' => [
            'DROP TABLE IF EXISTS password_reset_tokens',
            'DROP TABLE IF EXISTS user_password_history',
            'ALTER TABLE users DROP COLUMN force_password_change',
            'ALTER TABLE users DROP COLUMN password_changed_at',
        ],
    ],
];
