<?php
namespace App\Services;

use App\Config\PermissionCatalog;
use App\Config\Roles;
use App\Models\RbacModel;
use App\Models\UserModel;
use RuntimeException;

final class RbacService
{
    /** @var array<int, string> Permissions introduced after first install that are safe to add to matching default groups. */
    private const ADDITIVE_DEFAULT_PERMISSION_CODES = ['admin.audit_logs.restore'];
    private RbacModel $rbac;
    private UserModel $users;
    /** @var array<string, array<int, string>> */
    private static array $effectivePermissionCache = [];
    private static bool $defaultGroupsBootstrapped = false;

    public function __construct()
    {
        $this->rbac = new RbacModel();
        $this->users = new UserModel();
    }

    public function bootstrap(): void
    {
        $this->rbac->upsertPermissions(PermissionCatalog::definitions());
        $this->bootstrapDefaultGroups();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function permissions(): array
    {
        $this->bootstrap();
        return array_map(
            fn (array $definition): array => $this->decoratePermissionDefinition($definition),
            PermissionCatalog::definitions()
        );
    }

    /**
     * @return array{groups: array<int, array<string, mixed>>, rows: array<int, array<string, mixed>>}
     */
    public function matrix(): array
    {
        $this->bootstrap();
        $groups = $this->groups(['limit' => 200]);
        $groupRules = [];
        foreach ($groups as $group) {
            $groupId = (string)($group['id'] ?? '');
            if ($groupId !== '') {
                $groupRules[$groupId] = $this->rbac->listGroupRuleStates($groupId);
            }
        }
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $row = $this->decoratePermissionDefinition($definition);
            $code = (string)$definition['code'];
            $states = [];
            foreach ($groups as $group) {
                $groupId = (string)($group['id'] ?? '');
                if ($groupId !== '') {
                    $states[$groupId] = $groupRules[$groupId][$code] ?? 'inherit';
                }
            }
            $row['group_states'] = $states;
            $rows[] = $row;
        }
        return [
            'groups' => $groups,
            'rows' => $rows,
        ];
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function groups(array $filters = []): array
    {
        $this->bootstrap();
        return $this->rbac->listGroups($filters);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function group(string $groupId): ?array
    {
        $this->bootstrap();
        return $this->rbac->findGroupById($groupId);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createGroup(array $data, string $actorUserId = ''): array
    {
        $this->bootstrap();
        $payload = $this->normalizeGroupPayload($data, true);
        if ($actorUserId !== '') {
            $payload['created_by_user_id'] = $actorUserId;
            $payload['updated_by_user_id'] = $actorUserId;
        }
        self::$effectivePermissionCache = [];
        return $this->rbac->createGroup($payload);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>|null
     */
    public function updateGroup(string $groupId, array $data, string $actorUserId = ''): ?array
    {
        $this->bootstrap();
        $payload = $this->normalizeGroupPayload($data, false, $groupId);
        if ($actorUserId !== '') {
            $payload['updated_by_user_id'] = $actorUserId;
        }
        $group = $this->rbac->updateGroup($groupId, $payload);
        self::$effectivePermissionCache = [];
        return $group;
    }

    public function deleteGroup(string $groupId): bool
    {
        $this->bootstrap();
        $deleted = $this->rbac->deleteGroup($groupId);
        if ($deleted) {
            self::$effectivePermissionCache = [];
        }
        return $deleted;
    }

    /**
     * @return array{group: array<string, mixed>, members: array<int, array<string, mixed>>}|null
     */
    public function groupMembers(string $groupId): ?array
    {
        $this->bootstrap();
        $group = $this->rbac->findGroupById($groupId);
        if ($group === null) {
            return null;
        }

        return [
            'group' => $group,
            'members' => $this->rbac->listGroupMembers($groupId),
        ];
    }

    /**
     * @param array<int, string> $userIds
     * @return array{group: array<string, mixed>, members: array<int, array<string, mixed>>}|null
     */
    public function setGroupMembers(string $groupId, array $userIds): ?array
    {
        $this->bootstrap();
        if (!$this->rbac->replaceGroupMembers($groupId, $userIds)) {
            return null;
        }
        self::$effectivePermissionCache = [];
        return $this->groupMembers($groupId);
    }

    /**
     * @return array{group: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function groupPermissions(string $groupId): ?array
    {
        $this->bootstrap();
        $group = $this->rbac->findGroupById($groupId);
        if ($group === null) {
            return null;
        }

        $states = $this->rbac->listGroupRuleStates($groupId);
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $rows[] = array_merge($this->decoratePermissionDefinition($definition), [
                'group_state' => $states[$code] ?? 'inherit',
            ]);
        }

        return [
            'group' => $group,
            'rows' => $rows,
        ];
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array{group: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function setGroupPermissions(string $groupId, array $statesByCode): ?array
    {
        $this->bootstrap();
        $validated = $this->validateStateMap($statesByCode);
        if (!$this->rbac->replaceGroupRules($groupId, $validated)) {
            return null;
        }
        self::$effectivePermissionCache = [];
        return $this->groupPermissions($groupId);
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>|null
     */
    public function setUserOverrides(string $userId, array $statesByCode): ?array
    {
        $this->bootstrap();
        if ($this->users->findById($userId) === null) {
            return null;
        }
        $validated = $this->validateStateMap($statesByCode);
        $this->rbac->replaceUserOverrides($userId, $validated);
        self::$effectivePermissionCache = [];
        return $this->rbac->listUserOverrideStates($userId);
    }

    /**
     * @return array{user: array<string, mixed>, rows: array<int, array<string, mixed>>}|null
     */
    public function userOverrides(string $userId): ?array
    {
        $this->bootstrap();
        $user = $this->users->findById($userId);
        if ($user === null) {
            return null;
        }
        $groupStates = $this->rbac->listUserGroupRuleStates($userId);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $rows = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $groupState = $groupStates[$code] ?? 'inherit';
            $groupAllowed = $this->applyState(false, $groupState);
            $userState = $userStates[$code] ?? 'inherit';
            $rows[] = array_merge($this->decoratePermissionDefinition($definition), [
                'group_state' => $groupState,
                'group_allowed' => $groupAllowed,
                'user_state' => $userState,
                'effective' => $this->applyState($groupAllowed, $userState),
            ]);
        }
        return [
            'user' => $this->hydrateUserPermissions($user),
            'rows' => $rows,
        ];
    }

    /**
     * @return array<int, string>
     */
    public function effectivePermissionCodesForUser(string $userId, string $role = ''): array
    {
        $this->bootstrap();
        $this->ensureUserDefaultGroup($userId, $role);
        $cacheKey = $userId;
        if (isset(self::$effectivePermissionCache[$cacheKey])) {
            return self::$effectivePermissionCache[$cacheKey];
        }
        $groupStates = $this->rbac->listUserGroupRuleStates($userId);
        $userStates = $this->rbac->listUserOverrideStates($userId);
        $allowed = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            $code = (string)$definition['code'];
            $groupAllowed = $this->applyState(false, $groupStates[$code] ?? 'inherit');
            $effective = $this->applyState($groupAllowed, $userStates[$code] ?? 'inherit');
            if ($effective) {
                $allowed[] = $code;
            }
        }
        sort($allowed);
        self::$effectivePermissionCache[$cacheKey] = $allowed;
        return $allowed;
    }

    public function hasPermission(string $userId, string $role, string $permissionCode): bool
    {
        return in_array($permissionCode, $this->effectivePermissionCodesForUser($userId, $role), true);
    }

    /**
     * @param array<int, string> $permissionCodes
     */
    public function hasAnyPermission(string $userId, string $role, array $permissionCodes): bool
    {
        $allowed = array_flip($this->effectivePermissionCodesForUser($userId, $role));
        foreach ($permissionCodes as $code) {
            if (isset($allowed[$code])) {
                return true;
            }
        }
        return false;
    }

    public function hydrateUserPermissions(array $user): array
    {
        $this->bootstrap();
        $this->ensureUserDefaultGroup(
            (string)($user['id'] ?? ''),
            (string)($user['role'] ?? '')
        );
        $user['permissions'] = $this->effectivePermissionCodesForUser(
            (string)($user['id'] ?? ''),
            (string)($user['role'] ?? '')
        );
        $user['groups'] = $this->rbac->listUserGroups((string)($user['id'] ?? ''));
        return $user;
    }

    private function ensureUserDefaultGroup(string $userId, string $role): void
    {
        if (
            $userId === ''
            || $role === ''
            || !in_array($role, Roles::all(), true)
            || !$this->rbac->supportsGroups()
            || $this->rbac->listUserGroups($userId) !== []
        ) {
            return;
        }

        $group = $this->rbac->findGroupByCode($role);
        if ($group === null || (string)($group['id'] ?? '') === '') {
            return;
        }

        $groupId = (string)$group['id'];
        $memberIds = array_map(
            static fn (array $member): string => (string)$member['id'],
            $this->rbac->listGroupMembers($groupId)
        );
        $memberIds[] = $userId;
        if ($this->rbac->replaceGroupMembers($groupId, array_values(array_unique($memberIds)))) {
            self::$effectivePermissionCache = [];
        }
    }

    private function bootstrapDefaultGroups(): void
    {
        if (self::$defaultGroupsBootstrapped || !$this->rbac->supportsGroups()) {
            return;
        }

        self::$defaultGroupsBootstrapped = true;
        $groupsByRole = [];
        $existingGroupsByRole = [];
        $existingStatesByRole = [];
        $hasAnyDefaultGroupRules = false;
        foreach (Roles::all() as $role) {
            $existing = $this->rbac->findGroupByCode($role);
            if ($existing === null || (string)($existing['id'] ?? '') === '') {
                continue;
            }
            $states = $this->rbac->listGroupRuleStates((string)$existing['id']);
            $existingGroupsByRole[$role] = $existing;
            $existingStatesByRole[$role] = $states;
            if ($states !== []) {
                $hasAnyDefaultGroupRules = true;
            }
        }

        foreach (Roles::all() as $role) {
            $created = false;
            $group = $existingGroupsByRole[$role] ?? null;
            if ($group === null) {
                $group = $this->rbac->createGroup([
                    'code' => $role,
                    'name' => $this->defaultGroupName($role),
                    'description' => $this->defaultGroupDescription($role),
                    'is_active' => true,
                ]);
                $created = true;
            }
            if ($group === []) {
                continue;
            }

            $groupId = (string)$group['id'];
            $states = $existingStatesByRole[$role] ?? [];
            if ($created || (!$hasAnyDefaultGroupRules && $states === [])) {
                $this->rbac->replaceGroupRules($groupId, $this->defaultPermissionStatesForRole($role));
            } else {
                $additive = array_intersect_key(
                    $this->defaultPermissionStatesForRole($role),
                    array_fill_keys(self::ADDITIVE_DEFAULT_PERMISSION_CODES, true)
                );
                $missing = array_diff_key($additive, $states);
                if ($missing !== []) {
                    $this->rbac->replaceGroupRules($groupId, array_merge($states, $missing));
                }
            }
            $groupsByRole[$role] = $group;
        }

        $this->assignUsersToDefaultGroups($groupsByRole);
    }

    /**
     * @param array<string, array<string, mixed>> $groupsByRole
     */
    private function assignUsersToDefaultGroups(array $groupsByRole): void
    {
        if ($groupsByRole === []) {
            return;
        }

        $membersByGroupId = [];
        foreach ($groupsByRole as $group) {
            $groupId = (string)($group['id'] ?? '');
            if ($groupId === '') {
                continue;
            }
            $membersByGroupId[$groupId] = array_map(
                static fn (array $member): string => (string)$member['id'],
                $this->rbac->listGroupMembers($groupId)
            );
        }

        $dirtyGroupIds = [];
        $offset = 0;
        do {
            $users = $this->users->list(['limit' => 200, 'offset' => $offset]);
            foreach ($users as $user) {
                $userId = (string)($user['id'] ?? '');
                $role = (string)($user['role'] ?? '');
                if ($userId === '' || $role === '' || !isset($groupsByRole[$role])) {
                    continue;
                }
                if ($this->rbac->listUserGroups($userId) !== []) {
                    continue;
                }

                $groupId = (string)$groupsByRole[$role]['id'];
                $membersByGroupId[$groupId][] = $userId;
                $membersByGroupId[$groupId] = array_values(array_unique($membersByGroupId[$groupId]));
                $dirtyGroupIds[$groupId] = true;
            }
            $offset += 200;
        } while (count($users) === 200);

        foreach (array_keys($dirtyGroupIds) as $groupId) {
            $userIds = $membersByGroupId[$groupId] ?? [];
            $this->rbac->replaceGroupMembers($groupId, $userIds);
        }
    }

    /**
     * @return array<string, string>
     */
    private function defaultPermissionStatesForRole(string $role): array
    {
        $states = [];
        foreach (PermissionCatalog::definitions() as $definition) {
            if (in_array($role, (array)($definition['default_roles'] ?? []), true)) {
                $states[(string)$definition['code']] = 'allow';
            }
        }
        return $states;
    }

    private function defaultGroupName(string $role): string
    {
        return match ($role) {
            Roles::MEMBER => 'Learners',
            Roles::TRAINER => 'Trainers',
            Roles::EDITOR => 'Editors',
            Roles::SUPPORT => 'Support',
            Roles::ADMIN => 'Administrators',
            default => ucwords(str_replace(['_', '-'], ' ', $role)),
        };
    }

    private function defaultGroupDescription(string $role): string
    {
        return match ($role) {
            Roles::MEMBER => 'Learner access group for authenticated website users.',
            Roles::TRAINER => 'Training and eLearning management group.',
            Roles::EDITOR => 'Website content and media management group.',
            Roles::SUPPORT => 'Contact desk, media viewing, and support operations group.',
            Roles::ADMIN => 'Full system administration group.',
            default => 'Default access group.',
        };
    }

    /**
     * @param array<string, mixed> $definition
     * @return array<string, mixed>
     */
    private function decoratePermissionDefinition(array $definition): array
    {
        $kind = $this->permissionAccessKind($definition);
        $sectionCode = (string)($definition['section_code'] ?? 'general');
        $moduleCode = (string)($definition['module_code'] ?? 'general');
        $actionCode = (string)($definition['action_code'] ?? '');

        return array_merge($definition, [
            'access_kind' => $kind,
            'access_kind_label' => $kind === 'visibility' ? 'Can see' : 'Can do',
            'policy_key' => $sectionCode . '.' . $moduleCode,
            'policy_scope' => implode(':', array_filter([$sectionCode, $moduleCode, $actionCode])),
        ]);
    }

    /**
     * @param array<string, mixed> $definition
     */
    private function permissionAccessKind(array $definition): string
    {
        $action = strtolower((string)($definition['action_code'] ?? ''));
        return in_array($action, ['access', 'view', 'read', 'list', 'browse'], true) ? 'visibility' : 'action';
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeGroupPayload(array $data, bool $creating, ?string $existingGroupId = null): array
    {
        $payload = [];

        if ($creating || array_key_exists('name', $data)) {
            $name = trim((string)($data['name'] ?? ''));
            if ($name === '') {
                throw new RuntimeException('Group name is required.');
            }
            $payload['name'] = $name;
        }

        if ($creating || array_key_exists('code', $data) || array_key_exists('name', $data)) {
            $source = trim((string)($data['code'] ?? ''));
            if ($source === '' && isset($payload['name'])) {
                $source = (string)$payload['name'];
            }
            $code = strtolower(trim((string)preg_replace('/[^a-zA-Z0-9_.-]+/', '_', $source), '_-.'));
            if ($code === '' || preg_match('/^[a-z][a-z0-9_.-]{0,79}$/', $code) !== 1) {
                throw new RuntimeException('Group code must start with a letter and contain only letters, numbers, underscores, dots, or dashes.');
            }
            $owner = $this->rbac->findGroupByCode($code);
            if ($owner !== null && (string)$owner['id'] !== (string)$existingGroupId) {
                throw new RuntimeException('That group code is already in use.');
            }
            $payload['code'] = $code;
        }

        if ($creating || array_key_exists('description', $data)) {
            $payload['description'] = trim((string)($data['description'] ?? ''));
        }
        if ($creating || array_key_exists('is_active', $data)) {
            $payload['is_active'] = filter_var($data['is_active'] ?? true, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) ?? true;
        }

        return $payload;
    }

    private function applyState(bool $base, string $state): bool
    {
        return match ($state) {
            'allow' => true,
            'deny' => false,
            default => $base,
        };
    }

    /**
     * @param array<string, string> $statesByCode
     * @return array<string, string>
     */
    private function validateStateMap(array $statesByCode): array
    {
        $catalog = PermissionCatalog::indexed();
        $validated = [];
        foreach ($statesByCode as $code => $state) {
            $permissionCode = (string)$code;
            if (!isset($catalog[$permissionCode])) {
                continue;
            }
            $normalized = strtolower(trim((string)$state));
            if ($normalized === '' || $normalized === 'inherit') {
                continue;
            }
            if (!in_array($normalized, ['allow', 'deny'], true)) {
                throw new RuntimeException('Invalid permission state supplied.');
            }
            $validated[$permissionCode] = $normalized;
        }
        return $validated;
    }
}
