<?php
namespace App\Config;

final class AuthConfig
{
    public static function passwordMinLength(): int
    {
        return max(8, Env::int('AUTH_PASSWORD_MIN_LENGTH', 12));
    }

    public static function requireUppercase(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_UPPERCASE', true);
    }

    public static function requireLowercase(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_LOWERCASE', true);
    }

    public static function requireNumber(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_NUMBER', true);
    }

    public static function requireSymbol(): bool
    {
        return Env::bool('AUTH_PASSWORD_REQUIRE_SYMBOL', true);
    }

    public static function bcryptCost(): int
    {
        return max(10, min(15, Env::int('AUTH_BCRYPT_COST', 12)));
    }

    public static function throttleEnabled(): bool
    {
        return Env::bool('AUTH_LOGIN_THROTTLE_ENABLED', true);
    }

    public static function maxLoginAttempts(): int
    {
        return max(1, Env::int('AUTH_LOGIN_MAX_ATTEMPTS', 5));
    }

    public static function loginDecaySeconds(): int
    {
        return max(60, Env::int('AUTH_LOGIN_DECAY_SECONDS', 900));
    }

    public static function lockoutSeconds(): int
    {
        return max(60, Env::int('AUTH_LOGIN_LOCKOUT_SECONDS', 900));
    }

    public static function tokenIssuer(): ?string
    {
        $value = trim((string)Env::get('AUTH_TOKEN_ISSUER', ''));
        return $value !== '' ? $value : null;
    }

    public static function tokenAudience(): ?string
    {
        $value = trim((string)Env::get('AUTH_TOKEN_AUDIENCE', ''));
        return $value !== '' ? $value : null;
    }

    /**
     * @return array<string, string>
     */
    public static function jwtValidationOptions(): array
    {
        $options = [];
        $issuer = self::tokenIssuer();
        if ($issuer !== null) {
            $options['issuer'] = $issuer;
        }

        $audience = self::tokenAudience();
        if ($audience !== null) {
            $options['audience'] = $audience;
        }

        return $options;
    }

    public static function jwtSecret(): string
    {
        return (string)Env::get('JWT_SECRET', 'unsafe-default');
    }

    public static function jwtSecretIsWeak(): bool
    {
        $secret = trim(self::jwtSecret());
        if ($secret === '') {
            return true;
        }

        if (in_array(strtolower($secret), ['change-me', 'unsafe-default', 'secret', 'password'], true)) {
            return true;
        }

        return strlen($secret) < 32;
    }
}
