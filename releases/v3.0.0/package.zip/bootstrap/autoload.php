<?php

$rootPath = dirname(__DIR__);
$autoloadPath = $rootPath . '/vendor/autoload.php';

if (!is_file($autoloadPath)) {
    $message = 'Composer dependencies are not installed. Run "composer install" from the project root.';

    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $message . PHP_EOL);
        exit(1);
    }

    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    echo $message;
    exit;
}

require $autoloadPath;

return $rootPath;
