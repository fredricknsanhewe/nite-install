<?php

ob_start();

use App\Config\Env;
use App\Admin\Integration\AngularAdminRenderer;
use App\Admin\Legacy\LegacyAdminRenderer;
use App\Controllers\AdminRuntimeConfigController;
use App\Controllers\AdminUsersController;
use App\Controllers\AuditAdminController;
use App\Controllers\AuthController;
use App\Controllers\ContactController;
use App\Controllers\CoursesController;
use App\Controllers\DashboardController;
use App\Controllers\DataRecoveryController;
use App\Controllers\EventsController;
use App\Controllers\ExamplesController;
use App\Controllers\FrameworkController;
use App\Controllers\GalleryController;
use App\Controllers\HealthController;
use App\Controllers\MediaController;
use App\Controllers\NewsController;
use App\Controllers\PagesController;
use App\Controllers\RbacController;
use App\Controllers\ResourcesController;
use App\Controllers\SearchController;
use App\Controllers\SecurityController;
use App\Controllers\SiteController;
use App\Controllers\UserController;
use App\Exceptions\AuthenticationException;
use App\Exceptions\ThrottleException;
use App\Exceptions\ValidationException;
use App\Http\ApiResponse;
use App\Http\Middleware\AuthMiddleware;
use App\Http\Middleware\PermissionMiddleware;
use App\Http\Request;
use App\Http\Response;
use App\Http\Router;
use App\Services\RbacService;
use App\Services\SystemAuditService;
use App\Support\ApiExplorerCatalog;
use App\Support\AdminRenderer;
use App\Support\BrowsableApiRenderer;
use App\Support\DebugExceptionRenderer;
use App\Support\GeneratedResourceRegistry;
use App\Support\ProjectRegistry;

$rootPath = require dirname(__DIR__) . '/bootstrap/autoload.php';

@mkdir($rootPath . '/storage', 0777, true);
@mkdir(__DIR__ . '/uploads', 0777, true);

Env::loadFirstAvailable([
    $rootPath . '/.env',
    $rootPath . '/.env.example',
]);
(new ProjectRegistry($rootPath))->bootstrapActiveFromEnvironment();
try {
    (new RbacService())->bootstrap();
} catch (\Throwable) {
    // Keep non-database metadata routes and browsable API pages available even when the DB is not configured yet.
}

$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$requestPath = parse_url($requestUri, PHP_URL_PATH) ?: '/';
$normalizedRequestPath = rtrim($requestPath, '/') ?: '/';
if (servePublicUpload($requestPath)) {
    exit;
}

function send_cors_headers(): void
{
    $allowedOrigins = trim((string)Env::get('CORS_ALLOWED_ORIGINS', ''));
    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($allowedOrigins === '' || $origin === '') {
        return;
    }

    $allowed = array_map('trim', explode(',', $allowedOrigins));
    if (in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-User-Timezone');
        header('Access-Control-Allow-Methods: GET,HEAD,POST,PUT,PATCH,DELETE,OPTIONS');
        header('Access-Control-Max-Age: 86400');
    }
}

function html_interface_enabled(): bool
{
    return Env::bool('NITE_HTML_INTERFACE_ENABLED', browsable_api_enabled());
}

function admin_interface_enabled(): bool
{
    return Env::bool('NITE_ADMIN_ENABLED', html_interface_enabled());
}

function browsable_api_enabled(): bool
{
    return Env::bool('NITE_BROWSABLE_API', Env::bool('NITE_HTML_INTERFACE_ENABLED', true));
}

function servePublicUpload(string $requestPath): bool
{
    if (!preg_match('#^/uploads/[^/].*$#', $requestPath)) {
        return false;
    }
    $publicRoot = realpath($rootPath . '/public');
    $uploadsRoot = $publicRoot !== false ? realpath($publicRoot . '/uploads') : false;
    if ($publicRoot === false || $uploadsRoot === false) {
        return false;
    }
    $candidate = realpath($publicRoot . $requestPath);
    if ($candidate === false || !is_file($candidate) || !str_starts_with($candidate, $uploadsRoot . DIRECTORY_SEPARATOR)) {
        http_response_code(404);
        echo 'Not found';
        return true;
    }
    $mime = mime_content_type($candidate) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=31536000, immutable');
    readfile($candidate);
    return true;
}

function response_status_text(int $status): string
{
    return match ($status) {
        200 => 'OK',
        201 => 'Created',
        204 => 'No Content',
        400 => 'Bad Request',
        401 => 'Unauthorized',
        403 => 'Forbidden',
        404 => 'Not Found',
        405 => 'Method Not Allowed',
        422 => 'Unprocessable Entity',
        500 => 'Internal Server Error',
        default => '',
    };
}

/**
 * @param array<string, string> $headers
 * @return array<string, string>
 */
function safe_response_headers(array $headers): array
{
    $safe = [];
    foreach ($headers as $key => $value) {
        $normalized = strtolower(trim((string)$key));
        if (in_array($normalized, ['set-cookie', 'authorization'], true)) {
            continue;
        }
        $safe[(string)$key] = (string)$value;
    }

    return $safe;
}

function request_url(Request $request): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string)($_SERVER['HTTP_HOST'] ?? parse_url((string)Env::get('APP_URL', 'http://127.0.0.1:8185'), PHP_URL_HOST) ?? '127.0.0.1:8185');
    $query = $request->query === [] ? '' : ('?' . http_build_query($request->query));
    return $scheme . '://' . $host . $request->path . $query;
}

function debug_enabled(): bool
{
    return Env::bool('APP_DEBUG', false);
}

function expose_error_details(): bool
{
    return debug_enabled();
}

function should_render_browsable_api(Request $request, Response $response): bool
{
    if (!browsable_api_enabled()) {
        return false;
    }

    if (($request->query['format'] ?? null) === 'json') {
        return false;
    }

    if (!$request->prefersHtml()) {
        return false;
    }

    return $response->format === 'json';
}

/**
 * @param array<int, object> $matchingRoutes
 */
function render_browsable_api_page(Request $request, Response $response, array $matchingRoutes): string
{
    $documentedRoutes = ApiExplorerCatalog::documentRoutes($matchingRoutes);
    $currentRoute = is_array($request->attributes['route'] ?? null) ? $request->attributes['route'] : [];
    $currentRouteDoc = null;
    foreach ($documentedRoutes as $routeDoc) {
        if ((string)($routeDoc['method'] ?? '') === $request->method) {
            $currentRouteDoc = $routeDoc;
            break;
        }
    }
    if (!is_array($currentRouteDoc) && $documentedRoutes !== []) {
        $currentRouteDoc = $documentedRoutes[0];
    }
    $resourceKey = is_array($currentRouteDoc) ? (string)($currentRouteDoc['resource_key'] ?? '') : '';
    $resourceDoc = $resourceKey !== '' ? ApiExplorerCatalog::resource($resourceKey) : null;
    $allowedMethods = array_values(is_array($currentRoute['allowed_methods'] ?? null) ? $currentRoute['allowed_methods'] : []);
    if ($allowedMethods === []) {
        $allowedMethods = array_values(array_unique(array_map(
            static fn (array $route): string => (string)($route['method'] ?? ''),
            $documentedRoutes
        )));
    }

    $responsePayload = $response->payload;
    $responseBody = is_string($response->body) ? $response->body : '';
    $prettyBody = is_array($responsePayload)
        ? json_encode($responsePayload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE)
        : $responseBody;
    if (!is_string($prettyBody)) {
        $prettyBody = $responseBody;
    }

    return BrowsableApiRenderer::render([
        'browsable_enabled' => browsable_api_enabled(),
        'endpoint' => [
            'url' => request_url($request),
            'path' => $request->path,
            'route_name' => (string)($currentRoute['name'] ?? ''),
            'route_path' => (string)($currentRoute['path'] ?? ($documentedRoutes[0]['path'] ?? $request->path)),
            'current_method' => $request->method,
            'allowed_methods' => $allowedMethods,
        ],
        'request' => [
            'query' => $request->query,
            'body' => $request->body,
        ],
        'resource' => $resourceDoc,
        'response' => [
            'status' => $response->status,
            'status_text' => response_status_text($response->status),
            'request_method' => $request->method,
            'headers' => safe_response_headers($response->headers),
            'content_type' => (string)($response->headers['Content-Type'] ?? 'application/json; charset=UTF-8'),
            'payload' => $responsePayload,
            'body' => $responseBody,
            'pretty_body' => $prettyBody,
        ],
        'routes' => $documentedRoutes,
    ]);
}

function admin_selection_from_path(string $normalizedRequestPath): ?string
{
    $basePath = nite_admin_base_path();
    if ($normalizedRequestPath === $basePath) {
        return null;
    }

    if (!str_starts_with($normalizedRequestPath, $basePath . '/')) {
        return null;
    }

    $selection = trim(substr($normalizedRequestPath, strlen($basePath . '/')), '/');
    return $selection === '' ? null : $selection;
}

function nite_admin_base_path(): string
{
    $path = '/' . trim((string) Env::get('NITE_ADMIN_BASE_PATH', '/admin'), '/');
    return $path === '/' ? '/admin' : $path;
}

function nite_admin_driver(): string
{
    return strtolower(trim((string) Env::get('NITE_ADMIN_DRIVER', 'angular'))) === 'legacy' ? 'legacy' : 'angular';
}

function render_admin_workspace(?string $selection = null): string
{
    global $rootPath;
    $routes = array_values(ApiExplorerCatalog::routeDocsMap());
    if (nite_admin_driver() === 'angular') {
        $angular = new AngularAdminRenderer($rootPath);
        if ($angular->isAvailable()) {
            return $angular->render();
        }
        error_log('Nite Admin Angular build unavailable; using deprecated legacy compatibility renderer.');
    }

    return LegacyAdminRenderer::render($routes, $selection);
}

function should_render_debug_exception(?Request $request = null): bool
{
    if (!debug_enabled()) {
        return false;
    }

    $activeRequest = $request ?? safe_request_from_globals();
    if (($activeRequest->query['format'] ?? null) === 'json') {
        return false;
    }

    return $activeRequest->prefersHtml();
}

function safe_request_from_globals(): Request
{
    try {
        return Request::fromGlobals();
    } catch (\Throwable) {
        return new Request(
            $_SERVER['REQUEST_METHOD'] ?? 'GET',
            parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/',
            $_GET ?? [],
            [],
            []
        );
    }
}

function exception_error_response(\Throwable $error, ?Request $request = null): Response
{
    $activeRequest = $request ?? safe_request_from_globals();

    if ($error instanceof ValidationException) {
        return ApiResponse::validationError($error->errors(), $error->getMessage());
    }

    if ($error instanceof ThrottleException) {
        return ApiResponse::error($error->getMessage(), ['retry_after' => $error->retryAfterSeconds()], 429, [], [
            'Retry-After' => (string)$error->retryAfterSeconds(),
        ]);
    }

    if ($error instanceof AuthenticationException) {
        return ApiResponse::error($error->getMessage(), null, 401);
    }

    if (should_render_debug_exception($activeRequest)) {
        return Response::html(
            DebugExceptionRenderer::render($error, $activeRequest),
            500,
            ['Vary' => 'Accept']
        );
    }

    return expose_error_details()
        ? ApiResponse::exception($error, 'Internal server error', 500)
        : ApiResponse::error('Internal server error', null, 500);
}

function emit_response(Response $response): void
{
    if (!headers_sent()) {
        send_cors_headers();
        http_response_code($response->status);
        foreach ($response->headers as $key => $value) {
            header($key . ': ' . $value);
        }
    }
    if (ob_get_level() > 0) {
        ob_clean();
    }
    echo $response->body;
}

function render_uncaught_exception(\Throwable $error): void
{
    if (!empty($GLOBALS['__nite_exception_rendered'])) {
        exit(1);
    }
    $GLOBALS['__nite_exception_rendered'] = true;

    try {
        $response = exception_error_response($error, safe_request_from_globals());
        emit_response($response);
    } catch (\Throwable $renderError) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: text/plain; charset=UTF-8');
        }
        if (ob_get_level() > 0) {
            ob_clean();
        }
        if (debug_enabled()) {
            echo "Failed to render debug exception page.\n\n";
            echo get_class($renderError) . ': ' . $renderError->getMessage() . "\n\n";
            echo "Original exception:\n";
            echo get_class($error) . ': ' . $error->getMessage() . "\n";
            echo $error->getFile() . ':' . $error->getLine() . "\n";
        } else {
            echo 'Internal server error';
        }
    }

    exit(1);
}

set_exception_handler(static function (\Throwable $error): void {
    render_uncaught_exception($error);
});

if (debug_enabled()) {
    set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
        if (!(error_reporting() & $severity)) {
            return false;
        }

        if (in_array($severity, [E_DEPRECATED, E_USER_DEPRECATED], true)) {
            return false;
        }

        throw new \ErrorException($message, 0, $severity, $file, $line);
    });

    register_shutdown_function(static function (): void {
        if (!debug_enabled() || !empty($GLOBALS['__nite_exception_rendered'])) {
            return;
        }

        $error = error_get_last();
        if (!is_array($error)) {
            return;
        }

        if (!in_array($error['type'] ?? 0, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
            return;
        }

        render_uncaught_exception(new \ErrorException(
            (string)($error['message'] ?? 'Fatal error'),
            0,
            (int)($error['type'] ?? E_ERROR),
            (string)($error['file'] ?? ''),
            (int)($error['line'] ?? 0)
        ));
    });
}

$router = new Router('/api');
$auth = new AuthMiddleware();
$perm = static fn (string|array $codes): callable => PermissionMiddleware::require($codes);

$router->group('/v1', function (Router $r) use ($auth, $perm): void {
    $r->get('', [FrameworkController::class, 'apiRoot'])->name('api.root');
    $r->get('/health', [HealthController::class, '__invoke']);
    $r->get('/admin/runtime-config', [AdminRuntimeConfigController::class, '__invoke']);
    $r->get('/meta/routes', function () use ($r): Response {
        return Response::json([
            'data' => ApiExplorerCatalog::documentRoutes($r->routes()),
            'meta' => ApiExplorerCatalog::summary(),
        ]);
    });
    $r->get('/meta/resources', function (): Response {
        return Response::json([
            'data' => array_values(ApiExplorerCatalog::resources()),
            'meta' => ApiExplorerCatalog::summary(),
        ]);
    });
    $r->get('/meta/resources/{resource}', function (Request $request): Response {
        $resource = ApiExplorerCatalog::resource((string)($request->params['resource'] ?? ''));
        return $resource !== null
            ? Response::json(['data' => $resource, 'meta' => ApiExplorerCatalog::summary()])
            : Response::json(['error' => 'Resource not found.'], 404);
    });

    $r->post('/auth/register', [AuthController::class, 'register']);
    $r->post('/auth/login', [AuthController::class, 'login']);
    $r->post('/auth/password/forgot', [AuthController::class, 'forgotPassword']);
    $r->post('/auth/password/reset', [AuthController::class, 'resetPassword']);
    $r->post('/auth/password/change', [AuthController::class, 'changePassword'])->middleware($auth);
    $r->get('/framework', [FrameworkController::class, 'overview']);
    $r->get('/framework/modules', [FrameworkController::class, 'modules']);
    $r->get('/framework/modules/{module}', [FrameworkController::class, 'module']);
    $r->get('/search/global', [SearchController::class, 'global']);

    $r->get('/examples/{module}/{entity}', [ExamplesController::class, 'list']);
    $r->get('/examples/{module}/{entity}/{id}', [ExamplesController::class, 'show']);
    $r->get('/examples/{module}/{entity}/{id}/entries', [ExamplesController::class, 'entries']);
    $r->post('/examples/{module}/{entity}', [ExamplesController::class, 'create'])->middleware($auth)->middleware($perm('framework.examples.manage'));
    $r->put('/examples/{module}/{entity}/{id}', [ExamplesController::class, 'update'])->middleware($auth)->middleware($perm('framework.examples.manage'));
    $r->patch('/examples/{module}/{entity}/{id}', [ExamplesController::class, 'update'])->middleware($auth)->middleware($perm('framework.examples.manage'));
    $r->delete('/examples/{module}/{entity}/{id}', [ExamplesController::class, 'delete'])->middleware($auth)->middleware($perm('framework.examples.manage'));
    $r->post('/examples/{module}/{entity}/{id}/entries', [ExamplesController::class, 'createEntry'])->middleware($auth)->middleware($perm('framework.examples.manage'));

    $r->get('/site/bootstrap', [SiteController::class, 'bootstrap']);
    $r->get('/site/settings', [SiteController::class, 'publicSettings']);
    $r->get('/pages', [PagesController::class, 'list']);
    $r->get('/pages/{slug}', [PagesController::class, 'show']);
    $r->get('/news', [NewsController::class, 'list']);
    $r->get('/news/{slug}', [NewsController::class, 'show']);
    $r->get('/events', [EventsController::class, 'list']);
    $r->get('/events/{id}', [EventsController::class, 'show']);
    $r->post('/events/{id}/registrations', [EventsController::class, 'register']);
    $r->get('/resources', [ResourcesController::class, 'list']);
    $r->get('/resources/{slug}', [ResourcesController::class, 'show']);
    $r->get('/gallery', [GalleryController::class, 'overview']);
    $r->post('/contact/messages', [ContactController::class, 'create']);
    $r->get('/courses', [CoursesController::class, 'list']);
    $r->get('/courses/{slug}', [CoursesController::class, 'show']);
    $r->get('/media', [MediaController::class, 'accessibleList']);
    $r->get('/media/{id}', [MediaController::class, 'publicShow']);
    $r->get('/media/{id}/download', [MediaController::class, 'download']);
    $r->get('/me', [UserController::class, 'me'])->middleware($auth);
    $r->get('/dashboard/me', [DashboardController::class, 'me'])->middleware($auth)->middleware($perm('module.member_dashboard.access'));
    $r->get('/courses/me/enrollments', [CoursesController::class, 'myEnrollments'])->middleware($auth)->middleware($perm('courses.catalog.view'));
    $r->post('/courses/{id}/enroll', [CoursesController::class, 'enroll'])->middleware($auth)->middleware($perm('courses.enroll'));
    $r->put('/courses/{id}/progress', [CoursesController::class, 'updateProgress'])->middleware($auth)->middleware($perm('courses.progress.manage'));
    $r->patch('/courses/{id}/progress', [CoursesController::class, 'updateProgress'])->middleware($auth)->middleware($perm('courses.progress.manage'));

    $r->get('/admin/dashboard', [DashboardController::class, 'admin'])->middleware($auth)->middleware($perm('module.admin_dashboard.access'));
    $r->get('/admin/site-settings', [SiteController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.site_settings.view'));
    $r->get('/admin/site-settings/{key}', [SiteController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.site_settings.view'));
    $r->put('/admin/site-settings/{key}', [SiteController::class, 'adminUpdate'])->middleware($auth)->middleware($perm('admin.site_settings.manage'));
    $r->patch('/admin/site-settings/{key}', [SiteController::class, 'adminUpdate'])->middleware($auth)->middleware($perm('admin.site_settings.manage'));
    $r->get('/admin/security/password-policy', [SecurityController::class, 'passwordPolicy'])->middleware($auth)->middleware($perm('admin.security.manage'));
    $r->put('/admin/security/password-policy/{id}', [SecurityController::class, 'updatePasswordPolicy'])->middleware($auth)->middleware($perm('admin.security.manage'));
    $r->patch('/admin/security/password-policy/{id}', [SecurityController::class, 'updatePasswordPolicy'])->middleware($auth)->middleware($perm('admin.security.manage'));

    $r->get('/admin/pages', [PagesController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.pages.view'));
    $r->get('/admin/pages/{id}', [PagesController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.pages.view'));
    $r->post('/admin/pages', [PagesController::class, 'create'])->middleware($auth)->middleware($perm('admin.pages.manage'));
    $r->put('/admin/pages/{id}', [PagesController::class, 'update'])->middleware($auth)->middleware($perm('admin.pages.manage'));
    $r->patch('/admin/pages/{id}', [PagesController::class, 'update'])->middleware($auth)->middleware($perm('admin.pages.manage'));
    $r->delete('/admin/pages/{id}', [PagesController::class, 'delete'])->middleware($auth)->middleware($perm('admin.pages.manage'));

    $r->get('/admin/news', [NewsController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.news.view'));
    $r->get('/admin/news/{id}', [NewsController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.news.view'));
    $r->post('/admin/news', [NewsController::class, 'create'])->middleware($auth)->middleware($perm('admin.news.manage'));
    $r->put('/admin/news/{id}', [NewsController::class, 'update'])->middleware($auth)->middleware($perm('admin.news.manage'));
    $r->patch('/admin/news/{id}', [NewsController::class, 'update'])->middleware($auth)->middleware($perm('admin.news.manage'));
    $r->delete('/admin/news/{id}', [NewsController::class, 'delete'])->middleware($auth)->middleware($perm('admin.news.manage'));

    $r->get('/admin/events', [EventsController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.events.view'));
    $r->get('/admin/events/{id}', [EventsController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.events.view'));
    $r->post('/admin/events', [EventsController::class, 'create'])->middleware($auth)->middleware($perm('admin.events.manage'));
    $r->put('/admin/events/{id}', [EventsController::class, 'update'])->middleware($auth)->middleware($perm('admin.events.manage'));
    $r->patch('/admin/events/{id}', [EventsController::class, 'update'])->middleware($auth)->middleware($perm('admin.events.manage'));
    $r->delete('/admin/events/{id}', [EventsController::class, 'delete'])->middleware($auth)->middleware($perm('admin.events.manage'));
    $r->get('/admin/events/{id}/registrations', [EventsController::class, 'registrations'])->middleware($auth)->middleware($perm('admin.events.view'));
    $r->get('/admin/registrations/{id}', [EventsController::class, 'showRegistration'])->middleware($auth)->middleware($perm('admin.events.view'));
    $r->put('/admin/registrations/{id}', [EventsController::class, 'updateRegistration'])->middleware($auth)->middleware($perm('admin.events.manage'));
    $r->patch('/admin/registrations/{id}', [EventsController::class, 'updateRegistration'])->middleware($auth)->middleware($perm('admin.events.manage'));

    $r->get('/admin/resources', [ResourcesController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.resources.view'));
    $r->get('/admin/resources/{id}', [ResourcesController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.resources.view'));
    $r->post('/admin/resources', [ResourcesController::class, 'create'])->middleware($auth)->middleware($perm('admin.resources.manage'));
    $r->put('/admin/resources/{id}', [ResourcesController::class, 'update'])->middleware($auth)->middleware($perm('admin.resources.manage'));
    $r->patch('/admin/resources/{id}', [ResourcesController::class, 'update'])->middleware($auth)->middleware($perm('admin.resources.manage'));
    $r->delete('/admin/resources/{id}', [ResourcesController::class, 'delete'])->middleware($auth)->middleware($perm('admin.resources.manage'));

    $r->get('/admin/gallery/albums', [GalleryController::class, 'adminAlbums'])->middleware($auth)->middleware($perm('admin.gallery.view'));
    $r->get('/admin/gallery/albums/{id}', [GalleryController::class, 'showAlbum'])->middleware($auth)->middleware($perm('admin.gallery.view'));
    $r->post('/admin/gallery/albums', [GalleryController::class, 'createAlbum'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->put('/admin/gallery/albums/{id}', [GalleryController::class, 'updateAlbum'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->patch('/admin/gallery/albums/{id}', [GalleryController::class, 'updateAlbum'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->delete('/admin/gallery/albums/{id}', [GalleryController::class, 'deleteAlbum'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->get('/admin/gallery/items', [GalleryController::class, 'adminItems'])->middleware($auth)->middleware($perm('admin.gallery.view'));
    $r->get('/admin/gallery/items/{id}', [GalleryController::class, 'showItem'])->middleware($auth)->middleware($perm('admin.gallery.view'));
    $r->post('/admin/gallery/items', [GalleryController::class, 'createItem'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->put('/admin/gallery/items/{id}', [GalleryController::class, 'updateItem'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->patch('/admin/gallery/items/{id}', [GalleryController::class, 'updateItem'])->middleware($auth)->middleware($perm('admin.gallery.manage'));
    $r->delete('/admin/gallery/items/{id}', [GalleryController::class, 'deleteItem'])->middleware($auth)->middleware($perm('admin.gallery.manage'));

    $r->get('/admin/contact/messages', [ContactController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.contacts.view'));
    $r->get('/admin/contact/messages/{id}', [ContactController::class, 'show'])->middleware($auth)->middleware($perm('admin.contacts.view'));
    $r->put('/admin/contact/messages/{id}', [ContactController::class, 'update'])->middleware($auth)->middleware($perm('admin.contacts.manage'));
    $r->patch('/admin/contact/messages/{id}', [ContactController::class, 'update'])->middleware($auth)->middleware($perm('admin.contacts.manage'));
    $r->delete('/admin/contact/messages/{id}', [ContactController::class, 'delete'])->middleware($auth)->middleware($perm('admin.contacts.manage'));

    $r->get('/admin/courses', [CoursesController::class, 'adminList'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->get('/admin/courses/{id}', [CoursesController::class, 'adminShow'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->post('/admin/courses', [CoursesController::class, 'createCourse'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->put('/admin/courses/{id}', [CoursesController::class, 'updateCourse'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->patch('/admin/courses/{id}', [CoursesController::class, 'updateCourse'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->delete('/admin/courses/{id}', [CoursesController::class, 'deleteCourse'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->get('/admin/courses/{id}/modules', [CoursesController::class, 'modules'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->post('/admin/courses/{id}/modules', [CoursesController::class, 'createModule'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->get('/admin/modules/{id}', [CoursesController::class, 'showModule'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->put('/admin/modules/{id}', [CoursesController::class, 'updateModule'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->patch('/admin/modules/{id}', [CoursesController::class, 'updateModule'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->delete('/admin/modules/{id}', [CoursesController::class, 'deleteModule'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->get('/admin/courses/{id}/enrollments', [CoursesController::class, 'enrollments'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->get('/admin/enrollments/{id}', [CoursesController::class, 'showEnrollment'])->middleware($auth)->middleware($perm('admin.courses.view'));
    $r->put('/admin/enrollments/{id}', [CoursesController::class, 'updateEnrollment'])->middleware($auth)->middleware($perm('admin.courses.manage'));
    $r->patch('/admin/enrollments/{id}', [CoursesController::class, 'updateEnrollment'])->middleware($auth)->middleware($perm('admin.courses.manage'));

    $r->get('/admin/users', [AdminUsersController::class, 'list'])->middleware($auth)->middleware($perm('admin.users.view'));
    $r->post('/admin/users', [AdminUsersController::class, 'create'])->middleware($auth)->middleware($perm('admin.users.manage'));
    $r->get('/admin/users/{id}', [AdminUsersController::class, 'show'])->middleware($auth)->middleware($perm('admin.users.view'));
    $r->put('/admin/users/{id}', [AdminUsersController::class, 'update'])->middleware($auth)->middleware($perm('admin.users.manage'));
    $r->patch('/admin/users/{id}', [AdminUsersController::class, 'update'])->middleware($auth)->middleware($perm('admin.users.manage'));
    $r->delete('/admin/users/{id}', [AdminUsersController::class, 'delete'])->middleware($auth)->middleware($perm('admin.users.manage'));

    $r->get('/admin/rbac/roles', [RbacController::class, 'roles'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->get('/admin/rbac/permissions', [RbacController::class, 'permissions'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->get('/admin/rbac/matrix', [RbacController::class, 'matrix'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->get('/admin/rbac/groups', [RbacController::class, 'groups'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->post('/admin/rbac/groups', [RbacController::class, 'createGroup'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->get('/admin/rbac/groups/{id}/members', [RbacController::class, 'groupMembers'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->put('/admin/rbac/groups/{id}/members', [RbacController::class, 'setGroupMembers'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->patch('/admin/rbac/groups/{id}/members', [RbacController::class, 'setGroupMembers'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->get('/admin/rbac/groups/{id}/permissions', [RbacController::class, 'groupPermissions'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->put('/admin/rbac/groups/{id}/permissions', [RbacController::class, 'setGroupPermissions'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->patch('/admin/rbac/groups/{id}/permissions', [RbacController::class, 'setGroupPermissions'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->put('/admin/rbac/roles/{role}/permissions', [RbacController::class, 'setRolePermissions'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->patch('/admin/rbac/roles/{role}/permissions', [RbacController::class, 'setRolePermissions'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->get('/admin/rbac/groups/{id}', [RbacController::class, 'group'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->put('/admin/rbac/groups/{id}', [RbacController::class, 'updateGroup'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->patch('/admin/rbac/groups/{id}', [RbacController::class, 'updateGroup'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->delete('/admin/rbac/groups/{id}', [RbacController::class, 'deleteGroup'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->get('/admin/rbac/users/{id}/overrides', [RbacController::class, 'userOverrides'])->middleware($auth)->middleware($perm('admin.rbac.view'));
    $r->put('/admin/rbac/users/{id}/overrides', [RbacController::class, 'setUserOverrides'])->middleware($auth)->middleware($perm('admin.rbac.manage'));
    $r->patch('/admin/rbac/users/{id}/overrides', [RbacController::class, 'setUserOverrides'])->middleware($auth)->middleware($perm('admin.rbac.manage'));

    $r->get('/admin/media/history', [MediaController::class, 'history'])->middleware($auth)->middleware($perm('admin.media.view'));
    $r->post('/admin/media/history/{logId}/restore', [MediaController::class, 'restore'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->get('/admin/media', [MediaController::class, 'list'])->middleware($auth)->middleware($perm('admin.media.view'));
    $r->post('/admin/media', [MediaController::class, 'upload'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->get('/admin/media/{id}/history', [MediaController::class, 'recordHistory'])->middleware($auth)->middleware($perm('admin.media.view'));
    $r->get('/admin/media/{id}/versions', [MediaController::class, 'versions'])->middleware($auth)->middleware($perm('admin.media.view'));
    $r->post('/admin/media/{id}/versions', [MediaController::class, 'uploadVersion'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->post('/admin/media/{id}/versions/{versionId}/restore', [MediaController::class, 'restoreVersion'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->get('/admin/media/{id}', [MediaController::class, 'show'])->middleware($auth)->middleware($perm('admin.media.view'));
    $r->put('/admin/media/{id}', [MediaController::class, 'update'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->patch('/admin/media/{id}', [MediaController::class, 'update'])->middleware($auth)->middleware($perm('admin.media.manage'));
    $r->delete('/admin/media/{id}', [MediaController::class, 'delete'])->middleware($auth)->middleware($perm('admin.media.manage'));

    $r->get('/admin/audit-logs', [AuditAdminController::class, 'list'])->middleware($auth)->middleware($perm('admin.audit_logs.view'));
    $r->get('/admin/data-recovery', [DataRecoveryController::class, 'list'])->middleware($auth)->middleware($perm('admin.audit_logs.view'));
    $r->get('/admin/data-recovery/{logId}', [DataRecoveryController::class, 'show'])->middleware($auth)->middleware($perm('admin.audit_logs.view'));
    $r->post('/admin/data-recovery/{logId}/restore', [DataRecoveryController::class, 'restore'])->middleware($auth)->middleware($perm('admin.audit_logs.restore'));
    GeneratedResourceRegistry::registerRoutes($r, $auth, $perm);
});

if (!str_starts_with($requestPath, '/api')) {
    $angularAdmin = new AngularAdminRenderer($rootPath);
    if ($angularAdmin->serveRuntimeConfiguration($normalizedRequestPath) || $angularAdmin->serveAsset($normalizedRequestPath)) {
        exit;
    }
    $landingRequest = Request::fromGlobals();

    $adminBasePath = nite_admin_base_path();
    if (admin_interface_enabled() && ($normalizedRequestPath === $adminBasePath || str_starts_with($normalizedRequestPath, $adminBasePath . '/')) && $landingRequest->prefersHtml()) {
        $selection = trim((string)($landingRequest->query['resource'] ?? ''));
        if ($selection === '') {
            $selection = (string)(admin_selection_from_path($normalizedRequestPath) ?? '');
        }

        http_response_code(200);
        header('Content-Type: text/html; charset=UTF-8');
        header('Vary: Accept');
        echo render_admin_workspace($selection === '' ? null : $selection);
        exit;
    }

    if ($normalizedRequestPath === '/health') {
        http_response_code(200);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['status' => 'ok', 'time' => gmdate('c')]);
        exit;
    }

    if (html_interface_enabled() && ($normalizedRequestPath === '/' || $normalizedRequestPath === '/explorer') && $landingRequest->prefersHtml()) {
        http_response_code(302);
        header('Location: /api/v1/meta/routes');
        header('Vary: Accept');
        exit;
    }

    if ($normalizedRequestPath === '/explorer') {
        http_response_code(410);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'name' => 'nite-api',
            'message' => 'The standalone explorer has been removed. Use /api/v1/meta/routes for the browsable route index.',
            'docs' => [
                'api_root' => '/api/v1',
                'routes' => '/api/v1/meta/routes',
                'resources' => '/api/v1/meta/resources',
                'framework' => '/api/v1/framework',
            ],
        ]);
        exit;
    }

    http_response_code(200);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'name' => 'nite-api',
        'message' => 'Use /api/v1/meta/routes as the first browsable page and /api/v1/* for endpoint responses.',
        'docs' => [
            'api_root' => '/api/v1',
            'routes' => '/api/v1/meta/routes',
            'resources' => '/api/v1/meta/resources',
            'framework' => '/api/v1/framework',
        ],
    ]);
    exit;
}

send_cors_headers();
$request = Request::fromGlobals();
$normalizedApiRequestPath = rtrim($request->path, '/') ?: '/';
if (
    html_interface_enabled()
    && $normalizedApiRequestPath === '/api/v1'
    && ($request->query['format'] ?? null) !== 'json'
    && $request->prefersHtml()
) {
    http_response_code(302);
    header('Location: /api/v1/meta/routes');
    header('Vary: Accept');
    exit;
}

$matchingRoutes = $router->matchingRoutes($request->path);
$audits = new SystemAuditService();
$startedAt = microtime(true);
$dispatchError = null;

if (isset($request->attributes['body_parse_error'])) {
    $response = ApiResponse::validationError(['body' => [$request->attributes['body_parse_error']]]);
} else {
    try {
        $response = $router->dispatch($request);
    } catch (\Throwable $e) {
        $dispatchError = $e;
        $response = exception_error_response($e, $request);
    }
}

$auditResponse = $response;
if (should_render_browsable_api($request, $response)) {
    $html = render_browsable_api_page($request, $response, $matchingRoutes);
    $htmlHeaders = safe_response_headers($response->headers);
    unset($htmlHeaders['Content-Type']);
    $htmlHeaders['Vary'] = 'Accept';
    $response = Response::html($html, $response->status, $htmlHeaders);
}

$audits->logRequest($request, $auditResponse, (int)round((microtime(true) - $startedAt) * 1000), $dispatchError);
emit_response($response);
