# Nite

Nite is a custom PHP starter framework for building JSON-first applications with a lightweight runtime and a browsable API interface for live endpoint inspection. It ships with:

- a lightweight custom runtime: request, response, router, middleware, JWT auth, RBAC, audit logging
- working concrete modules: content, media, events, resources, courses, enrollments, dashboard
- generic example modules for broader capability families
- route metadata, resource schemas, and a browsable API interface for live endpoint testing
- editor-friendly metadata contracts for autofill, completion, and inline validation
- reusable validation, password policy, login throttling, and stronger JWT claim validation
- a lightweight query-builder foundation for model queries
- PHPUnit-backed framework tests plus console and smoke-test tooling
- a SQL-like resource DSL that can explain, generate, alter, and drop resource modules plus stored blueprints
- PostgreSQL and MySQL schema support, seed data, migration and smoke-test scripts
- docs and request examples so new users can start quickly

## Included Feature Families

- content and site settings
- media library and gallery
- events and registrations
- courses, modules, enrollments, and progress
- catalog examples: categories, service areas, tags
- workflow examples: work items, offers, ratings, favorites, milestones, reports
- messaging examples: notifications, conversations, webhooks, outbound queue, integrations
- payments examples: integrations, currencies, transactions, escrows, disputes, callback queue
- subscriptions examples: plans, features, invoices, activations
- trust examples: reports, blocks, moderation actions
- chatbot examples: config, knowledge, conversations
- analytics examples: tracking events, dashboards, anomalies, rules
- recruitment examples: programs, activation rules, bonuses, tiers, cashouts
- governance: users, RBAC, audit logs

## Quick Start

Install Composer dependencies first:

```bash
composer install
```

Prefer the console entrypoint for setup and lifecycle work after that:

```bash
php nite list
php nite starter:list
```

Fastest full setup path:

```bash
php nite app:bootstrap "Acme Inventory" --starter=inventory-management --sample-count=240 --db-driver=pgsql --db-name=acme_inventory --seed
```

For a dedicated project under `projects/<slug>`:

```bash
php nite app:bootstrap "Client Portal" --project=client-portal --starter=website-management --port=8286 --sample-count=120 --db-name=nite_client_portal --seed
```

See [Starter Apps](docs/starters.md) and [App Bootstrap](docs/app-bootstrap.md) for the full console-first workflow.

Declarative generated resources are also supported:

```bash
php nite schema:explain --file=docs/examples/lesson-schedules.nite --json
php nite schema:apply --file=docs/examples/lesson-schedules.nite
```

See [Resource DSL](docs/resource-dsl.md) for the SQL-like resource syntax and the generated `blueprints/resources/*.resource.json` contracts.

1. Copy `.env.example` to `.env`.
2. Choose `DB_DRIVER=pgsql` or `DB_DRIVER=mysql` in `.env`.
3. Create the matching database named `nite`.
4. Run:

```bash
php nite app:install --seed
php nite app:serve --host=0.0.0.0 --port=8185
```

Common Composer shortcuts are also available:

```bash
composer run install-app
composer run serve
composer run doctor
composer run test
```

Mail delivery can be configured from env only. See [Mail](docs/mail.md) for SMTP/DSN setup, queue workers, anti-spoof controls, DKIM, and local Mailpit usage.

## Usage Modes

This repository supports three usage models side by side:

- single-project application mode from the repository root
- multi-project shared framework mode under `projects/<slug>`
- public framework distribution mode through tagged GitHub releases

See [Usage Modes](docs/usage-modes.md) for the combined workflow.

For release-to-release upgrades, read [UPGRADE.md](UPGRADE.md) before running `php nite app:update`.

Multi-project setup is also supported from the same framework codebase. Create each project with its own port and then serve it by slug:

```bash
php nite app:bootstrap "Project 1" --project=project1 --starter=website-management --port=8286 --seed
php nite app:bootstrap "Project 2" --project=project2 --starter=inventory-management --port=8287 --seed
php nite app:serve --project=project1
php nite app:serve --project=project2
```

Each project gets a manifest under `projects/<slug>/project.json`, keeps the same framework code, and now also gets:

- `projects/<slug>/.env` for host-based `php nite ... --project=<slug>` runs
- `projects/<slug>/.env.docker` for container-based runs
- `projects/<slug>/app.blueprint.json` and `projects/<slug>/app-blueprint.md` for human and AI context
- `projects/<slug>/starter-samples.json` and `projects/<slug>/starter-samples.md` when a starter app sample bundle is generated
- `projects/<slug>/Dockerfile`
- `projects/<slug>/docker-compose.yml`

Legacy one-off scripts and the raw built-in server still exist, but prefer `php nite ...`:

```bash
php -S 0.0.0.0:8185 -t public public/index.php
php scripts/migrate.php
php scripts/seed.php
```

## Docker

Single-project root runtime:

```bash
copy .env.docker.example .env.docker
docker compose up --build
```

The root Docker stack also exposes Mailpit for local SMTP capture:

- SMTP: `127.0.0.1:1025`
- UI: `http://127.0.0.1:8025`
- A dedicated `queue-worker` service runs `php nite queue:work --daemon` for background mail delivery

Multi-project runtime:

```bash
php nite project:create "Project 1" --slug=project1 --port=8286
docker compose -f projects/project1/docker-compose.yml up --build
```

If you run PostgreSQL from the bundled root `docker-compose.yml` but keep PHP on the host machine, leave `DB_HOST=127.0.0.1` and use `DB_PORT=55440`. If you run the app inside the compose `app` container as well, keep `DB_HOST=postgres` and `DB_PORT=5432`.

For multi-project runs, each generated `projects/<slug>/.env` and `projects/<slug>/.env.docker` pair keeps host and container database settings separate so the same project can run both ways without manual rewiring.

4. Open:

- `http://127.0.0.1:8185/`
- `http://127.0.0.1:8185/admin`
- `http://127.0.0.1:8185/api/v1/meta/routes`
- `http://127.0.0.1:8185/api/v1`
- `http://127.0.0.1:8185/api/v1/health`
- `http://127.0.0.1:8185/api/v1/framework`
- `http://127.0.0.1:8185/api/v1/meta/resources`

Browsable API:

- Set `NITE_BROWSABLE_API=true` to render HTML endpoint pages for browser requests that prefer `text/html`
- Set `NITE_BROWSABLE_API=false` to keep API endpoints JSON-only
- Set `NITE_ADMIN_ENABLED=false` to disable the `/admin` frontend without disabling other HTML helper pages
- Use `?format=json` on an API URL to force plain JSON in the browser
- Use `/admin` for the standalone Django-style administration frontend. It is sign-in gated, auto-attaches to built-in and generated Nite resources, and renders grouped models, changelists, filters, sortable/API-paged result tables, add/change forms, bulk actions, RBAC roles/groups/user overrides, object history, relation pickers, related child panels, media upload controls, date inputs, and switchable themes. See [Nite Admin](docs/admin.md).
- Browser visits to `/`, `/explorer`, and HTML `/api/v1` redirect to `/api/v1/meta/routes`
- The browsable UI exposes `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE`, and `OPTIONS` when an endpoint supports them
- Relation fields can render live picker lists, and media-linked fields can upload files inline
- `201 Created` responses expose `Location` headers when the created resource has a canonical detail route

Mail:

- `MAIL_QUEUE_MODE=database` stores outbound mail in `mail_queue` for worker-driven delivery
- `MAIL_QUEUE_SLEEP_SECONDS=3` controls the worker polling interval in daemon mode
- `MAIL_OVERRIDE_TO=qa@example.com` redirects every outbound message to a safe inbox
- `MAIL_ENFORCE_TRUSTED_FROM=true` blocks arbitrary custom `From` spoofing and rewrites untrusted senders back to the configured framework sender
- `MAIL_DSN=` supports advanced Symfony Mailer DSNs such as failover and round-robin transports
- `MAIL_CONTACT_NOTIFICATION_ENABLED=true` and `MAIL_CONTACT_AUTO_REPLY_ENABLED=true` enable built-in contact-form notifications

Auth and validation:

- `AUTH_PASSWORD_*` env keys enforce framework-wide password rules without duplicating controller logic
- `AUTH_LOGIN_*` env keys enable login throttling with database-backed attempt tracking
- `AUTH_TOKEN_ISSUER` and `AUTH_TOKEN_AUDIENCE` let JWT validation enforce tighter private-enterprise token boundaries

Media storage:

- `MEDIA_STORAGE_DRIVER=local` keeps the current filesystem behavior under `MEDIA_STORAGE_ROOT`
- `MEDIA_STORAGE_DRIVER=ftp` or `ftps` sends uploads to a remote FTP server with username/password auth
- `MEDIA_STORAGE_DRIVER=s3` targets AWS S3 and most S3-compatible bucket providers
- `MEDIA_STORAGE_DRIVER=http`, `https`, or `webdav` targets a remote HTTPS endpoint that supports `PUT`, `GET`, `HEAD`, and `DELETE`
- `MEDIA_UPLOAD_MAX_BYTES`, `MEDIA_UPLOAD_ALLOWED_MIME_TYPES`, and `MEDIA_UPLOAD_ALLOWED_EXTENSIONS` constrain accepted uploads before storage
- Existing media routes stay the same: uploads still go through `/api/v1/admin/media` and downloads still come from `/api/v1/media/{id}/download`
- Storage history now keeps the real backend locator, so version restore does not assume local disk paths anymore

Example bucket config:

```bash
MEDIA_STORAGE_DRIVER=s3
MEDIA_STORAGE_S3_BUCKET=my-app-media
MEDIA_STORAGE_S3_REGION=us-east-1
MEDIA_STORAGE_S3_KEY=your-access-key
MEDIA_STORAGE_S3_SECRET=your-secret-key
MEDIA_STORAGE_S3_ENDPOINT=
MEDIA_STORAGE_S3_PATH_STYLE=false
MEDIA_STORAGE_PREFIX=project1
```

Example remote file server config:

```bash
MEDIA_STORAGE_DRIVER=https
MEDIA_STORAGE_HTTP_BASE_URL=https://files.example.com/dav/uploads
MEDIA_STORAGE_HTTP_USERNAME=media-user
MEDIA_STORAGE_HTTP_PASSWORD=change-me
MEDIA_STORAGE_HTTP_VERIFY_TLS=true
MEDIA_STORAGE_PREFIX=project1
```

`s3` works with AWS S3 and most compatible services such as MinIO, Wasabi, DigitalOcean Spaces, Cloudflare R2, and similar gateways. Native Google Drive, OneDrive, and SharePoint are not simple username/password file targets; use an S3-compatible gateway, a WebDAV-compatible bridge, or add a dedicated adapter for those providers.

Starter login:

- email: `admin@nite.local`
- password: `Passw0rd!2026` unless `NITE_SEED_DEFAULT_PASSWORD` is set before seeding

Production hardening:

- set `APP_ENV=production`
- set `APP_DEBUG=false`
- set `NITE_BROWSABLE_API=false` unless route inspection is intentionally public
- set `NITE_ADMIN_ENABLED=false` when the built-in admin frontend should not be publicly reachable
- replace `JWT_SECRET=change-me` with a generated secret of at least 32 characters
- set `NITE_SEED_DEFAULT_PASSWORD` before running `php nite db:seed`
- replace default database credentials
- run `php nite app:doctor`; production-mode debug, placeholder JWT, default DB passwords, and browsable API exposure are reported as errors

## Console

Use `php nite list` to inspect the built-in console commands. Prefer `php nite ...` for install, update, upgrade, downgrade, migrations, scaffolding, and release management:

```bash
php nite list
php nite starter:list
php nite starter:show inventory-management --json
php nite app:bootstrap "Acme Inventory" --starter=inventory-management --sample-count=500 --seed
php nite app:bootstrap "Project 1" --project=project1 --starter=website-management --port=8286 --sample-count=120 --no-migrate
php nite app:remove-samples --force
php nite create resource Report
php nite schema:explain --file=docs/examples/lesson-schedules.nite --json
php nite schema:apply --file=docs/examples/lesson-schedules.nite
php nite create migration add_report_indexes --version=1.0.1
php nite remove resource Report --backup
php nite db:migrate
php nite db:seed
php nite db:rollback --steps=1
php nite db:refresh --force --seed
php nite db:wipe --force
php nite route:list --method=GET --path=/admin
php nite resource:list --group=content
php nite module:list
php nite permission:list --role=admin
php nite mail:test --to=dev@example.com
php nite mail:queue:list
php nite mail:queue:work --limit=25
php nite queue:stats
php nite queue:work --daemon --sleep=3
php nite mail:queue:retry --all
php nite project:create "Project 1" --slug=project1 --port=8286
php nite project:list
php nite app:about
php nite app:doctor
php scripts/rest-audit.php --api-base=http://127.0.0.1:8185
php scripts/smoke-test.php --api-base=http://127.0.0.1:8185
php nite app:install 1.0.1 --seed
php nite app:serve --host=127.0.0.1 --port=8185
php nite app:update
php nite app:releases --limit=10
php nite app:version
php nite app:uninstall --force
php nite app:upgrade 3.0.0 --accept-compatibility
php nite app:downgrade 1.0.0 --force
php nite app:conflicts:check resource Report --table=reports
php nite eval "return App\Config\Database::driver();"
```

Composer helpers for the most common tasks:

```bash
composer run nite -- list
composer run app-about
composer run doctor
composer run test
composer run migrate
composer run seed
composer run serve
php nite project:list
composer run rest-audit -- --api-base=http://127.0.0.1:8185
composer run smoke -- --api-base=http://127.0.0.1:8185
```

Generated resources include:

- a model scaffold
- a service scaffold
- a controller scaffold
- a reversible migration file with `up` and `down`
- a generated route manifest under `routes/generated/` that auto-registers public and admin CRUD routes
- a preview route snippet under `examples/generated/`
- generated admin permission definitions for view/manage access in RBAC

Destructive commands such as `db:refresh`, `db:wipe`, `app:uninstall`, and `app:downgrade` require confirmation in an interactive shell, or `--force` in non-interactive runs.
Use `php nite samples:clean --dry-run` to inspect only untouched Nite 2.x sample files before a conservative cleanup.
Use `--rollback` with `remove resource` or `remove migration` when you also want the matching console migration rolled back before the files are deleted.
`app:install`, `app:update`, `app:upgrade`, and `app:downgrade` sync curated public install releases over HTTPS from `https://github.com/fredricknsanhewe/nite-install`.
Use `app:about`, `app:doctor`, `route:list`, `resource:list`, `module:list`, and `permission:list` when you want Laravel or Django style framework introspection from the same console entrypoint.
Those inspection commands accept `--json`, and `app:doctor` returns a non-zero exit code when it finds hard errors.

## Project Layout

```text
nite/
  projects/
  public/
  src/
    Config/
    Console/
    Controllers/
    Http/
    Models/
    Services/
    Support/
    Utils/
  database/
    schema.sql
    schema.mysql.sql
    examples/
  docs/
  examples/
  routes/
    generated/
  .env.docker.example
  docker-compose.yml
  Dockerfile
  nite.php
  scripts/
```

## Key Routes

- `GET /api/v1/framework`
- `GET /api/v1/framework/modules`
- `GET /api/v1/meta/routes`
- `GET /api/v1/meta/resources`
- `GET /api/v1/examples/{module}/{entity}`
- `POST /api/v1/examples/{module}/{entity}`
- `GET /api/v1/search/global?q=...`
- `GET /api/v1/site/bootstrap`
- `GET /api/v1/pages`
- `GET /api/v1/news`
- `GET /api/v1/events`
- `GET /api/v1/resources`
- `GET /api/v1/courses`

## Docs

- [Architecture](docs/architecture.md)
- [Quick Start](docs/quick-start.md)
- [Module Map](docs/module-map.md)
- [Database Guide](docs/database.md)
- [Examples](docs/examples.md)
- [Extending Nite](docs/extending.md)
- [Editor Integration](docs/editor-integration.md)
- [Usage Modes](docs/usage-modes.md)
- [Mail](docs/mail.md)
- [Releases](docs/releases.md)
- [Sample CRUD Module](docs/sample-crud.md)
