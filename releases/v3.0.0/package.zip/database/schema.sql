CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password_hash TEXT NOT NULL,
    name VARCHAR(200) NOT NULL,
    role VARCHAR(30) NOT NULL CHECK (role IN ('member', 'trainer', 'editor', 'support', 'admin')),
    account_status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (account_status IN ('active', 'inactive', 'suspended')),
    profile_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    last_login_at TIMESTAMPTZ NULL,
    password_changed_at TIMESTAMPTZ NULL,
    force_password_change BOOLEAN NOT NULL DEFAULT FALSE,
    created_by_user_id UUID NULL,
    updated_by_user_id UUID NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_lower ON users (LOWER(email));

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_created_by_fk') THEN
        ALTER TABLE users
            ADD CONSTRAINT users_created_by_fk FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_updated_by_fk') THEN
        ALTER TABLE users
            ADD CONSTRAINT users_updated_by_fk FOREIGN KEY (updated_by_user_id) REFERENCES users(id) ON DELETE SET NULL;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS user_password_history (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    password_hash TEXT NOT NULL,
    changed_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    change_source VARCHAR(40) NOT NULL DEFAULT 'user_change',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_password_history_user_created ON user_password_history (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_password_history_changed_by ON user_password_history (changed_by_user_id);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ NULL,
    requested_ip VARCHAR(64) NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_email ON password_reset_tokens (email);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_created ON password_reset_tokens (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS permissions (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(120) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    description TEXT NULL,
    section_code VARCHAR(120) NULL,
    section_title VARCHAR(180) NULL,
    module_code VARCHAR(120) NULL,
    module_title VARCHAR(180) NULL,
    action_code VARCHAR(120) NULL,
    action_title VARCHAR(180) NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS role_permission_rules (
    role VARCHAR(30) NOT NULL CHECK (role IN ('member', 'trainer', 'editor', 'support', 'admin')),
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (role, permission_id)
);

CREATE TABLE IF NOT EXISTS rbac_groups (
    id UUID PRIMARY KEY,
    code VARCHAR(80) NOT NULL UNIQUE,
    name VARCHAR(160) NOT NULL,
    description TEXT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rbac_groups_active_name ON rbac_groups (is_active, name);

CREATE TABLE IF NOT EXISTS rbac_group_members (
    group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (group_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_rbac_group_members_user ON rbac_group_members (user_id);

CREATE TABLE IF NOT EXISTS rbac_group_permission_rules (
    group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (group_id, permission_id)
);

CREATE INDEX IF NOT EXISTS idx_rbac_group_permission_rules_permission ON rbac_group_permission_rules (permission_id);

CREATE TABLE IF NOT EXISTS user_permission_overrides (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, permission_id)
);

CREATE TABLE IF NOT EXISTS site_settings (
    config_key VARCHAR(80) PRIMARY KEY,
    visibility VARCHAR(20) NOT NULL DEFAULT 'admin' CHECK (visibility IN ('public', 'admin')),
    settings JSONB NOT NULL DEFAULT '{}'::JSONB,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pages (
    id UUID PRIMARY KEY,
    slug VARCHAR(120) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    summary TEXT NULL,
    hero_title VARCHAR(200) NULL,
    hero_summary TEXT NULL,
    hero_image_url TEXT NULL,
    content_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    seo_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    sort_order INTEGER NOT NULL DEFAULT 0,
    published_at TIMESTAMPTZ NULL,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pages_status_sort ON pages (status, sort_order, updated_at DESC);

CREATE TABLE IF NOT EXISTS news_posts (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    post_type VARCHAR(30) NOT NULL CHECK (post_type IN ('news', 'announcement', 'notice')),
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    body TEXT NOT NULL DEFAULT '',
    featured_image_url TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    published_at TIMESTAMPTZ NULL,
    meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_news_posts_status_type_published ON news_posts (status, post_type, published_at DESC);

CREATE TABLE IF NOT EXISTS training_events (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    description TEXT NOT NULL DEFAULT '',
    event_format VARCHAR(20) NOT NULL DEFAULT 'in_person' CHECK (event_format IN ('in_person', 'online', 'hybrid')),
    location VARCHAR(240) NULL,
    meeting_url TEXT NULL,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NULL,
    registration_open BOOLEAN NOT NULL DEFAULT TRUE,
    registration_deadline TIMESTAMPTZ NULL,
    capacity INTEGER NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'cancelled', 'completed')),
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_training_events_status_starts ON training_events (status, starts_at ASC);

CREATE TABLE IF NOT EXISTS event_registrations (
    id UUID PRIMARY KEY,
    event_id UUID NOT NULL REFERENCES training_events(id) ON DELETE CASCADE,
    registered_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(60) NULL,
    organisation VARCHAR(200) NULL,
    role_title VARCHAR(200) NULL,
    notes TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'waitlisted', 'cancelled', 'declined')),
    attended BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_event_registrations_unique_email ON event_registrations (event_id, LOWER(email));

CREATE TABLE IF NOT EXISTS resources (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    description TEXT NOT NULL DEFAULT '',
    resource_type VARCHAR(30) NOT NULL CHECK (resource_type IN ('manual', 'guideline', 'publication', 'report', 'research', 'multimedia', 'link')),
    file_url TEXT NULL,
    external_url TEXT NULL,
    thumbnail_url TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    published_at TIMESTAMPTZ NULL,
    meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_resources_status_type_published ON resources (status, resource_type, published_at DESC);

CREATE TABLE IF NOT EXISTS media_assets (
    id UUID PRIMARY KEY,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(150) NOT NULL,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    storage_path TEXT NOT NULL,
    public_url TEXT NULL,
    alt_text TEXT NULL,
    access_scope VARCHAR(20) NOT NULL DEFAULT 'private' CHECK (access_scope IN ('public', 'authenticated', 'roles', 'users', 'private')),
    allowed_roles_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    allowed_user_ids_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    checksum_sha1 VARCHAR(40) NULL,
    current_version_number INTEGER NOT NULL DEFAULT 1,
    version_count INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_media_assets_scope_status_created ON media_assets (access_scope, status, created_at DESC);

CREATE TABLE IF NOT EXISTS media_asset_versions (
    id UUID PRIMARY KEY,
    media_asset_id UUID NOT NULL REFERENCES media_assets(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(150) NOT NULL,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    storage_path TEXT NOT NULL,
    public_url TEXT NULL,
    alt_text TEXT NULL,
    checksum_sha1 VARCHAR(40) NULL,
    change_notes TEXT NULL,
    action VARCHAR(20) NOT NULL DEFAULT 'create' CHECK (action IN ('create', 'replace', 'restore')),
    source_version_id UUID NULL REFERENCES media_asset_versions(id) ON DELETE SET NULL,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (media_asset_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_media_asset_versions_asset_created ON media_asset_versions (media_asset_id, created_at DESC);

CREATE TABLE IF NOT EXISTS gallery_albums (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    cover_image_url TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gallery_items (
    id UUID PRIMARY KEY,
    album_id UUID NULL REFERENCES gallery_albums(id) ON DELETE SET NULL,
    media_asset_id UUID NULL REFERENCES media_assets(id) ON DELETE SET NULL,
    title VARCHAR(240) NOT NULL,
    caption TEXT NULL,
    media_type VARCHAR(20) NOT NULL DEFAULT 'image' CHECK (media_type IN ('image', 'video')),
    media_url TEXT NOT NULL,
    thumbnail_url TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    sort_order INTEGER NOT NULL DEFAULT 0,
    captured_at TIMESTAMPTZ NULL,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gallery_items_status_sort ON gallery_items (status, sort_order, created_at DESC);

CREATE TABLE IF NOT EXISTS contact_messages (
    id UUID PRIMARY KEY,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(60) NULL,
    subject VARCHAR(240) NOT NULL,
    message TEXT NOT NULL,
    source VARCHAR(30) NOT NULL DEFAULT 'website',
    status VARCHAR(20) NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'resolved', 'closed', 'spam')),
    assigned_to_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_contact_messages_status_created ON contact_messages (status, created_at DESC);

CREATE TABLE IF NOT EXISTS mail_queue (
    id UUID PRIMARY KEY,
    message_type VARCHAR(80) NOT NULL DEFAULT 'transactional',
    status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'sent', 'failed')),
    transport VARCHAR(40) NOT NULL DEFAULT 'smtp',
    priority INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    cc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    bcc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    reply_to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
    subject VARCHAR(255) NOT NULL,
    text_body TEXT NULL,
    html_body TEXT NULL,
    from_address VARCHAR(255) NOT NULL,
    from_name VARCHAR(255) NULL,
    sender_address VARCHAR(255) NULL,
    headers_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    metadata_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    delivery_meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    last_error TEXT NULL,
    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reserved_at TIMESTAMPTZ NULL,
    sent_at TIMESTAMPTZ NULL,
    failed_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mail_queue_status_available ON mail_queue (status, available_at ASC, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_mail_queue_type_status_created ON mail_queue (message_type, status, created_at DESC);

CREATE TABLE IF NOT EXISTS auth_login_attempts (
    id UUID PRIMARY KEY,
    throttle_key VARCHAR(128) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL,
    ip_address VARCHAR(64) NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    first_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locked_until TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auth_login_attempts_last_attempt ON auth_login_attempts (last_attempt_at DESC);

CREATE TABLE IF NOT EXISTS courses (
    id UUID PRIMARY KEY,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    description TEXT NOT NULL DEFAULT '',
    delivery_mode VARCHAR(20) NOT NULL DEFAULT 'self_paced' CHECK (delivery_mode IN ('self_paced', 'cohort', 'webinar', 'external_lms')),
    lms_url TEXT NULL,
    starts_at TIMESTAMPTZ NULL,
    ends_at TIMESTAMPTZ NULL,
    certificate_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_courses_status_created ON courses (status, created_at DESC);

CREATE TABLE IF NOT EXISTS course_modules (
    id UUID PRIMARY KEY,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    content_type VARCHAR(20) NOT NULL DEFAULT 'document' CHECK (content_type IN ('text', 'document', 'video', 'quiz', 'live_session', 'link')),
    content_url TEXT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    duration_minutes INTEGER NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_course_modules_course_sort ON course_modules (course_id, sort_order ASC);

CREATE TABLE IF NOT EXISTS course_enrollments (
    id UUID PRIMARY KEY,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'enrolled' CHECK (status IN ('enrolled', 'completed', 'cancelled')),
    progress_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
    certificate_issued BOOLEAN NOT NULL DEFAULT FALSE,
    enrolled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL,
    last_activity_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (course_id, user_id)
);

CREATE TABLE IF NOT EXISTS course_progress (
    id UUID PRIMARY KEY,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    module_id UUID NOT NULL REFERENCES course_modules(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed')),
    progress_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
    completed_at TIMESTAMPTZ NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (module_id, user_id)
);

CREATE TABLE IF NOT EXISTS data_change_logs (
    id BIGSERIAL PRIMARY KEY,
    table_name VARCHAR(120) NOT NULL,
    record_id VARCHAR(120) NOT NULL,
    record_slug VARCHAR(160) NULL,
    record_title VARCHAR(255) NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('create', 'update', 'delete', 'restore')),
    change_scope VARCHAR(120) NOT NULL DEFAULT 'data',
    actor_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    actor_role VARCHAR(30) NULL,
    request_method VARCHAR(10) NULL,
    request_path TEXT NULL,
    route_path TEXT NULL,
    ip_address VARCHAR(64) NULL,
    user_agent TEXT NULL,
    reason TEXT NULL,
    before_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    after_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    diff_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    metadata_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    restorable_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    restored_from_log_id BIGINT NULL REFERENCES data_change_logs(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_data_change_logs_table_record ON data_change_logs (table_name, record_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_data_change_logs_action_created ON data_change_logs (action, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_data_change_logs_actor_created ON data_change_logs (actor_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS system_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    scope VARCHAR(80) NOT NULL,
    actor_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    actor_role VARCHAR(30) NULL,
    method VARCHAR(10) NOT NULL,
    path TEXT NOT NULL,
    route_path TEXT NULL,
    required_permissions JSONB NOT NULL DEFAULT '[]'::JSONB,
    success BOOLEAN NOT NULL DEFAULT TRUE,
    http_status INTEGER NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    ip_address VARCHAR(64) NULL,
    user_agent TEXT NULL,
    request_payload JSONB NOT NULL DEFAULT '{}'::JSONB,
    response_payload JSONB NOT NULL DEFAULT '{}'::JSONB,
    error_message TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_system_audit_logs_scope_created ON system_audit_logs (scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_system_audit_logs_actor_created ON system_audit_logs (actor_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS example_entities (
    id UUID PRIMARY KEY,
    module_key VARCHAR(80) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    slug VARCHAR(140) NULL,
    title VARCHAR(240) NOT NULL,
    summary TEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'published', 'archived', 'disabled')),
    owner_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    payload_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_example_entities_module_entity ON example_entities (module_key, entity_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_example_entities_slug ON example_entities (slug);
CREATE INDEX IF NOT EXISTS idx_example_entities_status ON example_entities (status);

CREATE TABLE IF NOT EXISTS example_entries (
    id UUID PRIMARY KEY,
    entity_id UUID NOT NULL REFERENCES example_entities(id) ON DELETE CASCADE,
    entry_type VARCHAR(30) NOT NULL CHECK (entry_type IN ('note', 'message', 'timeline', 'audit', 'status_change')),
    body TEXT NOT NULL,
    payload_json JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_example_entries_entity_created ON example_entries (entity_id, created_at ASC);
