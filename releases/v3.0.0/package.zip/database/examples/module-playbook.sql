-- Content examples
SELECT slug, title, status FROM pages ORDER BY sort_order, created_at DESC;
SELECT slug, title, post_type, published_at
FROM news_posts
ORDER BY (published_at IS NULL) ASC, published_at DESC;

-- Learning examples
SELECT slug, title, delivery_mode, status FROM courses ORDER BY created_at DESC;
SELECT course_id, user_id, progress_percent, status FROM course_enrollments ORDER BY enrolled_at DESC;

-- Generic module examples
SELECT module_key, entity_type, title, status FROM example_entities ORDER BY module_key, entity_type, created_at DESC;

-- Workflow examples
SELECT title, payload_json->>'status_flow' AS status_flow
FROM example_entities
WHERE module_key = 'workflow' AND entity_type = 'work_items';

-- Messaging examples
SELECT title, payload_json->'channels' AS channels
FROM example_entities
WHERE module_key = 'messaging' AND entity_type = 'notifications';

-- Payment examples
SELECT title, payload_json->>'provider' AS provider
FROM example_entities
WHERE module_key = 'payments' AND entity_type = 'integrations';

-- Subscription examples
SELECT title, payload_json->>'billing_cycle' AS billing_cycle
FROM example_entities
WHERE module_key = 'subscriptions' AND entity_type = 'plans';

-- Trust examples
SELECT title, payload_json->>'priority' AS priority
FROM example_entities
WHERE module_key = 'trust' AND entity_type = 'reports';

-- Chatbot examples
SELECT title, payload_json->>'source' AS source
FROM example_entities
WHERE module_key = 'chatbot' AND entity_type = 'knowledge';

-- Analytics examples
SELECT title, payload_json->>'event' AS event_name
FROM example_entities
WHERE module_key = 'analytics' AND entity_type = 'tracking_events';

-- Recruitment examples
SELECT title, payload_json->>'payout_model' AS payout_model
FROM example_entities
WHERE module_key = 'recruitment' AND entity_type = 'programs';
