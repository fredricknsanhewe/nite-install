<?php

return [
    'name' => 'create_rbac_groups',
    'version' => '1.1.0',
    'up' => [
        'pgsql' => [
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_groups (
                id UUID PRIMARY KEY,
                code VARCHAR(80) NOT NULL UNIQUE,
                name VARCHAR(160) NOT NULL,
                description TEXT NULL,
                is_active BOOLEAN NOT NULL DEFAULT TRUE,
                created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            SQL,
            'CREATE INDEX IF NOT EXISTS idx_rbac_groups_active_name ON rbac_groups (is_active, name)',
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_group_members (
                group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
                user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (group_id, user_id)
            )
            SQL,
            'CREATE INDEX IF NOT EXISTS idx_rbac_group_members_user ON rbac_group_members (user_id)',
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_group_permission_rules (
                group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
                permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
                effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (group_id, permission_id)
            )
            SQL,
            'CREATE INDEX IF NOT EXISTS idx_rbac_group_permission_rules_permission ON rbac_group_permission_rules (permission_id)',
        ],
        'mysql' => [
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_groups (
                id CHAR(36) PRIMARY KEY,
                code VARCHAR(80) NOT NULL,
                name VARCHAR(160) NOT NULL,
                description TEXT NULL,
                is_active BOOLEAN NOT NULL DEFAULT TRUE,
                created_by_user_id CHAR(36) NULL,
                updated_by_user_id CHAR(36) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY idx_rbac_groups_code (code),
                KEY idx_rbac_groups_active_name (is_active, name),
                KEY idx_rbac_groups_created_by (created_by_user_id),
                KEY idx_rbac_groups_updated_by (updated_by_user_id),
                CONSTRAINT rbac_groups_created_by_fk FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
                CONSTRAINT rbac_groups_updated_by_fk FOREIGN KEY (updated_by_user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL,
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_group_members (
                group_id CHAR(36) NOT NULL,
                user_id CHAR(36) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (group_id, user_id),
                KEY idx_rbac_group_members_user (user_id),
                CONSTRAINT rbac_group_members_group_fk FOREIGN KEY (group_id) REFERENCES rbac_groups(id) ON DELETE CASCADE,
                CONSTRAINT rbac_group_members_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL,
            <<<'SQL'
            CREATE TABLE IF NOT EXISTS rbac_group_permission_rules (
                group_id CHAR(36) NOT NULL,
                permission_id BIGINT NOT NULL,
                effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (group_id, permission_id),
                KEY idx_rbac_group_permission_rules_permission (permission_id),
                CONSTRAINT rbac_group_permission_rules_group_fk FOREIGN KEY (group_id) REFERENCES rbac_groups(id) ON DELETE CASCADE,
                CONSTRAINT rbac_group_permission_rules_permission_fk FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL,
        ],
    ],
    'down' => [
        'pgsql' => [
            'DROP TABLE IF EXISTS rbac_group_permission_rules',
            'DROP TABLE IF EXISTS rbac_group_members',
            'DROP TABLE IF EXISTS rbac_groups',
        ],
        'mysql' => [
            'DROP TABLE IF EXISTS rbac_group_permission_rules',
            'DROP TABLE IF EXISTS rbac_group_members',
            'DROP TABLE IF EXISTS rbac_groups',
        ],
    ],
];
