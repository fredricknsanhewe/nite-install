<?php

use App\Config\Database;
use App\Config\Env;
use App\Support\DatabaseSchemaRunner;
use App\Support\ProjectRegistry;

$rootPath = require dirname(__DIR__) . '/bootstrap/autoload.php';

Env::loadFirstAvailable([
    $rootPath . '/.env',
    $rootPath . '/.env.example',
]);
(new ProjectRegistry($rootPath))->bootstrapActiveFromEnvironment();

function tableCount(\PDO $connection, string $databaseName): int
{
    $statement = $connection->prepare('SELECT COUNT(*) AS total FROM information_schema.tables WHERE table_schema = :schema');
    $statement->execute([':schema' => $databaseName]);
    $row = $statement->fetch();
    return (int)($row['total'] ?? 0);
}

try {
    $connection = Database::connection();
    DatabaseSchemaRunner::apply($connection);
    echo "Migration complete.\n";
    echo 'Driver: ' . Database::driver() . "\n";
    echo 'Database: ' . trim((string)Env::get('DB_NAME', 'nite')) . "\n";
    echo 'Schema file: ' . Database::schemaPath() . "\n";
    echo 'Tables available: ' . tableCount($connection, trim((string)Env::get('DB_NAME', 'nite'))) . "\n";
} catch (\Throwable $e) {
    fwrite(STDERR, 'Migration failed: ' . $e->getMessage() . "\n");
    exit(1);
}
