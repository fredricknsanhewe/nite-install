# Quick Start

## Local setup

Install Composer dependencies first:

```bash
composer install
```

Prefer the console entrypoint after that:

```bash
php nite list
php nite starter:list
```

Fastest way to shape a working app:

```bash
php nite app:bootstrap "Acme Inventory" --starter=inventory-management --sample-count=240 --db-driver=pgsql --db-name=acme_inventory --seed
```

For the shared-framework multi-project path:

```bash
php nite app:bootstrap "Project 1" --project=project1 --starter=website-management --port=8286 --sample-count=120 --db-name=nite_project1 --seed
```

See [Starter Apps](starters.md) and [App Bootstrap](app-bootstrap.md) for the full starter, sample-pack, resource, and blueprint workflow.

For generated modules described in a SQL-like DSL instead of hand scaffolding, use:

```bash
php nite schema:explain --file=docs/examples/lesson-schedules.nite --json
php nite schema:apply --file=docs/examples/lesson-schedules.nite
```

See [Resource DSL](resource-dsl.md) for the supported syntax.

1. Copy `.env.example` to `.env`.
2. Choose one database driver.
3. Create the matching database.
4. Run:

```bash
php nite app:install --seed
php nite app:serve --host=0.0.0.0 --port=8185
```

Common Composer shortcuts:

```bash
composer run install-app
composer run serve
composer run doctor
composer run test
```

Mail setup is env-driven. For a quick local SMTP target, run Mailpit or use the bundled Docker stack and then set:

```dotenv
MAIL_ENABLED=true
MAIL_TRANSPORT=smtp
MAIL_HOST=127.0.0.1
MAIL_PORT=1025
MAIL_FROM_ADDRESS=no-reply@example.test
MAIL_FROM_NAME=Example App
MAIL_QUEUE_MODE=database
```

See [Mail](mail.md) for queue workers, spoof protection, DKIM, and advanced DSN examples.

## Root Docker runtime

```bash
copy .env.docker.example .env.docker
docker compose up --build
```

The root Docker stack includes Mailpit:

- SMTP on `127.0.0.1:1025`
- web UI on `http://127.0.0.1:8025`
- a `queue-worker` service for background mail delivery

## Multiple projects on separate ports

You can run multiple projects from the same framework checkout by giving each one its own manifest and port:

```bash
php nite project:create "Project 1" --slug=project1 --port=8286
php nite project:create "Project 2" --slug=project2 --port=8287
php nite db:migrate --project=project1
php nite db:migrate --project=project2
php nite app:serve --project=project1
php nite app:serve --project=project2
```

Project manifests live in `projects/<slug>/project.json`. The framework code stays shared; each project also gets:

- `projects/<slug>/.env`
- `projects/<slug>/.env.example`
- `projects/<slug>/.env.docker`
- `projects/<slug>/.env.docker.example`
- `projects/<slug>/app.blueprint.json`
- `projects/<slug>/app-blueprint.md`
- `projects/<slug>/starter-samples.json`
- `projects/<slug>/starter-samples.md`
- `projects/<slug>/Dockerfile`
- `projects/<slug>/docker-compose.yml`

Run a project in Docker with:

```bash
docker compose -f projects/project1/docker-compose.yml up --build
```

Remote media storage is optional. Leave `MEDIA_STORAGE_DRIVER=local` to keep the current filesystem behavior, or switch to:

```dotenv
MEDIA_STORAGE_DRIVER=s3
MEDIA_STORAGE_S3_BUCKET=my-app-media
MEDIA_STORAGE_S3_REGION=us-east-1
MEDIA_STORAGE_S3_KEY=your-access-key
MEDIA_STORAGE_S3_SECRET=your-secret-key
MEDIA_STORAGE_PREFIX=project1
```

or:

```dotenv
MEDIA_STORAGE_DRIVER=https
MEDIA_STORAGE_HTTP_BASE_URL=https://files.example.com/dav/uploads
MEDIA_STORAGE_HTTP_USERNAME=media-user
MEDIA_STORAGE_HTTP_PASSWORD=change-me
```

Media uploads are constrained before storage:

```dotenv
MEDIA_UPLOAD_MAX_BYTES=10485760
MEDIA_UPLOAD_ALLOWED_MIME_TYPES=image/*,application/pdf,text/plain,text/csv
MEDIA_UPLOAD_ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,webp,svg,pdf,txt,csv
```

If you only want the old standalone scripts or raw PHP server, these still work, but prefer `php nite ...`:

```bash
php -S 0.0.0.0:8185 -t public public/index.php
php scripts/migrate.php
php scripts/seed.php
```

## Database options

PostgreSQL:

```dotenv
DB_DRIVER=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=nite
DB_USER=postgres
DB_PASSWORD=postgres
```

If you use the bundled root `docker-compose.yml` PostgreSQL service while running PHP on the host, keep `DB_HOST=127.0.0.1` and change `DB_PORT=55440`. If PHP is also running inside the compose `app` service, use `DB_HOST=postgres` and `DB_PORT=5432`.

MySQL:

```dotenv
DB_DRIVER=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=nite
DB_USER=root
DB_PASSWORD=
```

## Starter credentials

- `admin@nite.local` / `Passw0rd!2026`
- `editor@nite.local` / `Passw0rd!2026`
- `member@nite.local` / `Passw0rd!2026`

These are local starter credentials. Set `NITE_SEED_DEFAULT_PASSWORD` before seeding when you want a different first password. In `APP_ENV=production`, seeding with the default password fails.

## Production hardening

Before exposing a beta instance:

- set `APP_ENV=production`
- set `APP_DEBUG=false`
- set `NITE_BROWSABLE_API=false` unless route inspection is intentionally public
- set a real `JWT_SECRET` with at least 32 characters
- replace default database credentials
- set `NITE_SEED_DEFAULT_PASSWORD` before `php nite db:seed`
- run `php nite app:doctor`

## First endpoints to inspect

- `/`
- `/api/v1/meta/routes`
- `/api/v1`
- `/api/v1/framework`
- `/api/v1/framework/modules`
- `/api/v1/meta/resources`
- `/api/v1/site/bootstrap`
- `/api/v1/examples/workflow/work_items`
- `/api/v1/examples/payments/transactions`
- `/api/v1/search/global?q=example`

## HTML landing

By default, browser visits to `/`, `/explorer`, and HTML requests to `/api/v1` redirect to the browsable route index at `/api/v1/meta/routes`; there is no separate explorer UI anymore.
Use `/admin` for the standalone Django-style administration frontend. It is sign-in gated, auto-attaches to built-in and generated Nite resources, and renders grouped sections, changelists, filters, sortable/API-paged result tables, add/change forms, bulk actions, RBAC roles/groups/user overrides, object history, relation pickers, related child panels, media upload controls, date inputs, and switchable themes. See [Nite Admin](admin.md).
Set `NITE_HTML_INTERFACE_ENABLED=true` in `.env` to keep that enabled.
Set it to `false` to keep the framework JSON-only outside the API routes.

## Browsable API

Set `NITE_BROWSABLE_API=true` to render a browser-friendly API page for `/api/v1/*` routes when the request prefers HTML.
Set `NITE_BROWSABLE_API=false` to keep API endpoints JSON-only.
Append `?format=json` to any API URL when you want raw JSON in the browser.
The browsable API exposes `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE`, and `OPTIONS` when an endpoint supports them, and it can auto-render relation pickers and media upload helpers from route metadata.
Writable resources expose canonical item `GET` routes, and successful `201` create responses include `Location` headers when a stable detail URI exists.

## Editor tooling

Use the machine-readable metadata endpoints for autofill and completion:

- `/api/v1/meta/routes?format=json`
- `/api/v1/meta/resources?format=json`
- `OPTIONS /api/v1/...?...`

See [Editor Integration](editor-integration.md) for the full contract.

## Safe extension path

1. Generate a starter app or project with `php nite app:bootstrap ...` when you want Nite to shape the initial resources for you.
   Use `php nite starter:list` and `php nite starter:show <key>` first when you want a product-shaped starting point.
2. Generate an extra starter resource with `php nite create resource Report` or `php nite schema:apply --file=docs/examples/lesson-schedules.nite` when needed.
3. The runtime auto-loads the generated manifest from `routes/generated/`.
4. Adjust the generated model, service, controller, and migration for your domain.
5. Run `php nite db:migrate`.
6. Add seed or example requests.

## Console shortcuts

- `composer install`
- `composer run nite -- list`
- `composer run app-about`
- `composer run doctor`
- `composer run migrate`
- `composer run seed`
- `composer run serve`
- `php nite project:create "Project 1" --slug=project1 --port=8286`
- `php nite project:list`
- `php nite list`
- `php nite app:about`
- `php nite app:doctor`
- `php nite starter:list`
- `php nite starter:show inventory-management --json`
- `php scripts/rest-audit.php --api-base=http://127.0.0.1:8185`
- `php scripts/smoke-test.php --api-base=http://127.0.0.1:8185`
- `php nite app:serve --host=127.0.0.1 --port=8185`
- `php nite route:list --method=GET --path=/admin`
- `php nite resource:list --group=content`
- `php nite module:list`
- `php nite permission:list --role=admin`
- `php nite mail:test --to=dev@example.com`
- `php nite mail:queue:list`
- `php nite mail:queue:work --limit=25`
- `php nite queue:stats`
- `php nite queue:work --daemon --sleep=3`
- `php nite mail:queue:retry --all`
- `php nite db:seed`
- `php nite db:status`
- `php nite db:rollback --steps=1`
- `php nite db:wipe --force`
- `php nite app:remove-samples --force`
- `php nite app:update`
- `php nite app:releases --limit=10`
- `php nite app:version`
- `php nite app:uninstall --force`
- `php nite app:conflicts:check resource Report --table=reports`

`db:refresh`, `db:wipe`, `app:uninstall`, and `app:downgrade` are destructive. Use them interactively or pass `--force`.
Use `php nite samples:clean --dry-run` before removing untouched Nite 2.x sample material from an upgraded application.
Use `--rollback` with `remove resource` or `remove migration` when you want the matching console migration undone before those files are deleted.
`app:install`, `app:update`, `app:upgrade`, and `app:downgrade` sync curated public install releases over HTTPS from `https://github.com/fredricknsanhewe/nite-install`.
The inspection commands accept `--json`, and `app:doctor` exits non-zero when it finds real environment errors.
