# Legacy administrator migration

Nite 3.0.0 defaults to the Angular administrator at the existing `/admin` URL. PHP remains the authority for JWT authentication, RBAC, API permissions, audit logging, data access, and upgrades.

Set `NITE_ADMIN_DRIVER=legacy` for a controlled transition. If the Angular build is missing or invalid, Nite logs a developer-facing diagnostic and falls back to the deprecated PHP renderer. Legacy support is retained for 3.0.x and is planned for 3.1.0 only when safe; otherwise the adapter will remain longer.
