# Examples

## HTTP examples

See [examples/http/nite.http](../examples/http/nite.http) for ready-to-run requests.

Nite 3 keeps documentation examples non-runtime; generate a resource when you need a live CRUD surface.

## Database examples

See [database/examples/module-playbook.sql](../database/examples/module-playbook.sql) for starter queries covering:

- content
- learning
- workflow
- messaging
- payments
- subscriptions
- trust
- chatbot
- analytics
- recruitment
