# Safe Nite 2.x sample cleanup

Nite 3 installs without active business demonstrations. Upgrade cleanup is conservative:

```bash
php nite samples:clean --dry-run
php nite samples:clean
php nite samples:clean --report=json
```

A known Nite 2.2.0 sample source file is removed only if its SHA-256 matches the original public package. Modified files are reported as `preserved_modified`; removals are backed up. Tables are removed only when known sample tables are empty and have no external foreign-key dependency. Other tables remain untouched with a reason.
