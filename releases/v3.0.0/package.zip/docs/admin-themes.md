# Nite Admin themes

Nite Admin uses CSS custom-property tokens for primary, secondary, accent, surfaces, text, borders, state, focus, and chart colours. Built-in themes: Nite Default, Light, Dark, Ocean Blue, Emerald, Royal Purple, Amber, Slate, and High Contrast.

```bash
php nite admin:theme:list
php nite admin:theme:set dark
```

The selected theme persists in browser storage. `NITE_ADMIN_DEFAULT_THEME` provides the PHP default and is applied before Angular starts to avoid flashing. Add custom `{ "key", "name", "tokens" }` entries to `resources/nite-admin/custom/themes/themes.json`, then run `php nite admin:build`.
