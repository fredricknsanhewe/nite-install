# Nite Admin development

Nite Admin is an Angular 20 standalone application. Releases contain both editable source and a precompiled build, so Node.js is not required to run the administrator.

- Source: `resources/nite-admin/source`
- Developer overlay: `resources/nite-admin/custom`
- Shipped output: `public/nite-admin`
- Metadata: `public/nite-admin/nite-admin-build.json`

```bash
php nite admin:status
php nite admin:install
php nite admin:build
php nite admin:serve
php nite admin:watch
```

`admin:build` builds in `storage/console/tmp`, validates the Angular output and metadata, then replaces `public/nite-admin` only after success. A failed build leaves the previous working build in place. The development server is `http://localhost:4200`; its proxy forwards `/api` to PHP.

The production shell reads safe configuration from `/admin/runtime-config.json`; it contains no secrets. Use `php nite admin:sync-source` before an upgrade. Keep token-only changes in the custom overlay.
