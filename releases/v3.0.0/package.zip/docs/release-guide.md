# Nite 3 release guide

```bash
vendor/bin/phpunit
php nite admin:install
php nite admin:build --configuration=production
cd resources/nite-admin/source && npm run test && npm run lint
php scripts/build-public-release.php --tag=v3.0.0
```

The packager validates Angular source, compiled assets, metadata, version parity, and excluded `node_modules` before creating `package.zip`. Publish it through `scripts/publish-public-install.php`; it appends the new tag without changing earlier releases.
