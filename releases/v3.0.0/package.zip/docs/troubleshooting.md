# Nite Admin troubleshooting

- `admin:status` reports a missing build: reinstall the published package or run `php nite admin:build` on a development machine.
- Node.js and npm are required only for source changes, never to use shipped assets.
- A failed build preserves the previous `public/nite-admin` directory.
- `/admin` gives legacy output: inspect `NITE_ADMIN_DRIVER` and `php nite admin:status`.
- A custom theme does not appear: validate its JSON, rebuild, then clear only the `nite.admin.theme` browser-storage key if necessary.
