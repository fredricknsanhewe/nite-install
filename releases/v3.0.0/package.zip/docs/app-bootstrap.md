# App Bootstrap

`php nite app:bootstrap` turns the framework into a usable starting application in one pass instead of forcing you to chain `project:create`, manual `.env` edits, starter selection, resource scaffolds, and migrations by hand.

It is designed for two things:

- creating a real working baseline quickly
- leaving behind machine-readable and human-readable structure so developers and AI agents can extend the app safely later

## What it writes

Root mode writes or updates:

- `.env`
- `.env.docker`
- `app.blueprint.json`
- `docs/app-blueprint.md`
- `blueprints/starters/generated/starter-samples.json` when a starter app is selected
- `docs/starter-samples.md` when a starter app is selected

Project mode writes or updates:

- `projects/<slug>/.env`
- `projects/<slug>/.env.docker`
- `projects/<slug>/app.blueprint.json`
- `projects/<slug>/app-blueprint.md`
- `projects/<slug>/starter-samples.json` when a starter app is selected
- `projects/<slug>/starter-samples.md` when a starter app is selected

It also scaffolds starter CRUD resources under:

- `src/Controllers`
- `src/Services`
- `src/Models`
- `database/migrations`
- `routes/generated`
- `examples/generated`

## Starter-first root app example

```bash
php nite starter:list
php nite starter:show inventory-management
php nite app:bootstrap "Acme Inventory" --starter=inventory-management --sample-count=240 --db-driver=pgsql --db-name=acme_inventory --seed
```

That will:

- shape the root env files
- generate a stronger default JWT secret if one is still placeholder-based
- resolve the inventory starter on top of the matching preset
- scaffold the starter resources
- generate a starter sample bundle for examples and AI context
- attempt to create the database
- run migrations and seed data
- emit app blueprint files for future editing and AI context

## Starter-first multi-project example

```bash
php nite app:bootstrap "Client Portal" --project=client-portal --starter=website-management --port=8286 --sample-count=120 --db-name=nite_client_portal --seed
```

If `projects/client-portal/project.json` does not exist yet, bootstrap creates it first and then configures the matching project env files and blueprint.

## Starter apps and presets

Starter apps sit on top of presets.

- Presets describe the broad technical posture: `basic`, `standard`, or `advanced`.
- Starter apps describe the product shape developers actually want to begin from: inventory, POS, CRM, clinic, school, website management, and similar.
- Starter sample packs create large example bundles that admins, developers, and AI tooling can inspect or install.

Built-in starter apps currently include:

- `website-management`
- `inventory-management`
- `point-of-sale`
- `crm-sales`
- `helpdesk-support`
- `learning-platform`
- `clinic-management`
- `school-management`

Inspect the catalog with:

```bash
php nite starter:list
php nite starter:show point-of-sale --json
```

## Presets

- `basic`: content, catalog, governance, and light operational records
- `standard`: a stronger operational baseline with workflow and messaging focus
- `advanced`: broader platform shape with workflow, messaging, analytics, billing, trust, and more starter entities

These presets define the baseline app blueprint and generated resource posture. They do **not** remove built-in framework modules. The rest of the framework still exists; the preset or starter simply tells Nite what this app should lean on first.

## Common options

```bash
php nite app:bootstrap "Acme Ops" \
  --starter=point-of-sale \
  --project=client-portal \
  --db-driver=pgsql \
  --db-host=127.0.0.1 \
  --db-port=55441 \
  --db-name=nite_client_portal \
  --db-user=postgres \
  --db-password=postgres \
  --media-driver=local \
  --resources=DealRoom,OnboardingChecklist \
  --with=analytics,messaging \
  --without=payments \
  --sample-packs=pos-retail,pos-operations \
  --sample-count=1000 \
  --no-install-samples \
  --seed
```

Useful flags:

- `--preset=basic|standard|advanced`
- `--starter=website-management|inventory-management|point-of-sale|...`
- `--project=<slug>` to bootstrap a named project under `projects/<slug>`
- `--resources=Foo,Bar` to add extra generated CRUD resources
- `--with=module1,module2` to expand the focus-module list
- `--without=module1,module2` to reduce the focus-module list
- `--sample-packs=pack1,pack2` to override the starter's default sample packs
- `--sample-count=1000` to generate a large starter bundle
- `--install-samples` or `--no-install-samples` to control whether generated starter samples are inserted into `example_entities`
- `--db-driver=pgsql|mysql`
- `--db-host`, `--db-port`, `--db-name`, `--db-user`, `--db-password`
- `--media-driver=local|ftp|ftps|s3|http|https|webdav`
- `--seed` or `--no-seed`
- `--migrate` or `--no-migrate`
- `--provision-db` or `--no-provision-db`
- `--json` when you want the resulting bootstrap plan as machine-readable output

## Re-run behavior

Bootstrap is safe to run more than once:

- existing env files are updated in place
- existing generated resources are skipped unless you pass `--force` or `--backup`
- blueprint files are regenerated so the current app shape stays documented
- starter sample bundle files are regenerated so example data stays in sync with the selected starter

## AI and editor workflow

After bootstrap, the easiest files for AI agents and developers to inspect are:

- `app.blueprint.json` or `projects/<slug>/app.blueprint.json`
- `docs/app-blueprint.md` or `projects/<slug>/app-blueprint.md`
- `blueprints/starters/generated/starter-samples.json` or `projects/<slug>/starter-samples.json`
- `routes/generated/*.php`
- `src/Services/*Service.php`
- `src/Controllers/*Controller.php`

Pair that with:

- `/api/v1/meta/routes?format=json`
- `/api/v1/meta/resources?format=json`
- `OPTIONS /api/v1/...`

That combination gives both source-level and runtime-level structure quickly.

## Custom starter catalogs

Starter apps and sample packs are data-driven.

- Drop custom starter app JSON files into `blueprints/starters/apps/`
- Drop custom sample pack JSON files into `blueprints/starters/samples/`

See [Starter Apps](starters.md) plus the runnable examples:

- [docs/examples/custom-starter-app.json](examples/custom-starter-app.json)
- [docs/examples/custom-starter-sample-pack.json](examples/custom-starter-sample-pack.json)

## Docker note

The bootstrap flow fully aligns generated Docker env database values when the app is using PostgreSQL.

Host-side MySQL is supported, but the bundled Docker compose templates are still PostgreSQL-first. If you choose `--db-driver=mysql` and want to run the app inside Docker, keep the generated blueprint as your source of truth and then adjust the compose/database service to match your MySQL target.
