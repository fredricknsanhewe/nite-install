# Resource DSL

Nite now supports a SQL-like resource definition DSL for generated modules. The goal is to let developers and AI tools describe a resource once, then let the framework produce:

- the model, service, and controller classes
- the generated route manifest
- the migration files
- a stored JSON blueprint under `blueprints/resources/`

Use `schema:explain` when you want to inspect what a statement means before writing files, and `schema:apply` when you want to generate or update the resource.

## Commands

```bash
php nite schema:explain --file=docs/examples/lesson-schedules.nite --json
php nite schema:apply --file=docs/examples/lesson-schedules.nite
php nite schema:apply --file=docs/examples/lesson-schedules.nite --migrate
```

You can also pass a statement inline:

```bash
php nite schema:apply --statement="CREATE RESOURCE lesson_schedules DB:lesson_schedules{ slug string(140) required unique public; title string(240) required; }"
```

## Create Resource

Example:

```text
CREATE RESOURCE lesson_schedules
GROUP learning
LABEL 'Lesson Schedules'
SUMMARY 'Scheduling resource for lessons and cohorts.'
ACCESS {
    guest CAN { list, show };
    role.support CAN { admin_list, admin_show };
    role.editor CAN { admin_list, admin_show, create, update };
    role.admin CAN { admin_list, admin_show, create, update, delete };
}
DB:lesson_schedules {
    slug string(140) required unique public;
    title string(240) required search;
    summary text nullable;
    status enum('draft','published','archived') default 'draft' index;
    trainer_user_id uuid nullable references users.id;
    starts_at timestamp nullable;
    seats integer default 0;
    metadata json default '{}';
};
```

Supported top-level clauses:

- `GROUP <value>`
- `LABEL '<plural label>'`
- `ITEM TYPE '<singular item label>'`
- `SUMMARY '<description>'`
- `ROUTE <segment>`
- `PUBLIC KEY <field>`
- `ACCESS { ... }`
- `DB:<table> { ... }`
- `FIELDS { ... }`

## Field Syntax

Field declarations use a SQL-like shape:

```text
slug string(140) required unique public;
status enum('draft','published','archived') default 'draft' index;
trainer_user_id uuid nullable references users.id;
metadata json default '{}';
```

Common types:

- `uuid`
- `string(140)`
- `text`
- `integer`
- `bigint`
- `decimal(10,2)`
- `boolean`
- `json`
- `date`
- `timestamp`
- `enum('a','b','c')`

Common modifiers:

- `required`
- `nullable`
- `unique`
- `index`
- `search`
- `filterable`
- `public`
- `read_only`
- `write_only`
- `default <value>`
- `references users.id`
- `belongs_to users.id`
- `label 'Display Label'`
- `description 'Longer help text'`

Nite auto-adds `id`, `created_at`, and `updated_at` if you do not define them yourself.

## Access Rules

Access rules are stored in the JSON blueprint and compiled into route permissions when the rule is simple enough to map to default roles.

Example:

```text
ACCESS {
    guest CAN { list, show };
    role.editor CAN { admin_list, admin_show, create, update };
    role.admin CAN { admin_list, admin_show, create, update, delete };
    NOT role.suspended CAN { create, update, delete };
}
```

Notes:

- `OR` and `NOT` expressions are preserved in the blueprint.
- simple role grants and denies are compiled into default role mappings
- complex `AND` expressions are preserved for documentation but are not fully compiled into default grants automatically

## Alter Resource

Use one statement per operation, or separate operations with commas.

Examples:

```text
ALTER RESOURCE lesson_schedules ADD FIELD is_featured boolean default false index;
ALTER RESOURCE lesson_schedules MODIFY FIELD title string(320) required;
ALTER RESOURCE lesson_schedules DROP FIELD legacy_code;
ALTER RESOURCE lesson_schedules SET SUMMARY 'Updated scheduling summary.';
ALTER RESOURCE lesson_schedules GRANT role.support CAN { admin_list, admin_show };
ALTER RESOURCE lesson_schedules REVOKE role.editor CAN { delete };
```

`ALTER RESOURCE` rewrites the generated model/service/controller/manifest files and emits a new incremental migration when the database shape changes.

## Drop Resource

```text
DROP RESOURCE lesson_schedules;
```

That removes:

- generated PHP files
- generated route manifest
- stored resource blueprint
- tracked generated migrations for that resource

If you also want database rollback before removing the files:

```bash
php nite schema:apply --statement="DROP RESOURCE lesson_schedules;" --rollback
```

## Generated Blueprint

Each generated resource writes a JSON blueprint to:

```text
blueprints/resources/<route-segment>.resource.json
```

That file is meant to be easy for humans, editors, and AI tools to inspect. It stores:

- normalized field definitions
- route/access metadata
- generated file paths
- generated migration history
