<?php
namespace App\Config;

final class MediaConfig
{
    public const DEFAULT_UPLOAD_MAX_BYTES = 10485760;

    public static function uploadMaxBytes(): int
    {
        return max(1, Env::int('MEDIA_UPLOAD_MAX_BYTES', self::DEFAULT_UPLOAD_MAX_BYTES));
    }

    /**
     * @return array<int, string>
     */
    public static function allowedMimeTypes(): array
    {
        return self::csv('MEDIA_UPLOAD_ALLOWED_MIME_TYPES');
    }

    /**
     * @return array<int, string>
     */
    public static function allowedExtensions(): array
    {
        return self::csv('MEDIA_UPLOAD_ALLOWED_EXTENSIONS');
    }

    /**
     * @return array<int, string>
     */
    private static function csv(string $key): array
    {
        $raw = trim((string)Env::get($key, ''));
        if ($raw === '') {
            return [];
        }

        return array_values(array_unique(array_filter(
            array_map(
                static fn (string $value): string => strtolower(trim($value)),
                preg_split('/[,\s]+/', $raw) ?: []
            ),
            static fn (string $value): bool => $value !== ''
        )));
    }
}
