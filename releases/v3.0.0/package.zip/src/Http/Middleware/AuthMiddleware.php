<?php
namespace App\Http\Middleware;

use App\Config\AuthConfig;
use App\Http\Request;
use App\Http\Response;
use App\Models\UserModel;
use App\Services\PasswordPolicyService;
use App\Utils\JWT;

final class AuthMiddleware
{
    public function __invoke(Request $request, callable $next): Response
    {
        $authorization = $request->header('Authorization');
        if ($authorization === null || !str_starts_with($authorization, 'Bearer ')) {
            return Response::json([
                'error' => 'Unauthorized. A bearer token is required.',
                'error_code' => 'auth_required',
            ], 401);
        }

        $token = substr($authorization, 7);
        $payload = JWT::decode($token, AuthConfig::jwtSecret(), AuthConfig::jwtValidationOptions());
        if (!is_array($payload)) {
            return Response::json([
                'error' => 'Unauthorized. The bearer token is invalid or expired.',
                'error_code' => 'invalid_token',
            ], 401);
        }

        $userId = (string)($payload['sub'] ?? '');
        $user = (new UserModel())->findAuthContextById($userId);
        if ($user === null) {
            return Response::json([
                'error' => 'Unauthorized. The linked account could not be found.',
                'error_code' => 'session_user_missing',
            ], 401);
        }

        if (($user['account_status'] ?? 'inactive') !== 'active') {
            return Response::json([
                'error' => 'Forbidden. This account is not active.',
                'error_code' => 'account_inactive',
            ], 403);
        }

        $request->user = [
            'id' => (string)$user['id'],
            'email' => (string)$user['email'],
            'name' => (string)$user['name'],
            'role' => (string)$user['role'],
        ];

        try {
            $requirement = (new PasswordPolicyService())->changeRequirement($user);
            if (($requirement['required'] ?? false) && !$this->allowsPasswordChangeBypass($request->path)) {
                return Response::json([
                    'error' => 'Password change required before continuing.',
                    'error_code' => 'password_change_required',
                    'reason' => $requirement['reason'] ?? 'required',
                ], 403);
            }
        } catch (\Throwable) {
            // Do not make the API unavailable if password policy settings cannot be read.
        }

        return $next($request);
    }

    private function allowsPasswordChangeBypass(string $path): bool
    {
        $normalized = rtrim($path, '/') ?: '/';
        return in_array($normalized, [
            '/api/v1/me',
            '/api/v1/auth/password/change',
        ], true);
    }
}
