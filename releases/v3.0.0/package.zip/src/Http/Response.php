<?php
namespace App\Http;

final class Response
{
    public int $status;
    public array $headers = [];
    public string $body = '';
    public string $format = 'text';
    public mixed $payload = null;

    public function __construct(string $body = '', int $status = 200, array $headers = [])
    {
        $this->body = $body;
        $this->status = $status;
        $this->headers = $headers;
    }

    public static function json(mixed $data, int $status = 200, array $headers = []): self
    {
        return self::api(ApiResponse::normalize($data, $status), $status, $headers);
    }

    /**
     * @param array<string, mixed> $payload
     */
    public static function api(array $payload, int $status = 200, array $headers = []): self
    {
        $headers['Content-Type'] = 'application/json; charset=UTF-8';
        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            $status = $status >= 400 ? $status : 500;
            $payload = ApiResponse::normalize(['error' => 'JSON encoding failed'], $status);
            $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            if (!is_string($encoded)) {
                $encoded = '{"status":"error","code":500,"message":"Internal server error","data":null,"errors":{"detail":"JSON encoding failed"},"meta":{}}';
            }
        }

        $response = new self($encoded, $status, $headers);
        $response->format = 'json';
        $response->payload = $payload;
        return $response;
    }

    public static function html(string $body, int $status = 200, array $headers = []): self
    {
        $headers['Content-Type'] = 'text/html; charset=UTF-8';
        $response = new self($body, $status, $headers);
        $response->format = 'html';
        return $response;
    }

    public static function file(
        string $body,
        string $contentType = 'application/octet-stream',
        ?string $downloadName = null,
        bool $inline = true,
        int $status = 200,
        array $headers = []
    ): self {
        $headers['Content-Type'] = $contentType;
        $headers['Content-Length'] = (string)strlen($body);
        if ($downloadName !== null && $downloadName !== '') {
            $disposition = $inline ? 'inline' : 'attachment';
            $headers['Content-Disposition'] = $disposition . '; filename="' . str_replace('"', '', $downloadName) . '"';
        }

        $response = new self($body, $status, $headers);
        $response->format = 'binary';
        return $response;
    }
}
