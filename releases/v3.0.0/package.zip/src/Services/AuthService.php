<?php
namespace App\Services;

use App\Config\AuthConfig;
use App\Config\Env;
use App\Config\Roles;
use App\Exceptions\AuthenticationException;
use App\Exceptions\ValidationException;
use App\Models\PasswordResetTokenModel;
use App\Models\UserModel;
use App\Models\UserPasswordHistoryModel;
use App\Support\EmailTemplate;
use App\Utils\UUID;
use App\Utils\JWT;
use App\Validation\Validator;
use RuntimeException;

final class AuthService
{
    private UserModel $users;
    private RbacService $rbac;
    private AuthThrottleService $throttle;
    private PasswordPolicyService $passwordPolicy;
    private UserPasswordHistoryModel $passwordHistory;
    private PasswordResetTokenModel $resetTokens;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->rbac = new RbacService();
        $this->throttle = new AuthThrottleService();
        $this->passwordPolicy = new PasswordPolicyService();
        $this->passwordHistory = new UserPasswordHistoryModel();
        $this->resetTokens = new PasswordResetTokenModel();
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function register(array $data, array $context = []): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'name' => 'required|string|min:2|max:120',
            'password' => 'required|string',
            'profile' => 'nullable|array',
        ]);
        $password = (string)($validated['password'] ?? '');
        $this->passwordPolicy->assert($password);
        $passwordHash = $this->hashPassword($password);

        $user = $this->users->create([
            'email' => strtolower(trim((string)($validated['email'] ?? ''))),
            'name' => $validated['name'] ?? null,
            'password_hash' => $passwordHash,
            'role' => Roles::MEMBER,
            'profile' => is_array($validated['profile'] ?? null) ? $validated['profile'] : [],
        ]);
        $this->recordPasswordHistory((string)$user['id'], $passwordHash, null, 'register');

        return $this->tokenPayload($user);
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function login(array $data, array $context = []): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'password' => 'required|string',
        ]);
        $email = strtolower(trim((string)($validated['email'] ?? '')));
        $password = (string)($validated['password'] ?? '');
        $ipAddress = trim((string)($context['ip_address'] ?? '127.0.0.1')) ?: '127.0.0.1';
        $this->throttle->ensureCanAttempt($email, $ipAddress);

        $userRecord = $this->users->findForLogin($email);
        if ($userRecord === null) {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('Invalid login details.');
        }
        if (!password_verify($password, (string)$userRecord['password_hash'])) {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('Invalid login details.');
        }
        if (($userRecord['account_status'] ?? 'inactive') !== 'active') {
            $this->throttle->recordFailure($email, $ipAddress);
            throw new AuthenticationException('This account is not active.');
        }

        $this->throttle->clear($email, $ipAddress);
        $this->users->touchLogin((string)$userRecord['id']);
        $user = $this->users->findById((string)$userRecord['id']);
        return $this->tokenPayload($user ?? []);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createByAdmin(array $data, string $actorUserId): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'name' => 'required|string|min:2|max:120',
            'password' => 'required|string',
            'role' => 'sometimes|string|in:' . implode(',', Roles::all()),
            'account_status' => 'sometimes|string|in:active,inactive,suspended',
            'profile' => 'nullable|array',
        ]);
        $password = (string)($validated['password'] ?? '');
        $this->passwordPolicy->assert($password);
        $passwordHash = $this->hashPassword($password);
        $settings = $this->passwordPolicy->current();
        $user = $this->users->create([
            'email' => strtolower(trim((string)($validated['email'] ?? ''))),
            'name' => $validated['name'] ?? null,
            'password_hash' => $passwordHash,
            'role' => $validated['role'] ?? Roles::MEMBER,
            'account_status' => $validated['account_status'] ?? 'active',
            'profile' => is_array($validated['profile'] ?? null) ? $validated['profile'] : [],
            'force_password_change' => (bool)($settings['force_change_on_admin_created_user'] ?? false),
            'created_by_user_id' => $actorUserId,
            'updated_by_user_id' => $actorUserId,
        ]);
        $this->recordPasswordHistory((string)$user['id'], $passwordHash, $actorUserId, 'admin_create');

        return $this->rbac->hydrateUserPermissions($user);
    }

    public function updateByAdmin(string $userId, array $data, string $actorUserId): ?array
    {
        $payload = Validator::validate($data, [
            'email' => 'sometimes|string|email|max:255',
            'name' => 'sometimes|string|min:2|max:120',
            'password' => 'sometimes|string',
            'role' => 'sometimes|string|in:' . implode(',', Roles::all()),
            'account_status' => 'sometimes|string|in:active,inactive,suspended',
            'force_password_change' => 'sometimes|boolean',
            'profile' => 'sometimes|array',
            'group_ids' => 'sometimes|array',
        ]);

        $groupIds = array_key_exists('group_ids', $payload) ? (array)$payload['group_ids'] : null;
        unset($payload['group_ids']);

        if (array_key_exists('password', $payload)) {
            $password = (string)$payload['password'];
            if ($password !== '') {
                $this->passwordPolicy->assert($password);
                $this->passwordPolicy->assertNotRecentlyUsed($userId, $password);
                $payload['password_hash'] = $this->hashPassword($password);
                $payload['password_changed_at'] = gmdate('c');
                if (!array_key_exists('force_password_change', $payload)) {
                    $payload['force_password_change'] = (bool)($this->passwordPolicy->current()['force_change_on_admin_reset'] ?? true);
                }
            }
            unset($payload['password']);
        }
        $payload['updated_by_user_id'] = $actorUserId;
        $user = $this->users->update($userId, $payload);
        if ($user !== null && $groupIds !== null) {
            $user = $this->rbac->setUserGroups($userId, $groupIds);
        }
        if ($user !== null && isset($payload['password_hash'])) {
            $this->recordPasswordHistory($userId, (string)$payload['password_hash'], $actorUserId, 'admin_reset');
        }
        return $user ? $this->rbac->hydrateUserPermissions($user) : null;
    }

    public function me(string $userId): ?array
    {
        $user = $this->users->findById($userId);
        return $user ? $this->withPasswordRequirement($this->rbac->hydrateUserPermissions($user)) : null;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function changePassword(string $userId, array $data): array
    {
        $validated = Validator::validate($data, [
            'current_password' => 'required|string',
            'password' => 'required|string',
            'password_confirmation' => 'sometimes|string|same:password',
        ]);

        $record = $this->users->findForPasswordAuthById($userId);
        if ($record === null) {
            throw new AuthenticationException('User not found.');
        }

        if (!password_verify((string)$validated['current_password'], (string)$record['password_hash'])) {
            throw new AuthenticationException('Current password is incorrect.');
        }

        $newPassword = (string)$validated['password'];
        $this->passwordPolicy->assert($newPassword);
        $this->passwordPolicy->assertNotRecentlyUsed($userId, $newPassword);
        $passwordHash = $this->hashPassword($newPassword);
        $user = $this->users->update($userId, [
            'password_hash' => $passwordHash,
            'password_changed_at' => gmdate('c'),
            'force_password_change' => false,
            'updated_by_user_id' => $userId,
        ]);
        if ($user === null) {
            throw new RuntimeException('Failed to update password.');
        }

        $this->recordPasswordHistory($userId, $passwordHash, $userId, 'user_change');
        return $this->tokenPayload($user);
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function requestPasswordReset(array $data, array $context = []): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
        ]);
        $email = strtolower(trim((string)$validated['email']));
        $user = $this->users->findByEmail($email);

        if ($user !== null && ($user['account_status'] ?? 'inactive') === 'active') {
            $resetCode = $this->generatePasswordResetCode();
            $settings = $this->passwordPolicy->current();
            $record = $this->resetTokens->create(
                (string)$user['id'],
                $email,
                $resetCode,
                (int)($settings['reset_token_ttl_minutes'] ?? 60),
                trim((string)($context['ip_address'] ?? ''))
            );
            $this->sendPasswordResetEmail($user, $email, $resetCode, (string)($record['expires_at'] ?? ''));
        }

        return [
            'sent' => true,
            'message' => 'If that email is registered, a password reset code has been sent.',
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function resetPassword(array $data): array
    {
        $validated = Validator::validate($data, [
            'email' => 'required|string|email|max:255',
            'code' => 'sometimes|string',
            'token' => 'sometimes|string',
            'password' => 'required|string',
            'password_confirmation' => 'sometimes|string|same:password',
        ]);

        $email = strtolower(trim((string)$validated['email']));
        $resetCode = trim((string)($validated['code'] ?? $validated['token'] ?? ''));
        if ($resetCode === '') {
            throw new ValidationException(['code' => ['This field is required.']]);
        }

        $reset = $this->resetTokens->findValid($email, $resetCode);
        if ($reset === null) {
            throw new AuthenticationException('The password reset code is invalid or has expired.');
        }

        $userId = (string)$reset['user_id'];
        $user = $this->users->findById($userId);
        if ($user === null || ($user['account_status'] ?? 'inactive') !== 'active') {
            throw new AuthenticationException('The linked account is not active.');
        }

        $password = (string)$validated['password'];
        $this->passwordPolicy->assert($password);
        $this->passwordPolicy->assertNotRecentlyUsed($userId, $password);
        $passwordHash = $this->hashPassword($password);
        $updated = $this->users->update($userId, [
            'password_hash' => $passwordHash,
            'password_changed_at' => gmdate('c'),
            'force_password_change' => false,
            'updated_by_user_id' => $userId,
        ]);
        if ($updated === null) {
            throw new RuntimeException('Failed to reset password.');
        }

        $this->resetTokens->markUsed((string)$reset['id']);
        $this->resetTokens->invalidateUserTokens($userId);
        $this->recordPasswordHistory($userId, $passwordHash, $userId, 'password_reset');

        return $this->tokenPayload($updated);
    }

    /**
     * @param array<string, mixed> $user
     * @return array<string, mixed>
     */
    private function tokenPayload(array $user): array
    {
        $this->rbac->bootstrap();
        $user = $this->withPasswordRequirement($this->rbac->hydrateUserPermissions($user));
        $issuedAt = time();
        $ttl = max(900, (int)Env::get('JWT_TTL_SECONDS', '28800'));
        $payload = [
            'sub' => (string)($user['id'] ?? ''),
            'email' => (string)($user['email'] ?? ''),
            'name' => (string)($user['name'] ?? ''),
            'role' => (string)($user['role'] ?? ''),
            'jti' => UUID::v4(),
            'iat' => $issuedAt,
            'nbf' => $issuedAt,
            'exp' => $issuedAt + $ttl,
        ];
        if (AuthConfig::tokenIssuer() !== null) {
            $payload['iss'] = AuthConfig::tokenIssuer();
        }
        if (AuthConfig::tokenAudience() !== null) {
            $payload['aud'] = AuthConfig::tokenAudience();
        }

        $token = JWT::encode($payload, AuthConfig::jwtSecret());

        return [
            'token' => $token,
            'expires_in' => $ttl,
            'user' => $user,
        ];
    }

    private function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => AuthConfig::bcryptCost()]);
    }

    private function recordPasswordHistory(string $userId, string $passwordHash, ?string $actorUserId, string $source): void
    {
        if ($userId === '' || $passwordHash === '') {
            return;
        }
        $this->passwordHistory->record($userId, $passwordHash, $actorUserId, $source);
        $this->passwordHistory->pruneForUser($userId, (int)$this->passwordPolicy->current()['password_history_count']);
    }

    /**
     * @param array<string, mixed> $user
     * @return array<string, mixed>
     */
    private function withPasswordRequirement(array $user): array
    {
        $requirement = $this->passwordPolicy->changeRequirement($user);
        $user['password_change_required'] = (bool)$requirement['required'];
        $user['password_change_reason'] = $requirement['reason'];
        return $user;
    }

    /**
     * @param array<string, mixed> $user
     */
    private function sendPasswordResetEmail(array $user, string $email, string $resetCode, string $expiresAt): void
    {
        $appName = trim((string)Env::get('APP_NAME', 'Nite')) ?: 'Nite';
        $name = trim((string)($user['name'] ?? $appName . ' user')) ?: $appName . ' user';
        $displayCode = $this->formatPasswordResetCode($resetCode);
        $body = EmailTemplate::message([
            'preheader' => 'Use this secure code to reset your ' . $appName . ' password.',
            'headline' => 'Reset your ' . $appName . ' password',
            'greeting' => 'Hello ' . $name . ',',
            'intro' => [
                'We received a request to reset the password for your ' . $appName . ' account.',
                'Enter the 6-digit reset code below on the password reset screen. For security, the code can only be used once.',
            ],
            'details' => [
                'Account' => $email,
                'Code expires' => $expiresAt,
            ],
            'callout' => [
                'title' => 'Your reset code',
                'type' => 'code',
                'body' => $displayCode,
            ],
            'notice' => 'If you did not request this reset, ignore this email. Your current password will remain unchanged. Do not share this code with anyone.',
        ]);

        (new MailService())->dispatch([
            'message_type' => 'password_reset',
            'to' => $email,
            'subject' => 'Reset your ' . $appName . ' password',
            'text_body' => $body['text_body'],
            'html_body' => $body['html_body'],
            'metadata' => [
                'user_id' => (string)($user['id'] ?? ''),
                'purpose' => 'password_reset',
            ],
        ]);
    }

    private function generatePasswordResetCode(): string
    {
        $length = 6;
        return str_pad((string)random_int(0, (10 ** $length) - 1), $length, '0', STR_PAD_LEFT);
    }

    private function formatPasswordResetCode(string $code): string
    {
        $normalized = (string)(preg_replace('/\D/', '', $code) ?? '');
        if ($normalized === '') {
            return $code;
        }

        return $normalized;
    }
}
