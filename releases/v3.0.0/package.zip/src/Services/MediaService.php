<?php
namespace App\Services;

use App\Config\Database;
use App\Models\MediaAssetModel;
use App\Models\MediaAssetVersionModel;
use App\Storage\MediaStorageManager;
use App\Utils\UUID;
use RuntimeException;

final class MediaService
{
    private const TABLE = 'media_assets';

    private MediaAssetModel $media;
    private MediaAssetVersionModel $versions;
    private DataChangeLogService $changes;
    private RbacService $rbac;
    private ?MediaStorageManager $storage = null;

    public function __construct()
    {
        $this->media = new MediaAssetModel();
        $this->versions = new MediaAssetVersionModel();
        $this->changes = new DataChangeLogService();
        $this->rbac = new RbacService();
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function adminList(array $filters = [], ?array $user = null): array
    {
        $filters = $this->normalizeLibraryFilters($filters, $user);
        $bucket = strtolower(trim((string)($filters['bucket'] ?? $filters['library'] ?? '')));
        unset($filters['bucket'], $filters['library']);
        $assets = $this->media->list($filters);
        if ($bucket !== '') {
            $assets = array_values(array_filter(
                $assets,
                fn (array $asset): bool => $this->matchesLibraryBucket($asset, $user, $bucket)
            ));
        }

        return array_values(array_map(
            fn (array $asset): array => $this->sanitizeAssetForClient($asset, true),
            $assets
        ));
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function accessibleList(array $filters = [], ?array $user = null): array
    {
        $filters = $this->normalizeLibraryFilters($filters, $user);
        if (!isset($filters['status']) || trim((string)$filters['status']) === '') {
            $filters['status'] = 'active';
        }

        $bucket = strtolower(trim((string)($filters['bucket'] ?? $filters['library'] ?? '')));
        unset($filters['bucket'], $filters['library']);

        $assets = array_values(array_filter(
            $this->media->list($filters),
            fn (array $asset): bool => $this->canAccess($asset, $user) && $this->matchesLibraryBucket($asset, $user, $bucket)
        ));

        return array_values(array_map(
            fn (array $asset): array => $this->sanitizeAssetForClient($asset, $this->canAdminView($user)),
            $assets
        ));
    }

    public function showAdmin(string $id): ?array
    {
        $asset = $this->media->findById($id);
        return $asset ? $this->sanitizeAssetForClient($asset, true) : null;
    }

    /**
     * @return array{state: string, asset?: array<string, mixed>}
     */
    public function showAccessible(string $id, ?array $user = null): array
    {
        $result = $this->resolveAccessibleAsset($id, $user);
        if (($result['state'] ?? '') !== 'ok') {
            return $result;
        }

        $result['asset'] = $this->sanitizeAssetForClient((array)$result['asset'], false);
        return $result;
    }

    /**
     * @return array{state: string, asset?: array<string, mixed>, content?: string, mime_type?: string, download_name?: string, inline?: bool, message?: string}
     */
    public function downloadAsset(string $id, ?array $user = null): array
    {
        $result = $this->resolveAccessibleAsset($id, $user);
        if (($result['state'] ?? '') !== 'ok') {
            return $result;
        }

        $asset = (array)$result['asset'];
        try {
            $content = $this->storage()->read(
                (string)($asset['storage_path'] ?? ''),
                (string)($asset['stored_name'] ?? ''),
                $asset['updated_at'] ?? $asset['created_at'] ?? null
            );
        } catch (RuntimeException $e) {
            return [
                'state' => 'storage_error',
                'asset' => $this->sanitizeAssetForClient($asset, false),
                'message' => $e->getMessage(),
            ];
        }

        if (!is_string($content)) {
            return [
                'state' => 'missing_file',
                'asset' => $this->sanitizeAssetForClient($asset, false),
            ];
        }

        return [
            'state' => 'ok',
            'asset' => $this->sanitizeAssetForClient($asset, false),
            'content' => $content,
            'mime_type' => (string)($asset['mime_type'] ?? 'application/octet-stream'),
            'download_name' => (string)($asset['original_name'] ?? 'download'),
            'inline' => $this->shouldInline((string)($asset['mime_type'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function upload(array $file, array $payload = [], array $context = []): array
    {
        $assetId = UUID::v4();
        $accessScope = $this->normalizeAccessScope($payload['access_scope'] ?? 'private');
        $stored = $this->storeUploadedFile($file);
        $db = Database::connection();

        $db->beginTransaction();
        try {
            $asset = $this->media->create([
                'id' => $assetId,
                'original_name' => $stored['original_name'],
                'stored_name' => $stored['stored_name'],
                'mime_type' => $stored['mime_type'],
                'size_bytes' => $stored['size_bytes'],
                'storage_path' => $stored['storage_path'],
                'public_url' => $this->publicUrlFor($assetId, $accessScope),
                'alt_text' => $payload['alt_text'] ?? null,
                'access_scope' => $accessScope,
                'allowed_roles' => $payload['allowed_roles'] ?? [],
                'allowed_user_ids' => $payload['allowed_user_ids'] ?? [],
                'checksum_sha1' => $stored['checksum_sha1'],
                'current_version_number' => 1,
                'version_count' => 1,
                'status' => $payload['status'] ?? 'active',
            ], (string)($context['actor_user_id'] ?? ''));

            $version = $this->versions->create([
                'media_asset_id' => $assetId,
                'version_number' => 1,
                'original_name' => $stored['original_name'],
                'stored_name' => $stored['stored_name'],
                'mime_type' => $stored['mime_type'],
                'size_bytes' => $stored['size_bytes'],
                'storage_path' => $stored['storage_path'],
                'public_url' => $this->publicUrlFor($assetId, $accessScope),
                'alt_text' => $payload['alt_text'] ?? null,
                'checksum_sha1' => $stored['checksum_sha1'],
                'change_notes' => $payload['change_notes'] ?? null,
                'action' => 'create',
            ], (string)($context['actor_user_id'] ?? ''));

            $versions = $this->versions->listForAsset($assetId);
            $changeLog = $this->changes->logCreate(
                self::TABLE,
                $this->snapshotForLog($asset, $versions),
                $this->withMetadata($context, [
                    'operation' => 'media.upload',
                    'version_id' => $version['id'] ?? null,
                    'version_number' => $version['version_number'] ?? 1,
                ])
            );

            $db->commit();

            return [
                'asset' => $this->sanitizeAssetForClient($asset, true),
                'version' => $this->sanitizeVersionForClient($version),
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $this->cleanupStoredFile($stored['storage_path'] ?? null);
            throw $e;
        }
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function updateMetadata(string $id, array $payload, array $context = []): ?array
    {
        $existing = $this->media->findById($id);
        if ($existing === null) {
            return null;
        }

        $beforeVersions = $this->versions->listForAsset($id);
        $nextScope = $this->normalizeAccessScope($payload['access_scope'] ?? $existing['access_scope'] ?? 'private');
        $updatePayload = [];

        foreach (['alt_text', 'status', 'access_scope', 'allowed_roles', 'allowed_user_ids'] as $field) {
            if (array_key_exists($field, $payload)) {
                $updatePayload[$field] = $payload[$field];
            }
        }
        $updatePayload['access_scope'] = $nextScope;
        $updatePayload['public_url'] = $this->publicUrlFor($id, $nextScope);

        $db = Database::connection();
        $db->beginTransaction();
        try {
            $asset = $this->media->update($id, $updatePayload, (string)($context['actor_user_id'] ?? ''));
            if ($asset === null) {
                throw new RuntimeException('Media asset not found.');
            }

            $afterVersions = $this->versions->listForAsset($id);
            $changeLog = $this->changes->logUpdate(
                self::TABLE,
                $this->snapshotForLog($existing, $beforeVersions),
                $this->snapshotForLog($asset, $afterVersions),
                $this->withMetadata($context, [
                    'operation' => 'media.update',
                ])
            );

            $db->commit();

            return [
                'asset' => $this->sanitizeAssetForClient($asset, true),
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function replaceFile(string $id, array $file, array $payload = [], array $context = []): ?array
    {
        $existing = $this->media->findById($id);
        if ($existing === null) {
            return null;
        }

        $beforeVersions = $this->versions->listForAsset($id);
        $sourceVersion = $this->versions->findByAssetAndNumber($id, (int)($existing['current_version_number'] ?? 1));
        $nextScope = $this->normalizeAccessScope($payload['access_scope'] ?? $existing['access_scope'] ?? 'private');
        $stored = $this->storeUploadedFile($file);
        $newVersionNumber = $this->versions->nextVersionNumber($id);
        $db = Database::connection();

        $db->beginTransaction();
        try {
            $asset = $this->media->update($id, [
                'original_name' => $stored['original_name'],
                'stored_name' => $stored['stored_name'],
                'mime_type' => $stored['mime_type'],
                'size_bytes' => $stored['size_bytes'],
                'storage_path' => $stored['storage_path'],
                'public_url' => $this->publicUrlFor($id, $nextScope),
                'alt_text' => array_key_exists('alt_text', $payload) ? $payload['alt_text'] : ($existing['alt_text'] ?? null),
                'access_scope' => $nextScope,
                'allowed_roles' => $payload['allowed_roles'] ?? ($existing['allowed_roles'] ?? []),
                'allowed_user_ids' => $payload['allowed_user_ids'] ?? ($existing['allowed_user_ids'] ?? []),
                'checksum_sha1' => $stored['checksum_sha1'],
                'current_version_number' => $newVersionNumber,
                'version_count' => $newVersionNumber,
                'status' => $payload['status'] ?? ($existing['status'] ?? 'active'),
            ], (string)($context['actor_user_id'] ?? ''));
            if ($asset === null) {
                throw new RuntimeException('Media asset not found.');
            }

            $version = $this->versions->create([
                'media_asset_id' => $id,
                'version_number' => $newVersionNumber,
                'original_name' => $stored['original_name'],
                'stored_name' => $stored['stored_name'],
                'mime_type' => $stored['mime_type'],
                'size_bytes' => $stored['size_bytes'],
                'storage_path' => $stored['storage_path'],
                'public_url' => $this->publicUrlFor($id, $nextScope),
                'alt_text' => $asset['alt_text'] ?? null,
                'checksum_sha1' => $stored['checksum_sha1'],
                'change_notes' => $payload['change_notes'] ?? null,
                'action' => 'replace',
                'source_version_id' => $sourceVersion['id'] ?? null,
            ], (string)($context['actor_user_id'] ?? ''));

            $afterVersions = $this->versions->listForAsset($id);
            $changeLog = $this->changes->logUpdate(
                self::TABLE,
                $this->snapshotForLog($existing, $beforeVersions),
                $this->snapshotForLog($asset, $afterVersions),
                $this->withMetadata($context, [
                    'operation' => 'media.replace',
                    'restored_version_id' => null,
                    'version_id' => $version['id'] ?? null,
                    'version_number' => $version['version_number'] ?? $newVersionNumber,
                ])
            );

            $db->commit();

            return [
                'asset' => $this->sanitizeAssetForClient($asset, true),
                'version' => $this->sanitizeVersionForClient($version),
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $this->cleanupStoredFile($stored['storage_path'] ?? null);
            throw $e;
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function versions(string $assetId): array
    {
        return array_values(array_map(
            fn (array $version): array => $this->sanitizeVersionForClient($version),
            $this->versions->listForAsset($assetId)
        ));
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function restoreVersion(string $assetId, string $versionId, array $payload = [], array $context = []): ?array
    {
        $existing = $this->media->findById($assetId);
        if ($existing === null) {
            return null;
        }

        $targetVersion = $this->versions->findForAsset($assetId, $versionId);
        if ($targetVersion === null) {
            return null;
        }

        $beforeVersions = $this->versions->listForAsset($assetId);
        $nextScope = $this->normalizeAccessScope($payload['access_scope'] ?? $existing['access_scope'] ?? 'private');
        $newVersionNumber = $this->versions->nextVersionNumber($assetId);
        $db = Database::connection();

        $db->beginTransaction();
        try {
            $asset = $this->media->update($assetId, [
                'original_name' => $targetVersion['original_name'] ?? null,
                'stored_name' => $targetVersion['stored_name'] ?? null,
                'mime_type' => $targetVersion['mime_type'] ?? null,
                'size_bytes' => $targetVersion['size_bytes'] ?? 0,
                'storage_path' => $targetVersion['storage_path'] ?? null,
                'public_url' => $this->publicUrlFor($assetId, $nextScope),
                'alt_text' => array_key_exists('alt_text', $payload) ? $payload['alt_text'] : ($targetVersion['alt_text'] ?? null),
                'access_scope' => $nextScope,
                'allowed_roles' => $payload['allowed_roles'] ?? ($existing['allowed_roles'] ?? []),
                'allowed_user_ids' => $payload['allowed_user_ids'] ?? ($existing['allowed_user_ids'] ?? []),
                'checksum_sha1' => $targetVersion['checksum_sha1'] ?? null,
                'current_version_number' => $newVersionNumber,
                'version_count' => $newVersionNumber,
                'status' => $payload['status'] ?? ($existing['status'] ?? 'active'),
            ], (string)($context['actor_user_id'] ?? ''));
            if ($asset === null) {
                throw new RuntimeException('Media asset not found.');
            }

            $version = $this->versions->create([
                'media_asset_id' => $assetId,
                'version_number' => $newVersionNumber,
                'original_name' => $targetVersion['original_name'] ?? null,
                'stored_name' => $targetVersion['stored_name'] ?? null,
                'mime_type' => $targetVersion['mime_type'] ?? null,
                'size_bytes' => $targetVersion['size_bytes'] ?? 0,
                'storage_path' => $targetVersion['storage_path'] ?? null,
                'public_url' => $this->publicUrlFor($assetId, $nextScope),
                'alt_text' => $asset['alt_text'] ?? null,
                'checksum_sha1' => $targetVersion['checksum_sha1'] ?? null,
                'change_notes' => $payload['change_notes'] ?? null,
                'action' => 'restore',
                'source_version_id' => $targetVersion['id'] ?? null,
            ], (string)($context['actor_user_id'] ?? ''));

            $afterVersions = $this->versions->listForAsset($assetId);
            $changeLog = $this->changes->logUpdate(
                self::TABLE,
                $this->snapshotForLog($existing, $beforeVersions),
                $this->snapshotForLog($asset, $afterVersions),
                $this->withMetadata($context, [
                    'operation' => 'media.restore_version',
                    'restored_version_id' => $targetVersion['id'] ?? null,
                    'version_id' => $version['id'] ?? null,
                    'version_number' => $version['version_number'] ?? $newVersionNumber,
                ])
            );

            $db->commit();

            return [
                'asset' => $this->sanitizeAssetForClient($asset, true),
                'version' => $this->sanitizeVersionForClient($version),
                'restored_from_version' => $this->sanitizeVersionForClient($targetVersion),
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function delete(string $id, array $context = []): ?array
    {
        $existing = $this->media->findById($id);
        if ($existing === null) {
            return null;
        }

        $beforeVersions = $this->versions->listForAsset($id);
        $db = Database::connection();
        $db->beginTransaction();
        try {
            $changeLog = $this->changes->logDelete(
                self::TABLE,
                $this->snapshotForLog($existing, $beforeVersions),
                $this->withMetadata($context, [
                    'operation' => 'media.delete',
                    'retained_files' => count($beforeVersions),
                ])
            );
            $deleted = $this->media->delete($id);
            $db->commit();

            return [
                'deleted' => $deleted,
                'asset' => $this->sanitizeAssetForClient($existing, true),
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function history(array $filters = []): array
    {
        return $this->changes->listForTable(self::TABLE, $filters);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function recordHistory(string $assetId, array $filters = []): array
    {
        if (!preg_match('/^[0-9a-f-]{36}$/i', $assetId)) {
            return [];
        }

        return $this->changes->listForRecord(self::TABLE, $assetId, $filters);
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function restoreFromLog(int $logId, array $context = []): ?array
    {
        $log = $this->changes->findById($logId);
        if ($log === null || (string)($log['table_name'] ?? '') !== self::TABLE) {
            return null;
        }

        $snapshot = is_array($log['restorable_json'] ?? null) ? $log['restorable_json'] : [];
        $assetId = (string)($snapshot['id'] ?? $log['record_id'] ?? '');
        if (!preg_match('/^[0-9a-f-]{36}$/i', $assetId)) {
            throw new RuntimeException('The selected media history entry is not restorable.');
        }

        $versionHistory = is_array($snapshot['version_history'] ?? null) ? $snapshot['version_history'] : [];
        $this->assertRestorableFiles($versionHistory);

        $beforeAsset = $this->media->findById($assetId);
        $beforeVersions = $beforeAsset ? $this->versions->listForAsset($assetId) : [];
        $db = Database::connection();
        $db->beginTransaction();

        try {
            if ($beforeAsset !== null) {
                $this->versions->deleteForAsset($assetId);
            }

            $restoredAsset = $this->media->restoreSnapshot(
                $this->restoreAssetPayloadFromSnapshot($snapshot, $versionHistory),
                (string)($context['actor_user_id'] ?? '')
            );

            $orderedVersions = $this->orderVersionSnapshotsForRestore($versionHistory);
            foreach ($orderedVersions as $versionSnapshot) {
                $this->versions->create(
                    $this->restoreVersionPayloadFromSnapshot($assetId, $restoredAsset, $versionSnapshot),
                    (string)($context['actor_user_id'] ?? '')
                );
            }

            $afterAsset = $this->media->findById($assetId);
            if ($afterAsset === null) {
                throw new RuntimeException('Failed to restore the media asset.');
            }
            $afterVersions = $this->versions->listForAsset($assetId);

            $changeLog = $this->changes->logRestore(
                self::TABLE,
                $beforeAsset ? $this->snapshotForLog($beforeAsset, $beforeVersions) : [],
                $this->snapshotForLog($afterAsset, $afterVersions),
                $logId,
                $this->withMetadata($context, [
                    'operation' => 'media.restore',
                    'restored_action' => $log['action'] ?? null,
                ])
            );

            $db->commit();

            return [
                'asset' => $this->sanitizeAssetForClient($afterAsset, true),
                'versions' => array_values(array_map(
                    fn (array $version): array => $this->sanitizeVersionForClient($version),
                    $afterVersions
                )),
                'restored_from' => $log,
                'change_log' => $changeLog,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * @return array{state: string, asset?: array<string, mixed>}
     */
    private function resolveAccessibleAsset(string $id, ?array $user = null): array
    {
        $asset = $this->media->findById($id);
        if ($asset === null) {
            return ['state' => 'not_found'];
        }

        if (!$this->canAccess($asset, $user)) {
            return ['state' => 'forbidden'];
        }

        return [
            'state' => 'ok',
            'asset' => $asset,
        ];
    }

    private function canAccess(array $asset, ?array $user): bool
    {
        if ($this->canAdminView($user)) {
            return true;
        }

        if ((string)($asset['status'] ?? 'active') !== 'active') {
            return $this->isOwner($asset, $user);
        }

        $scope = (string)($asset['access_scope'] ?? 'private');
        if ($scope === 'public') {
            return true;
        }

        if ($this->isOwner($asset, $user)) {
            return true;
        }

        if (!is_array($user) || trim((string)($user['id'] ?? '')) === '') {
            return false;
        }

        return match ($scope) {
            'authenticated' => true,
            'roles' => in_array((string)($user['role'] ?? ''), is_array($asset['allowed_roles'] ?? null) ? $asset['allowed_roles'] : [], true),
            'users' => in_array((string)($user['id'] ?? ''), is_array($asset['allowed_user_ids'] ?? null) ? $asset['allowed_user_ids'] : [], true),
            default => false,
        };
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<string, mixed>
     */
    private function normalizeLibraryFilters(array $filters, ?array $user): array
    {
        $owner = strtolower(trim((string)($filters['owner'] ?? $filters['ownership'] ?? '')));
        unset($filters['owner'], $filters['ownership']);
        if ($owner === 'me' && is_array($user) && trim((string)($user['id'] ?? '')) !== '') {
            $filters['created_by_user_id'] = (string)$user['id'];
        }

        return $filters;
    }

    private function matchesLibraryBucket(array $asset, ?array $user, string $bucket): bool
    {
        if ($bucket === '') {
            return true;
        }

        $scope = (string)($asset['access_scope'] ?? 'private');
        return match ($bucket) {
            'mine', 'owned' => $this->isOwner($asset, $user),
            'public' => $scope === 'public',
            'authenticated', 'auth' => $scope === 'authenticated',
            'roles', 'role_shared' => $scope === 'roles',
            'users', 'user_shared' => $scope === 'users',
            'shared' => !$this->isOwner($asset, $user) && in_array($scope, ['authenticated', 'roles', 'users', 'public'], true),
            'private' => $scope === 'private',
            default => true,
        };
    }

    private function canAdminView(?array $user): bool
    {
        if (!is_array($user)) {
            return false;
        }

        $userId = trim((string)($user['id'] ?? ''));
        $role = trim((string)($user['role'] ?? ''));
        if ($userId === '' || $role === '') {
            return false;
        }

        return $this->rbac->hasAnyPermission($userId, $role, ['admin.media.view', 'admin.media.manage']);
    }

    private function isOwner(array $asset, ?array $user): bool
    {
        if (!is_array($user)) {
            return false;
        }

        return trim((string)($asset['created_by_user_id'] ?? '')) !== ''
            && (string)($asset['created_by_user_id'] ?? '') === (string)($user['id'] ?? '');
    }

    /**
     * @return array<string, mixed>
     */
    private function sanitizeAssetForClient(array $asset, bool $admin): array
    {
        unset($asset['storage_path']);
        $asset['download_url'] = '/api/v1/media/' . ($asset['id'] ?? '') . '/download';
        $asset['is_image'] = str_starts_with(strtolower((string)($asset['mime_type'] ?? '')), 'image/');
        $asset['asset_kind'] = $this->assetKind((string)($asset['mime_type'] ?? ''));
        $asset['preview_url'] = $asset['is_image'] ? $asset['download_url'] : null;
        $asset['visibility_label'] = $this->visibilityLabel($asset);
        $asset['share_summary'] = $this->shareSummary($asset);
        if ((string)($asset['access_scope'] ?? 'private') !== 'public') {
            $asset['public_url'] = null;
        }

        if (!$admin) {
            unset($asset['allowed_roles'], $asset['allowed_user_ids'], $asset['checksum_sha1'], $asset['created_by_user_id'], $asset['updated_by_user_id']);
        }

        return $asset;
    }

    private function assetKind(string $mimeType): string
    {
        $mime = strtolower(trim($mimeType));
        if (str_starts_with($mime, 'image/')) {
            return 'image';
        }
        if (str_starts_with($mime, 'video/')) {
            return 'video';
        }
        if (str_starts_with($mime, 'audio/')) {
            return 'audio';
        }
        if ($mime === 'application/pdf') {
            return 'pdf';
        }

        return 'file';
    }

    private function visibilityLabel(array $asset): string
    {
        return match ((string)($asset['access_scope'] ?? 'private')) {
            'public' => 'Public',
            'authenticated' => 'Signed-in users',
            'roles' => 'Shared with roles',
            'users' => 'Shared with users',
            default => 'Private owner media',
        };
    }

    private function shareSummary(array $asset): string
    {
        $scope = (string)($asset['access_scope'] ?? 'private');
        if ($scope === 'roles') {
            $roles = is_array($asset['allowed_roles'] ?? null) ? $asset['allowed_roles'] : [];
            return $roles === [] ? 'No roles selected' : ('Roles: ' . implode(', ', $roles));
        }
        if ($scope === 'users') {
            $users = is_array($asset['allowed_user_ids'] ?? null) ? $asset['allowed_user_ids'] : [];
            return $users === [] ? 'No users selected' : (count($users) . ' user' . (count($users) === 1 ? '' : 's'));
        }
        if ($scope === 'authenticated') {
            return 'All signed-in users';
        }
        if ($scope === 'public') {
            return 'Public website media';
        }

        return 'Owner and media admins';
    }

    /**
     * @return array<string, mixed>
     */
    private function sanitizeVersionForClient(array $version): array
    {
        unset($version['storage_path']);
        return $version;
    }

    /**
     * @param array<string, mixed> $asset
     * @param array<int, array<string, mixed>> $versions
     * @return array<string, mixed>
     */
    private function snapshotForLog(array $asset, array $versions): array
    {
        if ($asset === []) {
            return [];
        }

        $versionSnapshots = array_values(array_map(fn (array $version): array => $this->versionSnapshot($version), $versions));
        $currentVersion = null;
        foreach ($versionSnapshots as $version) {
            if ((int)($version['version_number'] ?? 0) === (int)($asset['current_version_number'] ?? 0)) {
                $currentVersion = $version;
                break;
            }
        }

        return [
            'id' => $asset['id'] ?? null,
            'original_name' => $asset['original_name'] ?? null,
            'stored_name' => $asset['stored_name'] ?? null,
            'mime_type' => $asset['mime_type'] ?? null,
            'size_bytes' => $asset['size_bytes'] ?? 0,
            'storage_path' => $asset['storage_path'] ?? null,
            'public_url' => $asset['public_url'] ?? null,
            'alt_text' => $asset['alt_text'] ?? null,
            'access_scope' => $asset['access_scope'] ?? 'private',
            'allowed_roles' => is_array($asset['allowed_roles'] ?? null) ? $asset['allowed_roles'] : [],
            'allowed_user_ids' => is_array($asset['allowed_user_ids'] ?? null) ? $asset['allowed_user_ids'] : [],
            'checksum_sha1' => $asset['checksum_sha1'] ?? null,
            'current_version_number' => (int)($asset['current_version_number'] ?? 1),
            'version_count' => (int)($asset['version_count'] ?? count($versionSnapshots)),
            'status' => $asset['status'] ?? 'active',
            'created_by_user_id' => $asset['created_by_user_id'] ?? null,
            'updated_by_user_id' => $asset['updated_by_user_id'] ?? null,
            'created_at' => $asset['created_at'] ?? null,
            'updated_at' => $asset['updated_at'] ?? null,
            'current_version' => $currentVersion,
            'version_history' => $versionSnapshots,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function versionSnapshot(array $version): array
    {
        return [
            'id' => $version['id'] ?? null,
            'media_asset_id' => $version['media_asset_id'] ?? null,
            'version_number' => (int)($version['version_number'] ?? 0),
            'original_name' => $version['original_name'] ?? null,
            'stored_name' => $version['stored_name'] ?? null,
            'mime_type' => $version['mime_type'] ?? null,
            'size_bytes' => $version['size_bytes'] ?? 0,
            'storage_path' => $version['storage_path'] ?? null,
            'public_url' => $version['public_url'] ?? null,
            'alt_text' => $version['alt_text'] ?? null,
            'checksum_sha1' => $version['checksum_sha1'] ?? null,
            'change_notes' => $version['change_notes'] ?? null,
            'action' => $version['action'] ?? 'create',
            'source_version_id' => $version['source_version_id'] ?? null,
            'created_by_user_id' => $version['created_by_user_id'] ?? null,
            'created_at' => $version['created_at'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $snapshot
     * @param array<int, array<string, mixed>> $versionHistory
     * @return array<string, mixed>
     */
    private function restoreAssetPayloadFromSnapshot(array $snapshot, array $versionHistory): array
    {
        $currentVersionNumber = max(1, (int)($snapshot['current_version_number'] ?? 1));
        $currentVersion = null;
        foreach ($versionHistory as $version) {
            if ((int)($version['version_number'] ?? 0) === $currentVersionNumber) {
                $currentVersion = $version;
                break;
            }
        }
        $currentVersion = is_array($currentVersion) ? $currentVersion : (is_array($snapshot['current_version'] ?? null) ? $snapshot['current_version'] : null);
        if (!is_array($currentVersion)) {
            throw new RuntimeException('The selected media history entry is missing the current version snapshot.');
        }

        return [
            'id' => $snapshot['id'] ?? null,
            'original_name' => $currentVersion['original_name'] ?? $snapshot['original_name'] ?? null,
            'stored_name' => $currentVersion['stored_name'] ?? $snapshot['stored_name'] ?? null,
            'mime_type' => $currentVersion['mime_type'] ?? $snapshot['mime_type'] ?? null,
            'size_bytes' => $currentVersion['size_bytes'] ?? $snapshot['size_bytes'] ?? 0,
            'storage_path' => $currentVersion['storage_path']
                ?? $snapshot['storage_path']
                ?? $this->buildLegacyStoragePath(
                    (string)($currentVersion['stored_name'] ?? $snapshot['stored_name'] ?? ''),
                    $currentVersion['created_at'] ?? $snapshot['updated_at'] ?? $snapshot['created_at'] ?? null
                ),
            'public_url' => $this->publicUrlFor((string)($snapshot['id'] ?? ''), $snapshot['access_scope'] ?? 'private'),
            'alt_text' => $currentVersion['alt_text'] ?? $snapshot['alt_text'] ?? null,
            'access_scope' => $snapshot['access_scope'] ?? 'private',
            'allowed_roles' => $snapshot['allowed_roles'] ?? [],
            'allowed_user_ids' => $snapshot['allowed_user_ids'] ?? [],
            'checksum_sha1' => $currentVersion['checksum_sha1'] ?? $snapshot['checksum_sha1'] ?? null,
            'current_version_number' => $currentVersionNumber,
            'version_count' => max($currentVersionNumber, (int)($snapshot['version_count'] ?? count($versionHistory))),
            'status' => $snapshot['status'] ?? 'active',
            'created_by_user_id' => $snapshot['created_by_user_id'] ?? null,
            'updated_by_user_id' => $snapshot['updated_by_user_id'] ?? null,
            'created_at' => $snapshot['created_at'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $asset
     * @param array<string, mixed> $versionSnapshot
     * @return array<string, mixed>
     */
    private function restoreVersionPayloadFromSnapshot(string $assetId, array $asset, array $versionSnapshot): array
    {
        return [
            'id' => $versionSnapshot['id'] ?? null,
            'media_asset_id' => $assetId,
            'version_number' => $versionSnapshot['version_number'] ?? 1,
            'original_name' => $versionSnapshot['original_name'] ?? $asset['original_name'] ?? null,
            'stored_name' => $versionSnapshot['stored_name'] ?? $asset['stored_name'] ?? null,
            'mime_type' => $versionSnapshot['mime_type'] ?? $asset['mime_type'] ?? null,
            'size_bytes' => $versionSnapshot['size_bytes'] ?? $asset['size_bytes'] ?? 0,
            'storage_path' => $versionSnapshot['storage_path']
                ?? $asset['storage_path']
                ?? $this->buildLegacyStoragePath(
                    (string)($versionSnapshot['stored_name'] ?? $asset['stored_name'] ?? ''),
                    $versionSnapshot['created_at'] ?? $asset['updated_at'] ?? $asset['created_at'] ?? null
                ),
            'public_url' => $this->publicUrlFor($assetId, $asset['access_scope'] ?? 'private'),
            'alt_text' => $versionSnapshot['alt_text'] ?? $asset['alt_text'] ?? null,
            'checksum_sha1' => $versionSnapshot['checksum_sha1'] ?? $asset['checksum_sha1'] ?? null,
            'change_notes' => $versionSnapshot['change_notes'] ?? null,
            'action' => $versionSnapshot['action'] ?? 'create',
            'source_version_id' => $versionSnapshot['source_version_id'] ?? null,
            'created_by_user_id' => $versionSnapshot['created_by_user_id'] ?? null,
            'created_at' => $versionSnapshot['created_at'] ?? null,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $versions
     * @return array<int, array<string, mixed>>
     */
    private function orderVersionSnapshotsForRestore(array $versions): array
    {
        usort($versions, static function (array $left, array $right): int {
            return [(int)($left['version_number'] ?? 0), (string)($left['created_at'] ?? '')]
                <=> [(int)($right['version_number'] ?? 0), (string)($right['created_at'] ?? '')];
        });

        return $versions;
    }

    /**
     * @param array<int, array<string, mixed>> $versions
     */
    private function assertRestorableFiles(array $versions): void
    {
        $missing = [];
        foreach ($versions as $version) {
            $path = (string)($version['storage_path'] ?? '');
            try {
                $exists = $this->storage()->exists(
                    $path,
                    (string)($version['stored_name'] ?? ''),
                    $version['created_at'] ?? null
                );
            } catch (RuntimeException $e) {
                throw new RuntimeException('Failed to verify archived media files for restore: ' . $e->getMessage(), 0, $e);
            }

            if (!$exists) {
                $missing[] = (string)($version['stored_name'] ?? 'unknown');
            }
        }

        if ($missing !== []) {
            throw new RuntimeException('The archived media files are no longer available for restore: ' . implode(', ', $missing));
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function storeUploadedFile(array $file): array
    {
        return $this->storage()->storeUpload($file);
    }

    private function cleanupStoredFile(mixed $path): void
    {
        try {
            $this->storage()->delete($path);
        } catch (\Throwable) {
            // Ignore cleanup failures so the primary application error is preserved.
        }
    }

    private function buildLegacyStoragePath(string $storedName, mixed $createdAt): string
    {
        return $this->storage()->legacyLocalAbsolutePath($storedName, $createdAt);
    }

    private function storage(): MediaStorageManager
    {
        if (!$this->storage instanceof MediaStorageManager) {
            $this->storage = new MediaStorageManager();
        }

        return $this->storage;
    }

    private function publicUrlFor(string $assetId, mixed $scope): ?string
    {
        return $this->normalizeAccessScope($scope) === 'public'
            ? '/api/v1/media/' . $assetId . '/download'
            : null;
    }

    private function normalizeAccessScope(mixed $value): string
    {
        $scope = strtolower(trim((string)$value));
        if (!in_array($scope, ['public', 'authenticated', 'roles', 'users', 'private'], true)) {
            throw new RuntimeException('Invalid media access scope supplied.');
        }

        return $scope;
    }

    private function shouldInline(string $mimeType): bool
    {
        $mime = strtolower(trim($mimeType));
        return str_starts_with($mime, 'image/')
            || str_starts_with($mime, 'text/')
            || str_starts_with($mime, 'audio/')
            || str_starts_with($mime, 'video/')
            || $mime === 'application/pdf';
    }

    /**
     * @param array<string, mixed> $context
     * @param array<string, mixed> $extraMetadata
     * @return array<string, mixed>
     */
    private function withMetadata(array $context, array $extraMetadata): array
    {
        $metadata = is_array($context['metadata'] ?? null) ? $context['metadata'] : [];
        $context['metadata'] = array_merge($metadata, $extraMetadata);
        return $context;
    }
}
