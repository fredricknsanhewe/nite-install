<?php
namespace App\Services;

use App\Config\MailConfig;
use App\Models\ContactMessageModel;

/**
 * Service wrapper around contact message persistence.
 *
 * Responsibilities:
 * - validate and store contact submissions through `ContactMessageModel`
 * - trigger optional admin notifications
 * - trigger optional customer acknowledgements
 * - keep notification failures non-fatal so contact capture still succeeds
 */
final class ContactMessageService
{
    private ContactMessageModel $messages;
    private MailService $mail;

    public function __construct()
    {
        $this->messages = new ContactMessageModel();
        $this->mail = new MailService();
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        $message = $this->messages->create($payload);
        $this->notifyBestEffort($message);
        return $message;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        return $this->messages->list($filters);
    }

    public function findById(string $id): ?array
    {
        return $this->messages->findById($id);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|null
     */
    public function update(string $id, array $payload): ?array
    {
        return $this->messages->update($id, $payload);
    }

    public function delete(string $id): bool
    {
        return $this->messages->delete($id);
    }

    private function notifyBestEffort(array $message): void
    {
        if (!MailConfig::enabled()) {
            return;
        }

        try {
            $this->sendAdminNotification($message);
        } catch (\Throwable $e) {
            error_log('Nite contact admin notification failed: ' . $e->getMessage());
        }

        try {
            $this->sendAcknowledgement($message);
        } catch (\Throwable $e) {
            error_log('Nite contact acknowledgement failed: ' . $e->getMessage());
        }
    }

    private function sendAdminNotification(array $message): void
    {
        if (!MailConfig::contactNotificationEnabled()) {
            return;
        }

        $adminRecipients = MailConfig::adminRecipients();
        if ($adminRecipients === []) {
            return;
        }

        $name = (string)($message['full_name'] ?? 'Contact');
        $email = (string)($message['email'] ?? '');
        $phone = trim((string)($message['phone'] ?? ''));
        $subject = (string)($message['subject'] ?? 'New contact message');
        $body = (string)($message['message'] ?? '');
        $source = (string)($message['source'] ?? 'website');

        $text = implode(PHP_EOL, [
            'A new contact message was submitted.',
            '',
            'Name: ' . $name,
            'Email: ' . $email,
            'Phone: ' . ($phone !== '' ? $phone : 'n/a'),
            'Source: ' . $source,
            'Subject: ' . $subject,
            '',
            $body,
        ]);

        $html = '<p>A new contact message was submitted.</p>'
            . '<ul>'
            . '<li><strong>Name:</strong> ' . htmlspecialchars($name) . '</li>'
            . '<li><strong>Email:</strong> ' . htmlspecialchars($email) . '</li>'
            . '<li><strong>Phone:</strong> ' . htmlspecialchars($phone !== '' ? $phone : 'n/a') . '</li>'
            . '<li><strong>Source:</strong> ' . htmlspecialchars($source) . '</li>'
            . '<li><strong>Subject:</strong> ' . htmlspecialchars($subject) . '</li>'
            . '</ul>'
            . '<p>' . nl2br(htmlspecialchars($body)) . '</p>';

        $this->mail->dispatch([
            'message_type' => 'contact_admin_alert',
            'to' => $adminRecipients,
            'reply_to' => [['address' => $email, 'name' => $name]],
            'subject' => '[Contact] ' . $subject,
            'text_body' => $text,
            'html_body' => $html,
            'metadata' => [
                'contact_message_id' => $message['id'] ?? null,
                'source' => 'contact_submission',
            ],
        ]);
    }

    private function sendAcknowledgement(array $message): void
    {
        if (!MailConfig::contactAutoReplyEnabled()) {
            return;
        }

        $recipient = trim((string)($message['email'] ?? ''));
        if ($recipient === '' || filter_var($recipient, FILTER_VALIDATE_EMAIL) === false) {
            return;
        }

        $name = (string)($message['full_name'] ?? 'there');
        $subject = (string)($message['subject'] ?? 'your message');
        $text = implode(PHP_EOL, [
            'Hello ' . $name . ',',
            '',
            'We received your message about "' . $subject . '".',
            'A member of the team will review it and respond soon.',
            '',
            'This is an automated acknowledgement from ' . \App\Config\App::NAME . '.',
        ]);

        $html = '<p>Hello ' . htmlspecialchars($name) . ',</p>'
            . '<p>We received your message about "<strong>' . htmlspecialchars($subject) . '</strong>".</p>'
            . '<p>A member of the team will review it and respond soon.</p>'
            . '<p>This is an automated acknowledgement from <strong>' . htmlspecialchars(\App\Config\App::NAME) . '</strong>.</p>';

        $this->mail->dispatch([
            'message_type' => 'contact_auto_reply',
            'to' => [['address' => $recipient, 'name' => $name]],
            'subject' => 'We received your message',
            'text_body' => $text,
            'html_body' => $html,
            'metadata' => [
                'contact_message_id' => $message['id'] ?? null,
                'source' => 'contact_submission_auto_reply',
            ],
        ]);
    }
}
