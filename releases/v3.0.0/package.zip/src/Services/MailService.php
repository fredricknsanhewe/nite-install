<?php
namespace App\Services;

use App\Config\App;
use App\Config\MailConfig;
use App\Models\MailQueueModel;
use RuntimeException;
use Symfony\Component\Mailer\Envelope;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;
use Symfony\Component\Mailer\SentMessage;
use Symfony\Component\Mailer\Transport;
use Symfony\Component\Mailer\Transport\TransportInterface;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Crypto\DkimSigner;
use Symfony\Component\Mime\Email;
use Symfony\Component\Mime\Message;

/**
 * Mail delivery facade for Nite.
 *
 * Usage examples:
 * ```php
 * $mail = new MailService();
 * $mail->dispatch([
 *     'to' => 'ops@example.com',
 *     'subject' => 'Background job completed',
 *     'text_body' => 'The nightly import finished successfully.',
 * ]);
 *
 * $mail->dispatch([
 *     'to' => ['client@example.com', 'Owner <owner@example.com>'],
 *     'reply_to' => [['address' => 'support@example.com', 'name' => 'Support']],
 *     'subject' => 'Welcome',
 *     'html_body' => '<p>Your account is ready.</p>',
 * ], ['queue' => true]);
 * ```
 *
 * Delivery rules:
 * - when `MAIL_ENABLED=false`, dispatches are skipped safely
 * - when `MAIL_QUEUE_MODE=database`, dispatches are stored in `mail_queue`
 * - when `MAIL_OVERRIDE_TO` is set, every message is redirected to those inboxes
 * - untrusted custom `From` addresses are rewritten to the configured sender and
 *   preserved as reply-to metadata instead of being sent verbatim
 */
final class MailService
{
    private ?MailQueueModel $queue = null;
    private ?TransportInterface $transport = null;

    public function __construct()
    {
    }

    /**
     * @param array<string, mixed> $message
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function dispatch(array $message, array $options = []): array
    {
        if (!MailConfig::enabled()) {
            return [
                'status' => 'disabled',
                'message' => 'Outbound mail is disabled.',
            ];
        }

        $normalized = $this->normalizeMessage($message);
        $queue = array_key_exists('queue', $options)
            ? (bool)$options['queue']
            : MailConfig::queueMode() === 'database';

        if ($queue) {
            $record = $this->queue()->create($normalized);
            return [
                'status' => 'queued',
                'queue_item' => $record,
            ];
        }

        return $this->sendPrepared($normalized);
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function sendTest(array $options = []): array
    {
        $to = $options['to'] ?? MailConfig::overrideRecipients() ?? [];
        $subject = trim((string)($options['subject'] ?? ('Nite mail test - ' . gmdate('c'))));
        $project = trim((string)\App\Config\Env::get('NITE_PROJECT', ''));
        $bodyLines = [
            'This is a Nite test email.',
            'Time: ' . gmdate('c'),
            'Application: ' . App::NAME . ' ' . App::VERSION,
            'Project: ' . ($project === '' ? 'root' : $project),
            'Transport: ' . MailConfig::transport(),
            'Queue mode: ' . MailConfig::queueMode(),
        ];

        return $this->dispatch([
            'message_type' => 'mail_test',
            'to' => $to,
            'subject' => $subject,
            'text_body' => implode(PHP_EOL, $bodyLines),
            'html_body' => '<p>This is a <strong>Nite</strong> test email.</p><p><strong>Time:</strong> ' . htmlspecialchars(gmdate('c')) . '</p>',
            'metadata' => [
                'source' => 'console.mail_test',
                'project' => $project,
            ],
        ], $options);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function queueList(array $filters = []): array
    {
        return $this->queue()->list($filters);
    }

    /**
     * @return array<string, int>
     */
    public function queueStatusCounts(): array
    {
        return $this->queue()->statusCounts();
    }

    /**
     * @return array<string, mixed>
     */
    public function queueSummary(): array
    {
        return [
            'status_counts' => $this->queue()->statusCounts(),
            'pending' => $this->queue()->pendingCount(),
            'batch_size' => MailConfig::batchSize(),
            'worker_sleep_seconds' => MailConfig::workerSleepSeconds(),
            'worker_max_runtime_seconds' => MailConfig::workerMaxRuntimeSeconds(),
        ];
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function work(array $options = []): array
    {
        if (!MailConfig::enabled()) {
            return [
                'claimed' => 0,
                'sent' => 0,
                'retried' => 0,
                'failed' => 0,
                'items' => [],
                'message' => 'Outbound mail is disabled.',
            ];
        }

        $limit = max(1, min(200, (int)($options['limit'] ?? MailConfig::batchSize())));
        $jobs = $this->queue()->claimReadyBatch($limit);
        $results = [];
        $sent = 0;
        $retried = 0;
        $failed = 0;

        foreach ($jobs as $job) {
            try {
                $delivery = $this->sendPrepared($this->messageFromQueueRow($job));
                $this->queue()->markSent((string)$job['id'], [
                    'transport_message_id' => $delivery['transport_message_id'] ?? null,
                    'dsn' => MailConfig::summary()['dsn'] ?? null,
                    'sent_at' => gmdate('c'),
                ]);
                $sent++;
                $results[] = [
                    'id' => $job['id'],
                    'status' => 'sent',
                    'subject' => $job['subject'] ?? '',
                    'to' => array_map(static fn (array $item): string => (string)($item['address'] ?? ''), $job['to'] ?? []),
                ];
            } catch (\Throwable $e) {
                $attempts = (int)($job['attempts'] ?? 1);
                $maxAttempts = max(1, (int)($job['max_attempts'] ?? MailConfig::maxAttempts()));
                $meta = [
                    'error' => $e->getMessage(),
                    'failed_at' => gmdate('c'),
                ];

                if ($attempts >= $maxAttempts) {
                    $this->queue()->markFailed((string)$job['id'], $e->getMessage(), $meta);
                    $failed++;
                    $results[] = [
                        'id' => $job['id'],
                        'status' => 'failed',
                        'error' => $e->getMessage(),
                    ];
                    continue;
                }

                $delaySeconds = max(5, MailConfig::retryDelaySeconds() * $attempts);
                $this->queue()->releaseForRetry((string)$job['id'], $e->getMessage(), $delaySeconds, $meta + [
                    'retry_in_seconds' => $delaySeconds,
                ]);
                $retried++;
                $results[] = [
                    'id' => $job['id'],
                    'status' => 'queued',
                    'retry_in_seconds' => $delaySeconds,
                    'error' => $e->getMessage(),
                ];
            }
        }

        return [
            'claimed' => count($jobs),
            'sent' => $sent,
            'retried' => $retried,
            'failed' => $failed,
            'items' => $results,
        ];
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function workLoop(array $options = []): array
    {
        $daemon = !empty($options['daemon']);
        $stopWhenEmpty = !empty($options['stop_when_empty']);
        $sleepSeconds = max(1, (int)($options['sleep'] ?? MailConfig::workerSleepSeconds()));
        $maxRuntimeSeconds = max(0, (int)($options['max_runtime'] ?? MailConfig::workerMaxRuntimeSeconds()));
        $maxJobs = max(0, (int)($options['max_jobs'] ?? 0));
        $startedAt = time();

        $summary = [
            'mode' => $daemon ? 'daemon' : 'drain',
            'iterations' => 0,
            'claimed' => 0,
            'sent' => 0,
            'retried' => 0,
            'failed' => 0,
            'sleep_seconds' => $sleepSeconds,
            'slept_cycles' => 0,
            'items' => [],
        ];

        do {
            $batch = $this->work($options);
            $summary['iterations']++;
            $summary['claimed'] += (int)($batch['claimed'] ?? 0);
            $summary['sent'] += (int)($batch['sent'] ?? 0);
            $summary['retried'] += (int)($batch['retried'] ?? 0);
            $summary['failed'] += (int)($batch['failed'] ?? 0);
            $summary['items'] = array_merge(
                array_values(is_array($summary['items'] ?? null) ? $summary['items'] : []),
                array_values(is_array($batch['items'] ?? null) ? $batch['items'] : [])
            );

            $claimed = (int)($batch['claimed'] ?? 0);
            if ($claimed === 0) {
                if (!$daemon || $stopWhenEmpty) {
                    break;
                }

                if ($maxRuntimeSeconds > 0 && (time() - $startedAt) >= $maxRuntimeSeconds) {
                    break;
                }

                sleep($sleepSeconds);
                $summary['slept_cycles']++;
                continue;
            }

            if ($maxJobs > 0 && $summary['claimed'] >= $maxJobs) {
                break;
            }
            if ($maxRuntimeSeconds > 0 && (time() - $startedAt) >= $maxRuntimeSeconds) {
                break;
            }
        } while (true);

        $summary['runtime_seconds'] = max(0, time() - $startedAt);

        return $summary;
    }

    public function retryFailedQueue(): int
    {
        return $this->queue()->retryFailed();
    }

    public function retryQueueItem(string $id): bool
    {
        return $this->queue()->retry($id);
    }

    /**
     * @param array<string, mixed> $prepared
     * @return array<string, mixed>
     */
    private function sendPrepared(array $prepared): array
    {
        [$message, $envelope, $meta] = $this->buildSymfonyMessage($prepared);

        try {
            $sent = $this->transport()->send($message, $envelope);
        } catch (TransportExceptionInterface $e) {
            throw new RuntimeException('Mail transport failed: ' . $e->getMessage(), 0, $e);
        }

        return [
            'status' => 'sent',
            'transport_message_id' => $sent instanceof SentMessage ? $sent->getMessageId() : null,
            'message_type' => $prepared['message_type'] ?? 'transactional',
            'to' => array_map(static fn (array $item): string => (string)($item['address'] ?? ''), $prepared['to'] ?? []),
            'meta' => $meta,
        ];
    }

    private function transport(): TransportInterface
    {
        if ($this->transport instanceof TransportInterface) {
            return $this->transport;
        }

        $this->transport = Transport::fromDsn(MailConfig::dsn());
        return $this->transport;
    }

    private function queue(): MailQueueModel
    {
        if (!$this->queue instanceof MailQueueModel) {
            $this->queue = new MailQueueModel();
        }

        return $this->queue;
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function normalizeMessage(array $input): array
    {
        $to = $this->normalizeAddressList($input['to'] ?? []);
        if ($to === []) {
            throw new RuntimeException('Outbound mail requires at least one recipient.');
        }

        $subject = trim((string)($input['subject'] ?? ''));
        if ($subject === '') {
            throw new RuntimeException('Outbound mail requires a subject.');
        }

        $textBody = $this->nullableText($input['text_body'] ?? $input['text'] ?? null);
        $htmlBody = $this->nullableText($input['html_body'] ?? $input['html'] ?? null);
        if ($textBody === null && $htmlBody === null) {
            throw new RuntimeException('Outbound mail requires either text_body or html_body.');
        }

        $from = $this->normalizeFromAddress($input);
        $replyTo = $this->normalizeReplyTo($input['reply_to'] ?? $input['replyTo'] ?? []);
        if (($from['original_from'] ?? null) !== null && $replyTo === []) {
            $replyTo = [$from['original_from']];
        }

        $cc = $this->normalizeAddressList($input['cc'] ?? []);
        $bcc = $this->normalizeAddressList($input['bcc'] ?? []);
        $overrideRecipients = MailConfig::overrideRecipients();
        $metadata = is_array($input['metadata'] ?? null) ? $input['metadata'] : [];
        $headers = $this->normalizeHeaders($input['headers'] ?? []);

        if ($overrideRecipients !== []) {
            $metadata['original_recipients'] = [
                'to' => $to,
                'cc' => $cc,
                'bcc' => $bcc,
            ];
            $headers['X-Nite-Original-To'] = implode(', ', array_map(static fn (array $item): string => (string)($item['address'] ?? ''), $to));
            $to = $overrideRecipients;
            $cc = [];
            $bcc = [];
        }

        if (($from['rewritten'] ?? false) === true) {
            $metadata['original_from'] = $from['original_from'];
        }

        $messageType = trim((string)($input['message_type'] ?? 'transactional'));
        $priority = max(1, min(5, (int)($input['priority'] ?? 3)));
        $maxAttempts = max(1, (int)($input['max_attempts'] ?? MailConfig::maxAttempts()));
        $senderAddress = $this->nullableEmail($input['sender_address'] ?? MailConfig::senderAddress());

        return [
            'message_type' => $messageType === '' ? 'transactional' : $messageType,
            'transport' => MailConfig::transport(),
            'priority' => $priority,
            'max_attempts' => $maxAttempts,
            'to' => $to,
            'cc' => $cc,
            'bcc' => $bcc,
            'reply_to' => $replyTo,
            'subject' => $subject,
            'text_body' => $textBody,
            'html_body' => $htmlBody,
            'from_address' => (string)$from['address'],
            'from_name' => $from['name'] ?? null,
            'sender_address' => $senderAddress,
            'headers' => $headers,
            'metadata' => $metadata,
            'available_at' => $input['available_at'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $prepared
     * @return array{0: Message, 1: Envelope, 2: array<string, mixed>}
     */
    private function buildSymfonyMessage(array $prepared): array
    {
        $email = (new Email())
            ->subject((string)$prepared['subject'])
            ->from($this->addressObject([
                'address' => (string)$prepared['from_address'],
                'name' => $prepared['from_name'] ?? null,
            ]))
            ->to(...$this->addressObjects($prepared['to'] ?? []))
            ->priority((int)($prepared['priority'] ?? 3));

        if (($prepared['sender_address'] ?? null) !== null) {
            $email->sender((string)$prepared['sender_address']);
            $email->returnPath((string)$prepared['sender_address']);
        }

        $replyTo = $prepared['reply_to'] ?? [];
        if (is_array($replyTo) && $replyTo !== []) {
            $email->replyTo(...$this->addressObjects($replyTo));
        } else {
            $defaultReplyTo = MailConfig::defaultReplyTo();
            if ($defaultReplyTo !== []) {
                $email->replyTo(...$this->addressObjects($defaultReplyTo));
            }
        }

        $cc = is_array($prepared['cc'] ?? null) ? $prepared['cc'] : [];
        if ($cc !== []) {
            $email->cc(...$this->addressObjects($cc));
        }

        $bcc = is_array($prepared['bcc'] ?? null) ? $prepared['bcc'] : [];
        if ($bcc !== []) {
            $email->bcc(...$this->addressObjects($bcc));
        }

        if (($prepared['text_body'] ?? null) !== null) {
            $email->text((string)$prepared['text_body']);
        }
        if (($prepared['html_body'] ?? null) !== null) {
            $email->html((string)$prepared['html_body']);
        }

        $headers = $email->getHeaders();
        $headers->addTextHeader('X-Mailer', App::NAME . '/' . App::VERSION);
        $headers->addTextHeader('X-Nite-Message-Type', (string)($prepared['message_type'] ?? 'transactional'));
        $headers->addTextHeader('X-Auto-Response-Suppress', 'All');
        $headers->addTextHeader('Auto-Submitted', 'auto-generated');

        foreach ($this->normalizeHeaders($prepared['headers'] ?? []) as $name => $value) {
            if (!$headers->has($name)) {
                $headers->addTextHeader($name, $value);
                continue;
            }
            $headers->setHeaderBody('Text', $name, $value);
        }

        $recipients = array_merge(
            $this->addressObjects($prepared['to'] ?? []),
            $this->addressObjects($cc),
            $this->addressObjects($bcc)
        );
        $envelopeRecipients = $recipients !== [] ? $recipients : $this->addressObjects($prepared['to'] ?? []);
        $envelopeSender = (string)($prepared['sender_address'] ?? $prepared['from_address']);
        $envelope = new Envelope(new Address($envelopeSender), $envelopeRecipients);

        $message = $email;
        $meta = ['dkim' => false];
        if (MailConfig::dkimEnabled()) {
            $message = $this->signDkim($email);
            $meta['dkim'] = true;
        }

        return [$message, $envelope, $meta];
    }

    private function signDkim(Email $email): Message
    {
        $options = MailConfig::dkimOptions();
        $privateKeyPath = (string)($options['private_key_path'] ?? '');
        if ($privateKeyPath === '' || !is_file($privateKeyPath)) {
            throw new RuntimeException('MAIL_DKIM_PRIVATE_KEY_PATH is configured but the file is missing.');
        }

        $signer = new DkimSigner(
            'file://' . $privateKeyPath,
            (string)($options['domain'] ?? ''),
            (string)($options['selector'] ?? ''),
            [
                'body_show_length' => (bool)($options['body_length'] ?? false),
            ],
            (string)($options['passphrase'] ?? '')
        );

        return $signer->sign($email);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function messageFromQueueRow(array $row): array
    {
        return [
            'message_type' => $row['message_type'] ?? 'transactional',
            'transport' => $row['transport'] ?? MailConfig::transport(),
            'priority' => $row['priority'] ?? 3,
            'max_attempts' => $row['max_attempts'] ?? MailConfig::maxAttempts(),
            'to' => $row['to'] ?? [],
            'cc' => $row['cc'] ?? [],
            'bcc' => $row['bcc'] ?? [],
            'reply_to' => $row['reply_to'] ?? [],
            'subject' => $row['subject'] ?? '',
            'text_body' => $row['text_body'] ?? null,
            'html_body' => $row['html_body'] ?? null,
            'from_address' => $row['from_address'] ?? '',
            'from_name' => $row['from_name'] ?? null,
            'sender_address' => $row['sender_address'] ?? null,
            'headers' => $row['headers'] ?? [],
            'metadata' => $row['metadata'] ?? [],
        ];
    }

    /**
     * @return array{address: string, name?: string, rewritten?: bool, original_from?: array{address: string, name?: string}}
     */
    private function normalizeFromAddress(array $input): array
    {
        $requested = null;
        if (array_key_exists('from', $input)) {
            $requested = MailConfig::parseAddress($input['from']);
        } elseif (array_key_exists('from_address', $input) || array_key_exists('from_name', $input)) {
            $requested = MailConfig::parseAddress([
                'address' => $input['from_address'] ?? null,
                'name' => $input['from_name'] ?? null,
            ]);
        }

        $default = MailConfig::defaultFrom();
        if ($requested === null) {
            return $default;
        }

        if (!$this->isTrustedFromAddress((string)($requested['address'] ?? ''))) {
            if (!MailConfig::enforceTrustedFrom()) {
                return $requested;
            }

            $default['rewritten'] = true;
            $default['original_from'] = $requested;
            return $default;
        }

        return $requested;
    }

    /**
     * @return array<int, array{address: string, name?: string}>
     */
    private function normalizeReplyTo(mixed $value): array
    {
        $items = $this->normalizeAddressList($value, true);
        $allowedDomains = MailConfig::allowedReplyToDomains();
        if ($allowedDomains === []) {
            return $items;
        }

        return array_values(array_filter($items, function (array $item) use ($allowedDomains): bool {
            $domain = $this->emailDomain((string)($item['address'] ?? ''));
            return $domain !== null && in_array($domain, $allowedDomains, true);
        }));
    }

    /**
     * @return array<int, array{address: string, name?: string}>
     */
    private function normalizeAddressList(mixed $value, bool $allowEmpty = false): array
    {
        $items = [];

        if (is_string($value)) {
            $items = MailConfig::parseAddressList($value);
        } elseif (is_array($value)) {
            $isAssoc = $value !== [] && array_keys($value) !== range(0, count($value) - 1);
            if ($isAssoc && (isset($value['address']) || isset($value['email']))) {
                $parsed = MailConfig::parseAddress($value);
                if ($parsed !== null) {
                    $items[] = $parsed;
                }
            } else {
                foreach ($value as $item) {
                    $parsed = MailConfig::parseAddress($item);
                    if ($parsed !== null) {
                        $items[] = $parsed;
                    }
                }
            }
        }

        if ($items === [] && !$allowEmpty) {
            return [];
        }

        $deduped = [];
        foreach ($items as $item) {
            $key = strtolower((string)($item['address'] ?? ''));
            if ($key === '') {
                continue;
            }
            $deduped[$key] = $item;
        }

        return array_values($deduped);
    }

    /**
     * @param array<int, array{address: string, name?: string}> $items
     * @return array<int, Address>
     */
    private function addressObjects(array $items): array
    {
        return array_values(array_map(fn (array $item): Address => $this->addressObject($item), $items));
    }

    /**
     * @param array{address: string, name?: string} $item
     */
    private function addressObject(array $item): Address
    {
        $name = trim((string)($item['name'] ?? ''));
        return $name === ''
            ? new Address((string)$item['address'])
            : new Address((string)$item['address'], $name);
    }

    /**
     * @param array<string, mixed>|mixed $headers
     * @return array<string, string>
     */
    private function normalizeHeaders(mixed $headers): array
    {
        if (!is_array($headers)) {
            return [];
        }

        $normalized = [];
        foreach ($headers as $name => $value) {
            $headerName = trim((string)$name);
            if ($headerName === '') {
                continue;
            }

            if (!preg_match('/^[A-Za-z0-9-]+$/', $headerName)) {
                continue;
            }

            $normalized[$headerName] = trim((string)$value);
        }

        return $normalized;
    }

    private function nullableText(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $text = trim((string)$value);
        return $text === '' ? null : $text;
    }

    private function nullableEmail(mixed $value): ?string
    {
        $email = strtolower(trim((string)$value));
        return $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false ? $email : null;
    }

    private function isTrustedFromAddress(string $email): bool
    {
        $address = strtolower(trim($email));
        if ($address === '') {
            return false;
        }

        if (in_array($address, MailConfig::allowedFromAddresses(), true)) {
            return true;
        }

        $domain = $this->emailDomain($address);
        return $domain !== null && in_array($domain, MailConfig::allowedFromDomains(), true);
    }

    private function emailDomain(string $email): ?string
    {
        $parts = explode('@', strtolower(trim($email)), 2);
        return count($parts) === 2 && $parts[1] !== '' ? $parts[1] : null;
    }
}
