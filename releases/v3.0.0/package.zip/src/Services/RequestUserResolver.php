<?php
namespace App\Services;

use App\Http\Request;
use App\Models\UserModel;
use App\Utils\JWT;
use App\Config\AuthConfig;

final class RequestUserResolver
{
    private UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function resolve(Request $request): ?array
    {
        if (is_array($request->user ?? null)) {
            return $request->user;
        }

        $authorization = $request->header('Authorization');
        if ($authorization === null || !str_starts_with($authorization, 'Bearer ')) {
            return null;
        }

        $token = substr($authorization, 7);
        $payload = JWT::decode(
            $token,
            AuthConfig::jwtSecret(),
            AuthConfig::jwtValidationOptions()
        );
        if (!is_array($payload)) {
            return null;
        }

        $userId = (string)($payload['sub'] ?? '');
        $user = $this->users->findAuthContextById($userId);
        if ($user === null || (string)($user['account_status'] ?? 'inactive') !== 'active') {
            return null;
        }

        $request->user = [
            'id' => (string)$user['id'],
            'email' => (string)$user['email'],
            'name' => (string)$user['name'],
            'role' => (string)$user['role'],
        ];

        return $request->user;
    }
}
