<?php
namespace App\Services;

use App\Config\Database;
use App\Support\RecoveryAuditInstaller;
use PDO;
use RuntimeException;

/** Restores a prior row snapshot while preserving a new immutable restore log. */
final class DataRecoveryService
{
    private DataChangeLogService $changes;

    public function __construct()
    {
        $this->changes = new DataChangeLogService();
    }

    /**
     * @param array<string, mixed> $context
     * @return array{record: array<string, mixed>, restored_from: array<string, mixed>, change_log: array<string, mixed>}|null
     */
    public function restoreFromLog(int $logId, array $context = []): ?array
    {
        $log = $this->changes->findById($logId);
        if ($log === null) {
            return null;
        }
        if (!in_array((string)($log['action'] ?? ''), ['update', 'delete'], true)) {
            throw new RuntimeException('Only update and delete audit entries can be restored.');
        }

        $table = trim((string)($log['table_name'] ?? ''));
        $connection = Database::connection();
        $tables = RecoveryAuditInstaller::recoverableTables($connection);
        $definition = $tables[$table] ?? null;
        if (!is_array($definition)) {
            throw new RuntimeException('This audit entry belongs to a protected or unsupported table.');
        }

        $snapshot = is_array($log['restorable_json'] ?? null) ? $log['restorable_json'] : [];
        $primaryKey = (string)$definition['primary_key'];
        $recordId = trim((string)($snapshot[$primaryKey] ?? $log['record_id'] ?? ''));
        if ($recordId === '') {
            throw new RuntimeException('The audit entry does not include a recoverable record identifier.');
        }

        $values = $this->restoreValues($snapshot, (array)$definition['columns']);
        if (!array_key_exists($primaryKey, $values)) {
            throw new RuntimeException('The audit snapshot does not include its primary key.');
        }

        $connection->beginTransaction();
        try {
            $this->setAuditSuppressed($connection, true);
            $before = $this->find($connection, $table, $primaryKey, $recordId);
            if ($before === null) {
                $this->insert($connection, $table, $values, (array)$definition['columns']);
            } else {
                $this->update($connection, $table, $primaryKey, $recordId, $values, (array)$definition['columns']);
            }
            $record = $this->find($connection, $table, $primaryKey, $recordId);
            if ($record === null) {
                throw new RuntimeException('The record could not be recovered.');
            }
            $this->setAuditSuppressed($connection, false);
            $context['metadata'] = array_merge(
                is_array($context['metadata'] ?? null) ? $context['metadata'] : [],
                ['operation' => 'data_recovery.restore', 'primary_key' => $primaryKey]
            );
            $changeLog = $this->changes->logRestore($table, $before ?? [], $record, $logId, $context);
            $connection->commit();

            return ['record' => $record, 'restored_from' => $log, 'change_log' => $changeLog];
        } catch (\Throwable $e) {
            if ($connection->inTransaction()) {
                $connection->rollBack();
            }
            throw $e;
        } finally {
            if (!$connection->inTransaction()) {
                $this->setAuditSuppressed($connection, false);
            }
        }
    }

    /** @param array<string, mixed> $snapshot @param array<string, string> $columns @return array<string, mixed> */
    private function restoreValues(array $snapshot, array $columns): array
    {
        $values = [];
        foreach ($columns as $column => $_type) {
            if (!array_key_exists($column, $snapshot) || preg_match('/password|token|secret/i', $column) === 1) {
                continue;
            }
            $value = $snapshot[$column];
            $values[$column] = is_array($value)
                ? json_encode($value, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE)
                : $value;
        }
        return $values;
    }

    /** @param array<string, string> $columns */
    private function insert(PDO $connection, string $table, array $values, array $columns): void
    {
        $names = array_keys($values);
        $params = [];
        $placeholders = [];
        foreach ($names as $index => $name) {
            $placeholder = ':v' . $index;
            $placeholders[] = $this->valueExpression($placeholder, (string)($columns[$name] ?? ''));
            $params[$placeholder] = $values[$name];
        }
        $sql = 'INSERT INTO ' . $this->quoteTable($table) . ' (' . implode(', ', array_map([$this, 'quoteColumn'], $names)) . ') VALUES (' . implode(', ', $placeholders) . ')';
        $connection->prepare($sql)->execute($params);
    }

    /** @param array<string, string> $columns */
    private function update(PDO $connection, string $table, string $primaryKey, string $recordId, array $values, array $columns): void
    {
        $sets = [];
        $params = [':record_id' => $recordId];
        $index = 0;
        foreach ($values as $column => $value) {
            if ($column === $primaryKey) {
                continue;
            }
            $placeholder = ':v' . $index++;
            $sets[] = $this->quoteColumn($column) . ' = ' . $this->valueExpression($placeholder, (string)($columns[$column] ?? ''));
            $params[$placeholder] = $value;
        }
        if ($sets === []) {
            return;
        }
        $sql = 'UPDATE ' . $this->quoteTable($table) . ' SET ' . implode(', ', $sets) . ' WHERE ' . $this->quoteColumn($primaryKey) . ' = :record_id';
        $connection->prepare($sql)->execute($params);
    }

    private function find(PDO $connection, string $table, string $primaryKey, string $recordId): ?array
    {
        $statement = $connection->prepare('SELECT * FROM ' . $this->quoteTable($table) . ' WHERE ' . $this->quoteColumn($primaryKey) . ' = :record_id LIMIT 1');
        $statement->execute([':record_id' => $recordId]);
        $row = $statement->fetch();
        return is_array($row) ? $row : null;
    }

    private function setAuditSuppressed(PDO $connection, bool $suppressed): void
    {
        if (Database::driver() === 'pgsql') {
            $connection->prepare("SELECT set_config('app.recovery_audit_suppressed', :value, true)")->execute([':value' => $suppressed ? '1' : '0']);
            return;
        }
        $connection->exec('SET @nite_recovery_audit_suppressed = ' . ($suppressed ? '1' : '0'));
    }

    private function valueExpression(string $placeholder, string $type): string
    {
        return Database::driver() === 'pgsql' && in_array(strtolower($type), ['json', 'jsonb'], true)
            ? 'CAST(' . $placeholder . ' AS JSONB)'
            : $placeholder;
    }

    private function quoteTable(string $name): string
    {
        return Database::driver() === 'pgsql'
            ? '"' . str_replace('"', '""', $name) . '"'
            : '`' . str_replace('`', '``', $name) . '`';
    }

    private function quoteColumn(string $name): string
    {
        return $this->quoteTable($name);
    }
}
