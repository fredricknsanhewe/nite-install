<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Services\ExampleModuleService;
use RuntimeException;

final class ExamplesController
{
    private ExampleModuleService $examples;

    public function __construct()
    {
        $this->examples = new ExampleModuleService();
    }

    public function list(Request $request): Response
    {
        try {
            $rows = $this->examples->list(
                (string)($request->params['module'] ?? ''),
                (string)($request->params['entity'] ?? ''),
                $request->query
            );
            return Response::json(['data' => $rows]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
    }

    public function show(Request $request): Response
    {
        try {
            $row = $this->examples->show(
                (string)($request->params['module'] ?? ''),
                (string)($request->params['entity'] ?? ''),
                (string)($request->params['id'] ?? '')
            );
            return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Example entity not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
    }

    public function create(Request $request): Response
    {
        try {
            $module = (string)($request->params['module'] ?? '');
            $entity = (string)($request->params['entity'] ?? '');
            $row = $this->examples->create(
                $module,
                $entity,
                $request->body,
                (string)($request->user['id'] ?? '')
            );
            return Response::json(['data' => $row], 201, [
                'Location' => '/api/v1/examples/' . rawurlencode($module) . '/' . rawurlencode($entity) . '/' . rawurlencode((string)($row['id'] ?? '')),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create example entity.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $row = $this->examples->update(
                (string)($request->params['module'] ?? ''),
                (string)($request->params['entity'] ?? ''),
                (string)($request->params['id'] ?? ''),
                $request->body,
                (string)($request->user['id'] ?? '')
            );
            return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Example entity not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update example entity.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        try {
            $deleted = $this->examples->delete(
                (string)($request->params['module'] ?? ''),
                (string)($request->params['entity'] ?? ''),
                (string)($request->params['id'] ?? '')
            );
            return Response::json(['data' => ['deleted' => $deleted]]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
    }

    public function entries(Request $request): Response
    {
        try {
            return Response::json([
                'data' => $this->examples->entries(
                    (string)($request->params['module'] ?? ''),
                    (string)($request->params['entity'] ?? ''),
                    (string)($request->params['id'] ?? '')
                ),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
    }

    public function createEntry(Request $request): Response
    {
        try {
            $row = $this->examples->addEntry(
                (string)($request->params['module'] ?? ''),
                (string)($request->params['entity'] ?? ''),
                (string)($request->params['id'] ?? ''),
                $request->body,
                (string)($request->user['id'] ?? '')
            );
            return Response::json(['data' => $row], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create example entry.'], 500);
        }
    }
}
