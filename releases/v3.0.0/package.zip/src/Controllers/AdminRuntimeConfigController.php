<?php
namespace App\Controllers;

use App\Admin\Integration\AngularAdminRenderer;
use App\Http\Request;
use App\Http\Response;

final class AdminRuntimeConfigController
{
    public function __invoke(Request $request): Response
    {
        $renderer = new AngularAdminRenderer(dirname(__DIR__, 2));
        return Response::json($renderer->runtimeConfiguration(), 200, [
            'Cache-Control' => 'no-store, private',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
