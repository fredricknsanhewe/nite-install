<?php
namespace App\Controllers;

use App\Exceptions\ValidationException;
use App\Http\ApiResponse;
use App\Http\Request;
use App\Http\Response;
use App\Services\ContactMessageService;
use RuntimeException;

final class ContactController
{
    private ContactMessageService $messages;

    public function __construct()
    {
        $this->messages = new ContactMessageService();
    }

    public function create(Request $request): Response
    {
        try {
            $message = $this->messages->create($request->body);
            return ApiResponse::success($message, 'Created successfully', 201);
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            return ApiResponse::error($e->getMessage(), ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to send contact message.', null, 500);
        }
    }

    public function adminList(Request $request): Response
    {
        return ApiResponse::success($this->messages->list($request->query));
    }

    public function show(Request $request): Response
    {
        $message = $this->messages->findById((string)($request->params['id'] ?? ''));
        return $message ? ApiResponse::success($message) : ApiResponse::error('Message not found.', null, 404);
    }

    public function update(Request $request): Response
    {
        try {
            $message = $this->messages->update((string)($request->params['id'] ?? ''), $request->body);
            return $message ? ApiResponse::success($message) : ApiResponse::error('Message not found.', null, 404);
        } catch (ValidationException $e) {
            return ApiResponse::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            return ApiResponse::error($e->getMessage(), ['detail' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return ApiResponse::error('Failed to update contact message.', null, 500);
        }
    }

    public function delete(Request $request): Response
    {
        return ApiResponse::success(['deleted' => $this->messages->delete((string)($request->params['id'] ?? ''))]);
    }
}
