<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\EventRegistrationModel;
use App\Models\TrainingEventModel;
use RuntimeException;

final class EventsController
{
    private TrainingEventModel $events;
    private EventRegistrationModel $registrations;

    public function __construct()
    {
        $this->events = new TrainingEventModel();
        $this->registrations = new EventRegistrationModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->events->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $event = $this->events->findById((string)($request->params['id'] ?? ''));
        if ($event === null || (string)($event['status'] ?? '') !== 'published') {
            return Response::json(['error' => 'Event not found.'], 404);
        }

        return Response::json(['data' => $event]);
    }

    public function register(Request $request): Response
    {
        try {
            $eventId = (string)($request->params['id'] ?? '');
            $event = $this->events->findById($eventId);
            if ($event === null || ($event['status'] ?? '') !== 'published') {
                return Response::json(['error' => 'Event not found.'], 404);
            }
            $registration = $this->registrations->create($eventId, $request->body, $request->user['id'] ?? null);
            return Response::json(['data' => $registration], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to register for event.'], 500);
        }
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->events->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $event = $this->events->findById((string)($request->params['id'] ?? ''));
        return $event ? Response::json(['data' => $event]) : Response::json(['error' => 'Event not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $event = $this->events->create($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $event], 201, [
                'Location' => '/api/v1/admin/events/' . (string)($event['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create event.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $event = $this->events->update((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $event ? Response::json(['data' => $event]) : Response::json(['error' => 'Event not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update event.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->events->delete((string)($request->params['id'] ?? ''))]]);
    }

    public function registrations(Request $request): Response
    {
        $eventId = (string)($request->params['id'] ?? '');
        return Response::json(['data' => $this->registrations->listByEvent($eventId)]);
    }

    public function showRegistration(Request $request): Response
    {
        $row = $this->registrations->findById((string)($request->params['id'] ?? ''));
        return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Registration not found.'], 404);
    }

    public function updateRegistration(Request $request): Response
    {
        try {
            $row = $this->registrations->update((string)($request->params['id'] ?? ''), $request->body);
            return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Registration not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update registration.'], 500);
        }
    }
}
