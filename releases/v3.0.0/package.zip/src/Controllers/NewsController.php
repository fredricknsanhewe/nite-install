<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\NewsPostModel;
use RuntimeException;

final class NewsController
{
    private NewsPostModel $news;

    public function __construct()
    {
        $this->news = new NewsPostModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->news->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $slug = (string)($request->params['slug'] ?? '');
        $item = $this->news->findBySlug($slug, false);
        return $item ? Response::json(['data' => $item]) : Response::json(['error' => 'Post not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->news->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $item = $this->news->findById((string)($request->params['id'] ?? ''));
        return $item ? Response::json(['data' => $item]) : Response::json(['error' => 'Post not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $item = $this->news->create($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $item], 201, [
                'Location' => '/api/v1/admin/news/' . (string)($item['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create news post.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $item = $this->news->update((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $item ? Response::json(['data' => $item]) : Response::json(['error' => 'Post not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update news post.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->news->delete((string)($request->params['id'] ?? ''))]]);
    }
}
