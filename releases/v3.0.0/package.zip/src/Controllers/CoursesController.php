<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\CourseModel;
use RuntimeException;

final class CoursesController
{
    private CourseModel $courses;

    public function __construct()
    {
        $this->courses = new CourseModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->courses->listCourses($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $course = $this->courses->findCourseBySlug((string)($request->params['slug'] ?? ''), false);
        if ($course === null) {
            return Response::json(['error' => 'Course not found.'], 404);
        }
        $course['modules'] = $this->courses->listModules((string)$course['id'], false);
        return Response::json(['data' => $course]);
    }

    public function myEnrollments(Request $request): Response
    {
        return Response::json(['data' => $this->courses->listEnrollments((string)($request->user['id'] ?? ''))]);
    }

    public function enroll(Request $request): Response
    {
        try {
            $courseId = (string)($request->params['id'] ?? '');
            $course = $this->courses->findCourseById($courseId);
            if ($course === null || ($course['status'] ?? '') !== 'published') {
                return Response::json(['error' => 'Course not found.'], 404);
            }
            return Response::json(['data' => $this->courses->enroll($courseId, (string)($request->user['id'] ?? ''))], 201);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to enroll in course.'], 500);
        }
    }

    public function updateProgress(Request $request): Response
    {
        try {
            $courseId = (string)($request->params['id'] ?? '');
            $moduleId = (string)($request->body['module_id'] ?? '');
            if ($moduleId === '') {
                return Response::json(['error' => 'module_id is required.'], 422);
            }
            $progress = $this->courses->updateProgress($courseId, $moduleId, (string)($request->user['id'] ?? ''), $request->body);
            return Response::json([
                'data' => [
                    'progress' => $progress,
                    'enrollment' => $this->courses->findEnrollment($courseId, (string)($request->user['id'] ?? '')),
                ],
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update course progress.'], 500);
        }
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->courses->listCourses($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $course = $this->courses->findCourseById((string)($request->params['id'] ?? ''));
        if ($course === null) {
            return Response::json(['error' => 'Course not found.'], 404);
        }

        $course['modules'] = $this->courses->listModules((string)$course['id'], true);
        return Response::json(['data' => $course]);
    }

    public function createCourse(Request $request): Response
    {
        try {
            $course = $this->courses->createCourse($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $course], 201, [
                'Location' => '/api/v1/admin/courses/' . (string)($course['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create course.'], 500);
        }
    }

    public function updateCourse(Request $request): Response
    {
        try {
            $course = $this->courses->updateCourse((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $course ? Response::json(['data' => $course]) : Response::json(['error' => 'Course not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update course.'], 500);
        }
    }

    public function deleteCourse(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->courses->deleteCourse((string)($request->params['id'] ?? ''))]]);
    }

    public function modules(Request $request): Response
    {
        return Response::json(['data' => $this->courses->listModules((string)($request->params['id'] ?? ''), true)]);
    }

    public function showModule(Request $request): Response
    {
        $module = $this->courses->findModule((string)($request->params['id'] ?? ''));
        return $module ? Response::json(['data' => $module]) : Response::json(['error' => 'Module not found.'], 404);
    }

    public function createModule(Request $request): Response
    {
        try {
            $module = $this->courses->createModule((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $module], 201, [
                'Location' => '/api/v1/admin/modules/' . (string)($module['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create course module.'], 500);
        }
    }

    public function updateModule(Request $request): Response
    {
        try {
            $module = $this->courses->updateModule((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $module ? Response::json(['data' => $module]) : Response::json(['error' => 'Module not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update module.'], 500);
        }
    }

    public function deleteModule(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->courses->deleteModule((string)($request->params['id'] ?? ''))]]);
    }

    public function enrollments(Request $request): Response
    {
        return Response::json(['data' => $this->courses->listEnrollments(null, (string)($request->params['id'] ?? ''))]);
    }

    public function showEnrollment(Request $request): Response
    {
        $row = $this->courses->findEnrollmentById((string)($request->params['id'] ?? ''));
        return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Enrollment not found.'], 404);
    }

    public function updateEnrollment(Request $request): Response
    {
        try {
            $row = $this->courses->updateEnrollment((string)($request->params['id'] ?? ''), $request->body);
            return $row ? Response::json(['data' => $row]) : Response::json(['error' => 'Enrollment not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update enrollment.'], 500);
        }
    }
}
