<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\UserModel;
use App\Services\AuthService;
use App\Services\RbacService;
use RuntimeException;

final class AdminUsersController
{
    private UserModel $users;
    private AuthService $auth;
    private RbacService $rbac;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->auth = new AuthService();
        $this->rbac = new RbacService();
    }

    public function list(Request $request): Response
    {
        $rows = array_map(fn (array $user): array => $this->rbac->hydrateUserPermissions($user), $this->users->list($request->query));
        return Response::json(['data' => $rows]);
    }

    public function show(Request $request): Response
    {
        $user = $this->users->findById((string)($request->params['id'] ?? ''));
        return $user ? Response::json(['data' => $this->rbac->hydrateUserPermissions($user)]) : Response::json(['error' => 'User not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $user = $this->auth->createByAdmin($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $user], 201, [
                'Location' => '/api/v1/admin/users/' . (string)($user['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create user.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            if (array_key_exists('group_ids', $request->body) && !$this->rbac->hasPermission(
                (string)($request->user['id'] ?? ''),
                (string)($request->user['role'] ?? ''),
                'admin.rbac.manage'
            )) {
                return Response::json(['error' => 'You do not have permission to change user group memberships.'], 403);
            }
            $user = $this->auth->updateByAdmin((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $user ? Response::json(['data' => $user]) : Response::json(['error' => 'User not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update user.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->users->delete((string)($request->params['id'] ?? ''))]]);
    }
}
