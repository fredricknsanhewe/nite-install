<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\GalleryModel;
use RuntimeException;

final class GalleryController
{
    private GalleryModel $gallery;

    public function __construct()
    {
        $this->gallery = new GalleryModel();
    }

    public function overview(Request $request): Response
    {
        return Response::json([
            'data' => [
                'albums' => $this->gallery->listAlbums([], false),
                'items' => $this->gallery->listItems($request->query, false),
            ],
        ]);
    }

    public function adminAlbums(Request $request): Response
    {
        return Response::json(['data' => $this->gallery->listAlbums($request->query, true)]);
    }

    public function showAlbum(Request $request): Response
    {
        $album = $this->gallery->findAlbum((string)($request->params['id'] ?? ''));
        return $album ? Response::json(['data' => $album]) : Response::json(['error' => 'Album not found.'], 404);
    }

    public function createAlbum(Request $request): Response
    {
        try {
            $album = $this->gallery->createAlbum($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $album], 201, [
                'Location' => '/api/v1/admin/gallery/albums/' . (string)($album['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create album.'], 500);
        }
    }

    public function updateAlbum(Request $request): Response
    {
        try {
            $album = $this->gallery->updateAlbum((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $album ? Response::json(['data' => $album]) : Response::json(['error' => 'Album not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update album.'], 500);
        }
    }

    public function deleteAlbum(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->gallery->deleteAlbum((string)($request->params['id'] ?? ''))]]);
    }

    public function adminItems(Request $request): Response
    {
        return Response::json(['data' => $this->gallery->listItems($request->query, true)]);
    }

    public function showItem(Request $request): Response
    {
        $item = $this->gallery->findItem((string)($request->params['id'] ?? ''));
        return $item ? Response::json(['data' => $item]) : Response::json(['error' => 'Gallery item not found.'], 404);
    }

    public function createItem(Request $request): Response
    {
        try {
            $item = $this->gallery->createItem($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $item], 201, [
                'Location' => '/api/v1/admin/gallery/items/' . (string)($item['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create gallery item.'], 500);
        }
    }

    public function updateItem(Request $request): Response
    {
        try {
            $item = $this->gallery->updateItem((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $item ? Response::json(['data' => $item]) : Response::json(['error' => 'Gallery item not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update gallery item.'], 500);
        }
    }

    public function deleteItem(Request $request): Response
    {
        return Response::json(['data' => ['deleted' => $this->gallery->deleteItem((string)($request->params['id'] ?? ''))]]);
    }
}
