<?php
namespace App\Controllers;

use App\Http\ApiResponse;
use App\Http\Request;
use App\Http\Response;
use App\Models\DataChangeLogModel;
use App\Services\DataRecoveryService;
use App\Support\DataChangeContext;
use RuntimeException;

final class DataRecoveryController
{
    private DataChangeLogModel $logs;
    private DataRecoveryService $recovery;

    public function __construct()
    {
        $this->logs = new DataChangeLogModel();
        $this->recovery = new DataRecoveryService();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->logs->list($request->query)]);
    }

    public function show(Request $request): Response
    {
        $log = $this->logs->findById((int)($request->params['logId'] ?? 0));
        return $log ? Response::json(['data' => $log]) : Response::json(['error' => 'Audit entry not found.'], 404);
    }

    public function restore(Request $request): Response
    {
        try {
            $restored = $this->recovery->restoreFromLog(
                (int)($request->params['logId'] ?? 0),
                DataChangeContext::fromRequest($request, ['change_scope' => 'data_recovery'])
            );
            return $restored ? Response::json(['data' => $restored]) : Response::json(['error' => 'Audit entry not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable $e) {
            return ApiResponse::exception($e, 'Failed to restore the archived record.', 500);
        }
    }
}
