<?php
namespace App\Controllers;

use App\Http\Request;
use App\Http\Response;
use App\Models\PageModel;
use RuntimeException;

final class PagesController
{
    private PageModel $pages;

    public function __construct()
    {
        $this->pages = new PageModel();
    }

    public function list(Request $request): Response
    {
        return Response::json(['data' => $this->pages->list($request->query, false)]);
    }

    public function show(Request $request): Response
    {
        $slug = (string)($request->params['slug'] ?? '');
        $page = $this->pages->findBySlug($slug, false);
        return $page ? Response::json(['data' => $page]) : Response::json(['error' => 'Page not found.'], 404);
    }

    public function adminList(Request $request): Response
    {
        return Response::json(['data' => $this->pages->list($request->query, true)]);
    }

    public function adminShow(Request $request): Response
    {
        $page = $this->pages->findById((string)($request->params['id'] ?? ''));
        return $page ? Response::json(['data' => $page]) : Response::json(['error' => 'Page not found.'], 404);
    }

    public function create(Request $request): Response
    {
        try {
            $page = $this->pages->create($request->body, (string)($request->user['id'] ?? ''));
            return Response::json(['data' => $page], 201, [
                'Location' => '/api/v1/admin/pages/' . (string)($page['id'] ?? ''),
            ]);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to create page.'], 500);
        }
    }

    public function update(Request $request): Response
    {
        try {
            $page = $this->pages->update((string)($request->params['id'] ?? ''), $request->body, (string)($request->user['id'] ?? ''));
            return $page ? Response::json(['data' => $page]) : Response::json(['error' => 'Page not found.'], 404);
        } catch (RuntimeException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        } catch (\Throwable) {
            return Response::json(['error' => 'Failed to update page.'], 500);
        }
    }

    public function delete(Request $request): Response
    {
        $deleted = $this->pages->delete((string)($request->params['id'] ?? ''));
        return Response::json(['data' => ['deleted' => $deleted]]);
    }
}
