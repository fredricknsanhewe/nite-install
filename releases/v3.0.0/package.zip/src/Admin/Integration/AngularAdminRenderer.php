<?php
namespace App\Admin\Integration;

use App\Config\App;
use App\Config\Env;
use RuntimeException;

final class AngularAdminRenderer
{
    public function __construct(private readonly string $rootPath)
    {
    }

    public function isAvailable(): bool
    {
        try {
            $this->validateBuild();
            return true;
        } catch (RuntimeException) {
            return false;
        }
    }

    public function render(): string
    {
        $this->validateBuild();
        $indexPath = $this->buildPath() . '/index.html';
        $html = file_get_contents($indexPath);
        if (!is_string($html)) {
            throw new RuntimeException('The compiled Nite Admin index could not be read.');
        }

        $basePath = htmlspecialchars($this->basePath() . '/', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $html = preg_replace('/<base\s+href="[^"]*"\s*>/i', '<base href="' . $basePath . '">', $html, 1) ?? $html;
        $config = json_encode($this->runtimeConfiguration(), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        if (!is_string($config)) {
            throw new RuntimeException('Failed to encode Nite Admin runtime configuration.');
        }

        $boot = '<script>window.__NITE_ADMIN_CONFIG__=' . $config . ';(function(){try{var c=JSON.parse(localStorage.getItem("nite.admin.theme")||"null");var t=(c&&c.name)||window.__NITE_ADMIN_CONFIG__.default_theme||"nite";document.documentElement.dataset.niteTheme=t;}catch(e){document.documentElement.dataset.niteTheme=window.__NITE_ADMIN_CONFIG__.default_theme||"nite";}})();</script>';
        return str_replace('</head>', $boot . '</head>', $html);
    }

    /** @return array<string, mixed> */
    public function runtimeConfiguration(): array
    {
        return [
            'application_name' => trim((string) Env::get('APP_NAME', App::NAME)) ?: App::NAME,
            'framework_version' => App::VERSION,
            'admin_version' => App::VERSION,
            'admin_base_path' => $this->basePath(),
            'api_base_path' => $this->apiBasePath(),
            'default_theme' => strtolower(trim((string) Env::get('NITE_ADMIN_DEFAULT_THEME', 'nite'))) ?: 'nite',
            'authentication_mode' => 'bearer',
            'enabled_features' => ['dashboard', 'users', 'rbac', 'api_explorer', 'themes', 'audit'],
            'branding' => [
                'title' => trim((string) Env::get('ADMIN_TITLE', 'Nite Administration')) ?: 'Nite Administration',
                'favicon_url' => trim((string) Env::get('NITE_ADMIN_FAVICON_URL', '')),
            ],
        ];
    }

    public function serveAsset(string $requestPath): bool
    {
        $base = $this->basePath();
        if (!str_starts_with($requestPath . '/', $base . '/')) {
            return false;
        }

        $relative = ltrim(substr($requestPath, strlen($base)), '/');
        if ($relative === '' || str_contains($relative, '..') || !preg_match('/\.(?:js|css|map|json|svg|png|webp|ico|woff2?)$/i', $relative)) {
            return false;
        }

        $root = realpath($this->buildPath());
        $candidate = realpath($this->buildPath() . '/' . str_replace('/', DIRECTORY_SEPARATOR, $relative));
        if ($root === false || $candidate === false || !is_file($candidate) || !str_starts_with($candidate, $root . DIRECTORY_SEPARATOR)) {
            return false;
        }

        $mime = match (strtolower(pathinfo($candidate, PATHINFO_EXTENSION))) {
            'js' => 'text/javascript; charset=UTF-8',
            'css' => 'text/css; charset=UTF-8',
            'json', 'map' => 'application/json; charset=UTF-8',
            'svg' => 'image/svg+xml',
            'png' => 'image/png',
            'webp' => 'image/webp',
            'ico' => 'image/x-icon',
            'woff', 'woff2' => 'font/woff2',
            default => 'application/octet-stream',
        };
        header('Content-Type: ' . $mime);
        header('Cache-Control: public, max-age=31536000, immutable');
        readfile($candidate);
        return true;
    }

    public function serveRuntimeConfiguration(string $requestPath): bool
    {
        if ($requestPath !== $this->basePath() . '/runtime-config.json') {
            return false;
        }
        $encoded = json_encode($this->runtimeConfiguration(), JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            return false;
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, private');
        header('X-Content-Type-Options: nosniff');
        echo $encoded;
        return true;
    }

    public function validateBuild(): void
    {
        $buildPath = $this->buildPath();
        $metadataPath = $buildPath . '/nite-admin-build.json';
        if (!is_file($buildPath . '/index.html') || !is_file($metadataPath)) {
            throw new RuntimeException('The precompiled Nite Admin build is unavailable.');
        }
        $metadata = json_decode((string) file_get_contents($metadataPath), true);
        if (!is_array($metadata)
            || (string) ($metadata['framework_version'] ?? '') !== App::VERSION
            || (string) ($metadata['admin_version'] ?? '') !== App::VERSION
            || trim((string) ($metadata['source_checksum'] ?? '')) === ''
            || trim((string) ($metadata['asset_manifest_checksum'] ?? '')) === '') {
            throw new RuntimeException('The Nite Admin build metadata is invalid or is for another framework version.');
        }
        $index = (string) file_get_contents($buildPath . '/index.html');
        if (preg_match_all('/(?:src|href)="([^"]+\.(?:js|css))"/i', $index, $matches) !== false) {
            foreach ($matches[1] as $asset) {
                $asset = preg_replace('/[?#].*$/', '', (string) $asset) ?? '';
                $asset = ltrim($asset, '/');
                if ($asset !== '' && !is_file($buildPath . '/' . $asset)) {
                    throw new RuntimeException('A required Nite Admin bundle is missing: ' . $asset);
                }
            }
        }
    }

    private function buildPath(): string
    {
        return $this->rootPath . '/public/nite-admin';
    }

    private function basePath(): string
    {
        $configured = trim((string) Env::get('NITE_ADMIN_BASE_PATH', '/admin'));
        $configured = '/' . trim($configured, '/');
        return $configured === '/' ? '/admin' : $configured;
    }

    private function apiBasePath(): string
    {
        $configured = trim((string) Env::get('NITE_API_BASE_PATH', '/api/v1'));
        return '/' . trim($configured, '/');
    }
}
