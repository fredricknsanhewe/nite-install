<?php
namespace App\Admin\Legacy;

use App\Support\AdminRenderer;

/**
 * Transitional adapter for the PHP-rendered administrator.
 *
 * It remains supported for the complete 3.0.x line. Its planned retirement is
 * 3.1.0, provided compatibility diagnostics show that no installed extension
 * still needs it.
 */
final class LegacyAdminRenderer
{
    /**
     * @param array<int, array<string, mixed>> $routes
     */
    public static function render(array $routes, ?string $selection = null): string
    {
        return AdminRenderer::render($routes, $selection);
    }
}
