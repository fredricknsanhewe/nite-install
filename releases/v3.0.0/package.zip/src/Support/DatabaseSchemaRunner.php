<?php
namespace App\Support;

use App\Config\Database;
use PDO;
use RuntimeException;

final class DatabaseSchemaRunner
{
    public static function read(): string
    {
        $schemaPath = Database::schemaPath();
        $schema = is_file($schemaPath) ? file_get_contents($schemaPath) : false;
        if (!is_string($schema) || trim($schema) === '') {
            throw new RuntimeException('Failed to read database schema file: ' . $schemaPath);
        }

        return $schema;
    }

    public static function apply(PDO $connection): void
    {
        $schema = self::read();
        if (Database::driver() !== 'mysql') {
            $connection->exec($schema);
            self::ensureRbacGroupSchema($connection);
            self::ensureMediaManagerSchema($connection);
            self::ensureMailQueueSchema($connection);
            self::ensureAuthLoginAttemptSchema($connection);
            self::ensurePasswordSecuritySchema($connection);
            RecoveryAuditInstaller::install($connection);
            return;
        }

        foreach (preg_split('/;\s*(?:\r?\n|$)/', $schema) ?: [] as $statement) {
            $statement = trim((string)$statement);
            if ($statement === '') {
                continue;
            }
            $connection->exec($statement);
        }

        self::ensureRbacGroupSchema($connection);
        self::ensureMediaManagerSchema($connection);
        self::ensureMailQueueSchema($connection);
        self::ensureAuthLoginAttemptSchema($connection);
        self::ensurePasswordSecuritySchema($connection);
        RecoveryAuditInstaller::install($connection);
    }

    private static function ensureRbacGroupSchema(PDO $connection): void
    {
        if (!self::tableExists($connection, 'users') || !self::tableExists($connection, 'permissions')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS rbac_groups (
                    id UUID PRIMARY KEY,
                    code VARCHAR(80) NOT NULL UNIQUE,
                    name VARCHAR(160) NOT NULL,
                    description TEXT NULL,
                    is_active BOOLEAN NOT NULL DEFAULT TRUE,
                    created_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                    updated_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_rbac_groups_active_name ON rbac_groups (is_active, name)');
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS rbac_group_members (
                    group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
                    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY (group_id, user_id)
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_rbac_group_members_user ON rbac_group_members (user_id)');
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS rbac_group_permission_rules (
                    group_id UUID NOT NULL REFERENCES rbac_groups(id) ON DELETE CASCADE,
                    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
                    effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY (group_id, permission_id)
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_rbac_group_permission_rules_permission ON rbac_group_permission_rules (permission_id)');
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS rbac_groups (
                id CHAR(36) PRIMARY KEY,
                code VARCHAR(80) NOT NULL,
                name VARCHAR(160) NOT NULL,
                description TEXT NULL,
                is_active BOOLEAN NOT NULL DEFAULT TRUE,
                created_by_user_id CHAR(36) NULL,
                updated_by_user_id CHAR(36) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY idx_rbac_groups_code (code),
                KEY idx_rbac_groups_active_name (is_active, name),
                KEY idx_rbac_groups_created_by (created_by_user_id),
                KEY idx_rbac_groups_updated_by (updated_by_user_id),
                CONSTRAINT rbac_groups_created_by_fk FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
                CONSTRAINT rbac_groups_updated_by_fk FOREIGN KEY (updated_by_user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS rbac_group_members (
                group_id CHAR(36) NOT NULL,
                user_id CHAR(36) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (group_id, user_id),
                KEY idx_rbac_group_members_user (user_id),
                CONSTRAINT rbac_group_members_group_fk FOREIGN KEY (group_id) REFERENCES rbac_groups(id) ON DELETE CASCADE,
                CONSTRAINT rbac_group_members_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS rbac_group_permission_rules (
                group_id CHAR(36) NOT NULL,
                permission_id BIGINT NOT NULL,
                effect VARCHAR(10) NOT NULL CHECK (effect IN ('allow', 'deny')),
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (group_id, permission_id),
                KEY idx_rbac_group_permission_rules_permission (permission_id),
                CONSTRAINT rbac_group_permission_rules_group_fk FOREIGN KEY (group_id) REFERENCES rbac_groups(id) ON DELETE CASCADE,
                CONSTRAINT rbac_group_permission_rules_permission_fk FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function ensureMediaManagerSchema(PDO $connection): void
    {
        if (!self::tableExists($connection, 'media_assets')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS access_scope VARCHAR(20) NOT NULL DEFAULT 'private'");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS allowed_roles_json JSONB NOT NULL DEFAULT '[]'::JSONB");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS allowed_user_ids_json JSONB NOT NULL DEFAULT '[]'::JSONB");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS checksum_sha1 VARCHAR(40) NULL");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS current_version_number INTEGER NOT NULL DEFAULT 1");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS version_count INTEGER NOT NULL DEFAULT 1");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS updated_by_user_id UUID NULL");
            $connection->exec("ALTER TABLE media_assets ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()");
            $connection->exec("ALTER TABLE media_assets ALTER COLUMN public_url DROP NOT NULL");
            $connection->exec("UPDATE media_assets SET access_scope = 'public' WHERE access_scope = 'private' AND COALESCE(TRIM(public_url), '') <> ''");
            $connection->exec("UPDATE media_assets SET allowed_roles_json = '[]'::JSONB WHERE allowed_roles_json IS NULL");
            $connection->exec("UPDATE media_assets SET allowed_user_ids_json = '[]'::JSONB WHERE allowed_user_ids_json IS NULL");
            return;
        }

        self::ensureMysqlColumn($connection, 'media_assets', 'access_scope', "ALTER TABLE media_assets ADD COLUMN access_scope VARCHAR(20) NOT NULL DEFAULT 'private' AFTER alt_text");
        self::ensureMysqlColumn($connection, 'media_assets', 'allowed_roles_json', "ALTER TABLE media_assets ADD COLUMN allowed_roles_json JSON NULL AFTER access_scope");
        self::ensureMysqlColumn($connection, 'media_assets', 'allowed_user_ids_json', "ALTER TABLE media_assets ADD COLUMN allowed_user_ids_json JSON NULL AFTER allowed_roles_json");
        self::ensureMysqlColumn($connection, 'media_assets', 'checksum_sha1', "ALTER TABLE media_assets ADD COLUMN checksum_sha1 VARCHAR(40) NULL AFTER allowed_user_ids_json");
        self::ensureMysqlColumn($connection, 'media_assets', 'current_version_number', "ALTER TABLE media_assets ADD COLUMN current_version_number INT NOT NULL DEFAULT 1 AFTER checksum_sha1");
        self::ensureMysqlColumn($connection, 'media_assets', 'version_count', "ALTER TABLE media_assets ADD COLUMN version_count INT NOT NULL DEFAULT 1 AFTER current_version_number");
        self::ensureMysqlColumn($connection, 'media_assets', 'updated_by_user_id', "ALTER TABLE media_assets ADD COLUMN updated_by_user_id CHAR(36) NULL AFTER created_by_user_id");
        self::ensureMysqlColumn($connection, 'media_assets', 'updated_at', "ALTER TABLE media_assets ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER created_at");
        $connection->exec('ALTER TABLE media_assets MODIFY COLUMN public_url TEXT NULL');

        $connection->exec("UPDATE media_assets SET access_scope = 'public' WHERE access_scope = 'private' AND COALESCE(TRIM(public_url), '') <> ''");
        $connection->exec("UPDATE media_assets SET allowed_roles_json = JSON_ARRAY() WHERE allowed_roles_json IS NULL");
        $connection->exec("UPDATE media_assets SET allowed_user_ids_json = JSON_ARRAY() WHERE allowed_user_ids_json IS NULL");
    }

    private static function ensureMailQueueSchema(PDO $connection): void
    {
        if (self::tableExists($connection, 'mail_queue')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS mail_queue (
                    id UUID PRIMARY KEY,
                    message_type VARCHAR(80) NOT NULL DEFAULT 'transactional',
                    status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'sent', 'failed')),
                    transport VARCHAR(40) NOT NULL DEFAULT 'smtp',
                    priority INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
                    attempts INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 3,
                    to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    cc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    bcc_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    reply_to_json JSONB NOT NULL DEFAULT '[]'::JSONB,
                    subject VARCHAR(255) NOT NULL,
                    text_body TEXT NULL,
                    html_body TEXT NULL,
                    from_address VARCHAR(255) NOT NULL,
                    from_name VARCHAR(255) NULL,
                    sender_address VARCHAR(255) NULL,
                    headers_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    metadata_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    delivery_meta_json JSONB NOT NULL DEFAULT '{}'::JSONB,
                    last_error TEXT NULL,
                    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    reserved_at TIMESTAMPTZ NULL,
                    sent_at TIMESTAMPTZ NULL,
                    failed_at TIMESTAMPTZ NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_mail_queue_status_available ON mail_queue (status, available_at ASC, created_at ASC)');
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_mail_queue_type_status_created ON mail_queue (message_type, status, created_at DESC)');
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS mail_queue (
                id CHAR(36) PRIMARY KEY,
                message_type VARCHAR(80) NOT NULL DEFAULT 'transactional',
                status VARCHAR(20) NOT NULL DEFAULT 'queued',
                transport VARCHAR(40) NOT NULL DEFAULT 'smtp',
                priority INT NOT NULL DEFAULT 3,
                attempts INT NOT NULL DEFAULT 0,
                max_attempts INT NOT NULL DEFAULT 3,
                to_json JSON NOT NULL,
                cc_json JSON NOT NULL,
                bcc_json JSON NOT NULL,
                reply_to_json JSON NOT NULL,
                subject VARCHAR(255) NOT NULL,
                text_body TEXT NULL,
                html_body LONGTEXT NULL,
                from_address VARCHAR(255) NOT NULL,
                from_name VARCHAR(255) NULL,
                sender_address VARCHAR(255) NULL,
                headers_json JSON NOT NULL,
                metadata_json JSON NOT NULL,
                delivery_meta_json JSON NOT NULL,
                last_error LONGTEXT NULL,
                available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                reserved_at DATETIME NULL,
                sent_at DATETIME NULL,
                failed_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_mail_queue_status_available (status, available_at, created_at),
                KEY idx_mail_queue_type_status_created (message_type, status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function ensureAuthLoginAttemptSchema(PDO $connection): void
    {
        if (self::tableExists($connection, 'auth_login_attempts')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS auth_login_attempts (
                    id UUID PRIMARY KEY,
                    throttle_key VARCHAR(128) NOT NULL UNIQUE,
                    email VARCHAR(255) NOT NULL,
                    ip_address VARCHAR(64) NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    first_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    last_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    locked_until TIMESTAMPTZ NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_auth_login_attempts_last_attempt ON auth_login_attempts (last_attempt_at DESC)');
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS auth_login_attempts (
                id CHAR(36) PRIMARY KEY,
                throttle_key VARCHAR(128) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL,
                ip_address VARCHAR(64) NOT NULL,
                attempts INT NOT NULL DEFAULT 0,
                first_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                locked_until DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_auth_login_attempts_last_attempt (last_attempt_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function ensurePasswordSecuritySchema(PDO $connection): void
    {
        if (!self::tableExists($connection, 'users')) {
            return;
        }

        if (Database::driver() === 'pgsql') {
            $connection->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMPTZ NULL");
            $connection->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS force_password_change BOOLEAN NOT NULL DEFAULT FALSE");
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS user_password_history (
                    id UUID PRIMARY KEY,
                    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    password_hash TEXT NOT NULL,
                    changed_by_user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
                    change_source VARCHAR(40) NOT NULL DEFAULT 'user_change',
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_user_password_history_user_created ON user_password_history (user_id, created_at DESC)');
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_user_password_history_changed_by ON user_password_history (changed_by_user_id)');
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS password_reset_tokens (
                    id UUID PRIMARY KEY,
                    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    email VARCHAR(255) NOT NULL,
                    token_hash CHAR(64) NOT NULL UNIQUE,
                    expires_at TIMESTAMPTZ NOT NULL,
                    used_at TIMESTAMPTZ NULL,
                    requested_ip VARCHAR(64) NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_email ON password_reset_tokens (email)');
            $connection->exec('CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_created ON password_reset_tokens (user_id, created_at DESC)');
            return;
        }

        self::ensureMysqlColumn($connection, 'users', 'password_changed_at', 'ALTER TABLE users ADD COLUMN password_changed_at DATETIME NULL AFTER last_login_at');
        self::ensureMysqlColumn($connection, 'users', 'force_password_change', 'ALTER TABLE users ADD COLUMN force_password_change BOOLEAN NOT NULL DEFAULT FALSE AFTER password_changed_at');
        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS user_password_history (
                id CHAR(36) PRIMARY KEY,
                user_id CHAR(36) NOT NULL,
                password_hash TEXT NOT NULL,
                changed_by_user_id CHAR(36) NULL,
                change_source VARCHAR(40) NOT NULL DEFAULT 'user_change',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_user_password_history_user_created (user_id, created_at),
                KEY idx_user_password_history_changed_by (changed_by_user_id),
                CONSTRAINT user_password_history_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT user_password_history_changed_by_fk FOREIGN KEY (changed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id CHAR(36) PRIMARY KEY,
                user_id CHAR(36) NOT NULL,
                email VARCHAR(255) NOT NULL,
                token_hash CHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                requested_ip VARCHAR(64) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY idx_password_reset_tokens_hash (token_hash),
                KEY idx_password_reset_tokens_email (email),
                KEY idx_password_reset_tokens_user_created (user_id, created_at),
                CONSTRAINT password_reset_tokens_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    private static function tableExists(PDO $connection, string $table): bool
    {
        if (Database::driver() === 'pgsql') {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = :table');
        } else {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :table');
        }

        $statement->execute([':table' => $table]);
        return (int)$statement->fetchColumn() > 0;
    }

    private static function ensureMysqlColumn(PDO $connection, string $table, string $column, string $ddl): void
    {
        $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :column');
        $statement->execute([
            ':table' => $table,
            ':column' => $column,
        ]);
        if ((int)$statement->fetchColumn() > 0) {
            return;
        }

        $connection->exec($ddl);
    }
}
