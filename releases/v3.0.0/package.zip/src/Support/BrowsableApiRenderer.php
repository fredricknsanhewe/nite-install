<?php
namespace App\Support;

final class BrowsableApiRenderer
{
    /**
     * @param array<string, mixed> $context
     */
    public static function render(array $context): string
    {
        $title = self::escape((string)($context['endpoint']['path'] ?? '/api'));
        $encoded = json_encode(
            $context,
            JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if (!is_string($encoded)) {
            $encoded = '{}';
        }

        $html = <<<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nite API __TITLE__</title>
    <style>
        :root {
            color-scheme: light;
            --nav-bg: #2c2c2c;
            --nav-accent: #a30000;
            --link: #a30000;
            --link-hover: #c20000;
            --text: #333333;
            --muted: #777777;
            --surface: #ffffff;
            --surface-soft: #f7f7f9;
            --surface-strong: #f5f5f5;
            --line: #dddddd;
            --line-soft: #e5e5e5;
            --shadow: 0 10px 28px rgba(0, 0, 0, 0.18);
            --primary: #428bca;
            --primary-hover: #3276b1;
            --primary-border: #357ebd;
            --danger: #d9534f;
            --danger-hover: #c9302c;
            --danger-border: #d43f3a;
            --radius: 4px;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            color: var(--text);
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 1.42857143;
            background-color: #fffdf9;
            background-image:
                linear-gradient(to right, rgba(170, 155, 120, 0.10) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(170, 155, 120, 0.10) 1px, transparent 1px);
            background-size: 40px 40px;
            background-attachment: fixed;
        }

        body.modal-open {
            overflow: hidden;
        }

        a {
            color: var(--link);
            text-decoration: none;
        }

        a:hover {
            color: var(--link-hover);
            text-decoration: underline;
        }

        button,
        input,
        select,
        textarea {
            font: inherit;
        }

        code,
        pre,
        textarea,
        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="password"],
        input[type="file"],
        select {
            font-family: Menlo, Consolas, "Andale Mono", "Lucida Console", monospace;
        }

        h1,
        h2,
        h3,
        h4 {
            margin: 0;
            font-weight: 300;
        }

        h1 {
            font-size: 54px;
            line-height: 1.1;
            margin-bottom: 10px;
        }

        h2 {
            font-size: 30px;
        }

        h4 {
            font-size: 18px;
        }

        p {
            margin: 0 0 10px;
        }

        .wrapper {
            position: relative;
            min-height: 100%;
            padding-top: 60px;
            margin: -60px 0;
        }

        .container {
            width: min(1170px, calc(100% - 30px));
            margin: 0 auto;
        }

        .navbar {
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            width: 100%;
            background: var(--nav-bg);
            border-top: 5px solid var(--nav-accent);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: 55px;
            gap: 16px;
        }

        .navbar-brand {
            display: inline-block;
            color: #9d9d9d;
            font-size: 20px;
            line-height: 20px;
            padding: 15px 0;
            text-decoration: none;
        }

        .navbar-brand:hover {
            color: #ffffff;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .nav.pull-right {
            margin-left: auto;
        }

        .nav-user {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 0;
            background: transparent;
            color: #ffffff;
            cursor: pointer;
            padding: 15px 0;
        }

        .nav-user:hover {
            color: #ffffff;
        }

        .caret {
            display: inline-block;
            width: 0;
            height: 0;
            vertical-align: middle;
            border-top: 4px dashed;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent;
        }

        .dropdown {
            position: relative;
        }

        .dropdown.open .dropdown-menu {
            display: block;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            z-index: 120;
            min-width: 180px;
            padding: 5px 0;
            margin: 2px 0 0;
            list-style: none;
            background-color: #ffffff;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: var(--radius);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
        }

        .dropdown-menu li {
            display: block;
        }

        .dropdown-menu a,
        .dropdown-menu button {
            display: block;
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--link);
            text-align: left;
            padding: 7px 16px;
            cursor: pointer;
            white-space: nowrap;
        }

        .dropdown-menu a:hover,
        .dropdown-menu button:hover {
            background: #eeeeee;
            color: var(--link-hover);
            text-decoration: none;
        }

        .dropdown-divider {
            height: 1px;
            margin: 8px 0;
            background: #eeeeee;
        }

        .session-menu {
            width: min(320px, calc(100vw - 24px));
            padding: 10px 0 12px;
        }

        .session-menu .menu-heading {
            display: block;
            padding: 4px 16px 8px;
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .session-menu .menu-block {
            padding: 0 16px 10px;
        }

        .session-menu input {
            width: 100%;
            margin-bottom: 8px;
        }

        .menu-actions {
            display: flex;
            gap: 8px;
        }

        .menu-actions .btn {
            flex: 1 1 auto;
        }

        .breadcrumb {
            list-style: none;
            margin: 70px 0 0;
            padding: 8px 15px;
            background: #fcfcfc;
            border: 1px solid #f0f0f0;
            border-radius: var(--radius);
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .breadcrumb li {
            color: var(--muted);
        }

        .breadcrumb li + li::before {
            content: "/";
            color: #cccccc;
            margin-right: 6px;
        }

        .breadcrumb li.active a,
        .breadcrumb li.active {
            color: var(--muted);
        }

        #content {
            margin: 0;
            padding-bottom: 56px;
        }

        .region {
            clear: both;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .pull-left {
            float: left;
        }

        .pull-right {
            float: right;
        }

        .button-form {
            float: right;
            margin-left: 10px;
        }

        .region::after,
        .content-main::after,
        .form-group::after,
        .writer-toolbar::after {
            content: "";
            display: table;
            clear: both;
        }

        .content-main {
            clear: both;
        }

        .page-header {
            border-bottom: 0;
            padding-bottom: 0;
            margin: 0 0 18px;
        }

        .resource-description {
            clear: both;
            margin-bottom: 18px;
            color: var(--text);
        }

        .request-info,
        .response-info {
            clear: both;
            margin-bottom: 24px;
        }

        pre {
            overflow: auto;
            word-wrap: normal;
            white-space: pre;
            font-size: 12px;
            margin: 0;
        }

        .prettyprint {
            background: #f8f8fb;
            border: 1px solid #dddddd;
            border-radius: var(--radius);
            padding: 14px 16px;
            min-height: 56px;
        }

        .response-body-panel {
            display: block;
        }

        .response-plain {
            margin: 0;
            white-space: pre-wrap;
            word-break: break-word;
        }

        .meta.nocode {
            display: block;
            margin-bottom: 14px;
            color: #333333;
        }

        .meta.nocode b {
            font-weight: 700;
        }

        .lit {
            color: #005f99;
        }

        .key,
        .str {
            color: #d14;
        }

        .num,
        .bool {
            color: #0086b3;
        }

        .null {
            color: #999999;
        }

        .route-catalog {
            display: grid;
            gap: 10px;
        }

        .route-catalog-summary {
            color: var(--muted);
            margin-bottom: 2px;
        }

        .route-doc {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: #ffffff;
            overflow: hidden;
        }

        .route-doc[open] {
            border-color: #c9d8e7;
            box-shadow: inset 0 0 0 1px rgba(66, 139, 202, 0.08);
        }

        .route-doc-summary {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 14px;
            cursor: pointer;
            list-style: none;
            user-select: none;
        }

        .route-doc-summary-main {
            flex: 1 1 auto;
            min-width: 0;
            display: grid;
            gap: 4px;
        }

        .route-doc-summary-methods,
        .route-doc-method-tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .route-doc-method-tab {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 68px;
            padding: 6px 10px;
            border: 1px solid #c7d3df;
            border-radius: 999px;
            background: #ffffff;
            color: #3a4a58;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            cursor: pointer;
        }

        .route-doc-method-tab.active {
            border-color: #428bca;
            background: #428bca;
            color: #ffffff;
        }

        .route-doc-summary::-webkit-details-marker {
            display: none;
        }

        .route-doc-summary::before {
            content: "+";
            flex: 0 0 auto;
            width: 18px;
            color: var(--muted);
            font-weight: 700;
            text-align: center;
        }

        .route-doc[open] .route-doc-summary::before {
            content: "-";
        }

        .route-method {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 62px;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .route-method-get,
        .route-method-head {
            background: #e7f1fb;
            color: #255a89;
        }

        .route-method-post {
            background: #e8f6eb;
            color: #2c6b38;
        }

        .route-method-put,
        .route-method-patch {
            background: #f4ecfb;
            color: #6e46ba;
        }

        .route-method-delete {
            background: #fdeceb;
            color: #b34139;
        }

        .route-method-options {
            background: #f0f3f7;
            color: #5d6b79;
        }

        .route-doc-path {
            flex: 1 1 auto;
            font-weight: 700;
            color: #333333;
            word-break: break-word;
        }

        .route-doc-caption {
            display: block;
            margin-top: 3px;
            font-weight: 400;
            color: var(--muted);
        }

        .route-doc-body {
            border-top: 1px solid var(--line-soft);
            padding: 14px;
            background: #fcfcfe;
        }

        .route-doc-links {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 12px;
        }

        .route-doc-note {
            margin-bottom: 12px;
            color: var(--muted);
        }

        .route-doc-link {
            display: inline-flex;
            align-items: center;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            padding: 6px 10px;
            color: var(--link);
            background: #ffffff;
        }

        .route-doc-link:hover {
            background: #f6f6f6;
            text-decoration: none;
        }

        .route-doc-grid {
            display: grid;
            gap: 10px;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            margin-bottom: 12px;
        }

        .route-doc-card {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: #ffffff;
            padding: 10px 12px;
        }

        .route-doc-card strong {
            display: block;
            margin-bottom: 5px;
            font-size: 12px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .route-doc-card span,
        .route-doc-card code {
            display: block;
            word-break: break-word;
        }

        .route-doc-section {
            margin-top: 12px;
        }

        .route-doc-section h5 {
            margin: 0 0 8px;
            font-size: 13px;
            font-weight: 700;
            color: #333333;
        }

        .route-field-list {
            display: grid;
            gap: 8px;
        }

        .route-field {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: #ffffff;
            padding: 10px 12px;
        }

        .route-field code {
            font-size: 12px;
        }

        .route-field-meta {
            display: block;
            margin-top: 4px;
            color: var(--muted);
            line-height: 1.45;
        }

        .route-empty {
            color: var(--muted);
            font-style: italic;
        }

        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            color: #333333;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            cursor: pointer;
            background-color: #ffffff;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            user-select: none;
        }

        .btn:hover {
            background-color: #e6e6e6;
            border-color: #adadad;
            color: #333333;
            text-decoration: none;
        }

        .btn:focus-visible,
        .nav-user:focus-visible,
        .dropdown-menu button:focus-visible,
        .dropdown-menu a:focus-visible,
        input:focus-visible,
        select:focus-visible,
        textarea:focus-visible {
            outline: 2px solid rgba(66, 139, 202, 0.25);
            outline-offset: 2px;
        }

        .btn-primary {
            color: #ffffff;
            background-color: var(--primary);
            border-color: var(--primary-border);
        }

        .btn-primary:hover {
            color: #ffffff;
            background-color: var(--primary-hover);
            border-color: #285e8e;
        }

        .btn-default {
            color: #333333;
            background-color: #ffffff;
            border-color: #cccccc;
        }

        .btn-danger {
            color: #ffffff;
            background-color: var(--danger);
            border-color: var(--danger-border);
        }

        .btn-danger:hover {
            color: #ffffff;
            background-color: var(--danger-hover);
            border-color: #ac2925;
        }

        .btn[disabled] {
            opacity: 0.65;
            cursor: not-allowed;
            box-shadow: none;
        }

        .btn-group {
            position: relative;
            display: inline-flex;
            vertical-align: middle;
        }

        .btn-group > .btn {
            position: relative;
            flex: 0 0 auto;
            border-radius: 0;
        }

        .btn-group > .btn + .btn {
            margin-left: -1px;
        }

        .btn-group > .btn:first-child {
            border-top-left-radius: var(--radius);
            border-bottom-left-radius: var(--radius);
        }

        .btn-group > .btn:last-child {
            border-top-right-radius: var(--radius);
            border-bottom-right-radius: var(--radius);
        }

        .btn-group.open .dropdown-menu {
            display: block;
        }

        .method-actions {
            flex-wrap: wrap;
            gap: 8px;
        }

        .method-actions > .btn {
            min-width: 72px;
            border-radius: var(--radius);
        }

        .method-actions > .btn + .btn {
            margin-left: 0;
        }

        .format-selection .dropdown-menu {
            right: 0;
            left: auto;
        }

        .well {
            min-height: 20px;
            padding: 0 18px 18px;
            margin-bottom: 20px;
            background-color: #f5f5f5;
            border: 1px solid #e3e3e3;
            border-radius: var(--radius);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
        }

        .writer-panel[hidden] {
            display: none;
        }

        .writer-methods {
            padding-top: 14px;
            margin-bottom: 8px;
            text-align: right;
        }

        .writer-methods .btn {
            min-width: 72px;
        }

        .writer-methods .btn-primary {
            box-shadow: none;
        }

        .nav-tabs {
            list-style: none;
            margin: 0 0 -1px;
            padding-left: 0;
            border: 0;
        }

        .nav-tabs > li {
            float: right;
            margin-left: 2px;
        }

        .nav-tabs > li > a {
            display: block;
            padding: 10px 15px;
            border: 1px solid transparent;
            border-radius: var(--radius) var(--radius) 0 0;
            color: var(--link);
        }

        .nav-tabs > li > a:hover {
            background: transparent;
            text-decoration: none;
        }

        .nav-tabs > li.active > a {
            background: #ffffff;
            border-color: #dddddd #dddddd transparent;
            color: var(--muted);
        }

        .tab-content {
            background: #ffffff;
            border: 1px solid #dddddd;
            border-radius: var(--radius);
            border-top-right-radius: 0;
            padding: 20px 18px 18px;
        }

        .tab-pane[hidden] {
            display: none;
        }

        .help-block {
            display: block;
            margin-top: 5px;
            margin-bottom: 0;
            color: var(--muted);
        }

        .text-muted {
            color: var(--muted);
        }

        .form-horizontal .form-group {
            margin-bottom: 18px;
        }

        .form-horizontal .control-label {
            float: left;
            width: 140px;
            padding-top: 7px;
            margin-bottom: 0;
            text-align: right;
            font-weight: 700;
        }

        .form-horizontal .controls {
            margin-left: 160px;
        }

        .form-horizontal .checkbox-control {
            display: flex;
            align-items: center;
            gap: 8px;
            padding-top: 6px;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="password"],
        input[type="file"],
        select,
        textarea {
            width: 90%;
            padding: 6px 10px;
            color: #555555;
            background-color: #ffffff;
            border: 1px solid #cccccc;
            border-radius: var(--radius);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        }

        textarea {
            min-height: 180px;
            resize: vertical;
        }

        select[multiple] {
            min-height: 150px;
        }

        input[type="checkbox"] {
            margin: 0;
        }

        .form-actions {
            padding-top: 12px;
            text-align: right;
        }

        .form-actions .btn {
            min-width: 72px;
        }

        .media-helper {
            margin-top: 10px;
            padding: 10px 12px;
            border: 1px dashed #cfd7df;
            border-radius: var(--radius);
            background: #fafbfd;
        }

        .media-helper-note {
            display: block;
            margin-bottom: 8px;
            color: var(--muted);
        }

        .media-helper-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.5fr) minmax(140px, 0.7fr);
            gap: 10px;
            align-items: end;
        }

        .media-helper-grid input,
        .media-helper-grid select {
            width: 100%;
        }

        .media-helper-status {
            display: block;
            margin-top: 8px;
            color: var(--muted);
        }

        .media-helper-status.is-success {
            color: #2d7d4f;
        }

        .media-helper-status.is-error {
            color: #b34139;
        }

        .relation-picker {
            display: grid;
            gap: 8px;
        }

        .relation-picker-controls {
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .relation-picker-controls input {
            flex: 1 1 auto;
            width: 100%;
        }

        .relation-picker-controls .btn {
            flex: 0 0 auto;
            min-width: 88px;
        }

        .relation-picker-row {
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .relation-picker-row select {
            flex: 1 1 auto;
            width: 100%;
        }

        .relation-picker-row .btn {
            flex: 0 0 auto;
            min-width: 88px;
        }

        .relation-picker-meta {
            display: block;
            color: var(--muted);
        }

        .relation-picker-meta.error {
            color: #b34139;
        }

        .empty-state {
            color: var(--muted);
        }

        .modal {
            position: fixed;
            inset: 0;
            z-index: 160;
            display: none;
            overflow-x: hidden;
            overflow-y: auto;
            padding: 24px 12px;
        }

        .modal.open {
            display: block;
        }

        .modal-backdrop {
            position: fixed;
            inset: 0;
            z-index: 150;
            background: rgba(0, 0, 0, 0.46);
            display: none;
        }

        .modal-backdrop.open {
            display: block;
        }

        .modal-dialog {
            position: relative;
            width: min(600px, calc(100vw - 24px));
            margin: 30px auto;
        }

        .modal-content {
            position: relative;
            background-color: #ffffff;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 6px;
            box-shadow: var(--shadow);
            background-clip: padding-box;
        }

        .modal-header,
        .modal-body {
            padding: 15px 18px;
        }

        .modal-header {
            border-bottom: 1px solid #e5e5e5;
        }

        .modal-close {
            float: right;
            padding: 0;
            border: 0;
            background: transparent;
            color: #000000;
            opacity: 0.4;
            font-size: 28px;
            line-height: 1;
            cursor: pointer;
        }

        .modal-close:hover {
            opacity: 0.7;
        }

        .filter-form p {
            margin-bottom: 14px;
        }

        .filter-form label {
            display: block;
            margin-bottom: 6px;
            font-weight: 700;
        }

        .filter-form input,
        .filter-form select,
        .filter-form textarea {
            width: 100%;
        }

        .search-form {
            display: flex;
            gap: 10px;
            align-items: stretch;
        }

        .search-form .search-input {
            flex: 1 1 auto;
        }

        .search-form .search-submit {
            flex: 0 0 auto;
        }

        .hidden {
            display: none !important;
        }

        @media (max-width: 900px) {
            .container {
                width: calc(100% - 20px);
            }

            .navbar .container {
                flex-wrap: wrap;
                padding-bottom: 6px;
            }

            h1 {
                font-size: 42px;
            }

            .form-horizontal .control-label,
            .form-horizontal .controls {
                float: none;
                width: 100%;
                margin-left: 0;
                text-align: left;
            }

            .form-horizontal .control-label {
                padding-top: 0;
                margin-bottom: 8px;
            }

            input[type="text"],
            input[type="number"],
            input[type="email"],
            input[type="password"],
            input[type="file"],
            select,
            textarea {
                width: 100%;
            }
        }

        @media (max-width: 680px) {
            .container {
                width: calc(100% - 16px);
            }

            .breadcrumb {
                margin-top: 76px;
            }

            .region {
                display: grid;
                gap: 10px;
            }

            .pull-left,
            .pull-right,
            .button-form {
                float: none;
                margin: 0;
            }

            .region .btn,
            .region .btn-group,
            .region .btn-group > .btn {
                width: 100%;
            }

            .btn-group {
                display: flex;
            }

            .btn-group > .btn + .btn {
                margin-left: 0;
            }

            .nav-tabs > li {
                float: none;
                margin-left: 0;
                margin-bottom: 2px;
            }

            .tab-content {
                border-top-right-radius: var(--radius);
            }

            .search-form {
                flex-direction: column;
            }

            .media-helper-grid {
                grid-template-columns: 1fr;
            }

            .relation-picker-controls,
            .relation-picker-row {
                flex-direction: column;
            }

            .route-doc-method-tabs,
            .route-doc-summary-methods {
                gap: 6px;
            }

            .session-menu {
                width: min(320px, calc(100vw - 16px));
            }

            .modal {
                padding: 0;
            }

            .modal-dialog {
                width: 100vw;
                margin: 0;
                min-height: 100vh;
            }

            .modal-content {
                min-height: 100vh;
                border-radius: 0;
                border: 0;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="navbar navbar-static-top navbar-inverse" role="navigation" aria-label="navbar">
            <div class="container">
                <span>
                    <a class="navbar-brand" href="/api/v1/meta/routes">Nite REST API</a>
                </span>
                <ul class="nav pull-right">
                    <li class="dropdown" id="sessionDropdown">
                        <button class="nav-user" id="sessionToggle" type="button" aria-haspopup="true" aria-expanded="false">
                            <span id="sessionLabel">Guest</span>
                            <span class="caret" aria-hidden="true"></span>
                        </button>
                        <ul class="dropdown-menu session-menu" id="sessionMenu" aria-label="session menu">
                            <li><span class="menu-heading">Authorization</span></li>
                            <li class="menu-block">
                                <input id="tokenInput" type="password" placeholder="Bearer token">
                                <div class="menu-actions">
                                    <button class="btn btn-primary" id="saveTokenButton" type="button">Save</button>
                                    <button class="btn btn-default" id="clearTokenButton" type="button">Clear</button>
                                </div>
                            </li>
                            <li class="dropdown-divider" role="separator"></li>
                            <li><a href="/api/v1">API root</a></li>
                            <li><a href="/api/v1/meta/routes">Routes</a></li>
                            <li><a href="/api/v1/meta/resources">Resources</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

        <div class="container">
            <ul class="breadcrumb" id="breadcrumbTrail">
                <li class="active"><a href="/api/v1">Api Root</a></li>
            </ul>

            <div id="content" role="main" aria-label="content">
                <div class="region" aria-label="request form">
                    <div class="button-form" id="methodActionsWrap">
                        <div class="btn-group method-actions" id="methodActions" aria-label="available methods"></div>
                    </div>

                    <div class="button-form hidden" id="filtersWrap">
                        <button class="btn btn-default" id="filtersButton" type="button">Filters</button>
                    </div>

                    <form id="format-form" class="pull-right">
                        <fieldset>
                            <div class="btn-group format-selection dropdown" id="formatDropdownWrap">
                                <button class="btn btn-default dropdown-toggle" id="formatToggle" type="button" aria-haspopup="true" aria-expanded="false">
                                    Format
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" id="formatMenu" aria-label="format selection">
                                    <li><a id="formatJsonLink" href="/?format=json" rel="nofollow">json</a></li>
                                    <li><a id="formatApiLink" href="/?format=api" rel="nofollow">api</a></li>
                                </ul>
                            </div>
                        </fieldset>
                    </form>
                </div>

                <div class="content-main" role="main" aria-label="main content">
                    <div class="page-header">
                        <h1 id="pageTitle">Browsable API</h1>
                    </div>
                    <div class="resource-description pull-left">
                        <p id="pageDescription"></p>
                    </div>

                    <div class="request-info" aria-label="request info">
                        <pre class="prettyprint" id="requestPreview"><b>GET</b> /</pre>
                    </div>

                    <div class="response-info" aria-label="response info">
                        <div class="prettyprint response-body-panel" id="responseBody"></div>
                    </div>

                    <div class="writer-panel" id="writerPanel" hidden>
                        <div class="well">
                            <div class="writer-methods hidden" id="writerMethods"></div>
                            <ul class="nav nav-tabs form-switcher" id="writerTabs">
                                <li><a href="#" data-tab="raw">Raw data</a></li>
                                <li class="active"><a href="#" data-tab="html">HTML form</a></li>
                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane" id="rawTab" hidden>
                                    <textarea id="rawJsonInput" spellcheck="false"></textarea>
                                    <p class="help-block" id="rawHelp">Send a JSON request body to this endpoint.</p>
                                </div>

                                <div class="tab-pane" id="htmlTab">
                                    <form class="form-horizontal" id="writerForm" novalidate>
                                        <div id="writerFields"></div>
                                    </form>
                                </div>
                            </div>

                            <div class="form-actions">
                                <button class="btn btn-primary" id="writerSubmit" type="button">POST</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop" id="filtersBackdrop"></div>
    <div class="modal" id="filtersModal" role="dialog" aria-modal="true" aria-labelledby="filtersTitle">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="modal-close" id="filtersClose" type="button" aria-label="Close">&times;</button>
                    <h4 class="modal-title" id="filtersTitle">Filters</h4>
                </div>
                <div class="modal-body">
                    <div id="fieldFiltersSection">
                        <h2>Field filters</h2>
                        <form class="filter-form" id="filtersForm"></form>
                    </div>
                    <hr id="searchDivider" class="hidden">
                    <div id="searchSection" class="hidden">
                        <h2>Search</h2>
                        <form class="search-form" id="searchForm">
                            <input class="search-input" id="searchInput" type="text" placeholder="Search this endpoint">
                            <button class="btn btn-default search-submit" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script id="niteBrowsableApiData" type="application/json">__PAYLOAD__</script>
    <script>
        (function () {
            const payloadNode = document.getElementById('niteBrowsableApiData');
            const payload = safeJsonParse(payloadNode ? payloadNode.textContent : '{}', {});
            const endpoint = payload.endpoint || {};
            const endpointResource = payload.resource && typeof payload.resource === 'object' ? payload.resource : null;
            const routes = Array.isArray(payload.routes) ? payload.routes : [];
            const initialRequest = payload.request || {};
            const initialResponse = payload.response || {};
            const routeMap = Object.fromEntries(routes.map(function (route) {
                return [String(route.method || '').toUpperCase(), route];
            }));
            const queryState = Object.assign({}, initialRequest.query || {});
            const storageKey = 'nite_browsable_api_token';
            const sessionStorageKey = 'nite_explorer_session';
            const relationChoiceCache = Object.create(null);
            const routeCatalogMethodState = Object.create(null);

            const breadcrumbTrailNode = document.getElementById('breadcrumbTrail');
            const pageTitleNode = document.getElementById('pageTitle');
            const pageDescriptionNode = document.getElementById('pageDescription');
            const requestPreviewNode = document.getElementById('requestPreview');
            const responseBodyNode = document.getElementById('responseBody');
            const methodActionsNode = document.getElementById('methodActions');
            const formatDropdownWrap = document.getElementById('formatDropdownWrap');
            const formatToggle = document.getElementById('formatToggle');
            const formatJsonLink = document.getElementById('formatJsonLink');
            const formatApiLink = document.getElementById('formatApiLink');
            const filtersWrapNode = document.getElementById('filtersWrap');
            const filtersButton = document.getElementById('filtersButton');
            const writerPanelNode = document.getElementById('writerPanel');
            const writerMethodsNode = document.getElementById('writerMethods');
            const writerTabsNode = document.getElementById('writerTabs');
            const rawTabNode = document.getElementById('rawTab');
            const htmlTabNode = document.getElementById('htmlTab');
            const rawJsonInput = document.getElementById('rawJsonInput');
            const rawHelpNode = document.getElementById('rawHelp');
            const writerFieldsNode = document.getElementById('writerFields');
            const writerSubmitNode = document.getElementById('writerSubmit');
            const filtersBackdrop = document.getElementById('filtersBackdrop');
            const filtersModal = document.getElementById('filtersModal');
            const filtersClose = document.getElementById('filtersClose');
            const filtersFormNode = document.getElementById('filtersForm');
            const searchSectionNode = document.getElementById('searchSection');
            const searchDividerNode = document.getElementById('searchDivider');
            const searchFormNode = document.getElementById('searchForm');
            const searchInputNode = document.getElementById('searchInput');
            const sessionDropdownNode = document.getElementById('sessionDropdown');
            const sessionToggleNode = document.getElementById('sessionToggle');
            const sessionLabelNode = document.getElementById('sessionLabel');
            const tokenInputNode = document.getElementById('tokenInput');
            const saveTokenButton = document.getElementById('saveTokenButton');
            const clearTokenButton = document.getElementById('clearTokenButton');

            if (!Object.prototype.hasOwnProperty.call(routeMap, 'HEAD') && routeMap.GET) {
                routeMap.HEAD = Object.assign({}, routeMap.GET, {
                    method: 'HEAD',
                    summary: 'Read headers for this endpoint without returning a response body.',
                });
            }

            if (!Object.prototype.hasOwnProperty.call(routeMap, 'PATCH') && routeMap.PUT) {
                routeMap.PATCH = Object.assign({}, routeMap.PUT, {
                    method: 'PATCH',
                    summary: 'Partially update this endpoint.',
                });
            }

            const allowedMethods = Array.isArray(endpoint.allowed_methods) && endpoint.allowed_methods.length > 0
                ? endpoint.allowed_methods.map(function (method) { return String(method || '').toUpperCase(); })
                : Object.keys(routeMap);
            const readRoute = routeMap.GET || routeMap[String(endpoint.current_method || '').toUpperCase()] || routes[0] || null;
            let activeWriteMethod = visibleWriteMethods()[0] || '';
            let activeTab = 'html';
            let currentResponse = initialResponse;
            let lastRequest = {
                method: String(initialResponse.request_method || endpoint.current_method || (readRoute ? readRoute.method : 'GET') || 'GET').toUpperCase(),
                path: String(endpoint.path || (readRoute ? readRoute.path : '/') || '/'),
                query: Object.assign({}, queryState),
            };
            let lastWriteDraft = initialRequest.body && typeof initialRequest.body === 'object' && !Array.isArray(initialRequest.body)
                ? Object.assign({}, initialRequest.body)
                : null;
            let lastWriteDraftPath = lastWriteDraft ? String(endpoint.route_path || endpoint.path || '/') : '';

            tokenInputNode.value = storageGet(storageKey) || '';

            function syncTokenCookie(value) {
                const token = normalizedTokenValue(value);
                try {
                    if (token === '') {
                        document.cookie = 'nite_browsable_api_token=; Path=/; Max-Age=0; SameSite=Lax';
                        return;
                    }

                    document.cookie = 'nite_browsable_api_token=' + encodeURIComponent(token) + '; Path=/; SameSite=Lax';
                } catch {}
            }

            syncTokenCookie(tokenInputNode.value);

            function escapeHtml(value) {
                return String(value === null || value === undefined ? '' : value)
                    .replaceAll('&', '&amp;')
                    .replaceAll('<', '&lt;')
                    .replaceAll('>', '&gt;')
                    .replaceAll('"', '&quot;')
                    .replaceAll("'", '&#39;');
            }

            function titleCase(value) {
                return String(value || '')
                    .split(' ')
                    .filter(Boolean)
                    .map(function (part) {
                        return part.charAt(0).toUpperCase() + part.slice(1);
                    })
                    .join(' ');
            }

            function humanizeToken(value) {
                return titleCase(String(value || '').replace(/[._-]+/g, ' ').replace(/\s+/g, ' ').trim());
            }

            function normalizeLookupKey(value) {
                return String(value || '').replaceAll('-', '_').toLowerCase();
            }

            function objectValue(object, key) {
                if (!object || typeof object !== 'object') {
                    return undefined;
                }
                if (Object.prototype.hasOwnProperty.call(object, key)) {
                    return object[key];
                }

                const target = normalizeLookupKey(key);
                const candidate = Object.keys(object).find(function (entry) {
                    return normalizeLookupKey(entry) === target;
                });

                return candidate ? object[candidate] : undefined;
            }

            function lookupValue(object, keys) {
                const candidates = Array.isArray(keys) ? keys : [keys];
                for (let index = 0; index < candidates.length; index += 1) {
                    const value = objectValue(object, candidates[index]);
                    if (value !== undefined && value !== null && String(value) !== '') {
                        return value;
                    }
                }

                return '';
            }

            function pathTitle(path) {
                const segments = String(path || '/')
                    .split('/')
                    .filter(Boolean)
                    .filter(function (segment) {
                        return !['api', 'v1', 'admin'].includes(segment) && !segment.startsWith('{') && !/^\d+$/.test(segment);
                    });
                if (segments.length === 0) {
                    return 'Api Root';
                }

                return humanizeToken(segments.join(' '));
            }

            function titleFromSummary(summary) {
                const clean = String(summary || '').trim().replace(/\.$/, '');
                if (clean === '') {
                    return '';
                }

                const patterns = [
                    /^List (.+)$/i,
                    /^Get one (.+?)(?: by .+)?$/i,
                    /^Get (.+?)(?: by .+)?$/i,
                    /^Create (.+)$/i,
                    /^Update (.+)$/i,
                    /^Delete (.+)$/i,
                    /^Restore (.+)$/i,
                    /^Authenticated (.+)$/i,
                    /^Administrative (.+)$/i,
                    /^Published (.+)$/i,
                    /^Role catalog$/i,
                    /^Permission catalog$/i,
                    /^Health check$/i
                ];

                for (let index = 0; index < patterns.length; index += 1) {
                    const match = clean.match(patterns[index]);
                    if (match) {
                        return titleCase(match[1] || match[0]);
                    }
                }

                return '';
            }

            function routeTitle(route) {
                if (!route) {
                    return pathTitle(endpoint.path || '/');
                }

                if (route.resource_key) {
                    if ((route.request && route.request.path_params || []).length > 0) {
                        return humanizeToken(String(route.resource_key).replace(/_+/g, ' ')) + ' Instance';
                    }
                    return humanizeToken(String(route.resource_key).replace(/_+/g, ' ')) + ' List';
                }

                if (route.name) {
                    return humanizeToken(route.name);
                }

                const summaryTitle = titleFromSummary(route.summary || '');
                if (summaryTitle !== '') {
                    return summaryTitle;
                }

                return pathTitle(route.path || endpoint.path || '/');
            }

            function routeDescription(route) {
                if (route && route.summary) {
                    return String(route.summary);
                }
                return 'Browsable REST API interface for this endpoint.';
            }

            function currentToken() {
                return tokenInputNode.value.trim();
            }

            function normalizedTokenValue(value) {
                return String(value || '').trim().replace(/^Bearer\s+/i, '');
            }

            function normalizeRole(value) {
                return normalizeLookupKey(value);
            }

            function normalizePermissions(value) {
                if (!Array.isArray(value)) {
                    return [];
                }

                return value
                    .map(function (permission) {
                        return String(permission || '').trim();
                    })
                    .filter(Boolean)
                    .filter(function (permission, index, list) {
                        return list.indexOf(permission) === index;
                    });
            }

            function decodeBase64Url(value) {
                const normalized = String(value || '').replaceAll('-', '+').replaceAll('_', '/');
                const padded = normalized + '==='.slice((normalized.length + 3) % 4);
                const decoded = atob(padded);
                const bytes = Uint8Array.from(decoded, function (char) {
                    return char.charCodeAt(0);
                });
                return new TextDecoder().decode(bytes);
            }

            function jwtPayload(token) {
                const normalized = normalizedTokenValue(token);
                if (normalized === '') {
                    return null;
                }

                const parts = normalized.split('.');
                if (parts.length < 2) {
                    return null;
                }

                try {
                    const payloadValue = JSON.parse(decodeBase64Url(parts[1]));
                    return payloadValue && typeof payloadValue === 'object' ? payloadValue : null;
                } catch {
                    return null;
                }
            }

            function readStoredSession() {
                try {
                    const stored = JSON.parse(storageGet(sessionStorageKey) || 'null');
                    return stored && typeof stored === 'object' ? stored : null;
                } catch {
                    return null;
                }
            }

            function writeStoredSession(session) {
                const token = normalizedTokenValue(session && session.token ? session.token : currentToken());
                if (token === '') {
                    storageRemove(sessionStorageKey);
                    return;
                }

                storageSet(sessionStorageKey, JSON.stringify({
                    token: token,
                    authenticated: !!(session && session.authenticated),
                    sub: String(session && session.sub ? session.sub : ''),
                    email: String(session && session.email ? session.email : ''),
                    name: String(session && session.name ? session.name : ''),
                    role: String(session && session.role ? session.role : ''),
                    permissions: normalizePermissions(session && session.permissions),
                    permissions_known: !!(session && session.permissions_known),
                }));
            }

            function sessionFromToken(token) {
                const payloadValue = jwtPayload(token);
                if (!payloadValue) {
                    return {
                        token: normalizedTokenValue(token),
                        authenticated: false,
                        sub: '',
                        email: '',
                        name: '',
                        role: '',
                        permissions: [],
                        permissions_known: false,
                    };
                }

                return {
                    token: normalizedTokenValue(token),
                    authenticated: true,
                    sub: String(payloadValue.sub || ''),
                    email: String(payloadValue.email || ''),
                    name: String(payloadValue.name || ''),
                    role: String(payloadValue.role || ''),
                    permissions: [],
                    permissions_known: false,
                };
            }

            function currentSession() {
                const derived = sessionFromToken(currentToken());
                const stored = readStoredSession();
                if (!stored || String(stored.token || '') !== derived.token) {
                    return derived;
                }
                if (!sessionProfileMatchesToken({
                    sub: String(stored.sub || ''),
                    email: String(stored.email || ''),
                }, derived.token)) {
                    return derived;
                }

                return {
                    token: derived.token,
                    authenticated: !!(stored.authenticated || derived.authenticated),
                    sub: String(stored.sub || derived.sub || ''),
                    email: String(stored.email || derived.email || ''),
                    name: String(stored.name || derived.name || ''),
                    role: String(stored.role || derived.role || ''),
                    permissions: normalizePermissions(stored.permissions),
                    permissions_known: !!stored.permissions_known,
                };
            }

            function sessionProfileFromPayload(payloadValue) {
                if (!payloadValue || typeof payloadValue !== 'object') {
                    return null;
                }

                const candidates = [
                    payloadValue.user,
                    payloadValue.data && payloadValue.data.user ? payloadValue.data.user : null,
                    payloadValue.data,
                ];
                const profile = candidates.find(function (candidate) {
                    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) {
                        return false;
                    }

                    return Boolean(
                        candidate.id
                        || candidate.email
                        || candidate.name
                        || candidate.role
                        || Array.isArray(candidate.permissions)
                    );
                });

                if (!profile || typeof profile !== 'object' || Array.isArray(profile)) {
                    return null;
                }

                return {
                    sub: String(profile.id || profile.sub || ''),
                    email: String(profile.email || ''),
                    name: String(profile.name || ''),
                    role: String(profile.role || ''),
                    permissions: normalizePermissions(profile.permissions),
                    permissions_known: Array.isArray(profile.permissions),
                };
            }

            function updateSessionLabel() {
                const session = currentSession();
                if (!session.authenticated) {
                    sessionLabelNode.textContent = 'guest';
                    return;
                }

                sessionLabelNode.textContent = session.role
                    ? String(session.role)
                    : 'authorized';
            }

            function persistToken() {
                const token = currentToken();
                if (token === '') {
                    storageRemove(storageKey);
                    storageRemove(sessionStorageKey);
                } else {
                    storageSet(storageKey, token);
                    const derived = sessionFromToken(token);
                    const stored = readStoredSession();
                    if (stored && String(stored.token || '') === derived.token) {
                        writeStoredSession(Object.assign({}, derived, stored, {
                            token: derived.token,
                            authenticated: !!(stored.authenticated || derived.authenticated),
                            permissions: normalizePermissions(stored.permissions),
                            permissions_known: !!stored.permissions_known,
                        }));
                    } else {
                        writeStoredSession(derived);
                    }
                }
                syncTokenCookie(token);
                updateSessionLabel();
            }

            function persistSessionFromPayload(payloadValue, preferredToken, method, path) {
                const token = normalizedTokenValue(preferredToken || currentToken());
                if (token === '') {
                    return;
                }

                const profile = sessionProfileFromPayload(payloadValue);
                if (profile && !isAuthenticationRoute(method, path) && !sessionProfileMatchesToken(profile, token)) {
                    return;
                }
                const session = profile
                    ? Object.assign({}, currentSession(), profile, { token: token, authenticated: true })
                    : Object.assign({}, currentSession(), { token: token, authenticated: currentSession().authenticated });
                writeStoredSession(session);
                updateSessionLabel();
            }

            function routeVisibleToSession(route, session = currentSession()) {
                if (!route || typeof route !== 'object') {
                    return false;
                }

                const method = String(route.method || 'GET').toUpperCase();
                const authRequired = !!route.auth_required;
                const permissions = normalizePermissions(route.permissions);

                if (!session.authenticated) {
                    if (authRequired) {
                        return false;
                    }
                    if (['GET', 'HEAD'].includes(method)) {
                        return true;
                    }
                    return method === 'POST' && permissions.length === 0;
                }

                if (!authRequired) {
                    return true;
                }
                if (permissions.length === 0) {
                    return true;
                }
                if (session.permissions_known) {
                    return permissions.some(function (permission) {
                        return session.permissions.includes(permission);
                    });
                }

                const role = normalizeRole(session.role);
                if (role === '') {
                    return false;
                }

                const fallbackRoles = Array.isArray(route.permission_default_roles)
                    ? route.permission_default_roles.map(normalizeRole)
                    : [];
                return fallbackRoles.includes(role);
            }

            function allDocumentedRoutesVisible(session = currentSession()) {
                return routes.every(function (route) {
                    return routeVisibleToSession(route, session);
                });
            }

            function visibleAllowedMethods(session = currentSession()) {
                return ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'].filter(function (method) {
                    if (!allowedMethods.includes(method)) {
                        return false;
                    }
                    if (method === 'OPTIONS') {
                        return !!readRoute && routeVisibleToSession(readRoute, session) && allDocumentedRoutesVisible(session);
                    }

                    const route = routeMap[method];
                    return !!route && routeVisibleToSession(route, session);
                });
            }

            function visibleWriteMethods(session = currentSession()) {
                const methods = visibleAllowedMethods(session);
                return ['POST', 'PUT', 'PATCH'].filter(function (method) {
                    return methods.includes(method) && !!routeMap[method];
                });
            }

            function refreshSessionVisibility() {
                const availableWriteMethods = visibleWriteMethods();
                if (!availableWriteMethods.includes(activeWriteMethod)) {
                    activeWriteMethod = availableWriteMethods[0] || '';
                }

                updateSessionLabel();
                renderPrimaryControls();
                renderFilters();
                renderWriterFields();
                renderResponse();
            }

            function tokenFromPayload(payloadValue) {
                if (!payloadValue || typeof payloadValue !== 'object') {
                    return '';
                }

                if (typeof payloadValue.token === 'string' && payloadValue.token !== '') {
                    return payloadValue.token;
                }
                if (typeof payloadValue.access_token === 'string' && payloadValue.access_token !== '') {
                    return payloadValue.access_token;
                }
                if (payloadValue.data && typeof payloadValue.data === 'object') {
                    if (typeof payloadValue.data.token === 'string' && payloadValue.data.token !== '') {
                        return payloadValue.data.token;
                    }
                    if (typeof payloadValue.data.access_token === 'string' && payloadValue.data.access_token !== '') {
                        return payloadValue.data.access_token;
                    }
                }

                return '';
            }

            function normalizedRoutePath(path) {
                const value = String(path || '').trim();
                if (value === '') {
                    return '';
                }

                try {
                    return new URL(value, window.location.origin).pathname;
                } catch {
                    return value.split('?')[0];
                }
            }

            function isAuthenticationRoute(method, path) {
                return String(method || 'GET').toUpperCase() === 'POST'
                    && normalizedRoutePath(path).startsWith('/api/v1/auth/');
            }

            function sessionProfileMatchesToken(profile, token) {
                if (!profile || typeof profile !== 'object') {
                    return false;
                }

                const derived = sessionFromToken(token);
                if (!derived.authenticated) {
                    return false;
                }

                const profileSub = String(profile.sub || '').trim();
                const derivedSub = String(derived.sub || '').trim();
                if (profileSub !== '' && derivedSub !== '') {
                    return profileSub === derivedSub;
                }

                const profileEmail = String(profile.email || '').trim().toLowerCase();
                const derivedEmail = String(derived.email || '').trim().toLowerCase();
                if (profileEmail !== '' && derivedEmail !== '') {
                    return profileEmail === derivedEmail;
                }

                return false;
            }

            function inferPathValues(templatePath, concretePath) {
                const templateParts = String(templatePath || '').split('/').filter(Boolean);
                const concreteParts = String(concretePath || '').split('/').filter(Boolean);
                const values = {};
                if (templateParts.length !== concreteParts.length) {
                    return values;
                }

                for (let index = 0; index < templateParts.length; index += 1) {
                    const templatePart = templateParts[index];
                    if (templatePart.startsWith('{') && templatePart.endsWith('}')) {
                        values[templatePart.slice(1, -1)] = decodeURIComponent(concreteParts[index] || '');
                    }
                }

                return values;
            }

            function payloadData(payloadValue) {
                if (!payloadValue || typeof payloadValue !== 'object') {
                    return null;
                }
                if (Object.prototype.hasOwnProperty.call(payloadValue, 'data')) {
                    return payloadValue.data;
                }
                return payloadValue;
            }

            function currentRecordSeed() {
                const data = payloadData(currentResponse.payload);
                if (data && typeof data === 'object' && !Array.isArray(data)) {
                    return data;
                }
                return {};
            }

            function routePathValues(route) {
                const inferred = inferPathValues(route && route.path ? route.path : endpoint.route_path || endpoint.path || '/', endpoint.path || '/');
                const seed = currentRecordSeed();
                const fields = route && route.request ? (route.request.path_params || []) : [];
                fields.forEach(function (field) {
                    if (!Object.prototype.hasOwnProperty.call(inferred, field.name) && Object.prototype.hasOwnProperty.call(seed, field.name)) {
                        inferred[field.name] = seed[field.name];
                    }
                    if (!Object.prototype.hasOwnProperty.call(inferred, field.name) && Object.prototype.hasOwnProperty.call(queryState, field.name)) {
                        inferred[field.name] = queryState[field.name];
                    }
                });
                return inferred;
            }

            function resolveRoutePath(route) {
                let path = String(route && route.path ? route.path : endpoint.route_path || endpoint.path || '/');
                const values = routePathValues(route);
                path = path.replace(/\{([^}]+)\}/g, function (_, key) {
                    const value = values[key];
                    if (value === undefined || value === null || value === '') {
                        return '{' + key + '}';
                    }
                    return encodeURIComponent(String(value));
                });
                return path;
            }

            function cleanQuery(values, includeFormat) {
                const output = {};
                Object.entries(values || {}).forEach(function (entry) {
                    const key = entry[0];
                    const value = entry[1];
                    if (!includeFormat && key === 'format') {
                        return;
                    }
                    if (value === '' || value === null || value === undefined) {
                        return;
                    }
                    output[key] = value;
                });
                return output;
            }

            function buildRelativeUrl(path, queryValues) {
                const params = new URLSearchParams();
                Object.entries(queryValues || {}).forEach(function (entry) {
                    const key = entry[0];
                    const value = entry[1];
                    if (Array.isArray(value)) {
                        value.forEach(function (item) {
                            if (item !== '' && item !== null && item !== undefined) {
                                params.append(key, String(item));
                            }
                        });
                        return;
                    }
                    params.set(key, String(value));
                });

                const query = params.toString();
                return String(path || '/') + (query === '' ? '' : '?' + query);
            }

            function buildAbsoluteUrl(path, queryValues) {
                return new URL(buildRelativeUrl(path, queryValues), window.location.origin).toString();
            }

            function navigationQuery(format) {
                const nextQuery = cleanQuery(queryState, false);
                if (format === 'json') {
                    nextQuery.format = 'json';
                } else if (format === 'api') {
                    nextQuery.format = 'api';
                }
                return nextQuery;
            }

            function updateNavigationLinks() {
                const path = resolveRoutePath(readRoute || { path: endpoint.path || '/' });
                formatJsonLink.href = buildRelativeUrl(path, navigationQuery('json'));
                formatApiLink.href = buildRelativeUrl(path, navigationQuery('api'));
            }

            function syntaxHighlightJson(value) {
                let jsonText = value;
                if (typeof jsonText !== 'string') {
                    try {
                        jsonText = JSON.stringify(jsonText, null, 4);
                    } catch {
                        jsonText = String(jsonText);
                    }
                }

                if (jsonText === undefined || jsonText === null) {
                    return '';
                }

                const tokenPattern = /("(?:\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*"(?::)?|\btrue\b|\bfalse\b|\bnull\b|-?\d+(?:\.\d+)?(?:[eE][+\-]?\d+)?)/g;
                let html = '';
                let lastIndex = 0;
                let match;

                while ((match = tokenPattern.exec(jsonText)) !== null) {
                    const token = match[0];
                    html += escapeHtml(jsonText.slice(lastIndex, match.index));
                    let cls = 'num';
                    let tokenHtml = escapeHtml(token);

                    if (token.charAt(0) === '"') {
                        if (token.endsWith(':')) {
                            cls = 'key';
                        } else {
                            cls = 'str';
                            try {
                                const decoded = JSON.parse(token);
                                if (/^https?:\/\//i.test(decoded)) {
                                    tokenHtml = '&quot;<a href="' + escapeHtml(decoded) + '" rel="nofollow" target="_blank">' + escapeHtml(decoded) + '</a>&quot;';
                                } else if (/^(\/[^"\s]*)$/.test(decoded)) {
                                    tokenHtml = '&quot;<a href="' + escapeHtml(decoded) + '" rel="nofollow">' + escapeHtml(decoded) + '</a>&quot;';
                                }
                            } catch {}
                        }
                    } else if (token === 'true' || token === 'false') {
                        cls = 'bool';
                    } else if (token === 'null') {
                        cls = 'null';
                    }

                    html += '<span class="' + cls + '">' + tokenHtml + '</span>';
                    lastIndex = tokenPattern.lastIndex;
                }

                html += escapeHtml(String(jsonText).slice(lastIndex));
                return html;
            }

            function routeCatalogItems(response) {
                const payloadValue = response && response.payload && typeof response.payload === 'object'
                    ? response.payload
                    : null;
                const data = payloadValue && Array.isArray(payloadValue.data) ? payloadValue.data : null;
                if (!Array.isArray(data) || data.length === 0) {
                    return [];
                }

                const isRouteCatalog = data.every(function (item) {
                    return item
                        && typeof item === 'object'
                        && typeof item.method === 'string'
                        && typeof item.path === 'string'
                        && item.request
                        && item.response;
                });

                return isRouteCatalog
                    ? data.filter(function (route) {
                        return routeVisibleToSession(route);
                    })
                    : [];
            }

            function methodSortOrder(method) {
                const normalized = String(method || '').toUpperCase();
                return {
                    GET: 10,
                    HEAD: 20,
                    POST: 30,
                    PUT: 40,
                    PATCH: 50,
                    DELETE: 60,
                    OPTIONS: 70,
                }[normalized] || 999;
            }

            function groupedRouteCatalogItems(response) {
                const grouped = new Map();
                routeCatalogItems(response).forEach(function (route) {
                    const path = String(route.path || '');
                    if (!grouped.has(path)) {
                        grouped.set(path, []);
                    }
                    grouped.get(path).push(route);
                });

                return Array.from(grouped.entries()).map(function (entry) {
                    return {
                        path: entry[0],
                        routes: entry[1].slice().sort(function (left, right) {
                            return methodSortOrder(left.method) - methodSortOrder(right.method);
                        }),
                    };
                }).sort(function (left, right) {
                    return left.path.localeCompare(right.path);
                });
            }

            function routeMethodClass(method) {
                const normalized = String(method || '').toUpperCase();
                if (normalized === 'GET') {
                    return 'route-method route-method-get';
                }
                if (normalized === 'HEAD') {
                    return 'route-method route-method-head';
                }
                if (normalized === 'POST') {
                    return 'route-method route-method-post';
                }
                if (normalized === 'PUT') {
                    return 'route-method route-method-put';
                }
                if (normalized === 'PATCH') {
                    return 'route-method route-method-patch';
                }
                if (normalized === 'DELETE') {
                    return 'route-method route-method-delete';
                }
                return 'route-method route-method-options';
            }

            function routeFieldType(field) {
                const dataType = String(field && field.data_type || 'string');
                const format = String(field && field.format || '');
                return format !== '' ? dataType + ':' + format : dataType;
            }

            function routeFieldRequired(field) {
                return !!(field && (field.required_on_create || field.required_on_update));
            }

            function routeFieldHtml(field) {
                const options = Array.isArray(field.options) && field.options.length > 0
                    ? ' Options: ' + field.options.join(', ') + '.'
                    : '';
                const description = field.description ? ' ' + String(field.description) : '';
                const required = routeFieldRequired(field) ? ' Required.' : '';
                const mediaUpload = field && field.media_upload ? ' Supports automatic media upload.' : '';

                return '<div class="route-field">' +
                    '<code>' + escapeHtml(field.name || '') + '</code>' +
                    '<span class="route-field-meta">' +
                        escapeHtml(routeFieldType(field) + required + description + options + mediaUpload) +
                    '</span>' +
                '</div>';
            }

            function routeFieldSection(title, fields) {
                const list = Array.isArray(fields) ? fields : [];
                return '<div class="route-doc-section">' +
                    '<h5>' + escapeHtml(title) + '</h5>' +
                    (list.length > 0
                        ? '<div class="route-field-list">' + list.map(routeFieldHtml).join('') + '</div>'
                        : '<div class="route-empty">None documented.</div>') +
                '</div>';
            }

            function routeDocResolvedPath(route) {
                const rawPath = String(route && route.path ? route.path : '');
                if (rawPath === '') {
                    return '/api/v1';
                }
                if (!rawPath.includes('{')) {
                    return rawPath;
                }

                try {
                    const resolved = resolveRoutePath(route);
                    return resolved.includes('{') ? null : resolved;
                } catch {
                    return null;
                }
            }

            function routeDocDetailsHtml(route, resolvedPath) {
                const request = route && route.request ? route.request : {};
                const response = route && route.response ? route.response : {};
                const permissions = Array.isArray(route.permissions) && route.permissions.length > 0
                    ? route.permissions.join(', ')
                    : 'none';
                const contentType = request.content_type || 'none';
                const returnType = response.return_type || 'json';
                const successStatus = response.success_status || 200;
                const summary = route.summary ? '<span class="route-doc-caption">' + escapeHtml(route.summary) + '</span>' : '';
                const linkHtml = resolvedPath === null
                    ? '<div class="route-doc-note">Open this route from a concrete record link or supply a real path value such as an id, slug, or key.</div>'
                    : '<div class="route-doc-links">' +
                        '<a class="route-doc-link" href="' + escapeHtml(resolvedPath) + '" rel="nofollow">Open endpoint</a>' +
                        '<a class="route-doc-link" href="' + escapeHtml(buildRelativeUrl(resolvedPath, { format: 'json' })) + '" rel="nofollow">Open JSON</a>' +
                    '</div>';

                return summary +
                    linkHtml +
                    '<div class="route-doc-grid">' +
                        '<div class="route-doc-card"><strong>Auth</strong><span>' + escapeHtml(route.auth_required ? 'Required' : 'Public') + '</span></div>' +
                        '<div class="route-doc-card"><strong>Permissions</strong><code>' + escapeHtml(permissions) + '</code></div>' +
                        '<div class="route-doc-card"><strong>Request</strong><code>' + escapeHtml(String(contentType)) + '</code></div>' +
                        '<div class="route-doc-card"><strong>Response</strong><code>' + escapeHtml(String(returnType) + ' (' + String(successStatus) + ')') + '</code></div>' +
                    '</div>' +
                    routeFieldSection('Path parameters', request.path_params) +
                    routeFieldSection('Query parameters', request.query) +
                    routeFieldSection('Body fields', request.body);
            }

            function routeGroupHtml(group) {
                const selectedMethod = routeCatalogMethodState[group.path]
                    && group.routes.some(function (route) { return String(route.method || '').toUpperCase() === routeCatalogMethodState[group.path]; })
                    ? routeCatalogMethodState[group.path]
                    : String((group.routes.find(function (route) { return String(route.method || '').toUpperCase() === 'GET'; }) || group.routes[0] || {}).method || 'GET').toUpperCase();
                routeCatalogMethodState[group.path] = selectedMethod;

                const selectedRoute = group.routes.find(function (route) {
                    return String(route.method || '').toUpperCase() === selectedMethod;
                }) || group.routes[0];
                const summary = selectedRoute && selectedRoute.summary
                    ? '<span class="route-doc-caption">' + escapeHtml(String(selectedRoute.summary)) + '</span>'
                    : '';
                const resolvedPath = routeDocResolvedPath(selectedRoute);

                return '<details class="route-doc">' +
                    '<summary class="route-doc-summary">' +
                        '<div class="route-doc-summary-main">' +
                            '<span class="route-doc-path">' + escapeHtml(group.path || '') + summary + '</span>' +
                            '<div class="route-doc-summary-methods">' + group.routes.map(function (route) {
                                return '<span class="' + routeMethodClass(route.method) + '">' + escapeHtml(String(route.method || '').toUpperCase()) + '</span>';
                            }).join('') + '</div>' +
                        '</div>' +
                    '</summary>' +
                    '<div class="route-doc-body">' +
                        '<div class="route-doc-method-tabs">' + group.routes.map(function (route) {
                            const method = String(route.method || '').toUpperCase();
                            const activeClass = method === selectedMethod ? ' active' : '';
                            return '<button class="route-doc-method-tab' + activeClass + '" type="button" data-route-group-method="' + escapeHtml(group.path) + '" data-route-group-selected="' + escapeHtml(method) + '">' + escapeHtml(method) + '</button>';
                        }).join('') + '</div>' +
                        routeDocDetailsHtml(selectedRoute, resolvedPath) +
                    '</div>' +
                '</details>';
            }

            function routeCatalogHtml(response) {
                const items = groupedRouteCatalogItems(response);
                if (items.length === 0) {
                    return '';
                }

                const metaLines = [
                    '<b>Route index</b>',
                    '<span class="route-catalog-summary">Click an endpoint row to expand additional details.</span>',
                ];

                return '<span class="meta nocode">' + metaLines.join('<br>') + '</span>' +
                    '<div class="route-catalog">' + items.map(routeGroupHtml).join('') + '</div>';
            }

            function resourceDetailRoute(resource, preferredPath) {
                const resourceRoutes = Array.isArray(resource && resource.routes) ? resource.routes : [];
                const preferAdmin = String(preferredPath || endpoint.path || '').includes('/admin/');
                const candidates = resourceRoutes.filter(function (route) {
                    if (!route || String(route.method || '').toUpperCase() !== 'GET') {
                        return false;
                    }

                    const path = String(route.path || '');
                    const pathParams = Array.isArray(route.request && route.request.path_params) ? route.request.path_params : [];
                    const returnType = String(route.response && route.response.return_type || '');
                    if (pathParams.length === 0 || returnType.endsWith('[]')) {
                        return false;
                    }

                    return !path.includes('/history')
                        && !path.includes('/download')
                        && !path.includes('/versions')
                        && !path.includes('/entries');
                });

                if (candidates.length === 0) {
                    return null;
                }

                candidates.sort(function (left, right) {
                    const leftPath = String(left.path || '');
                    const rightPath = String(right.path || '');
                    const leftScore = [
                        leftPath.includes('/admin/') === preferAdmin ? 0 : 1,
                        Array.isArray(left.request && left.request.path_params) ? left.request.path_params.length : 0,
                        leftPath.length,
                    ];
                    const rightScore = [
                        rightPath.includes('/admin/') === preferAdmin ? 0 : 1,
                        Array.isArray(right.request && right.request.path_params) ? right.request.path_params.length : 0,
                        rightPath.length,
                    ];

                    for (let index = 0; index < leftScore.length; index += 1) {
                        if (leftScore[index] < rightScore[index]) {
                            return -1;
                        }
                        if (leftScore[index] > rightScore[index]) {
                            return 1;
                        }
                    }

                    return 0;
                });

                return candidates[0];
            }

            function resourceRecordLink(resource, record, preferredPath) {
                if (!resource || !record || typeof record !== 'object' || Array.isArray(record)) {
                    return null;
                }

                const route = resourceDetailRoute(resource, preferredPath);
                if (!route) {
                    return null;
                }

                const pathParams = Array.isArray(route.request && route.request.path_params) ? route.request.path_params : [];
                const values = {};
                for (let index = 0; index < pathParams.length; index += 1) {
                    const field = pathParams[index];
                    const fieldName = String(field && field.name ? field.name : '').trim();
                    if (fieldName === '') {
                        return null;
                    }

                    const candidates = [fieldName];
                    if (fieldName === 'id') {
                        candidates.push('uuid');
                    } else if (fieldName === 'slug') {
                        candidates.push('id');
                    } else if (fieldName === 'key') {
                        candidates.push('id');
                    } else if (fieldName === 'module') {
                        candidates.push('module_key');
                    } else if (fieldName === 'entity') {
                        candidates.push('entity_type');
                    }

                    const value = lookupValue(record, candidates);
                    if (value === '') {
                        return null;
                    }
                    values[fieldName] = String(value);
                }

                let path = String(route.path || '');
                Object.entries(values).forEach(function (entry) {
                    path = path.replace('{' + entry[0] + '}', encodeURIComponent(String(entry[1])));
                });

                if (path.includes('{')) {
                    return null;
                }

                return {
                    path: path,
                    keys: Object.keys(values),
                };
            }

            function primitiveJsonHtml(value, context) {
                if (value === null) {
                    return '<span class="null">null</span>';
                }
                if (typeof value === 'boolean') {
                    return '<span class="bool">' + escapeHtml(String(value)) + '</span>';
                }
                if (typeof value === 'number') {
                    const numberContent = '<span class="num">' + escapeHtml(String(value)) + '</span>';
                    const numberLink = context && context.recordLink && context.currentKey && context.recordLink.keys.includes(context.currentKey)
                        ? context.recordLink.path
                        : '';
                    return numberLink !== ''
                        ? '<a href="' + escapeHtml(numberLink) + '" rel="nofollow">' + numberContent + '</a>'
                        : numberContent;
                }
                if (typeof value === 'string') {
                    const escaped = escapeHtml(value);
                    const recordLink = context && context.recordLink && context.currentKey && (
                        context.recordLink.keys.includes(context.currentKey)
                        || ['id', 'slug', 'key'].includes(String(context.currentKey || ''))
                    )
                        ? context.recordLink.path
                        : '';
                    if (recordLink !== '') {
                        return '&quot;<a href="' + escapeHtml(recordLink) + '" rel="nofollow">' + escaped + '</a>&quot;';
                    }
                    if (/^https?:\/\//i.test(value)) {
                        return '&quot;<a href="' + escapeHtml(value) + '" rel="nofollow" target="_blank">' + escaped + '</a>&quot;';
                    }
                    if (/^(\/[^"\s]*)$/.test(value)) {
                        return '&quot;<a href="' + escapeHtml(value) + '" rel="nofollow">' + escaped + '</a>&quot;';
                    }
                    return '<span class="str">&quot;' + escaped + '&quot;</span>';
                }

                return escapeHtml(String(value));
            }

            function structuredJsonHtml(value, depth, context) {
                const indent = '    '.repeat(depth);
                if (Array.isArray(value)) {
                    if (value.length === 0) {
                        return '[]';
                    }

                    return '[\n' + value.map(function (item) {
                        return '    '.repeat(depth + 1) + structuredJsonHtml(item, depth + 1, context);
                    }).join(',\n') + '\n' + indent + ']';
                }

                if (value && typeof value === 'object') {
                    const recordLink = resourceRecordLink(context && context.resource ? context.resource : null, value, context && context.preferredPath ? context.preferredPath : endpoint.path || '/');
                    const nextContext = Object.assign({}, context || {}, {
                        recordLink: recordLink,
                    });
                    const entries = Object.entries(value);
                    if (entries.length === 0) {
                        return '{}';
                    }

                    return '{\n' + entries.map(function (entry) {
                        const key = entry[0];
                        const childValue = entry[1];
                        return '    '.repeat(depth + 1)
                            + '<span class="key">&quot;' + escapeHtml(key) + '&quot;:</span> '
                            + structuredJsonHtml(childValue, depth + 1, Object.assign({}, nextContext, { currentKey: key }));
                    }).join(',\n') + '\n' + indent + '}';
                }

                return primitiveJsonHtml(value, context || {});
            }

            function responseBodyHtml(response) {
                const headers = Object.assign({}, response.headers || {});
                const allow = headers.Allow || headers.allow || (Array.isArray(endpoint.allowed_methods) ? endpoint.allowed_methods.join(', ') : '');
                const contentType = response.content_type || headers['Content-Type'] || headers['content-type'] || 'application/json';
                const vary = headers.Vary || headers.vary || 'Accept';
                const statusText = response.status
                    ? 'HTTP ' + String(response.status) + (response.status_text ? ' ' + String(response.status_text) : '')
                    : 'HTTP Request failed';

                const metaLines = ['<b>' + escapeHtml(statusText) + '</b>'];
                if (allow) {
                    metaLines.push('<b>Allow:</b> <span class="lit">' + escapeHtml(String(allow)) + '</span>');
                }
                if (contentType) {
                    metaLines.push('<b>Content-Type:</b> <span class="lit">' + escapeHtml(String(contentType).replace(/;.*$/, '')) + '</span>');
                }
                if (vary) {
                    metaLines.push('<b>Vary:</b> <span class="lit">' + escapeHtml(String(vary)) + '</span>');
                }

                const routeCatalog = routeCatalogHtml(response);
                if (routeCatalog !== '') {
                    return '<span class="meta nocode">' + metaLines.join('\n') + '\n\n</span>' + routeCatalog;
                }

                let bodyHtml = '';
                const payloadValue = response.payload;
                if (payloadValue !== undefined && payloadValue !== null && payloadValue !== '') {
                    if (payloadValue && typeof payloadValue === 'object') {
                        bodyHtml = structuredJsonHtml(payloadValue, 0, {
                            resource: endpointResource,
                            preferredPath: endpoint.path || '/',
                            currentKey: '',
                            recordLink: null,
                        });
                    } else {
                        bodyHtml = syntaxHighlightJson(payloadValue);
                    }
                } else if (typeof response.pretty_body === 'string' && response.pretty_body !== '') {
                    try {
                        const parsedPrettyBody = JSON.parse(response.pretty_body);
                        bodyHtml = parsedPrettyBody && typeof parsedPrettyBody === 'object'
                            ? structuredJsonHtml(parsedPrettyBody, 0, {
                                resource: endpointResource,
                                preferredPath: endpoint.path || '/',
                                currentKey: '',
                                recordLink: null,
                            })
                            : syntaxHighlightJson(parsedPrettyBody);
                    } catch {
                        bodyHtml = escapeHtml(response.pretty_body);
                    }
                } else if (typeof response.body === 'string' && response.body !== '') {
                    bodyHtml = escapeHtml(response.body);
                } else if (String(response.request_method || '').toUpperCase() === 'HEAD') {
                    bodyHtml = '<span class="text-muted">No response body is returned for HEAD requests.</span>';
                } else {
                    bodyHtml = '<span class="null">null</span>';
                }

                return '<span class="meta nocode">' + metaLines.join('\n') + '\n\n</span><pre class="response-plain">' + bodyHtml + '</pre>';
            }

            function renderRequestPreview() {
                const query = cleanQuery(lastRequest.query || {}, true);
                requestPreviewNode.innerHTML = '<b>' + escapeHtml(lastRequest.method || 'GET') + '</b> ' + escapeHtml(buildRelativeUrl(lastRequest.path || '/', query));
            }

            function renderResponse() {
                responseBodyNode.innerHTML = responseBodyHtml(currentResponse || {});
            }

            function renderBreadcrumbs(route) {
                const items = ['<li><a href="/">Api Root</a></li>'];
                if (route) {
                    items.push('<li class="active"><a href="' + escapeHtml(buildRelativeUrl(resolveRoutePath(route), cleanQuery(queryState, true))) + '">' + escapeHtml(routeTitle(route)) + '</a></li>');
                } else {
                    items.push('<li class="active"><a href="' + escapeHtml(endpoint.path || '/') + '">' + escapeHtml(pathTitle(endpoint.path || '/')) + '</a></li>');
                }
                breadcrumbTrailNode.innerHTML = items.join('');
            }

            function renderHeader(route) {
                pageTitleNode.textContent = routeTitle(route);
                pageDescriptionNode.textContent = routeDescription(route);
            }

            function defaultTemplateValue(field) {
                if (Array.isArray(field.options) && field.options.length > 0) {
                    return field.data_type === 'array' ? [] : field.options[0];
                }
                if (field.data_type === 'boolean') {
                    return false;
                }
                if (field.data_type === 'integer' || field.data_type === 'number') {
                    return 0;
                }
                if (field.data_type === 'array') {
                    return [];
                }
                if (field.data_type === 'object') {
                    return {};
                }
                return '';
            }

            function isRecordObject(value) {
                return !!value && typeof value === 'object' && !Array.isArray(value);
            }

            function writerBodyFields(route) {
                return route && route.request && Array.isArray(route.request.body)
                    ? route.request.body
                    : [];
            }

            function fieldSeedKeys(field) {
                const keys = [];
                const pushKey = function (value) {
                    const key = String(value || '').trim();
                    if (key !== '' && !keys.includes(key)) {
                        keys.push(key);
                    }
                };

                pushKey(field && field.name ? field.name : '');
                if (Array.isArray(field && field.seed_keys)) {
                    field.seed_keys.forEach(pushKey);
                }

                const name = String(field && field.name ? field.name : '').trim();
                if (name.endsWith('_json')) {
                    pushKey(name.slice(0, -5));
                }

                return keys;
            }

            function relationObjectSeedKeys(field) {
                const relation = fieldRelationMeta(field);
                const keys = [];
                const pushKey = function (value) {
                    const key = String(value || '').trim();
                    if (key !== '' && !keys.includes(key)) {
                        keys.push(key);
                    }
                };

                const name = String(field && field.name ? field.name : '').trim();
                const resourceKey = String(relation && relation.resource_key ? relation.resource_key : '').trim();
                pushKey(resourceKey);
                if (resourceKey.endsWith('s')) {
                    pushKey(resourceKey.slice(0, -1));
                }

                if (name.endsWith('_id')) {
                    const base = name.slice(0, -3);
                    pushKey(base);
                    if (!base.endsWith('s')) {
                        pushKey(base + 's');
                    }
                }

                if (name.endsWith('_ids')) {
                    const base = name.slice(0, -4);
                    pushKey(base);
                    if (base.endsWith('_user')) {
                        pushKey(base.replace(/_user$/, '_users'));
                    }
                    if (!base.endsWith('s')) {
                        pushKey(base + 's');
                    }
                }

                return keys;
            }

            function relationScalarValue(relation, value) {
                if (value === null || value === undefined || value === '') {
                    return '';
                }
                if (value && typeof value === 'object') {
                    return lookupValue(value, [
                        relation && relation.value_field ? relation.value_field : '',
                        relation && relation.column ? relation.column : '',
                        'id',
                        'slug',
                        'email',
                        'key',
                        'code',
                    ]);
                }
                return value;
            }

            function normalizeSeedValue(field, value) {
                if (value === undefined) {
                    return undefined;
                }

                let nextValue = value;
                if (typeof nextValue === 'string' && (field.data_type === 'array' || field.data_type === 'object')) {
                    nextValue = safeJsonParse(nextValue, nextValue);
                }

                const relation = fieldRelationMeta(field);
                if (relation) {
                    if (field.data_type === 'array') {
                        const items = Array.isArray(nextValue)
                            ? nextValue
                            : (nextValue === null || nextValue === undefined || nextValue === '' ? [] : [nextValue]);
                        return items.map(function (item) {
                            const scalar = relationScalarValue(relation, item);
                            return scalar === '' ? '' : String(scalar);
                        }).filter(Boolean);
                    }

                    const scalar = relationScalarValue(relation, nextValue);
                    return scalar === '' ? '' : String(scalar);
                }

                if (field.data_type === 'array') {
                    if (Array.isArray(nextValue)) {
                        return nextValue;
                    }
                    if (nextValue === null || nextValue === undefined || nextValue === '') {
                        return [];
                    }
                }

                return nextValue;
            }

            function fieldSeedValue(field, seed) {
                const sources = Array.isArray(seed) ? seed : [seed];

                for (let sourceIndex = 0; sourceIndex < sources.length; sourceIndex += 1) {
                    const source = sources[sourceIndex];
                    if (!isRecordObject(source)) {
                        continue;
                    }

                    const seedKeys = fieldSeedKeys(field);
                    for (let keyIndex = 0; keyIndex < seedKeys.length; keyIndex += 1) {
                        const key = seedKeys[keyIndex];
                        const candidate = objectValue(source, key);
                        if (candidate !== undefined) {
                            return normalizeSeedValue(field, candidate);
                        }
                    }

                    const relationKeys = relationObjectSeedKeys(field);
                    for (let keyIndex = 0; keyIndex < relationKeys.length; keyIndex += 1) {
                        const key = relationKeys[keyIndex];
                        const candidate = objectValue(source, key);
                        if (candidate !== undefined) {
                            return normalizeSeedValue(field, candidate);
                        }
                    }
                }

                return undefined;
            }

            function hasInputValue(value) {
                if (value === undefined || value === null) {
                    return false;
                }
                if (typeof value === 'string') {
                    return value !== '';
                }
                return true;
            }

            function fieldInputValue(field, seed, method) {
                const seededValue = fieldSeedValue(field, seed);
                if (seededValue !== undefined) {
                    return seededValue;
                }
                if (fieldIsRequired(field, method) && field.data_type === 'boolean') {
                    return false;
                }
                return '';
            }

            function labelForField(field) {
                return humanizeToken(field.name || 'field');
            }

            function fieldIsRequired(field, method) {
                const resolvedMethod = String(method || '').toUpperCase();
                if (resolvedMethod === 'PUT' || resolvedMethod === 'PATCH') {
                    return !!field.required_on_update;
                }
                if (resolvedMethod === 'POST') {
                    return !!field.required_on_create;
                }
                return !!field.required_on_create || !!field.required_on_update;
            }

            function fieldHelp(field, method) {
                const notes = [];
                if (fieldIsRequired(field, method)) {
                    notes.push('Required.');
                }
                if (field.description) {
                    notes.push(String(field.description));
                }
                if (Array.isArray(field.options) && field.options.length > 0) {
                    notes.push('Options: ' + field.options.join(', ') + '.');
                }
                if (field.format) {
                    notes.push('Format: ' + field.format + '.');
                }
                if (fieldRelationMeta(field)) {
                    notes.push('Select from related ' + String(fieldRelationMeta(field).resource_label || 'records').toLowerCase() + '.');
                }
                if (mediaUploadConfig(field)) {
                    notes.push('Supports automatic media upload.');
                }
                return notes.join(' ');
            }

            function mediaUploadConfig(field) {
                return field && field.media_upload && typeof field.media_upload === 'object'
                    ? field.media_upload
                    : null;
            }

            function mediaHelperFileId(fieldName) {
                return 'media_upload_file_' + String(fieldName || '').replace(/[^a-zA-Z0-9_-]/g, '_');
            }

            function mediaHelperScopeId(fieldName) {
                return 'media_upload_scope_' + String(fieldName || '').replace(/[^a-zA-Z0-9_-]/g, '_');
            }

            function mediaHelperStatusId(fieldName) {
                return 'media_upload_status_' + String(fieldName || '').replace(/[^a-zA-Z0-9_-]/g, '_');
            }

            function mediaHelperHtml(field) {
                const config = mediaUploadConfig(field);
                if (!config) {
                    return '';
                }

                return '<div class="media-helper" data-media-helper="' + escapeHtml(field.name || '') + '">' +
                    '<span class="media-helper-note">Upload a media file here and this field will be filled automatically when you submit the form.</span>' +
                    '<div class="media-helper-grid">' +
                        '<div>' +
                            '<label class="help-block" for="' + escapeHtml(mediaHelperFileId(field.name || '')) + '">Media file</label>' +
                            '<input type="file" id="' + escapeHtml(mediaHelperFileId(field.name || '')) + '" data-media-upload-file="' + escapeHtml(field.name || '') + '">' +
                        '</div>' +
                        '<div>' +
                            '<label class="help-block" for="' + escapeHtml(mediaHelperScopeId(field.name || '')) + '">Access</label>' +
                            '<select id="' + escapeHtml(mediaHelperScopeId(field.name || '')) + '" data-media-upload-scope="' + escapeHtml(field.name || '') + '">' +
                                '<option value="public"' + ((config.default_access_scope || 'public') === 'public' ? ' selected' : '') + '>public</option>' +
                                '<option value="authenticated"' + (config.default_access_scope === 'authenticated' ? ' selected' : '') + '>authenticated</option>' +
                                '<option value="private"' + (config.default_access_scope === 'private' ? ' selected' : '') + '>private</option>' +
                            '</select>' +
                        '</div>' +
                    '</div>' +
                    '<span class="media-helper-status" id="' + escapeHtml(mediaHelperStatusId(field.name || '')) + '" data-media-upload-status="' + escapeHtml(field.name || '') + '"></span>' +
                '</div>';
            }

            function safeJsonParse(value, fallback) {
                try {
                    return JSON.parse(String(value || ''));
                } catch {
                    return fallback;
                }
            }

            function storageGet(key) {
                try {
                    return localStorage.getItem(String(key || ''));
                } catch {
                    return null;
                }
            }

            function storageSet(key, value) {
                try {
                    localStorage.setItem(String(key || ''), String(value || ''));
                } catch {}
            }

            function storageRemove(key) {
                try {
                    localStorage.removeItem(String(key || ''));
                } catch {}
            }

            function fieldRelationMeta(field) {
                return field && field.relation && typeof field.relation === 'object'
                    ? field.relation
                    : null;
            }

            function relationSelectedValues(input) {
                if (!input) {
                    return [];
                }

                if (input.tagName === 'SELECT' && input.hasAttribute('data-multiple')) {
                    const selected = Array.from(input.selectedOptions).map(function (option) {
                        return String(option.value || '');
                    }).filter(Boolean);
                    if (selected.length > 0) {
                        return selected;
                    }
                } else if (input.value !== '') {
                    return [String(input.value)];
                }

                const parsed = safeJsonParse(input.getAttribute('data-initial-value') || '', input.value || '');
                if (Array.isArray(parsed)) {
                    return parsed.map(function (item) { return String(item); }).filter(Boolean);
                }
                if (parsed === null || parsed === undefined || parsed === '') {
                    return [];
                }

                return [String(parsed)];
            }

            function relationStatusNode(input) {
                if (!input || !input.id) {
                    return null;
                }
                return document.querySelector('[data-relation-status-for="' + input.id + '"]');
            }

            function setRelationStatus(input, text, isError) {
                const node = relationStatusNode(input);
                if (!node) {
                    return;
                }
                node.textContent = String(text || '');
                node.classList.toggle('error', !!isError);
            }

            function relationQueryValues(relation, searchTerm) {
                const query = {};
                if (relation && relation.limit_param) {
                    query[relation.limit_param] = 250;
                }
                if (relation && relation.offset_param) {
                    query[relation.offset_param] = 0;
                }
                if (relation && relation.search_param && String(searchTerm || '').trim() !== '') {
                    query[relation.search_param] = String(searchTerm || '').trim();
                }
                return query;
            }

            function relationSearchNode(input) {
                if (!input || !input.id) {
                    return null;
                }
                return document.querySelector('[data-relation-search-for="' + input.id + '"]');
            }

            function relationSearchTerm(input) {
                const node = relationSearchNode(input);
                return node ? String(node.value || '').trim() : '';
            }

            function relationCacheKey(relation, searchTerm) {
                return [
                    relation && relation.resource_key ? relation.resource_key : '',
                    relation && relation.list_path ? relation.list_path : '',
                    String(searchTerm || '').trim(),
                    currentToken(),
                ].join('|');
            }

            async function fetchRelationChoices(relation, forceRefresh, searchTerm) {
                const cacheKey = relationCacheKey(relation, searchTerm);
                if (!forceRefresh && Object.prototype.hasOwnProperty.call(relationChoiceCache, cacheKey)) {
                    return relationChoiceCache[cacheKey];
                }

                const headers = { 'Accept': 'application/json' };
                const token = currentToken();
                if (token !== '') {
                    headers.Authorization = token.startsWith('Bearer ') ? token : 'Bearer ' + token;
                }

                const response = await fetch(
                    buildAbsoluteUrl(relation.list_path || '/', relationQueryValues(relation, searchTerm)),
                    {
                        method: 'GET',
                        headers: headers,
                    }
                );
                const text = await response.text();
                let parsed = text;
                try {
                    parsed = JSON.parse(text);
                } catch {}

                let error = '';
                if (!response.ok) {
                    error = typeof parsed === 'object' && parsed && parsed.error
                        ? String(parsed.error)
                        : ('HTTP ' + String(response.status));
                }

                const payload = parsed && typeof parsed === 'object' && Object.prototype.hasOwnProperty.call(parsed, 'data')
                    ? parsed.data
                    : parsed;
                const rows = Array.isArray(payload)
                    ? payload.filter(function (row) { return row && typeof row === 'object'; })
                    : (payload && typeof payload === 'object' ? [payload] : []);

                const seen = new Set();
                const choices = rows.map(function (row) {
                    const value = lookupValue(row, [
                        relation.value_field || relation.column || 'id',
                        'id',
                    ]);
                    if (value === '') {
                        return null;
                    }

                    const stringValue = String(value);
                    if (seen.has(stringValue)) {
                        return null;
                    }
                    seen.add(stringValue);

                    const labelParts = (Array.isArray(relation.label_fields) ? relation.label_fields : []).map(function (fieldName) {
                        return lookupValue(row, [fieldName]);
                    }).filter(function (part) {
                        return part !== '';
                    }).map(function (part) {
                        return String(part);
                    });

                    return {
                        value: stringValue,
                        label: labelParts.length > 0 ? labelParts.join(' | ') : stringValue,
                    };
                }).filter(Boolean);

                const result = { choices: choices, error: error };
                relationChoiceCache[cacheKey] = result;
                return result;
            }

            function populateRelationPicker(input, relation, choices) {
                const selectedValues = relationSelectedValues(input);
                const selectedSet = new Set(selectedValues);
                const multiple = input.hasAttribute('data-multiple');
                const seen = new Set();
                const options = [];

                if (!multiple) {
                    options.push('<option value=""></option>');
                }

                (choices || []).forEach(function (choice) {
                    if (!choice || seen.has(choice.value)) {
                        return;
                    }
                    seen.add(choice.value);
                    const selected = selectedSet.has(String(choice.value)) ? ' selected' : '';
                    options.push(
                        '<option value="' + escapeHtml(choice.value) + '"' + selected + '>' +
                            escapeHtml(choice.label) +
                        '</option>'
                    );
                });

                selectedValues.forEach(function (value) {
                    const stringValue = String(value);
                    if (stringValue === '' || seen.has(stringValue)) {
                        return;
                    }
                    seen.add(stringValue);
                    options.push(
                        '<option value="' + escapeHtml(stringValue) + '" selected>' +
                            escapeHtml('Current: ' + stringValue) +
                        '</option>'
                    );
                });

                input.innerHTML = options.join('');
            }

            async function loadRelationPicker(input, forceRefresh) {
                const relation = safeJsonParse(input.getAttribute('data-field-relation') || '', null);
                if (!relation || typeof relation !== 'object' || !relation.list_path) {
                    return;
                }

                const searchTerm = relationSearchTerm(input);
                const relationLabel = String(relation.resource_label || relation.resource_key || 'options').toLowerCase();
                const searchSuffix = searchTerm !== '' ? ' matching "' + searchTerm + '"' : '';

                setRelationStatus(
                    input,
                    'Loading ' + relationLabel + searchSuffix + '...',
                    false
                );

                try {
                    const result = await fetchRelationChoices(relation, !!forceRefresh, searchTerm);
                    populateRelationPicker(input, relation, result.choices);
                    if (result.error) {
                        setRelationStatus(input, result.error, true);
                        return;
                    }

                    const label = String(relation.resource_label || relation.resource_key || 'records');
                    const count = Array.isArray(result.choices) ? result.choices.length : 0;
                    setRelationStatus(
                        input,
                        count > 0
                            ? 'Loaded ' + String(count) + ' ' + label.toLowerCase() + (searchTerm !== '' ? ' matching "' + searchTerm + '".' : '.')
                            : 'No related ' + label.toLowerCase() + (searchTerm !== '' ? ' match "' + searchTerm + '".' : ' are available.'),
                        false
                    );
                } catch (error) {
                    setRelationStatus(
                        input,
                        String(error && error.message ? error.message : error),
                        true
                    );
                }
            }

            function hydrateRelationPickers(container) {
                if (!container) {
                    return;
                }

                container.querySelectorAll('[data-relation-picker="true"]').forEach(function (input) {
                    if (input.getAttribute('data-relation-bound') !== 'true') {
                        const refreshButton = container.querySelector('[data-relation-refresh="' + input.id + '"]');
                        if (refreshButton) {
                            refreshButton.addEventListener('click', function () {
                                loadRelationPicker(input, true);
                            });
                        }
                        const searchInput = relationSearchNode(input);
                        if (searchInput) {
                            searchInput.addEventListener('input', function () {
                                const activeInput = input;
                                const timer = Number(activeInput.getAttribute('data-relation-search-timer') || '0');
                                if (timer > 0) {
                                    window.clearTimeout(timer);
                                }
                                const nextTimer = window.setTimeout(function () {
                                    activeInput.removeAttribute('data-relation-search-timer');
                                    loadRelationPicker(activeInput, true);
                                }, 250);
                                activeInput.setAttribute('data-relation-search-timer', String(nextTimer));
                            });
                            searchInput.addEventListener('keydown', function (event) {
                                if (event.key !== 'Enter') {
                                    return;
                                }
                                event.preventDefault();
                                const timer = Number(input.getAttribute('data-relation-search-timer') || '0');
                                if (timer > 0) {
                                    window.clearTimeout(timer);
                                    input.removeAttribute('data-relation-search-timer');
                                }
                                loadRelationPicker(input, true);
                            });
                        }
                        input.setAttribute('data-relation-bound', 'true');
                    }

                    loadRelationPicker(input, false);
                });
            }

            function relationPickerHtml(field, value, prefix, required) {
                const relation = fieldRelationMeta(field);
                const id = prefix + '_' + field.name.replace(/[^a-zA-Z0-9_-]/g, '_');
                const safeValue = value === null || value === undefined
                    ? (field.data_type === 'array' ? [] : '')
                    : value;
                const relationJson = escapeHtml(JSON.stringify(relation || {}));
                const initialValueJson = escapeHtml(JSON.stringify(safeValue));
                const requiredAttr = required ? ' required aria-required="true"' : '';
                const multipleAttr = field.data_type === 'array' ? ' multiple data-multiple="true"' : '';
                const searchLabel = String(relation && (relation.resource_label || relation.resource_key) ? (relation.resource_label || relation.resource_key) : 'records').toLowerCase();
                const controlsHtml = relation && relation.search_param
                    ? '<div class="relation-picker-controls">' +
                        '<input type="search" data-relation-search-for="' + escapeHtml(id) + '" placeholder="Search ' + escapeHtml(searchLabel) + '">' +
                        '<button class="btn btn-default" type="button" data-relation-refresh="' + escapeHtml(id) + '">Reload</button>' +
                    '</div>'
                    : '';
                const reloadButtonHtml = relation && relation.search_param
                    ? ''
                    : '<button class="btn btn-default" type="button" data-relation-refresh="' + escapeHtml(id) + '">Reload</button>';

                return '<div class="relation-picker">' +
                    controlsHtml +
                    '<div class="relation-picker-row">' +
                        '<select id="' + escapeHtml(id) + '" data-field-name="' + escapeHtml(field.name) + '" data-field-type="' + escapeHtml(field.data_type || 'string') + '" data-field-relation="' + relationJson + '" data-initial-value="' + initialValueJson + '" data-relation-picker="true"' + requiredAttr + multipleAttr + '>' +
                            (field.data_type === 'array' ? '' : '<option value=""></option>') +
                        '</select>' +
                        reloadButtonHtml +
                    '</div>' +
                    '<span class="relation-picker-meta" data-relation-status-for="' + escapeHtml(id) + '">Loading options...</span>' +
                '</div>';
            }

            function fieldControlHtml(field, value, prefix, required) {
                const id = prefix + '_' + field.name.replace(/[^a-zA-Z0-9_-]/g, '_');
                const safeValue = value === null || value === undefined ? '' : value;
                const attr = ' id="' + escapeHtml(id) + '" data-field-name="' + escapeHtml(field.name) + '" data-field-type="' + escapeHtml(field.data_type || 'string') + '"';
                const requiredAttr = required ? ' required aria-required="true"' : '';

                if (fieldRelationMeta(field) && (!Array.isArray(field.options) || field.options.length === 0)) {
                    return relationPickerHtml(field, safeValue, prefix, required);
                }

                if (Array.isArray(field.options) && field.options.length > 0) {
                    const multiple = field.data_type === 'array';
                    const selectedValues = multiple && Array.isArray(safeValue) ? safeValue.map(String) : [String(safeValue)];
                    let options = multiple ? '' : '<option value=""></option>';
                    options += field.options.map(function (option) {
                        const selected = selectedValues.includes(String(option)) ? ' selected' : '';
                        return '<option value="' + escapeHtml(option) + '"' + selected + '>' + escapeHtml(option) + '</option>';
                    }).join('');
                    return '<select' + attr + requiredAttr + (multiple ? ' multiple data-multiple="true"' : '') + '>' + options + '</select>';
                }

                if (field.data_type === 'boolean') {
                    return '<select' + attr + requiredAttr + '>' +
                        '<option value=""></option>' +
                        '<option value="true"' + (String(safeValue) === 'true' ? ' selected' : '') + '>true</option>' +
                        '<option value="false"' + (String(safeValue) === 'false' ? ' selected' : '') + '>false</option>' +
                    '</select>';
                }

                if (field.data_type === 'file') {
                    return '<input type="file"' + attr + requiredAttr + '>';
                }

                if (field.data_type === 'object' || field.data_type === 'array') {
                    const textValue = typeof safeValue === 'string' ? safeValue : JSON.stringify(safeValue, null, 2);
                    return '<textarea' + attr + requiredAttr + '>' + escapeHtml(textValue === undefined ? '' : textValue) + '</textarea>';
                }

                if (field.data_type === 'integer' || field.data_type === 'number') {
                    return '<input type="number" value="' + escapeHtml(String(safeValue)) + '"' + attr + requiredAttr + '>';
                }

                if (field.format === 'email') {
                    return '<input type="email" value="' + escapeHtml(String(safeValue)) + '"' + attr + requiredAttr + '>';
                }

                return '<input type="text" value="' + escapeHtml(String(safeValue)) + '"' + attr + requiredAttr + '>';
            }

            function renderWriterFields() {
                const writeMethods = visibleWriteMethods();
                if (!writeMethods.includes(activeWriteMethod)) {
                    activeWriteMethod = writeMethods[0] || '';
                }

                const route = writerRoute();
                if (!route) {
                    writerPanelNode.hidden = true;
                    return;
                }

                const fields = writerBodyFields(route);
                const seed = [];
                if (activeWriteMethod === 'PUT' || activeWriteMethod === 'PATCH') {
                    seed.push(currentRecordSeed());
                }
                if (lastWriteDraft !== null && lastWriteDraftPath === String(route.path || '')) {
                    seed.push(lastWriteDraft);
                }
                const usesMultipart = String(route.request && route.request.content_type || '').includes('multipart/form-data')
                    || fields.some(function (field) { return field.data_type === 'file'; });
                const routeMethod = String(route.method || activeWriteMethod || '').toUpperCase();

                writerPanelNode.hidden = false;
                writerSubmitNode.textContent = activeWriteMethod;
                rawHelpNode.textContent = usesMultipart
                    ? 'Raw JSON does not include binary file contents. Use the HTML form for file uploads.'
                    : 'Send a JSON request body to this endpoint.';

                if (writeMethods.length > 1) {
                    writerMethodsNode.classList.remove('hidden');
                    writerMethodsNode.innerHTML = '<div class="btn-group">' + writeMethods.map(function (method) {
                        const cls = method === activeWriteMethod ? 'btn btn-primary' : 'btn btn-default';
                        return '<button class="' + cls + '" type="button" data-write-method="' + escapeHtml(method) + '">' + escapeHtml(method) + '</button>';
                    }).join('') + '</div>';

                    writerMethodsNode.querySelectorAll('[data-write-method]').forEach(function (button) {
                        button.addEventListener('click', function () {
                            activeWriteMethod = button.getAttribute('data-write-method') || activeWriteMethod;
                            renderWriterFields();
                        });
                    });
                } else {
                    writerMethodsNode.classList.add('hidden');
                    writerMethodsNode.innerHTML = '';
                }

                if (fields.length === 0) {
                    writerFieldsNode.innerHTML = '<p class="empty-state">No form fields documented for this endpoint.</p>';
                } else {
                    writerFieldsNode.innerHTML = fields.map(function (field) {
                        const required = fieldIsRequired(field, routeMethod);
                        const help = fieldHelp(field, routeMethod);
                        return '<div class="form-group">' +
                            '<label class="control-label" for="writer_' + escapeHtml(field.name) + '">' + escapeHtml(labelForField(field)) + (required ? ' *' : '') + '</label>' +
                            '<div class="controls">' +
                                fieldControlHtml(field, fieldInputValue(field, seed, routeMethod), 'writer', required) +
                                mediaHelperHtml(field) +
                                (help !== '' ? '<span class="help-block">' + escapeHtml(help) + '</span>' : '') +
                            '</div>' +
                        '</div>';
                    }).join('');
                    hydrateRelationPickers(writerFieldsNode);
                }

                const rawTemplate = {};
                fields.forEach(function (field) {
                    if (field.data_type === 'file') {
                        return;
                    }
                    const value = fieldInputValue(field, seed, routeMethod);
                    rawTemplate[field.name] = hasInputValue(value)
                        ? value
                        : defaultTemplateValue(field);
                });
                rawJsonInput.value = JSON.stringify(rawTemplate, null, 4);
            }

            function setActiveTab(tab) {
                activeTab = tab === 'raw' ? 'raw' : 'html';
                writerTabsNode.querySelectorAll('li').forEach(function (item) {
                    item.classList.remove('active');
                });
                writerTabsNode.querySelectorAll('[data-tab]').forEach(function (link) {
                    if (link.getAttribute('data-tab') === activeTab) {
                        link.parentElement.classList.add('active');
                    }
                });
                rawTabNode.hidden = activeTab !== 'raw';
                htmlTabNode.hidden = activeTab !== 'html';
            }

            function readFieldValues(container) {
                const values = {};
                container.querySelectorAll('[data-field-name]').forEach(function (input) {
                    const name = input.getAttribute('data-field-name');
                    if (!name) {
                        return;
                    }

                    if (input.type === 'file') {
                        values[name] = input.files && input.files[0] ? input.files[0] : null;
                        return;
                    }

                    if (input.tagName === 'SELECT' && input.hasAttribute('data-multiple')) {
                        values[name] = Array.from(input.selectedOptions).map(function (option) {
                            return option.value;
                        });
                        return;
                    }

                    values[name] = input.value;
                });
                return values;
            }

            function coerceValue(field, value) {
                if (value === '' || value === null || value === undefined) {
                    return null;
                }
                if (field.data_type === 'boolean') {
                    return String(value) === 'true';
                }
                if (field.data_type === 'integer') {
                    return parseInt(String(value), 10);
                }
                if (field.data_type === 'number') {
                    return parseFloat(String(value));
                }
                if (field.data_type === 'object' || field.data_type === 'array') {
                    try {
                        return JSON.parse(String(value));
                    } catch {
                        return value;
                    }
                }
                return value;
            }

            function buildStructuredBody(route) {
                const values = readFieldValues(writerFieldsNode);
                const body = {};
                const fields = writerBodyFields(route);
                fields.forEach(function (field) {
                    const rawValue = values[field.name];
                    if (rawValue === '' || rawValue === null || rawValue === undefined) {
                        return;
                    }
                    if (field.data_type === 'file') {
                        return;
                    }
                    body[field.name] = coerceValue(field, rawValue);
                });
                return body;
            }

            function buildFormData(route) {
                const formData = new FormData();
                const values = readFieldValues(writerFieldsNode);
                const fields = writerBodyFields(route);
                fields.forEach(function (field) {
                    const rawValue = values[field.name];
                    if (rawValue === '' || rawValue === null || rawValue === undefined) {
                        return;
                    }
                    if (field.data_type === 'file') {
                        if (rawValue) {
                            formData.append(field.name, rawValue);
                        }
                        return;
                    }
                    const coerced = coerceValue(field, rawValue);
                    formData.append(field.name, typeof coerced === 'string' ? coerced : JSON.stringify(coerced));
                });
                return formData;
            }

            function writerFieldInput(fieldName) {
                return writerFieldsNode.querySelector('[data-field-name="' + String(fieldName || '').replaceAll('"', '\\"') + '"]');
            }

            function syncRawJsonFromWriterFields() {
                const route = writerRoute();
                if (!route) {
                    return;
                }
                rawJsonInput.value = JSON.stringify(buildStructuredBody(route), null, 4);
            }

            function setWriterFieldValue(fieldName, value) {
                const input = writerFieldInput(fieldName);
                if (!input) {
                    return;
                }

                if (input.tagName === 'SELECT' && input.hasAttribute('data-multiple')) {
                    const values = Array.isArray(value)
                        ? value.map(String)
                        : (value === null || value === undefined || value === '' ? [] : [String(value)]);
                    if (input.hasAttribute('data-relation-picker')) {
                        input.setAttribute('data-initial-value', JSON.stringify(values));
                    }
                    Array.from(input.options).forEach(function (option) {
                        option.selected = values.includes(option.value);
                    });
                    syncRawJsonFromWriterFields();
                    return;
                }

                if (input.hasAttribute('data-relation-picker')) {
                    const stringValue = value === null || value === undefined ? '' : String(value);
                    input.setAttribute('data-initial-value', JSON.stringify(stringValue));
                    if (stringValue !== '' && !Array.from(input.options).some(function (option) { return option.value === stringValue; })) {
                        input.innerHTML += '<option value="' + escapeHtml(stringValue) + '" selected>' + escapeHtml('Current: ' + stringValue) + '</option>';
                    }
                }

                if (input.tagName === 'TEXTAREA' && ['array', 'object'].includes(String(input.getAttribute('data-field-type') || ''))) {
                    input.value = value === null || value === undefined || value === ''
                        ? ''
                        : (typeof value === 'string' ? value : JSON.stringify(value, null, 2));
                    syncRawJsonFromWriterFields();
                    return;
                }

                input.value = value === null || value === undefined ? '' : String(value);
                syncRawJsonFromWriterFields();
            }

            function setMediaHelperStatus(fieldName, message, state) {
                const statusNode = writerFieldsNode.querySelector('[data-media-upload-status="' + String(fieldName || '').replaceAll('"', '\\"') + '"]');
                if (!statusNode) {
                    return;
                }

                statusNode.textContent = String(message || '');
                statusNode.classList.remove('is-success', 'is-error');
                if (state === 'success') {
                    statusNode.classList.add('is-success');
                } else if (state === 'error') {
                    statusNode.classList.add('is-error');
                }
            }

            function mediaTargetValue(config, asset) {
                const target = String(config && config.target || 'asset_url');
                const resource = asset && typeof asset === 'object' ? asset : {};
                if (target === 'asset_id') {
                    return resource.id || '';
                }

                return resource.public_url || resource.download_url || (resource.id ? '/api/v1/media/' + resource.id + '/download' : '');
            }

            function applyUploadedValuesToRawJson(uploadedValues) {
                if (!uploadedValues || Object.keys(uploadedValues).length === 0) {
                    return;
                }

                let parsed = {};
                const raw = rawJsonInput.value.trim();
                if (raw !== '') {
                    parsed = JSON.parse(raw);
                }
                if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
                    parsed = {};
                }

                Object.entries(uploadedValues).forEach(function (entry) {
                    parsed[entry[0]] = entry[1];
                });
                rawJsonInput.value = JSON.stringify(parsed, null, 4);
            }

            async function uploadMediaHelperField(field) {
                const config = mediaUploadConfig(field);
                if (!config) {
                    return null;
                }

                const fileInput = writerFieldsNode.querySelector('[data-media-upload-file="' + String(field.name || '').replaceAll('"', '\\"') + '"]');
                if (!fileInput || !fileInput.files || !fileInput.files[0]) {
                    return null;
                }

                const scopeInput = writerFieldsNode.querySelector('[data-media-upload-scope="' + String(field.name || '').replaceAll('"', '\\"') + '"]');
                const uploadPath = String(config.endpoint || '/api/v1/admin/media');
                const formData = new FormData();
                const token = currentToken();
                const headers = { 'Accept': 'application/json' };
                if (token !== '') {
                    headers.Authorization = token.startsWith('Bearer ') ? token : 'Bearer ' + token;
                }

                formData.append('file', fileInput.files[0]);
                formData.append('access_scope', scopeInput && scopeInput.value ? scopeInput.value : String(config.default_access_scope || 'public'));

                setMediaHelperStatus(field.name || '', 'Uploading media...', null);
                lastRequest = {
                    method: 'POST',
                    path: uploadPath,
                    query: {},
                };
                renderRequestPreview();

                const response = await fetch(buildAbsoluteUrl(uploadPath, {}), {
                    method: 'POST',
                    headers: headers,
                    body: formData,
                });
                const text = await response.text();
                let parsed = text;
                try {
                    parsed = JSON.parse(text);
                } catch {}

                if (!response.ok) {
                    currentResponse = {
                        status: response.status,
                        status_text: response.statusText,
                        request_method: 'POST',
                        headers: { 'content-type': response.headers.get('content-type') || 'application/json' },
                        content_type: response.headers.get('content-type') || 'application/json',
                        payload: parsed,
                        body: text,
                        pretty_body: typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 4),
                    };
                    renderRequestPreview();
                    renderResponse();
                    setMediaHelperStatus(field.name || '', 'Upload failed. Review the response below.', 'error');
                    throw new Error('Media upload failed for ' + String(field.name || 'field') + '.');
                }

                const discoveredToken = tokenFromPayload(parsed);
                if (discoveredToken !== '' && isAuthenticationRoute('POST', uploadPath)) {
                    tokenInputNode.value = discoveredToken;
                    persistToken();
                }
                persistSessionFromPayload(parsed, discoveredToken || token, 'POST', uploadPath);

                const asset = payloadData(parsed);
                const nextValue = mediaTargetValue(config, asset);
                if (nextValue === '') {
                    setMediaHelperStatus(field.name || '', 'Upload succeeded but no field value could be derived.', 'error');
                    throw new Error('Media upload completed without a usable return value.');
                }

                Object.keys(relationChoiceCache).forEach(function (key) {
                    delete relationChoiceCache[key];
                });
                setWriterFieldValue(field.name || '', nextValue);
                fileInput.value = '';
                setMediaHelperStatus(field.name || '', 'Uploaded and linked automatically.', 'success');

                return {
                    fieldName: String(field.name || ''),
                    value: nextValue,
                };
            }

            async function processPendingMediaUploads(route) {
                const fields = route && route.request && Array.isArray(route.request.body) ? route.request.body : [];
                const uploadedValues = {};

                for (let index = 0; index < fields.length; index += 1) {
                    const field = fields[index];
                    if (!mediaUploadConfig(field)) {
                        continue;
                    }

                    const uploaded = await uploadMediaHelperField(field);
                    if (uploaded && uploaded.fieldName) {
                        uploadedValues[uploaded.fieldName] = uploaded.value;
                    }
                }

                return uploadedValues;
            }

            function filterFields() {
                if (!readRoute || !readRoute.request || !routeVisibleToSession(readRoute)) {
                    return [];
                }
                return Array.isArray(readRoute.request.query) ? readRoute.request.query : [];
            }

            function splitFilterFields() {
                const fields = filterFields();
                const searchFields = fields.filter(function (field) {
                    return ['q', 'search'].includes(String(field.name || '').toLowerCase());
                });
                const normalFields = fields.filter(function (field) {
                    return !['q', 'search'].includes(String(field.name || '').toLowerCase());
                });
                return { searchFields: searchFields, normalFields: normalFields };
            }

            function renderFilters() {
                const split = splitFilterFields();
                const normalFields = split.normalFields;
                const searchFields = split.searchFields;

                filtersWrapNode.classList.toggle('hidden', filterFields().length === 0);

                if (normalFields.length === 0) {
                    filtersFormNode.innerHTML = '<p class="empty-state">No structured field filters are documented for this endpoint.</p>';
                } else {
                    filtersFormNode.innerHTML = normalFields.map(function (field) {
                        const value = Object.prototype.hasOwnProperty.call(queryState, field.name) ? queryState[field.name] : '';
                        return '<p>' +
                            '<label for="filter_' + escapeHtml(field.name) + '">' + escapeHtml(labelForField(field)) + ':</label>' +
                            fieldControlHtml(field, value, 'filter') +
                        '</p>';
                    }).join('') + '<button type="submit" class="btn btn-primary">Submit</button>';
                    hydrateRelationPickers(filtersFormNode);
                }

                if (searchFields.length > 0) {
                    searchSectionNode.classList.remove('hidden');
                    searchDividerNode.classList.remove('hidden');
                    const value = Object.prototype.hasOwnProperty.call(queryState, searchFields[0].name) ? queryState[searchFields[0].name] : '';
                    searchInputNode.value = value;
                    searchInputNode.setAttribute('data-search-name', searchFields[0].name);
                    searchInputNode.placeholder = searchFields[0].description || 'Search this endpoint';
                } else {
                    searchSectionNode.classList.add('hidden');
                    searchDividerNode.classList.add('hidden');
                    searchInputNode.value = '';
                    searchInputNode.removeAttribute('data-search-name');
                }
            }

            function openFiltersModal() {
                if (filterFields().length === 0) {
                    return;
                }
                document.body.classList.add('modal-open');
                filtersBackdrop.classList.add('open');
                filtersModal.classList.add('open');
            }

            function closeFiltersModal() {
                document.body.classList.remove('modal-open');
                filtersBackdrop.classList.remove('open');
                filtersModal.classList.remove('open');
            }

            async function executeRequest(method, route, options) {
                const requestRoute = route || readRoute;
                const path = resolveRoutePath(requestRoute || { path: endpoint.path || '/' });
                const query = options && options.query ? options.query : {};
                const url = buildAbsoluteUrl(path, cleanQuery(query, true));
                const headers = { 'Accept': 'application/json' };
                const token = currentToken();

                if (token !== '') {
                    headers.Authorization = token.startsWith('Bearer ') ? token : 'Bearer ' + token;
                }

                let body;
                if (options && options.body !== undefined) {
                    body = options.body;
                }
                if (body && !(body instanceof FormData)) {
                    headers['Content-Type'] = 'application/json';
                }

                const response = await fetch(url, {
                    method: method,
                    headers: headers,
                    body: body,
                });
                const text = await response.text();
                const headersObject = {};
                response.headers.forEach(function (value, key) {
                    headersObject[key] = value;
                });

                let parsed = text;
                try {
                    parsed = JSON.parse(text);
                } catch {}

                const discoveredToken = tokenFromPayload(parsed);
                if (discoveredToken !== '' && isAuthenticationRoute(method, path)) {
                    tokenInputNode.value = discoveredToken;
                    persistToken();
                }
                persistSessionFromPayload(parsed, discoveredToken || token, method, path);

                currentResponse = {
                    status: response.status,
                    status_text: response.statusText,
                    request_method: method,
                    headers: headersObject,
                    content_type: response.headers.get('content-type') || 'application/json',
                    payload: parsed,
                    body: text,
                    pretty_body: typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 4),
                };
                lastRequest = {
                    method: method,
                    path: path,
                    query: Object.assign({}, query),
                };
                if (response.ok && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(String(method || '').toUpperCase())) {
                    Object.keys(relationChoiceCache).forEach(function (key) {
                        delete relationChoiceCache[key];
                    });
                }
                renderRequestPreview();
                renderResponse();
                renderWriterFields();
                refreshSessionVisibility();

                return response;
            }

            function writerRoute() {
                return visibleWriteMethods().includes(activeWriteMethod) ? routeMap[activeWriteMethod] : null;
            }

            async function handleHeadRequest() {
                const route = routeMap.HEAD || readRoute;
                if (!route) {
                    return;
                }
                try {
                    await executeRequest('HEAD', route, { query: cleanQuery(queryState, false) });
                    history.replaceState({}, '', buildRelativeUrl(resolveRoutePath(route), cleanQuery(queryState, false)));
                    updateNavigationLinks();
                } catch (error) {
                    currentResponse = {
                        status: 0,
                        status_text: 'Request failed',
                        request_method: 'HEAD',
                        headers: {},
                        content_type: 'text/plain',
                        payload: null,
                        body: '',
                        pretty_body: String(error && error.message ? error.message : error),
                    };
                    renderRequestPreview();
                    renderResponse();
                }
            }

            async function handleGetRequest(event) {
                if (event) {
                    event.preventDefault();
                }
                if (!readRoute) {
                    return;
                }
                try {
                    await executeRequest('GET', readRoute, { query: cleanQuery(queryState, false) });
                    history.replaceState({}, '', buildRelativeUrl(resolveRoutePath(readRoute), cleanQuery(queryState, false)));
                    updateNavigationLinks();
                } catch (error) {
                    currentResponse = {
                        status: 0,
                        status_text: 'Request failed',
                        request_method: 'GET',
                        headers: {},
                        content_type: 'text/plain',
                        payload: null,
                        body: '',
                        pretty_body: String(error && error.message ? error.message : error),
                    };
                    renderRequestPreview();
                    renderResponse();
                }
            }

            async function handleOptionsRequest() {
                if (!readRoute) {
                    return;
                }
                try {
                    await executeRequest('OPTIONS', readRoute, { query: cleanQuery(queryState, false) });
                } catch (error) {
                    currentResponse = {
                        status: 0,
                        status_text: 'Request failed',
                        request_method: 'OPTIONS',
                        headers: {},
                        content_type: 'text/plain',
                        payload: null,
                        body: '',
                        pretty_body: String(error && error.message ? error.message : error),
                    };
                    renderRequestPreview();
                    renderResponse();
                }
            }

            async function handleDeleteRequest() {
                const route = routeMap.DELETE;
                if (!route) {
                    return;
                }
                if (!window.confirm('Delete this resource?')) {
                    return;
                }
                try {
                    await executeRequest('DELETE', route, { query: cleanQuery(queryState, false) });
                } catch (error) {
                    currentResponse = {
                        status: 0,
                        status_text: 'Request failed',
                        request_method: 'DELETE',
                        headers: {},
                        content_type: 'text/plain',
                        payload: null,
                        body: '',
                        pretty_body: String(error && error.message ? error.message : error),
                    };
                    renderRequestPreview();
                    renderResponse();
                }
            }

            function handleMethodAction(method) {
                const resolvedMethod = String(method || '').toUpperCase();
                if (!visibleAllowedMethods().includes(resolvedMethod)) {
                    return;
                }
                if (resolvedMethod === 'GET') {
                    handleGetRequest();
                    return;
                }
                if (resolvedMethod === 'HEAD') {
                    handleHeadRequest();
                    return;
                }
                if (resolvedMethod === 'OPTIONS') {
                    handleOptionsRequest();
                    return;
                }
                if (resolvedMethod === 'DELETE') {
                    handleDeleteRequest();
                    return;
                }
                if (['POST', 'PUT', 'PATCH'].includes(resolvedMethod) && routeMap[resolvedMethod]) {
                    activeWriteMethod = resolvedMethod;
                    renderWriterFields();
                    renderPrimaryControls();
                    writerPanelNode.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }

            async function handleWriterSubmit() {
                const route = writerRoute();
                if (!route) {
                    return;
                }

                const fields = writerBodyFields(route);
                const usesMultipart = String(route.request && route.request.content_type || '').includes('multipart/form-data')
                    || fields.some(function (field) { return field.data_type === 'file'; });
                let body;
                let draftBody = null;

                if (activeTab === 'raw') {
                    const rawBeforeUploads = rawJsonInput.value.trim();
                    if (rawBeforeUploads !== '') {
                        try {
                            JSON.parse(rawBeforeUploads);
                        } catch {
                            window.alert('Raw JSON is not valid.');
                            return;
                        }
                    }
                }

                let uploadedValues = {};
                try {
                    uploadedValues = await processPendingMediaUploads(route);
                    if (activeTab === 'raw' && Object.keys(uploadedValues).length > 0) {
                        applyUploadedValuesToRawJson(uploadedValues);
                    }
                } catch {
                    return;
                }

                if (activeTab === 'raw') {
                    const raw = rawJsonInput.value.trim();
                    if (raw !== '') {
                        let parsedRaw;
                        try {
                            parsedRaw = JSON.parse(raw);
                        } catch {
                            window.alert('Raw JSON is not valid.');
                            return;
                        }
                        draftBody = isRecordObject(parsedRaw) ? parsedRaw : null;
                        body = raw;
                    } else {
                        draftBody = {};
                        body = '{}';
                    }
                } else if (usesMultipart) {
                    draftBody = buildStructuredBody(route);
                    rawJsonInput.value = JSON.stringify(draftBody, null, 4);
                    body = buildFormData(route);
                } else {
                    draftBody = buildStructuredBody(route);
                    rawJsonInput.value = JSON.stringify(draftBody, null, 4);
                    body = JSON.stringify(draftBody);
                }

                lastWriteDraft = isRecordObject(draftBody) ? draftBody : null;
                lastWriteDraftPath = lastWriteDraft ? String(route.path || '') : '';

                try {
                    await executeRequest(route.method, route, { query: {}, body: body });
                } catch (error) {
                    currentResponse = {
                        status: 0,
                        status_text: 'Request failed',
                        request_method: route.method,
                        headers: {},
                        content_type: 'text/plain',
                        payload: null,
                        body: '',
                        pretty_body: String(error && error.message ? error.message : error),
                    };
                    renderRequestPreview();
                    renderResponse();
                }
            }

            function applyFilterValues() {
                filtersFormNode.querySelectorAll('[data-field-name]').forEach(function (input) {
                    const name = input.getAttribute('data-field-name');
                    if (!name) {
                        return;
                    }

                    if (input.tagName === 'SELECT' && input.hasAttribute('data-multiple')) {
                        const values = Array.from(input.selectedOptions).map(function (option) {
                            return option.value;
                        }).filter(Boolean);
                        if (values.length === 0) {
                            delete queryState[name];
                        } else {
                            queryState[name] = values;
                        }
                        return;
                    }

                    if (input.value === '') {
                        delete queryState[name];
                    } else {
                        queryState[name] = input.value;
                    }
                });

                const searchName = searchInputNode.getAttribute('data-search-name');
                if (searchName) {
                    if (searchInputNode.value.trim() === '') {
                        delete queryState[searchName];
                    } else {
                        queryState[searchName] = searchInputNode.value.trim();
                    }
                }
            }

            function renderPrimaryControls() {
                const orderedMethods = visibleAllowedMethods();
                const currentMethod = String(lastRequest.method || endpoint.current_method || 'GET').toUpperCase();

                if (orderedMethods.length === 0) {
                    methodActionsNode.innerHTML = '<span class="text-muted">No visible operations for this session.</span>';
                    filtersWrapNode.classList.add('hidden');
                    updateNavigationLinks();
                    return;
                }

                methodActionsNode.innerHTML = orderedMethods.map(function (method) {
                    const isSelected = ['POST', 'PUT', 'PATCH'].includes(method)
                        ? activeWriteMethod === method
                        : currentMethod === method;
                    const btnClass = isSelected
                        ? (method === 'DELETE' ? 'btn btn-danger' : 'btn btn-primary')
                        : 'btn btn-default';
                    return '<button class="' + btnClass + '" type="button" data-method-action="' + escapeHtml(method) + '">' + escapeHtml(method) + '</button>';
                }).join('');

                methodActionsNode.querySelectorAll('[data-method-action]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        handleMethodAction(button.getAttribute('data-method-action') || '');
                    });
                });

                filtersWrapNode.classList.toggle('hidden', filterFields().length === 0);
                updateNavigationLinks();
            }

            function initializePage() {
                renderBreadcrumbs(readRoute);
                renderHeader(readRoute);
                renderPrimaryControls();
                renderFilters();
                renderWriterFields();
                setActiveTab('html');
                renderRequestPreview();
                renderResponse();
                updateSessionLabel();
            }

            filtersButton.addEventListener('click', openFiltersModal);
            filtersClose.addEventListener('click', closeFiltersModal);
            filtersBackdrop.addEventListener('click', closeFiltersModal);

            filtersFormNode.addEventListener('submit', function (event) {
                event.preventDefault();
                applyFilterValues();
                closeFiltersModal();
                handleGetRequest();
            });

            searchFormNode.addEventListener('submit', function (event) {
                event.preventDefault();
                applyFilterValues();
                closeFiltersModal();
                handleGetRequest();
            });

            writerSubmitNode.addEventListener('click', handleWriterSubmit);
            writerFieldsNode.addEventListener('input', function (event) {
                if (event.target && event.target.closest('[data-field-name]')) {
                    const target = event.target;
                    const fieldType = String(target.getAttribute('data-field-type') || '');
                    if (target.tagName === 'TEXTAREA' && (fieldType === 'array' || fieldType === 'object')) {
                        return;
                    }
                    syncRawJsonFromWriterFields();
                }
            });
            writerFieldsNode.addEventListener('change', function (event) {
                if (event.target && event.target.closest('[data-field-name]')) {
                    syncRawJsonFromWriterFields();
                }
            });

            writerTabsNode.querySelectorAll('[data-tab]').forEach(function (link) {
                link.addEventListener('click', function (event) {
                    event.preventDefault();
                    setActiveTab(link.getAttribute('data-tab') || 'html');
                });
            });

            saveTokenButton.addEventListener('click', function () {
                persistToken();
                refreshSessionVisibility();
                sessionDropdownNode.classList.remove('open');
            });

            clearTokenButton.addEventListener('click', function () {
                tokenInputNode.value = '';
                persistToken();
                refreshSessionVisibility();
                sessionDropdownNode.classList.remove('open');
            });

            tokenInputNode.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    persistToken();
                    refreshSessionVisibility();
                    sessionDropdownNode.classList.remove('open');
                }
            });

            responseBodyNode.addEventListener('click', function (event) {
                const methodButton = event.target && event.target.closest('[data-route-group-method]');
                if (!methodButton) {
                    return;
                }

                event.preventDefault();
                const groupPath = methodButton.getAttribute('data-route-group-method') || '';
                const selectedMethod = methodButton.getAttribute('data-route-group-selected') || '';
                if (groupPath === '' || selectedMethod === '') {
                    return;
                }

                routeCatalogMethodState[groupPath] = selectedMethod.toUpperCase();
                renderResponse();
            });

            sessionToggleNode.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                const isOpen = sessionDropdownNode.classList.contains('open');
                sessionDropdownNode.classList.toggle('open', !isOpen);
                sessionToggleNode.setAttribute('aria-expanded', String(!isOpen));
                formatDropdownWrap.classList.remove('open');
                formatToggle.setAttribute('aria-expanded', 'false');
            });

            formatToggle.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                const isOpen = formatDropdownWrap.classList.contains('open');
                formatDropdownWrap.classList.toggle('open', !isOpen);
                formatToggle.setAttribute('aria-expanded', String(!isOpen));
                sessionDropdownNode.classList.remove('open');
                sessionToggleNode.setAttribute('aria-expanded', 'false');
            });

            document.addEventListener('click', function (event) {
                if (!sessionDropdownNode.contains(event.target)) {
                    sessionDropdownNode.classList.remove('open');
                    sessionToggleNode.setAttribute('aria-expanded', 'false');
                }
                if (!formatDropdownWrap.contains(event.target)) {
                    formatDropdownWrap.classList.remove('open');
                    formatToggle.setAttribute('aria-expanded', 'false');
                }
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    closeFiltersModal();
                    sessionDropdownNode.classList.remove('open');
                    formatDropdownWrap.classList.remove('open');
                    sessionToggleNode.setAttribute('aria-expanded', 'false');
                    formatToggle.setAttribute('aria-expanded', 'false');
                }
            });

            initializePage();
        }());
    </script>
</body>
</html>
HTML;

        return strtr($html, [
            '__TITLE__' => $title,
            '__PAYLOAD__' => $encoded,
        ]);
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
