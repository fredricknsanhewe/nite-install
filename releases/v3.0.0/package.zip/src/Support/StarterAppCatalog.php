<?php
namespace App\Support;

use App\Console\ConsoleSupport;
use RuntimeException;

/**
 * Catalog of high-level starter applications.
 *
 * A starter application is broader than a simple preset. It describes a
 * product-shaped starting point such as inventory management, point of sale,
 * CRM, or website management. Each starter:
 *
 * - selects a baseline preset
 * - adds focus modules
 * - contributes starter resources
 * - recommends starter sample packs
 * - can be extended with local JSON definitions under
 *   `blueprints/starters/apps/*.json`
 *
 * This data-driven structure is the scale point that allows Nite to grow from a
 * handful of built-ins to hundreds or thousands of internal or public starter
 * blueprints without rewriting the bootstrap engine.
 *
 * @phpstan-type StarterResource array{
 *   name: string,
 *   label: string,
 *   group: string,
 *   item_type: string,
 *   summary: string
 * }
 * @phpstan-type StarterDefinition array{
 *   key: string,
 *   title: string,
 *   summary: string,
 *   preset: string,
 *   modules: list<string>,
 *   operations: list<string>,
 *   resources: list<StarterResource>,
 *   sample_packs: list<string>,
 *   default_sample_count: int,
 *   tags: list<string>
 * }
 */
final class StarterAppCatalog
{
    /**
     * List every available starter application definition.
     *
     * Built-ins are merged with any local JSON files from
     * `blueprints/starters/apps/*.json`.
     *
     * Example:
     * `StarterAppCatalog::starters()['inventory-management']['resources']`
     *
     * @return array<string, StarterDefinition>
     */
    public static function starters(?string $rootPath = null): array
    {
        $rootPath = $rootPath ?? ConsoleSupport::rootPath();
        $starters = [];

        foreach (self::builtIns() as $starter) {
            $starters[(string)$starter['key']] = $starter;
        }
        foreach (self::loadJsonDefinitions($rootPath) as $starter) {
            $starters[(string)$starter['key']] = $starter;
        }

        ksort($starters, SORT_STRING);
        return $starters;
    }

    /**
     * Fetch one starter definition by key.
     *
     * Example:
     * `StarterAppCatalog::starter('point-of-sale')`
     *
     * @return StarterDefinition
     */
    public static function starter(string $key, ?string $rootPath = null): array
    {
        $normalized = trim(ConsoleSupport::kebab($key));
        $starter = self::starters($rootPath)[$normalized] ?? null;
        if (!is_array($starter)) {
            throw new RuntimeException('Unknown starter app: ' . $key . '. Use `php nite starter:list` to inspect the available catalog.');
        }

        return $starter;
    }

    /**
     * Resolve a fully-expanded starter blueprint that bootstrap can consume.
     *
     * @param array<int, string> $withModules
     * @param array<int, string> $withoutModules
     * @param array<int, string> $extraResources
     *
     * Example:
     * `StarterAppCatalog::resolve('inventory-management', ['messaging'], ['payments'], ['CycleCountBoard'])`
     *
     * @return StarterDefinition
     */
    public static function resolve(
        string $key,
        array $withModules = [],
        array $withoutModules = [],
        array $extraResources = [],
        ?string $rootPath = null
    ): array {
        $starter = self::starter($key, $rootPath);
        $presetKey = trim((string)($starter['preset'] ?? 'standard')) ?: 'standard';

        $preset = AppPresetCatalog::resolve(
            $presetKey,
            array_values(array_unique(array_merge(
                array_values(is_array($starter['modules'] ?? null) ? array_map('strval', $starter['modules']) : []),
                $withModules
            ))),
            $withoutModules,
            []
        );

        $resources = [];
        foreach (array_values(is_array($preset['resources'] ?? null) ? $preset['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $resources[self::resourceKey((string)($resource['name'] ?? ''))] = $resource;
        }
        foreach (array_values(is_array($starter['resources'] ?? null) ? $starter['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $resources[self::resourceKey((string)($resource['name'] ?? ''))] = $resource;
        }
        foreach ($extraResources as $resourceName) {
            $normalizedName = ConsoleSupport::studly($resourceName);
            if ($normalizedName === '') {
                continue;
            }
            $resources[self::resourceKey($normalizedName)] = self::resource(
                $normalizedName,
                self::labelFromName($normalizedName),
                'Custom starter resource scaffolded during app bootstrap.',
                'generated'
            );
        }

        $operations = [];
        foreach (array_merge(
            array_values(is_array($preset['operations'] ?? null) ? $preset['operations'] : []),
            array_values(is_array($starter['operations'] ?? null) ? $starter['operations'] : [])
        ) as $operation) {
            $text = trim((string)$operation);
            if ($text === '') {
                continue;
            }
            $operations[$text] = $text;
        }

        $starter['preset'] = $presetKey;
        $starter['preset_title'] = (string)($preset['title'] ?? $presetKey);
        $starter['preset_summary'] = (string)($preset['summary'] ?? '');
        $starter['modules'] = array_values(is_array($preset['modules'] ?? null) ? $preset['modules'] : []);
        $starter['resources'] = array_values($resources);
        $starter['operations'] = array_values($operations);
        $starter['tags'] = array_values(array_unique(array_filter(
            array_map('strval', is_array($starter['tags'] ?? null) ? $starter['tags'] : []),
            static fn (string $value): bool => trim($value) !== ''
        )));
        $starter['sample_packs'] = array_values(array_unique(array_filter(
            array_map('strval', is_array($starter['sample_packs'] ?? null) ? $starter['sample_packs'] : []),
            static fn (string $value): bool => trim($value) !== ''
        )));
        $starter['default_sample_count'] = max(0, (int)($starter['default_sample_count'] ?? 48));

        return $starter;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function builtIns(): array
    {
        return [
            self::starterDefinition(
                'website-management',
                'Website Management System',
                'Public website, marketing content, lead capture, team profiles, SEO-friendly content, and admin management for a complete content-led web presence.',
                'basic',
                ['content', 'catalog', 'messaging', 'governance'],
                [
                    'Public pages, posts, resources, media, and structured site settings',
                    'Lead capture, support FAQs, and team directory management',
                    'Marketing content editing with reusable brand assets and navigation structures',
                ],
                [
                    self::resource('HeroBanner', 'Hero Banner', 'Reusable homepage or section hero banners with rich metadata.'),
                    self::resource('NavigationMenu', 'Navigation Menu', 'Managed navigation trees and menu groups for the public site shell.'),
                    self::resource('ServicePage', 'Service Page', 'Structured service landing pages with marketing content and action blocks.'),
                    self::resource('Testimonial', 'Testimonial', 'Customer or partner testimonials that can be reused across landing pages.'),
                    self::resource('LeadCaptureForm', 'Lead Capture Form', 'Managed forms and inbound lead touchpoints exposed on the public website.'),
                    self::resource('BrandAsset', 'Brand Asset', 'Brand files, logo variants, document templates, and design references.'),
                ],
                ['website-core', 'content-marketing', 'team-directory'],
                72,
                ['website', 'cms', 'marketing', 'content']
            ),
            self::starterDefinition(
                'inventory-management',
                'Inventory Management System',
                'Warehouses, stock movements, suppliers, procurement, stock counts, and replenishment workflows for product operations teams.',
                'advanced',
                ['catalog', 'workflow', 'analytics', 'messaging', 'governance'],
                [
                    'Warehouse and stock location management',
                    'Procurement, adjustments, counts, and transfer workflows',
                    'Operational dashboards and exception reporting for stock health',
                ],
                [
                    self::resource('Warehouse', 'Warehouse', 'Storage sites, fulfillment centers, and managed inventory locations.'),
                    self::resource('InventorySku', 'Inventory SKU', 'Trackable stock keeping units with product and costing metadata.'),
                    self::resource('SupplierAccount', 'Supplier Account', 'Suppliers, vendors, and procurement contact records.'),
                    self::resource('PurchaseOrder', 'Purchase Order', 'Incoming procurement orders and replenishment batches.'),
                    self::resource('StockMovement', 'Stock Movement', 'Inbound, outbound, and internal stock movement records.'),
                    self::resource('StockCountSession', 'Stock Count Session', 'Cycle counts, audits, and reconciliation sessions.'),
                    self::resource('StockAdjustment', 'Stock Adjustment', 'Manual inventory corrections with justification and audit context.'),
                    self::resource('ReorderRule', 'Reorder Rule', 'Thresholds and replenishment rules for automated stock decisions.'),
                ],
                ['inventory-core', 'inventory-procurement', 'inventory-analytics'],
                120,
                ['inventory', 'operations', 'warehouse', 'erp']
            ),
            self::starterDefinition(
                'point-of-sale',
                'Point Of Sale System',
                'Retail checkout, receipts, cash drawer sessions, loyalty members, terminal operations, and payment-linked workflows for in-store sales.',
                'advanced',
                ['catalog', 'workflow', 'payments', 'analytics', 'messaging', 'governance'],
                [
                    'Retail checkout and terminal session tracking',
                    'Sales, returns, drawer balancing, and payment reconciliation',
                    'Loyalty and receipt workflows connected to analytics',
                ],
                [
                    self::resource('PosTerminal', 'POS Terminal', 'Physical or virtual checkout terminals used by store staff.'),
                    self::resource('PosSale', 'POS Sale', 'Completed point-of-sale transactions and customer checkout events.'),
                    self::resource('PosSaleLine', 'POS Sale Line', 'Line items belonging to retail sales and returns.'),
                    self::resource('CashDrawerSession', 'Cash Drawer Session', 'Open/close cash sessions, floats, and balancing snapshots.'),
                    self::resource('LoyaltyMember', 'Loyalty Member', 'Retail loyalty customers and tracked benefits.'),
                    self::resource('ReceiptTemplate', 'Receipt Template', 'Branded printable or digital receipt layouts.'),
                    self::resource('StoreLocation', 'Store Location', 'Physical branches or pop-up sales locations.'),
                ],
                ['pos-retail', 'pos-payments', 'pos-operations'],
                96,
                ['retail', 'pos', 'checkout', 'store']
            ),
            self::starterDefinition(
                'crm-sales',
                'CRM And Sales Pipeline',
                'Accounts, leads, deals, follow-ups, sales stages, and customer success tracking for commercial teams.',
                'standard',
                ['workflow', 'messaging', 'analytics', 'governance'],
                [
                    'Lead capture, pipeline stages, and opportunity management',
                    'Relationship notes, follow-ups, and customer health workflows',
                    'Commercial dashboards and account-level reporting',
                ],
                [
                    self::resource('LeadRecord', 'Lead Record', 'Inbound prospects and qualification records.'),
                    self::resource('DealPipeline', 'Deal Pipeline', 'Commercial opportunities progressing across sales stages.'),
                    self::resource('AccountContact', 'Account Contact', 'Key stakeholders linked to accounts or opportunities.'),
                    self::resource('SalesActivity', 'Sales Activity', 'Calls, meetings, demos, and other recorded commercial interactions.'),
                    self::resource('SuccessPlaybook', 'Success Playbook', 'Customer success guidance, checklists, and expansion milestones.'),
                ],
                ['crm-pipeline', 'crm-accounts', 'crm-success'],
                90,
                ['crm', 'sales', 'pipeline', 'accounts']
            ),
            self::starterDefinition(
                'helpdesk-support',
                'Helpdesk And Support',
                'Ticketing, SLAs, response templates, issue categories, escalation handling, and knowledge operations for support teams.',
                'standard',
                ['workflow', 'messaging', 'trust', 'analytics', 'governance'],
                [
                    'Incident and support ticket intake',
                    'SLA tracking, escalations, canned replies, and review queues',
                    'Support metrics, trust signals, and customer issue analytics',
                ],
                [
                    self::resource('SupportQueue', 'Support Queue', 'Queues and routing buckets for incoming tickets or support work.'),
                    self::resource('SupportTicket', 'Support Ticket', 'Customer issues, service requests, and tracked support cases.'),
                    self::resource('SlaPolicy', 'SLA Policy', 'Response and resolution targets for service operations.'),
                    self::resource('ResponseTemplate', 'Response Template', 'Reusable support responses and operational messages.'),
                    self::resource('EscalationRule', 'Escalation Rule', 'Escalation policies that route or alert on delayed work.'),
                ],
                ['support-core', 'support-escalations', 'support-knowledge'],
                84,
                ['support', 'helpdesk', 'tickets', 'service']
            ),
            self::starterDefinition(
                'learning-platform',
                'Learning And Training Platform',
                'Courses, schedules, cohorts, trainers, assessments, enrollments, and learning operations for education or internal training.',
                'advanced',
                ['learning', 'content', 'workflow', 'analytics', 'governance'],
                [
                    'Course catalog and training event delivery',
                    'Cohorts, trainer assignments, enrollments, and completion tracking',
                    'Learning analytics and curriculum operations',
                ],
                [
                    self::resource('LearningPath', 'Learning Path', 'Sequenced learning pathways and structured course bundles.'),
                    self::resource('CohortGroup', 'Cohort Group', 'Cohort-based enrolment groups and scheduled learning runs.'),
                    self::resource('TrainerProfile', 'Trainer Profile', 'Internal or external trainers, facilitators, and assessors.'),
                    self::resource('AssessmentItem', 'Assessment Item', 'Knowledge checks, assessments, and evaluation records.'),
                    self::resource('CertificateTemplate', 'Certificate Template', 'Completion certificate templates and issue rules.'),
                ],
                ['learning-catalog', 'learning-cohorts', 'learning-assessments'],
                88,
                ['learning', 'lms', 'training', 'education']
            ),
            self::starterDefinition(
                'clinic-management',
                'Clinic Management System',
                'Appointments, patient records, staff scheduling, service packages, and operational workflows for clinics or practice teams.',
                'advanced',
                ['workflow', 'messaging', 'analytics', 'governance', 'content'],
                [
                    'Patient intake and scheduled appointment operations',
                    'Clinical service catalog, care notes, and treatment follow-ups',
                    'Scheduling, reminders, and service delivery analytics',
                ],
                [
                    self::resource('PatientRecord', 'Patient Record', 'Managed patient or client health-service records.'),
                    self::resource('AppointmentSlot', 'Appointment Slot', 'Bookable appointments, clinics, and scheduling windows.'),
                    self::resource('PractitionerProfile', 'Practitioner Profile', 'Doctors, nurses, therapists, or clinical service providers.'),
                    self::resource('CarePlan', 'Care Plan', 'Tracked care plans, treatment sequences, and review steps.'),
                    self::resource('ServicePackage', 'Service Package', 'Clinical services or bundled treatment offerings.'),
                ],
                ['clinic-appointments', 'clinic-care', 'clinic-operations'],
                72,
                ['clinic', 'healthcare', 'appointments', 'operations']
            ),
            self::starterDefinition(
                'school-management',
                'School Management System',
                'Students, classes, attendance, notices, assignments, parents, and school-wide operational records.',
                'advanced',
                ['learning', 'content', 'workflow', 'messaging', 'analytics', 'governance'],
                [
                    'Student lifecycle and class administration',
                    'Notices, attendance, assignments, and timetable workflows',
                    'Parent-facing messaging and school operations analytics',
                ],
                [
                    self::resource('StudentProfile', 'Student Profile', 'Student records and profile-level school data.'),
                    self::resource('ClassRoom', 'Class Room', 'Teaching groups, classes, and timetable anchors.'),
                    self::resource('AttendanceSession', 'Attendance Session', 'Attendance rollups and status records by session.'),
                    self::resource('GuardianContact', 'Guardian Contact', 'Parents or guardians linked to student records.'),
                    self::resource('AssignmentBoard', 'Assignment Board', 'Assignments, homework, and tracked class tasks.'),
                ],
                ['school-academics', 'school-attendance', 'school-communications'],
                90,
                ['school', 'education', 'students', 'administration']
            ),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function loadJsonDefinitions(string $rootPath): array
    {
        $directory = $rootPath . '/blueprints/starters/apps';
        if (!is_dir($directory)) {
            return [];
        }

        $results = [];
        foreach (glob($directory . '/*.json') ?: [] as $path) {
            $decoded = json_decode((string)file_get_contents($path), true);
            if (!is_array($decoded)) {
                continue;
            }

            $definition = self::normalizeStarterDefinition($decoded);
            if ($definition !== null) {
                $results[] = $definition;
            }
        }

        return $results;
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function normalizeStarterDefinition(array $input): ?array
    {
        $key = ConsoleSupport::kebab((string)($input['key'] ?? ''));
        if ($key === '') {
            return null;
        }

        $title = trim((string)($input['title'] ?? $key));
        $summary = trim((string)($input['summary'] ?? ''));
        $preset = trim((string)($input['preset'] ?? 'standard')) ?: 'standard';

        $resources = [];
        foreach (array_values(is_array($input['resources'] ?? null) ? $input['resources'] : []) as $resource) {
            if (!is_array($resource)) {
                continue;
            }

            $name = ConsoleSupport::studly((string)($resource['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            $resources[] = self::resource(
                $name,
                trim((string)($resource['label'] ?? self::labelFromName($name))),
                trim((string)($resource['summary'] ?? 'Custom starter resource loaded from JSON definition.')),
                trim((string)($resource['group'] ?? 'generated')) ?: 'generated'
            );
        }

        return [
            'key' => $key,
            'title' => $title,
            'summary' => $summary,
            'preset' => $preset,
            'modules' => array_values(array_filter(
                array_map('strval', is_array($input['modules'] ?? null) ? $input['modules'] : []),
                static fn (string $value): bool => trim($value) !== ''
            )),
            'operations' => array_values(array_filter(
                array_map('strval', is_array($input['operations'] ?? null) ? $input['operations'] : []),
                static fn (string $value): bool => trim($value) !== ''
            )),
            'resources' => $resources,
            'sample_packs' => array_values(array_filter(
                array_map('strval', is_array($input['sample_packs'] ?? null) ? $input['sample_packs'] : []),
                static fn (string $value): bool => trim($value) !== ''
            )),
            'default_sample_count' => max(0, (int)($input['default_sample_count'] ?? 48)),
            'tags' => array_values(array_filter(
                array_map('strval', is_array($input['tags'] ?? null) ? $input['tags'] : []),
                static fn (string $value): bool => trim($value) !== ''
            )),
        ];
    }

    /**
     * @param array<int, string> $modules
     * @param array<int, string> $operations
     * @param array<int, array<string, mixed>> $resources
     * @param array<int, string> $samplePacks
     * @param array<int, string> $tags
     * @return array<string, mixed>
     */
    private static function starterDefinition(
        string $key,
        string $title,
        string $summary,
        string $preset,
        array $modules,
        array $operations,
        array $resources,
        array $samplePacks,
        int $defaultSampleCount,
        array $tags
    ): array {
        return [
            'key' => ConsoleSupport::kebab($key),
            'title' => trim($title),
            'summary' => trim($summary),
            'preset' => trim($preset) !== '' ? trim($preset) : 'standard',
            'modules' => array_values($modules),
            'operations' => array_values($operations),
            'resources' => array_values($resources),
            'sample_packs' => array_values($samplePacks),
            'default_sample_count' => max(0, $defaultSampleCount),
            'tags' => array_values($tags),
        ];
    }

    /**
     * Create a normalized resource definition that starter blueprints can reuse.
     *
     * @return StarterResource
     */
    public static function resource(string $name, string $label, string $summary, string $group = 'generated'): array
    {
        return [
            'name' => ConsoleSupport::studly($name),
            'label' => trim($label),
            'group' => trim(ConsoleSupport::snake($group)) !== '' ? ConsoleSupport::snake($group) : 'generated',
            'item_type' => ConsoleSupport::studly($name),
            'summary' => trim($summary),
        ];
    }

    private static function labelFromName(string $name): string
    {
        return trim((string)(preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', ConsoleSupport::studly($name)) ?? $name));
    }

    private static function resourceKey(string $name): string
    {
        return strtolower(ConsoleSupport::studly($name));
    }
}
