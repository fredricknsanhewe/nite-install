<?php
namespace App\Support;

use App\Config\Database;
use PDO;

/**
 * Installs row-level snapshots for recoverable application data. The database
 * owns the capture so new models and generated resources cannot bypass it.
 */
final class RecoveryAuditInstaller
{
    /** @var array<int, string> */
    private const EXCLUDED_TABLES = [
        'app_console_migrations', 'auth_login_attempts', 'data_change_logs',
        'mail_queue', 'media_assets', 'media_asset_versions', 'password_reset_tokens', 'permissions', 'rbac_group_members',
        'rbac_group_permission_rules', 'rbac_groups', 'role_permission_rules',
        'system_audit_logs', 'user_password_history', 'user_permission_overrides', 'users',
    ];

    public static function install(PDO $connection): void
    {
        if (!self::tableExists($connection, 'data_change_logs')) {
            return;
        }

        $tables = self::recoverableTables($connection);
        if (Database::driver() === 'pgsql') {
            self::installPostgres($connection, $tables);
            return;
        }

        self::installMysql($connection, $tables);
    }

    /**
     * @return array<string, array{primary_key: string, columns: array<string, string>}>
     */
    public static function recoverableTables(PDO $connection): array
    {
        $tableRows = Database::driver() === 'pgsql'
            ? $connection->query("SELECT table_name FROM information_schema.tables WHERE table_schema = current_schema() AND table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN)
            : $connection->query("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN);

        $result = [];
        foreach ($tableRows ?: [] as $table) {
            $table = (string)$table;
            if ($table === '' || in_array($table, self::EXCLUDED_TABLES, true)) {
                continue;
            }

            $primaryKey = self::singlePrimaryKey($connection, $table);
            if ($primaryKey === null) {
                continue;
            }

            $columns = self::columns($connection, $table);
            if (!isset($columns[$primaryKey])) {
                continue;
            }
            $result[$table] = ['primary_key' => $primaryKey, 'columns' => $columns];
        }

        ksort($result);
        return $result;
    }

    private static function installPostgres(PDO $connection, array $tables): void
    {
        $connection->exec(<<<'SQL'
CREATE OR REPLACE FUNCTION app_recovery_audit_row()
RETURNS trigger AS $$
DECLARE
    before_snapshot JSONB := '{}'::JSONB;
    after_snapshot JSONB := '{}'::JSONB;
    restorable_snapshot JSONB := '{}'::JSONB;
    row_action VARCHAR(20);
BEGIN
    IF COALESCE(current_setting('app.recovery_audit_suppressed', true), '') = '1' THEN
        IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'INSERT' THEN
        after_snapshot := to_jsonb(NEW);
        restorable_snapshot := after_snapshot;
        row_action := 'create';
    ELSIF TG_OP = 'UPDATE' THEN
        before_snapshot := to_jsonb(OLD);
        after_snapshot := to_jsonb(NEW);
        restorable_snapshot := before_snapshot;
        row_action := 'update';
    ELSE
        before_snapshot := to_jsonb(OLD);
        restorable_snapshot := before_snapshot;
        row_action := 'delete';
    END IF;

    SELECT COALESCE(jsonb_object_agg(key, value), '{}'::JSONB)
      INTO before_snapshot
      FROM jsonb_each(before_snapshot)
     WHERE key !~* '(password|token|secret)';
    SELECT COALESCE(jsonb_object_agg(key, value), '{}'::JSONB)
      INTO after_snapshot
      FROM jsonb_each(after_snapshot)
     WHERE key !~* '(password|token|secret)';
    SELECT COALESCE(jsonb_object_agg(key, value), '{}'::JSONB)
      INTO restorable_snapshot
      FROM jsonb_each(restorable_snapshot)
     WHERE key !~* '(password|token|secret)';

    INSERT INTO data_change_logs (
        table_name, record_id, record_slug, record_title, action, change_scope,
        before_json, after_json, diff_json, metadata_json, restorable_json
    ) VALUES (
        TG_TABLE_NAME,
        COALESCE(after_snapshot ->> TG_ARGV[0], before_snapshot ->> TG_ARGV[0], ''),
        COALESCE(after_snapshot ->> 'slug', before_snapshot ->> 'slug'),
        COALESCE(after_snapshot ->> 'title', after_snapshot ->> 'name', before_snapshot ->> 'title', before_snapshot ->> 'name'),
        row_action,
        'data',
        before_snapshot,
        after_snapshot,
        '{}'::JSONB,
        jsonb_build_object('source', 'database_trigger', 'primary_key', TG_ARGV[0]),
        restorable_snapshot
    );

    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
SQL);

        foreach ($tables as $table => $definition) {
            $quotedTable = self::quotePostgres($table);
            $connection->exec('DROP TRIGGER IF EXISTS nite_recovery_audit ON ' . $quotedTable);
            $connection->exec(
                'CREATE TRIGGER nite_recovery_audit AFTER INSERT OR UPDATE OR DELETE ON ' . $quotedTable
                . ' FOR EACH ROW EXECUTE FUNCTION app_recovery_audit_row(' . $connection->quote($definition['primary_key']) . ')'
            );
        }
    }

    private static function installMysql(PDO $connection, array $tables): void
    {
        foreach ($tables as $table => $definition) {
            $columns = array_filter(
                array_keys($definition['columns']),
                static fn (string $column): bool => preg_match('/password|token|secret/i', $column) !== 1
            );
            if ($columns === []) {
                continue;
            }

            foreach (['insert' => 'INSERT', 'update' => 'UPDATE', 'delete' => 'DELETE'] as $action => $operation) {
                $trigger = self::mysqlTriggerName($table, $action);
                $connection->exec('DROP TRIGGER IF EXISTS ' . self::quoteMysql($trigger));
                $old = self::mysqlJson('OLD', $columns);
                $new = self::mysqlJson('NEW', $columns);
                $before = $action === 'insert' ? 'JSON_OBJECT()' : $old;
                $after = $action === 'delete' ? 'JSON_OBJECT()' : $new;
                $restorable = $action === 'insert' ? $new : $old;
                $record = $action === 'delete' ? 'OLD' : 'NEW';
                $slug = in_array('slug', $columns, true) ? $record . '.`slug`' : 'NULL';
                $labelColumn = in_array('title', $columns, true) ? 'title' : (in_array('name', $columns, true) ? 'name' : '');
                $title = $labelColumn === '' ? 'NULL' : $record . '.`' . $labelColumn . '`';
                $primaryKey = str_replace("'", "''", $definition['primary_key']);

                $connection->exec(
                    'CREATE TRIGGER ' . self::quoteMysql($trigger)
                    . ' AFTER ' . $operation . ' ON ' . self::quoteMysql($table)
                    . ' FOR EACH ROW BEGIN '
                    . 'IF COALESCE(@nite_recovery_audit_suppressed, 0) = 0 THEN '
                    . 'INSERT INTO data_change_logs (table_name, record_id, record_slug, record_title, action, change_scope, before_json, after_json, diff_json, metadata_json, restorable_json) VALUES ('
                    . $connection->quote($table) . ', CAST(' . $record . '.`' . $definition['primary_key'] . '` AS CHAR), ' . $slug . ', ' . $title . ', '
                    . $connection->quote($action === 'insert' ? 'create' : $action) . ", 'data', "
                    . $before . ', ' . $after . ", JSON_OBJECT(), JSON_OBJECT('source', 'database_trigger', 'primary_key', '" . $primaryKey . "'), " . $restorable
                    . '); END IF; END'
                );
            }
        }
    }

    /** @return array<string, string> */
    private static function columns(PDO $connection, string $table): array
    {
        $sql = Database::driver() === 'pgsql'
            ? 'SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = :table ORDER BY ordinal_position'
            : 'SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = :table ORDER BY ordinal_position';
        $statement = $connection->prepare($sql);
        $statement->execute([':table' => $table]);
        $columns = [];
        foreach ($statement->fetchAll() as $row) {
            $columns[(string)$row['column_name']] = strtolower((string)$row['data_type']);
        }
        return $columns;
    }

    private static function singlePrimaryKey(PDO $connection, string $table): ?string
    {
        $sql = Database::driver() === 'pgsql'
            ? "SELECT kcu.column_name FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage kcu ON kcu.constraint_name = tc.constraint_name AND kcu.table_schema = tc.table_schema WHERE tc.table_schema = current_schema() AND tc.table_name = :table AND tc.constraint_type = 'PRIMARY KEY' ORDER BY kcu.ordinal_position"
            : "SELECT kcu.column_name FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage kcu ON kcu.constraint_name = tc.constraint_name AND kcu.table_schema = tc.table_schema AND kcu.table_name = tc.table_name WHERE tc.table_schema = DATABASE() AND tc.table_name = :table AND tc.constraint_type = 'PRIMARY KEY' ORDER BY kcu.ordinal_position";
        $statement = $connection->prepare($sql);
        $statement->execute([':table' => $table]);
        $columns = $statement->fetchAll(PDO::FETCH_COLUMN);
        return count($columns) === 1 ? (string)$columns[0] : null;
    }

    private static function tableExists(PDO $connection, string $table): bool
    {
        $sql = Database::driver() === 'pgsql'
            ? 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = :table'
            : 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :table';
        $statement = $connection->prepare($sql);
        $statement->execute([':table' => $table]);
        return (int)$statement->fetchColumn() > 0;
    }

    /** @param array<int, string> $columns */
    private static function mysqlJson(string $record, array $columns): string
    {
        $pairs = [];
        foreach ($columns as $column) {
            $pairs[] = "'" . str_replace("'", "''", $column) . "', " . $record . '.`' . str_replace('`', '``', $column) . '`';
        }
        return 'JSON_OBJECT(' . implode(', ', $pairs) . ')';
    }

    private static function mysqlTriggerName(string $table, string $action): string
    {
        return substr('nite_recovery_' . $action . '_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $table), 0, 64);
    }

    private static function quotePostgres(string $identifier): string
    {
        return '"' . str_replace('"', '""', $identifier) . '"';
    }

    private static function quoteMysql(string $identifier): string
    {
        return '`' . str_replace('`', '``', $identifier) . '`';
    }
}
