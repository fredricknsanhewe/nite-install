<?php
namespace App\Support;

use RuntimeException;

final class DemoFrontendBuilder
{
    /**
     * @return array<string, mixed>
     */
    public function build(string $targetPath, ?string $projectSlug = null): array
    {
        $targetPath = rtrim(str_replace('\\', '/', $targetPath), '/');
        if ($targetPath === '' || !is_dir($targetPath)) {
            throw new RuntimeException('Target application path was not found: ' . $targetPath);
        }

        $projectSlug = $projectSlug !== null ? trim($projectSlug) : null;
        $blueprintPath = $this->blueprintPath($targetPath, $projectSlug);
        if (!is_file($blueprintPath)) {
            throw new RuntimeException('Blueprint file was not found: ' . $blueprintPath);
        }

        $payload = json_decode((string)file_get_contents($blueprintPath), true);
        if (!is_array($payload)) {
            throw new RuntimeException('Blueprint file did not contain valid JSON: ' . $blueprintPath);
        }

        $frontendData = $this->frontendData($payload, $projectSlug);
        $theme = $this->themeFor($frontendData);
        $outputDir = $this->outputDirectory($targetPath, $projectSlug);
        $this->ensureDirectory($outputDir);

        $indexPath = $outputDir . '/index.html';
        $stylesPath = $outputDir . '/styles.css';
        $scriptPath = $outputDir . '/app.js';

        $this->writeFile($stylesPath, $this->styles($theme));
        $this->writeFile($scriptPath, $this->script());
        $this->writeFile($indexPath, $this->index($frontendData));

        return [
            'target' => str_replace('/', DIRECTORY_SEPARATOR, $targetPath),
            'project' => $projectSlug,
            'blueprint' => str_replace('/', DIRECTORY_SEPARATOR, $blueprintPath),
            'output_directory' => str_replace('/', DIRECTORY_SEPARATOR, $outputDir),
            'demo_path' => $projectSlug === null ? '/demo/' : '/demo/' . rawurlencode($projectSlug) . '/',
            'files' => [
                str_replace('/', DIRECTORY_SEPARATOR, $indexPath),
                str_replace('/', DIRECTORY_SEPARATOR, $stylesPath),
                str_replace('/', DIRECTORY_SEPARATOR, $scriptPath),
            ],
        ];
    }

    private function blueprintPath(string $targetPath, ?string $projectSlug): string
    {
        if ($projectSlug === null || $projectSlug === '') {
            return $targetPath . '/app.blueprint.json';
        }

        return $targetPath . '/projects/' . $projectSlug . '/app.blueprint.json';
    }

    private function outputDirectory(string $targetPath, ?string $projectSlug): string
    {
        if ($projectSlug === null || $projectSlug === '') {
            return $targetPath . '/public/demo';
        }

        return $targetPath . '/public/demo/' . rawurlencode($projectSlug);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function frontendData(array $payload, ?string $projectSlug): array
    {
        $application = is_array($payload['application'] ?? null) ? $payload['application'] : [];
        $preset = is_array($payload['preset'] ?? null) ? $payload['preset'] : [];
        $starter = is_array($payload['starter'] ?? null) ? $payload['starter'] : [];
        $modules = array_values(array_filter(
            is_array($payload['focus_modules'] ?? null) ? $payload['focus_modules'] : [],
            static fn (mixed $item): bool => is_array($item)
        ));
        $resources = array_values(array_filter(
            is_array($payload['generated_resources'] ?? null) ? $payload['generated_resources'] : [],
            static fn (mixed $item): bool => is_array($item)
        ));
        $samplePacks = array_values(array_filter(
            is_array($starter['sample_packs'] ?? null) ? $starter['sample_packs'] : [],
            static fn (mixed $item): bool => is_array($item)
        ));
        $starterKey = trim((string)($starter['key'] ?? ''));
        $presetKey = trim((string)($preset['key'] ?? 'basic'));
        $appName = trim((string)($application['name'] ?? 'Nite Website'));
        $starterTitle = trim((string)($starter['title'] ?? ''));
        $presetTitle = trim((string)($preset['title'] ?? 'Starter'));
        $projectLabel = $projectSlug === null || $projectSlug === '' ? 'Root application' : 'Project application';
        $summary = $this->publicCopy(trim((string)($starter['summary'] ?? $preset['summary'] ?? 'Build production-shaped apps with Nite.')));

        $storyPoints = [
            'Launch around ' . count($modules) . ' focused content and service areas from day one.',
            'Keep pages, stories, and reusable sections aligned across one shared website surface.',
            'Extend the starter confidently without losing the public-facing narrative.',
        ];

        $editorialNotes = [
            'The launch surface keeps public content, services, and reusable resources aligned from one coherent story.',
            'This starter already ships with ' . count($resources) . ' structured sections that can be refined instead of created from scratch.',
            'Sample content sets are included to help teams shape the website quickly before custom edits begin.',
        ];

        $signalCards = [
            ['label' => 'Focus modules', 'value' => (string)count($modules)],
            ['label' => 'Generated resources', 'value' => (string)count($resources)],
            ['label' => 'Sample packs', 'value' => (string)count($samplePacks)],
            ['label' => 'Launch lanes', 'value' => '3'],
        ];

        $quickLinks = [
            ['label' => 'Read the story', 'href' => '#story'],
            ['label' => 'Browse content', 'href' => '#live'],
            ['label' => 'View sections', 'href' => '#build'],
            ['label' => 'See the launch plan', 'href' => '#launch'],
        ];

        return [
            'application_name' => $appName === '' ? 'Nite Website' : $appName,
            'application_url' => trim((string)($application['url'] ?? 'http://127.0.0.1:8185')),
            'mode_label' => $projectLabel,
            'project_slug' => $projectSlug ?? '',
            'starter_key' => $starterKey,
            'starter_title' => $starterTitle,
            'starter_summary' => trim((string)($starter['summary'] ?? '')),
            'preset_key' => $presetKey,
            'preset_title' => $presetTitle,
            'preset_summary' => trim((string)($preset['summary'] ?? '')),
            'headline' => $this->headlineFor($appName, $starterTitle, $presetTitle),
            'eyebrow' => trim($projectLabel . ' | ' . ($starterTitle !== '' ? $starterTitle : $presetTitle)),
            'summary' => $summary,
            'lead' => $this->leadFor($summary, count($resources), count($modules)),
            'story_points' => array_values(array_filter($storyPoints, static fn (string $item): bool => trim($item) !== '')),
            'signal_cards' => $signalCards,
            'quick_links' => $quickLinks,
            'editorial_notes' => $editorialNotes,
            'modules' => array_map(function (array $module): array {
                $entities = array_values(array_filter(
                    array_map('strval', is_array($module['entities'] ?? null) ? $module['entities'] : []),
                    static fn (string $item): bool => trim($item) !== ''
                ));

                return [
                    'key' => trim((string)($module['key'] ?? 'module')),
                    'title' => trim((string)($module['title'] ?? 'Module')),
                    'summary' => $this->publicCopy(trim((string)($module['summary'] ?? ''))),
                    'entities' => array_slice($entities, 0, 5),
                ];
            }, array_slice($modules, 0, 6)),
            'resources' => array_map(function (array $resource): array {
                return [
                    'name' => trim((string)($resource['name'] ?? 'Resource')),
                    'label' => trim((string)($resource['label'] ?? $resource['name'] ?? 'Resource')),
                    'summary' => $this->publicCopy(trim((string)($resource['summary'] ?? ''))),
                    'public_path' => trim((string)($resource['public_path'] ?? '')),
                    'admin_path' => trim((string)($resource['admin_path'] ?? '')),
                ];
            }, array_slice($resources, 0, 9)),
            'sample_packs' => array_map(function (array $pack): array {
                return [
                    'key' => trim((string)($pack['key'] ?? 'sample-pack')),
                    'title' => trim((string)($pack['title'] ?? 'Sample pack')),
                ];
            }, array_slice($samplePacks, 0, 4)),
            'team_lanes' => [
                [
                    'title' => 'Content team',
                    'summary' => 'Plan pages, publish stories, and keep the public narrative fresh without leaving the product surface.',
                ],
                [
                    'title' => 'Operations team',
                    'summary' => 'Manage inventory, bookings, requests, or fulfilment using the same structured data backbone.',
                ],
                [
                    'title' => 'Leadership view',
                    'summary' => 'Review the live offering, sample packs, and launch scope as one coherent system story.',
                ],
            ],
            'collection_endpoints' => [
                'pages' => '/api/v1/pages?format=json',
                'news' => '/api/v1/news?format=json',
                'resources' => '/api/v1/resources?format=json',
            ],
        ];
    }

    /**
     * @param array<string, mixed> $frontendData
     * @return array<string, string>
     */
    private function themeFor(array $frontendData): array
    {
        $key = (string)($frontendData['starter_key'] ?: $frontendData['preset_key'] ?: 'basic');
        $themes = [
            'basic' => ['ink' => '#18324d', 'accent' => '#1f8fff', 'canvas' => '#f6f2e8', 'paper' => '#fffdf8'],
            'standard' => ['ink' => '#15342d', 'accent' => '#0b9168', 'canvas' => '#eff6ed', 'paper' => '#fbfffb'],
            'advanced' => ['ink' => '#2a1f46', 'accent' => '#d76921', 'canvas' => '#f8ede4', 'paper' => '#fffbf8'],
            'website-management' => ['ink' => '#173650', 'accent' => '#0e9b84', 'canvas' => '#eaf8f5', 'paper' => '#fbfffd'],
            'inventory-management' => ['ink' => '#2f3e1f', 'accent' => '#dd6f0c', 'canvas' => '#fbf5e7', 'paper' => '#fffdf7'],
            'point-of-sale' => ['ink' => '#3b2028', 'accent' => '#fb6240', 'canvas' => '#fff0e8', 'paper' => '#fffaf7'],
            'crm-sales' => ['ink' => '#163253', 'accent' => '#0087ff', 'canvas' => '#edf6ff', 'paper' => '#fbfdff'],
            'helpdesk-support' => ['ink' => '#21324a', 'accent' => '#5c67ff', 'canvas' => '#f2f1ff', 'paper' => '#fdfcff'],
            'learning-platform' => ['ink' => '#2b2e58', 'accent' => '#ef7d00', 'canvas' => '#fff2e2', 'paper' => '#fffdf8'],
            'clinic-management' => ['ink' => '#104049', 'accent' => '#08afa1', 'canvas' => '#ebfbf8', 'paper' => '#fbfffe'],
            'school-management' => ['ink' => '#3b2b17', 'accent' => '#c79700', 'canvas' => '#fff7dc', 'paper' => '#fffdf7'],
        ];

        return $themes[$key] ?? $themes['basic'];
    }

    /**
     * @param array<string, mixed> $frontendData
     */
    private function index(array $frontendData): string
    {
        $title = $this->escape((string)$frontendData['application_name']);
        $headline = $this->escape((string)$frontendData['headline']);
        $eyebrow = $this->escape((string)$frontendData['eyebrow']);
        $summary = $this->escape((string)$frontendData['summary']);
        $lead = $this->escape((string)$frontendData['lead']);

        $bootJson = json_encode([
            'frameworkUrl' => '/api/v1/framework?format=json',
            'pagesUrl' => (string)$frontendData['collection_endpoints']['pages'],
            'newsUrl' => (string)$frontendData['collection_endpoints']['news'],
            'resourcesUrl' => (string)$frontendData['collection_endpoints']['resources'],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if (!is_string($bootJson)) {
            throw new RuntimeException('Failed to encode demo bootstrap data.');
        }

        return <<<HTML
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{$title}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles.css">
</head>
<body>
    <div class="canvas-glow canvas-glow-a"></div>
    <div class="canvas-glow canvas-glow-b"></div>
    <div class="site-shell">
        <header class="site-header">
            <a class="brand-mark" href="#top">Nite</a>
            <nav class="main-nav">
                <a href="#story">Story</a>
                <a href="#live">Live Content</a>
                <a href="#build">Sections</a>
                <a href="#launch">Launch Plan</a>
            </nav>
            <a class="header-cta" href="#live">Explore now</a>
        </header>

        <main id="top">
            <section class="hero-grid">
                <div class="hero-copy">
                    <p class="eyebrow">{$eyebrow}</p>
                    <h1>{$headline}</h1>
                    <p class="summary">{$summary}</p>
                    <p class="lead">{$lead}</p>
                    <div class="hero-actions">{$this->renderQuickLinks((array)$frontendData['quick_links'])}</div>
                    <div class="signal-strip">{$this->renderSignalCards((array)$frontendData['signal_cards'])}</div>
                </div>
                <div class="hero-stage">
                    <div class="runtime-card">
                        <p class="runtime-kicker">Site snapshot</p>
                        <h2 id="statusTitle">Checking live content...</h2>
                        <p id="statusSummary">The homepage is reading published collections and rollout details from this app instance.</p>
                        <dl class="runtime-metrics">
                            <div><dt>Pages</dt><dd id="metricPages">...</dd></div>
                            <div><dt>Stories</dt><dd id="metricNews">...</dd></div>
                            <div><dt>Sections</dt><dd id="metricResources">...</dd></div>
                            <div><dt>Version</dt><dd id="metricVersion">...</dd></div>
                        </dl>
                    </div>
                    <div class="showcase-card">
                        <div class="showcase-bar">
                            <span></span><span></span><span></span>
                        </div>
                        <div class="showcase-body">
                            <p class="showcase-label">What this app comes with</p>
                            <div class="showcase-list">{$this->renderStoryPoints((array)$frontendData['story_points'])}</div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="editorial-band" id="story">
                <div class="band-copy">
                    <p class="section-kicker">Product narrative</p>
                    <h2>A starting website, not just a temporary demo shell.</h2>
                    <p>This frontend frames each Nite bootstrap as a usable launch surface. It reads the live application data behind the scenes and presents the generated product shape as a public-facing story instead of a raw technical checklist.</p>
                </div>
                <div class="module-ribbon">{$this->renderModules((array)$frontendData['modules'])}</div>
            </section>

            <section class="content-stage" id="live">
                <div class="section-heading">
                    <p class="section-kicker">Live collections</p>
                    <h2>Pages, news, and resources from the running app</h2>
                    <p>These rails are filled from the running application so each generated website reflects the live content state, not only its scaffold blueprint.</p>
                </div>
                <div class="content-columns">
                    <article class="content-column">
                        <div class="column-head">
                            <h3>Pages</h3>
                        </div>
                        <div class="content-list" id="pagesRail">
                            <p class="loading-copy">Loading seeded pages...</p>
                        </div>
                    </article>
                    <article class="content-column">
                        <div class="column-head">
                            <h3>News</h3>
                        </div>
                        <div class="content-list" id="newsRail">
                            <p class="loading-copy">Loading seeded posts...</p>
                        </div>
                    </article>
                    <article class="content-column">
                        <div class="column-head">
                            <h3>Resources</h3>
                        </div>
                        <div class="content-list" id="resourcesRail">
                            <p class="loading-copy">Loading seeded resources...</p>
                        </div>
                    </article>
                </div>
            </section>

            <section class="build-stage" id="build">
                <div class="section-heading">
                    <p class="section-kicker">Featured sections</p>
                    <h2>What visitors can browse across the site</h2>
                    <p>The website is organized into the same content areas the starter generated, but presented here as a visitor-facing experience rather than a raw system map.</p>
                </div>
                <div class="build-grid">
                    <div class="resource-wall">
                        {$this->renderResources((array)$frontendData['resources'])}
                    </div>
                    <aside class="build-sidebar">
                        <section class="sidebar-panel">
                            <h3>Experience tracks</h3>
                            <div class="sample-pack-list">{$this->renderSamplePacks((array)$frontendData['sample_packs'])}</div>
                        </section>
                        <section class="sidebar-panel">
                            <h3>Editorial notes</h3>
                            <ul class="note-list">{$this->renderNotes((array)$frontendData['editorial_notes'])}</ul>
                        </section>
                    </aside>
                </div>
            </section>

            <section class="access-stage" id="launch">
                <div class="section-heading">
                    <p class="section-kicker">Launch plan</p>
                    <h2>How teams can run this starter together</h2>
                    <p>Each starter is shaped for content, operations, and leadership teams to work from one coherent product surface without the homepage exposing system internals.</p>
                </div>
                <div class="access-grid">
                    <div class="account-wall">
                        {$this->renderTeamLanes((array)$frontendData['team_lanes'])}
                    </div>
                    <div class="access-panel">
                        <h3>Launch highlights</h3>
                        <div class="showcase-list">{$this->renderStoryPoints((array)$frontendData['story_points'])}</div>
                    </div>
                </div>
            </section>
        </main>

        <footer class="site-footer">
            <p>{$title} runs on Nite and is generated from a live bootstrap blueprint.</p>
            <a href="#top">Back to top</a>
        </footer>
    </div>
    <script>window.NITE_DEMO_BOOTSTRAP = {$bootJson};</script>
    <script src="./app.js"></script>
</body>
</html>
HTML;
    }

    /**
     * @param array<string, string> $theme
     */
    private function styles(array $theme): string
    {
        $ink = $theme['ink'];
        $accent = $theme['accent'];
        $canvas = $theme['canvas'];
        $paper = $theme['paper'];

        return <<<CSS
:root {
    --ink: {$ink};
    --accent: {$accent};
    --canvas: {$canvas};
    --paper: {$paper};
    --muted: color-mix(in srgb, var(--ink) 66%, white);
    --faint: rgba(15, 23, 42, 0.08);
    --edge: rgba(15, 23, 42, 0.14);
    --hero-shadow: 0 34px 80px rgba(15, 23, 42, 0.16);
    --soft-shadow: 0 18px 48px rgba(15, 23, 42, 0.1);
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    font-family: "Manrope", "Segoe UI", sans-serif;
    color: var(--ink);
    background:
        linear-gradient(180deg, rgba(255,255,255,0.74), rgba(255,255,255,0.92)),
        linear-gradient(135deg, var(--canvas), #fffdf8 60%);
    min-height: 100vh;
}

a {
    color: inherit;
    text-decoration: none;
}

.canvas-glow {
    position: fixed;
    width: 420px;
    height: 420px;
    border-radius: 50%;
    filter: blur(16px);
    opacity: 0.48;
    pointer-events: none;
    z-index: 0;
}

.canvas-glow-a {
    top: -140px;
    right: -120px;
    background: color-mix(in srgb, var(--accent) 22%, transparent);
}

.canvas-glow-b {
    bottom: -120px;
    left: -100px;
    background: color-mix(in srgb, var(--ink) 12%, transparent);
}

.site-shell {
    position: relative;
    z-index: 1;
    width: min(1240px, calc(100vw - 32px));
    margin: 0 auto;
    padding: 24px 0 64px;
}

.site-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 18px;
    border: 1px solid var(--edge);
    border-radius: 22px;
    background: rgba(255, 255, 255, 0.68);
    backdrop-filter: blur(18px);
    box-shadow: var(--soft-shadow);
    position: sticky;
    top: 14px;
    z-index: 20;
}

.brand-mark {
    font-family: "Fraunces", Georgia, serif;
    font-size: 1.4rem;
    font-weight: 700;
    letter-spacing: 0.02em;
}

.main-nav {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
    justify-content: center;
}

.main-nav a {
    color: var(--muted);
    font-size: 0.95rem;
}

.header-cta,
.hero-actions a,
.access-links a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 46px;
    padding: 0 18px;
    border-radius: 999px;
    border: 1px solid color-mix(in srgb, var(--accent) 18%, black 6%);
    background: var(--accent);
    color: white;
    font-weight: 700;
}

.hero-actions,
.access-links {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.hero-actions a:nth-child(n+2),
.access-links a:nth-child(n+2) {
    background: rgba(255, 255, 255, 0.86);
    color: var(--ink);
    border-color: var(--edge);
}

.hero-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(320px, 0.9fr);
    gap: 28px;
    margin-top: 26px;
}

.hero-copy,
.runtime-card,
.showcase-card,
.editorial-band,
.content-stage,
.build-stage,
.access-stage {
    background: rgba(255, 255, 255, 0.86);
    border: 1px solid var(--edge);
    box-shadow: var(--hero-shadow);
}

.hero-copy {
    border-radius: 34px;
    padding: 42px;
    position: relative;
    overflow: hidden;
}

.hero-copy::after {
    content: "";
    position: absolute;
    right: -40px;
    top: -36px;
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: color-mix(in srgb, var(--accent) 16%, transparent);
}

.eyebrow,
.section-kicker,
.runtime-kicker,
.showcase-label {
    margin: 0 0 12px;
    font-size: 0.8rem;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    color: color-mix(in srgb, var(--ink) 64%, white);
}

h1,
h2,
h3 {
    margin: 0;
    font-family: "Fraunces", Georgia, serif;
    line-height: 0.95;
}

h1 {
    font-size: clamp(3rem, 7vw, 5.6rem);
    max-width: 9ch;
}

h2 {
    font-size: clamp(2rem, 4vw, 3rem);
}

h3 {
    font-size: 1.22rem;
}

.summary {
    margin: 20px 0 0;
    max-width: 18ch;
    font-size: 1.18rem;
    line-height: 1.15;
    color: color-mix(in srgb, var(--ink) 88%, white);
}

.lead {
    margin: 18px 0 0;
    max-width: 62ch;
    color: var(--muted);
    line-height: 1.75;
}

.hero-actions {
    margin-top: 26px;
}

.signal-strip {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    margin-top: 28px;
}

.signal-card {
    padding: 14px 16px;
    border-radius: 18px;
    border: 1px solid var(--edge);
    background: rgba(255, 255, 255, 0.72);
}

.signal-card dt {
    margin: 0;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: color-mix(in srgb, var(--ink) 62%, white);
}

.signal-card dd {
    margin: 8px 0 0;
    font-size: 1.6rem;
    font-weight: 700;
}

.hero-stage {
    display: grid;
    gap: 18px;
}

.runtime-card,
.showcase-card,
.editorial-band,
.content-stage,
.build-stage,
.access-stage {
    border-radius: 30px;
    padding: 28px;
}

.runtime-card p,
.editorial-band p,
.content-stage p,
.build-stage p,
.access-stage p,
.resource-card p,
.module-card p,
.sample-pack p,
.content-item p,
.account-card p,
.command-chip p {
    color: var(--muted);
    line-height: 1.68;
}

.runtime-metrics {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
    margin: 22px 0 0;
}

.runtime-metrics div {
    padding: 14px;
    border-radius: 18px;
    background: color-mix(in srgb, var(--accent) 8%, white);
    border: 1px solid var(--edge);
}

.runtime-metrics dt {
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: color-mix(in srgb, var(--ink) 62%, white);
}

.runtime-metrics dd {
    margin: 10px 0 0;
    font-size: 1.45rem;
    font-weight: 700;
}

.showcase-card {
    padding: 0;
    overflow: hidden;
}

.showcase-bar {
    display: flex;
    gap: 8px;
    padding: 16px 18px 0;
}

.showcase-bar span {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: color-mix(in srgb, var(--ink) 20%, white);
}

.showcase-body {
    padding: 20px 22px 24px;
}

.showcase-list {
    display: grid;
    gap: 12px;
}

.showcase-item {
    padding: 14px 16px;
    border-radius: 18px;
    border: 1px solid var(--edge);
    background: rgba(255,255,255,0.8);
    font-weight: 600;
    line-height: 1.5;
}

.editorial-band,
.content-stage,
.build-stage,
.access-stage {
    margin-top: 26px;
}

.editorial-band {
    display: grid;
    grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
    gap: 22px;
}

.module-ribbon {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
}

.module-card,
.resource-card,
.sample-pack,
.content-item,
.account-card,
.command-chip {
    padding: 18px;
    border-radius: 22px;
    border: 1px solid var(--edge);
    background: rgba(255,255,255,0.78);
}

.module-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 12px;
}

.module-meta span {
    padding: 6px 10px;
    border-radius: 999px;
    background: color-mix(in srgb, var(--accent) 10%, white);
    font-size: 0.84rem;
}

.section-heading {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 18px;
}

.content-columns {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
}

.content-column {
    padding: 18px;
    border-radius: 24px;
    border: 1px solid var(--edge);
    background: rgba(255,255,255,0.72);
}

.column-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 12px;
}

.column-head a,
.resource-links a,
.site-footer a {
    color: var(--accent);
    font-weight: 700;
}

.content-list,
.resource-wall,
.sample-pack-list,
.command-stack {
    display: grid;
    gap: 12px;
}

.content-item h4,
.resource-card h4,
.sample-pack h4,
.account-card h4 {
    margin: 0 0 8px;
    font-size: 1.02rem;
    font-family: "Fraunces", Georgia, serif;
}

.content-item small,
.resource-card small,
.sample-pack small {
    display: inline-block;
    margin-top: 10px;
    color: color-mix(in srgb, var(--ink) 60%, white);
}

.build-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.2fr) minmax(280px, 0.8fr);
    gap: 18px;
}

.resource-wall {
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

.resource-links {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 12px;
}

.build-sidebar {
    display: grid;
    gap: 16px;
}

.sidebar-panel {
    padding: 20px;
    border-radius: 24px;
    border: 1px solid var(--edge);
    background: rgba(255,255,255,0.74);
}

.command-chip {
    font-family: "Courier New", monospace;
    font-size: 0.88rem;
    overflow-wrap: anywhere;
}

.note-list {
    margin: 12px 0 0;
    padding-left: 18px;
    color: var(--muted);
    line-height: 1.7;
}

.access-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.2fr) minmax(250px, 0.8fr);
    gap: 18px;
}

.account-wall {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
}

.credential {
    display: inline-block;
    margin-top: 12px;
    padding: 8px 12px;
    border-radius: 12px;
    background: color-mix(in srgb, var(--accent) 12%, white);
    border: 1px solid color-mix(in srgb, var(--accent) 24%, white);
    font-weight: 700;
}

.access-panel {
    padding: 20px;
    border-radius: 24px;
    border: 1px solid var(--edge);
    background: rgba(255,255,255,0.74);
}

.site-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-top: 24px;
    padding: 18px 4px 0;
    color: color-mix(in srgb, var(--ink) 70%, white);
}

.loading-copy,
.empty-copy {
    margin: 0;
    color: color-mix(in srgb, var(--ink) 60%, white);
}

.runtime-ok {
    color: #0d7d56;
}

.runtime-error {
    color: #b42318;
}

@media (max-width: 1080px) {
    .hero-grid,
    .editorial-band,
    .build-grid,
    .access-grid,
    .content-columns {
        grid-template-columns: 1fr;
    }

    .resource-wall,
    .account-wall,
    .module-ribbon {
        grid-template-columns: 1fr 1fr;
    }
}

@media (max-width: 760px) {
    .site-shell {
        width: min(100vw - 18px, 100%);
        padding-top: 14px;
    }

    .site-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .hero-copy,
    .runtime-card,
    .showcase-card,
    .editorial-band,
    .content-stage,
    .build-stage,
    .access-stage {
        border-radius: 24px;
        padding: 20px;
    }

    .signal-strip,
    .runtime-metrics,
    .resource-wall,
    .account-wall,
    .module-ribbon {
        grid-template-columns: 1fr;
    }

    h1 {
        max-width: none;
    }

    .site-footer {
        flex-direction: column;
        align-items: flex-start;
    }
}
CSS;
    }

    private function script(): string
    {
        return <<<'JS'
(function () {
    const boot = window.NITE_DEMO_BOOTSTRAP || {};
    const statusTitle = document.getElementById('statusTitle');
    const statusSummary = document.getElementById('statusSummary');
    const pagesNode = document.getElementById('metricPages');
    const newsNode = document.getElementById('metricNews');
    const resourcesNode = document.getElementById('metricResources');
    const versionNode = document.getElementById('metricVersion');

    function html(value) {
        return String(value == null ? '' : value)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function fetchJson(url) {
        return fetch(String(url || ''), { headers: { Accept: 'application/json' } })
            .then(function (response) {
                return response.text().then(function (text) {
                    let parsed = {};
                    try {
                        parsed = JSON.parse(text);
                    } catch {
                        parsed = {};
                    }
                    if (!response.ok) {
                        throw new Error('Request failed for ' + url + ' with HTTP ' + response.status);
                    }
                    return parsed;
                });
            });
    }

    function payloadItems(payload) {
        if (!payload || typeof payload !== 'object') {
            return [];
        }
        const data = payload.data;
        if (Array.isArray(data)) {
            return data;
        }
        if (Array.isArray(payload)) {
            return payload;
        }
        return [];
    }

    function renderCollection(targetId, items, label) {
        const target = document.getElementById(targetId);
        if (!target) {
            return;
        }

        if (!Array.isArray(items) || items.length === 0) {
            target.innerHTML = '<p class="empty-copy">No ' + html(label) + ' are seeded yet.</p>';
            return;
        }

        target.innerHTML = items.slice(0, 4).map(function (item) {
            const title = html(item.title || item.name || item.label || item.slug || 'Untitled');
            const summary = html(item.summary || item.description || item.body || 'Structured content from the running app.');
            const status = html(item.status || item.resource_type || item.post_type || 'live');
            return '<article class="content-item">'
                + '<h4>' + title + '</h4>'
                + '<p>' + summary + '</p>'
                + '<small>' + status + '</small>'
                + '</article>';
        }).join('');
    }

    Promise.all([
        fetchJson(boot.frameworkUrl || '/api/v1/framework?format=json'),
        fetchJson(boot.pagesUrl || '/api/v1/pages?format=json'),
        fetchJson(boot.newsUrl || '/api/v1/news?format=json'),
        fetchJson(boot.resourcesUrl || '/api/v1/resources?format=json'),
    ]).then(function (results) {
        const framework = results[0] || {};
        const version = framework.installed_version || framework.code_version || 'unknown';
        const pages = payloadItems(results[1]);
        const news = payloadItems(results[2]);
        const resources = payloadItems(results[3]);

        if (statusTitle) {
            statusTitle.textContent = 'The live site is ready';
            statusTitle.classList.add('runtime-ok');
        }
        if (statusSummary) {
            statusSummary.textContent = 'Published pages, stories, and sections were loaded from this app instance.';
        }
        if (pagesNode) {
            pagesNode.textContent = String(pages.length);
        }
        if (newsNode) {
            newsNode.textContent = String(news.length);
        }
        if (resourcesNode) {
            resourcesNode.textContent = String(resources.length);
        }
        if (versionNode) {
            versionNode.textContent = String(version);
        }

        renderCollection('pagesRail', pages, 'pages');
        renderCollection('newsRail', news, 'posts');
        renderCollection('resourcesRail', resources, 'resources');
    }).catch(function (error) {
        if (statusTitle) {
            statusTitle.textContent = 'Live content is temporarily unavailable';
            statusTitle.classList.add('runtime-error');
        }
        if (statusSummary) {
            statusSummary.textContent = String(error && error.message ? error.message : error);
        }
        renderCollection('pagesRail', [], 'pages');
        renderCollection('newsRail', [], 'posts');
        renderCollection('resourcesRail', [], 'resources');
    });
}());
JS;
    }

    private function headlineFor(string $appName, string $starterTitle, string $presetTitle): string
    {
        if ($starterTitle !== '') {
            return $appName . ' launches as a full ' . $starterTitle . ' website.';
        }

        return $appName . ' launches as a ' . $presetTitle . ' website.';
    }

    private function leadFor(string $summary, int $resourceCount, int $moduleCount): string
    {
        return $summary
            . ' This install already carries '
            . $resourceCount
            . ' generated starter resources across '
            . $moduleCount
            . ' focus modules, so the public surface and the content model start from the same system story.';
    }

    /**
     * @param array<int, array<string, string>> $links
     */
    private function renderQuickLinks(array $links): string
    {
        $html = [];
        foreach ($links as $link) {
            $label = $this->escape((string)($link['label'] ?? 'Open'));
            $href = $this->escape((string)($link['href'] ?? '#'));
            $html[] = '<a href="' . $href . '">' . $label . '</a>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, array<string, string>> $cards
     */
    private function renderSignalCards(array $cards): string
    {
        $html = [];
        foreach ($cards as $card) {
            $label = $this->escape((string)($card['label'] ?? 'Signal'));
            $value = $this->escape((string)($card['value'] ?? '0'));
            $html[] = '<dl class="signal-card"><dt>' . $label . '</dt><dd>' . $value . '</dd></dl>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, string> $points
     */
    private function renderStoryPoints(array $points): string
    {
        $html = [];
        foreach ($points as $point) {
            $text = $this->escape($point);
            $html[] = '<div class="showcase-item">' . $text . '</div>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, array<string, mixed>> $modules
     */
    private function renderModules(array $modules): string
    {
        if ($modules === []) {
            return '<p class="empty-copy">No focus modules were documented for this app.</p>';
        }

        $html = [];
        foreach ($modules as $module) {
            $title = $this->escape((string)($module['title'] ?? 'Module'));
            $summary = $this->escape((string)($module['summary'] ?? ''));
            $entities = array_values(array_filter(
                array_map(fn (mixed $item): string => $this->escape((string)$item), is_array($module['entities'] ?? null) ? $module['entities'] : []),
                static fn (string $item): bool => $item !== ''
            ));
            $entityHtml = $entities === []
                ? ''
                : '<div class="module-meta"><span>' . implode('</span><span>', $entities) . '</span></div>';
            $html[] = '<article class="module-card"><h3>' . $title . '</h3><p>' . $summary . '</p>' . $entityHtml . '</article>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, array<string, mixed>> $resources
     */
    private function renderResources(array $resources): string
    {
        if ($resources === []) {
            return '<p class="empty-copy">No featured sections were documented for this app yet.</p>';
        }

        $html = [];
        foreach ($resources as $resource) {
            $label = $this->escape((string)($resource['label'] ?? $resource['name'] ?? 'Resource'));
            $summary = $this->escape((string)($resource['summary'] ?? ''));
            $html[] = '<article class="resource-card"><h4>' . $label . '</h4><p>' . $summary . '</p></article>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, array<string, string>> $samplePacks
     */
    private function renderSamplePacks(array $samplePacks): string
    {
        if ($samplePacks === []) {
            return '<p class="empty-copy">This starter is currently using its core experience set only.</p>';
        }

        $html = [];
        foreach ($samplePacks as $pack) {
            $title = $this->escape((string)($pack['title'] ?? 'Sample pack'));
            $html[] = '<article class="sample-pack"><h4>' . $title . '</h4><p>Curated launch-ready sample content for this website track.</p></article>';
        }

        return implode('', $html);
    }

    /**
     * @param array<int, string> $notes
     */
    private function renderNotes(array $notes): string
    {
        if ($notes === []) {
            return '<li>Bootstrap notes were not provided for this app.</li>';
        }

        $items = array_map(fn (string $note): string => '<li>' . $this->escape($note) . '</li>', $notes);
        return implode('', $items);
    }

    /**
     * @param array<int, array<string, string>> $lanes
     */
    private function renderTeamLanes(array $lanes): string
    {
        $html = [];
        foreach ($lanes as $lane) {
            $title = $this->escape((string)($lane['title'] ?? 'Team lane'));
            $summary = $this->escape((string)($lane['summary'] ?? ''));
            $html[] = '<article class="account-card"><h4>' . $title . '</h4><p>' . $summary . '</p></article>';
        }

        return implode('', $html);
    }

    private function ensureDirectory(string $path): void
    {
        if (!is_dir($path) && !mkdir($path, 0777, true) && !is_dir($path)) {
            throw new RuntimeException('Failed to create directory: ' . $path);
        }
    }

    private function writeFile(string $path, string $contents): void
    {
        if (file_put_contents($path, $contents) === false) {
            throw new RuntimeException('Failed to write file: ' . $path);
        }
    }

    private function publicCopy(string $value): string
    {
        if ($value === '') {
            return '';
        }

        return str_ireplace(
            ['admin management', 'admin API', 'RBAC', 'CRUD', 'bootstrap responses', 'backend'],
            ['team management', 'management workspace', 'role-based access', 'structured management', 'launch-ready responses', 'service'],
            $value
        );
    }

    private function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
