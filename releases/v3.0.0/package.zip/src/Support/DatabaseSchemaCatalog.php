<?php
namespace App\Support;

use App\Config\Database;

final class DatabaseSchemaCatalog
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function tables(): array
    {
        static $cache = [];

        $schemaPath = Database::schemaPath();
        if (isset($cache[$schemaPath])) {
            return $cache[$schemaPath];
        }

        $sql = is_file($schemaPath) ? file_get_contents($schemaPath) : false;
        if (!is_string($sql) || trim($sql) === '') {
            return $cache[$schemaPath] = [];
        }

        $tables = [];
        $alterForeignKeys = self::parseAlterTableForeignKeys($sql);
        foreach (self::extractCreateTableBodies($sql) as $tableName => $body) {
            $tables[$tableName] = [
                'name' => $tableName,
                'fields' => self::parseFields(
                    $body,
                    array_merge(
                        self::parseForeignKeysFromBody($body),
                        $alterForeignKeys[$tableName] ?? []
                    )
                ),
            ];
        }

        return $cache[$schemaPath] = $tables;
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function table(string $table): ?array
    {
        return self::tables()[trim($table)] ?? null;
    }

    /**
     * @param array<string, mixed> $options
     * @return array<int, array<string, mixed>>
     */
    public static function apiFields(string $table, array $options = []): array
    {
        $tableMeta = self::table($table);
        if ($tableMeta === null) {
            return [];
        }

        $hidden = array_fill_keys($options['hidden'] ?? [], true);
        $aliases = is_array($options['aliases'] ?? null) ? $options['aliases'] : [];
        $descriptions = is_array($options['descriptions'] ?? null) ? $options['descriptions'] : [];
        $readOnly = array_fill_keys(array_merge(self::defaultReadOnlyFields(), $options['read_only'] ?? []), true);
        $writeOnly = array_fill_keys($options['write_only'] ?? [], true);
        $requiredOnCreate = array_fill_keys($options['required_on_create'] ?? [], true);
        $requiredOnUpdate = array_fill_keys($options['required_on_update'] ?? [], true);
        $optionalOnCreate = array_fill_keys($options['optional_on_create'] ?? [], true);
        $fields = [];

        foreach ($tableMeta['fields'] as $field) {
            $sourceName = (string)$field['name'];
            if (isset($hidden[$sourceName])) {
                continue;
            }

            $name = (string)($aliases[$sourceName] ?? $sourceName);
            $normalizedType = self::normalizeType((string)$field['database_type']);
            $requiredCreate = isset($requiredOnCreate[$name]) || isset($requiredOnCreate[$sourceName]) || (bool)$field['required_on_create'];
            if (isset($optionalOnCreate[$name]) || isset($optionalOnCreate[$sourceName])) {
                $requiredCreate = false;
            }

            $apiField = [
                'name' => $name,
                'data_type' => $normalizedType['data_type'],
                'format' => $normalizedType['format'],
                'database_type' => $field['database_type'],
                'database_column' => $name === $sourceName ? null : $sourceName,
                'nullable' => $field['nullable'],
                'required_on_create' => $requiredCreate,
                'required_on_update' => isset($requiredOnUpdate[$name]) || isset($requiredOnUpdate[$sourceName]),
                'read_only' => isset($readOnly[$sourceName]) || isset($readOnly[$name]),
                'write_only' => isset($writeOnly[$sourceName]) || isset($writeOnly[$name]),
                'default' => $field['default'],
                'options' => $field['options'],
                'description' => $descriptions[$name] ?? ($descriptions[$sourceName] ?? null),
            ];

            if (is_array($field['relation'] ?? null)) {
                $apiField['relation'] = [
                    'table' => (string)($field['relation']['table'] ?? ''),
                    'column' => (string)($field['relation']['column'] ?? 'id'),
                ];
            }

            if ($apiField['read_only']) {
                $apiField['required_on_create'] = false;
                $apiField['required_on_update'] = false;
            }

            $fields[] = $apiField;
        }

        foreach ($options['virtual_fields'] ?? [] as $virtualField) {
            if (!is_array($virtualField) || ($virtualField['name'] ?? '') === '') {
                continue;
            }

            $fields[] = array_merge([
                'data_type' => 'string',
                'format' => null,
                'database_type' => null,
                'database_column' => null,
                'nullable' => true,
                'required_on_create' => false,
                'required_on_update' => false,
                'read_only' => false,
                'write_only' => false,
                'default' => null,
                'options' => [],
                'description' => null,
            ], $virtualField);
        }

        return $fields;
    }

    /**
     * @return array<int, string>
     */
    private static function defaultReadOnlyFields(): array
    {
        return [
            'id',
            'created_at',
            'updated_at',
            'last_login_at',
            'created_by_user_id',
            'updated_by_user_id',
            'registered_by_user_id',
            'enrolled_at',
            'completed_at',
            'last_activity_at',
        ];
    }

    /**
     * @return array<string, string>
     */
    private static function extractCreateTableBodies(string $sql): array
    {
        $tables = [];
        if (!preg_match_all('/CREATE TABLE IF NOT EXISTS\s+([a-z_][a-z0-9_]*)\s*\(/i', $sql, $matches, PREG_OFFSET_CAPTURE)) {
            return $tables;
        }

        foreach ($matches[1] as $index => $tableMatch) {
            $tableName = strtolower((string)($tableMatch[0] ?? ''));
            $offset = (int)($matches[0][$index][1] ?? 0);
            $openParenOffset = strpos($sql, '(', $offset);
            if ($tableName === '' || $openParenOffset === false) {
                continue;
            }

            $tables[$tableName] = self::extractParenthesizedBody($sql, $openParenOffset);
        }

        return $tables;
    }

    private static function extractParenthesizedBody(string $sql, int $openParenOffset): string
    {
        $depth = 0;
        $body = '';
        $length = strlen($sql);

        for ($index = $openParenOffset; $index < $length; $index++) {
            $char = $sql[$index];
            if ($char === '(') {
                $depth++;
                if ($depth === 1) {
                    continue;
                }
            } elseif ($char === ')') {
                $depth--;
                if ($depth === 0) {
                    break;
                }
            }

            if ($depth >= 1) {
                $body .= $char;
            }
        }

        return trim($body);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function parseFields(string $body, array $foreignKeys = []): array
    {
        $fields = [];
        foreach (preg_split('/\r?\n/', $body) ?: [] as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }

            $line = rtrim($line, ',');
            if (!preg_match('/^([a-z_][a-z0-9_]*)\s+(.+)$/i', $line, $matches)) {
                continue;
            }

            $name = strtolower((string)$matches[1]);
            if (in_array(strtoupper($name), ['PRIMARY', 'FOREIGN', 'UNIQUE', 'CONSTRAINT', 'KEY', 'INDEX'], true)) {
                continue;
            }

            $definition = trim((string)$matches[2]);
            $databaseType = trim((string)preg_split('/\s+(?:NOT\s+NULL|NULL|DEFAULT|CHECK|REFERENCES|PRIMARY\s+KEY|UNIQUE|AUTO_INCREMENT)\b/i', $definition, 2)[0]);
            $nullable = !preg_match('/\bNOT\s+NULL\b/i', $definition) && !preg_match('/\bPRIMARY\s+KEY\b/i', $definition);
            $default = null;
            if (preg_match('/\bDEFAULT\s+(.+?)(?=(?:\s+CHECK|\s+REFERENCES|\s+PRIMARY\s+KEY|\s+UNIQUE|\s+AUTO_INCREMENT|\s*$))/i', $definition, $defaultMatch)) {
                $default = trim((string)$defaultMatch[1]);
            }

            $options = [];
            if (preg_match('/\bCHECK\s*\(\s*' . preg_quote($name, '/') . '\s+IN\s*\((.*?)\)\s*\)/i', $definition, $optionsMatch)) {
                preg_match_all("/'([^']+)'/", (string)$optionsMatch[1], $valueMatches);
                $options = array_values(array_map('strval', $valueMatches[1] ?? []));
            }

            $relation = $foreignKeys[$name] ?? self::parseInlineReference($definition);

            $fields[] = [
                'name' => $name,
                'database_type' => $databaseType,
                'nullable' => $nullable,
                'required_on_create' => !$nullable
                    && $default === null
                    && !preg_match('/\bPRIMARY\s+KEY\b/i', $definition)
                    && !preg_match('/\bSERIAL\b/i', $databaseType)
                    && !preg_match('/\bAUTO_INCREMENT\b/i', $definition),
                'default' => $default,
                'options' => $options,
                'relation' => $relation,
            ];
        }

        return $fields;
    }

    /**
     * @return array<string, array<string, array<string, string>>>
     */
    private static function parseAlterTableForeignKeys(string $sql): array
    {
        $foreignKeys = [];
        if (!preg_match_all(
            '/ALTER\s+TABLE\s+([a-z_][a-z0-9_]*)\s+.*?FOREIGN\s+KEY\s*\(\s*([a-z_][a-z0-9_]*)\s*\)\s*REFERENCES\s+([a-z_][a-z0-9_]*)\s*\(\s*([a-z_][a-z0-9_]*)\s*\)/is',
            $sql,
            $matches,
            PREG_SET_ORDER
        )) {
            return $foreignKeys;
        }

        foreach ($matches as $match) {
            $table = strtolower(trim((string)($match[1] ?? '')));
            $column = strtolower(trim((string)($match[2] ?? '')));
            $referencedTable = strtolower(trim((string)($match[3] ?? '')));
            $referencedColumn = strtolower(trim((string)($match[4] ?? 'id')));
            if ($table === '' || $column === '' || $referencedTable === '') {
                continue;
            }
            $foreignKeys[$table][$column] = [
                'table' => $referencedTable,
                'column' => $referencedColumn !== '' ? $referencedColumn : 'id',
            ];
        }

        return $foreignKeys;
    }

    /**
     * @return array<string, array<string, string>>
     */
    private static function parseForeignKeysFromBody(string $body): array
    {
        $foreignKeys = [];
        foreach (preg_split('/\r?\n/', $body) ?: [] as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }

            $line = rtrim($line, ',');
            if (!preg_match(
                '/^(?:CONSTRAINT\s+[a-z_][a-z0-9_]*\s+)?FOREIGN\s+KEY\s*\(\s*([a-z_][a-z0-9_]*)\s*\)\s*REFERENCES\s+([a-z_][a-z0-9_]*)\s*\(\s*([a-z_][a-z0-9_]*)\s*\)/i',
                $line,
                $matches
            )) {
                continue;
            }

            $column = strtolower(trim((string)($matches[1] ?? '')));
            $referencedTable = strtolower(trim((string)($matches[2] ?? '')));
            $referencedColumn = strtolower(trim((string)($matches[3] ?? 'id')));
            if ($column === '' || $referencedTable === '') {
                continue;
            }

            $foreignKeys[$column] = [
                'table' => $referencedTable,
                'column' => $referencedColumn !== '' ? $referencedColumn : 'id',
            ];
        }

        return $foreignKeys;
    }

    /**
     * @return array<string, string>|null
     */
    private static function parseInlineReference(string $definition): ?array
    {
        if (!preg_match(
            '/\bREFERENCES\s+([a-z_][a-z0-9_]*)\s*\(\s*([a-z_][a-z0-9_]*)\s*\)/i',
            $definition,
            $matches
        )) {
            return null;
        }

        $table = strtolower(trim((string)($matches[1] ?? '')));
        $column = strtolower(trim((string)($matches[2] ?? 'id')));
        if ($table === '') {
            return null;
        }

        return [
            'table' => $table,
            'column' => $column !== '' ? $column : 'id',
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private static function normalizeType(string $databaseType): array
    {
        $type = strtoupper(trim($databaseType));
        if ($type === 'UUID' || $type === 'CHAR(36)' || $type === 'VARCHAR(36)') {
            return ['data_type' => 'string', 'format' => 'uuid'];
        }
        if (str_starts_with($type, 'VARCHAR') || $type === 'TEXT' || str_starts_with($type, 'CHAR')) {
            return ['data_type' => 'string', 'format' => null];
        }
        if ($type === 'BOOLEAN' || $type === 'BOOL') {
            return ['data_type' => 'boolean', 'format' => null];
        }
        if (str_contains($type, 'JSON')) {
            return ['data_type' => 'object', 'format' => 'json'];
        }
        if (str_starts_with($type, 'TIMESTAMP') || $type === 'DATETIME') {
            return ['data_type' => 'string', 'format' => 'date-time'];
        }
        if ($type === 'DATE') {
            return ['data_type' => 'string', 'format' => 'date'];
        }
        if (str_contains($type, 'INT') || str_contains($type, 'SERIAL')) {
            return ['data_type' => 'integer', 'format' => null];
        }
        if (str_starts_with($type, 'NUMERIC') || str_starts_with($type, 'DECIMAL')) {
            return ['data_type' => 'number', 'format' => null];
        }

        return ['data_type' => 'string', 'format' => null];
    }
}
