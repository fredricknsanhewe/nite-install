<?php
namespace App\Support;

use App\Config\Database;
use App\Console\ConsoleSupport;
use App\Models\ExampleEntityModel;
use PDO;
use RuntimeException;

/**
 * Generates, persists, and optionally installs starter sample bundles.
 *
 * Bundles are written as JSON/Markdown artifacts so developers and AI tooling
 * can inspect them without a live database. When the database is available,
 * sample items can also be installed into `example_entities` for direct use via
 * the existing examples API surface.
 */
final class StarterSampleManager
{
    public function __construct(private readonly string $rootPath)
    {
    }

    /**
     * Persist one generated sample bundle to disk.
     *
     * Root mode writes to `blueprints/starters/generated/` and `docs/`.
     * Project mode writes into the selected project directory.
     *
     * @param array<string, mixed> $bundle
     * @param array<string, mixed>|null $project
     * @return array<string, string>
     */
    public function writeBundle(array $bundle, ?array $project = null): array
    {
        if ($project === null) {
            $jsonPath = $this->rootPath . '/blueprints/starters/generated/starter-samples.json';
            $markdownPath = $this->rootPath . '/docs/starter-samples.md';
        } else {
            $directory = (string)($project['paths']['directory'] ?? '');
            $jsonPath = $directory . '/starter-samples.json';
            $markdownPath = $directory . '/starter-samples.md';
        }

        ConsoleSupport::ensureDirectory(dirname($jsonPath));
        ConsoleSupport::ensureDirectory(dirname($markdownPath));

        $encoded = json_encode($bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode starter sample bundle JSON.');
        }

        if (file_put_contents($jsonPath, $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write starter sample bundle JSON: ' . $jsonPath);
        }
        if (file_put_contents($markdownPath, $this->renderMarkdown($bundle)) === false) {
            throw new RuntimeException('Failed to write starter sample bundle markdown: ' . $markdownPath);
        }

        return [
            'json' => $jsonPath,
            'markdown' => $markdownPath,
        ];
    }

    /**
     * Install generated sample items into the existing example entity tables.
     *
     * This keeps the starter bundle visible through the normal example API
     * surface without inventing a second storage model for starter examples.
     *
     * @param array<string, mixed> $bundle
     * @return array<string, mixed>
     */
    public function installBundle(array $bundle): array
    {
        $items = array_values(is_array($bundle['items'] ?? null) ? $bundle['items'] : []);
        if ($items === []) {
            return [
                'status' => 'skipped',
                'detail' => 'No starter sample items were generated.',
                'installed' => 0,
            ];
        }

        $model = new ExampleEntityModel();
        $db = Database::connection();
        $installed = 0;
        $warnings = [];

        $db->beginTransaction();
        try {
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $moduleKey = trim((string)($item['module_key'] ?? ''));
                $entityType = trim((string)($item['entity_type'] ?? ''));
                if ($moduleKey === '' || $entityType === '') {
                    continue;
                }

                try {
                    $model->create($moduleKey, $entityType, [
                        'slug' => $item['slug'] ?? null,
                        'title' => $item['title'] ?? 'Starter Sample',
                        'summary' => $item['summary'] ?? null,
                        'status' => $item['status'] ?? 'draft',
                        'payload' => is_array($item['payload'] ?? null) ? $item['payload'] : [],
                    ]);
                    $installed++;
                } catch (\Throwable $e) {
                    $warnings[] = 'Skipped sample `' . (string)($item['slug'] ?? '') . '`: ' . $e->getMessage();
                }
            }

            $db->commit();
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }

        return [
            'status' => $installed > 0 ? 'installed' : 'warning',
            'detail' => $installed > 0
                ? 'Installed starter sample items into example_entities.'
                : 'No starter sample items could be installed.',
            'installed' => $installed,
            'warnings' => $warnings,
        ];
    }

    /**
     * @param array<string, mixed> $bundle
     */
    private function renderMarkdown(array $bundle): string
    {
        $lines = [
            '# Starter Samples',
            '',
            'Starter: `' . (string)($bundle['starter_key'] ?? '') . '`',
            'Total items: ' . (string)($bundle['count'] ?? 0),
            '',
            '## Packs',
            '',
        ];

        foreach (array_values(is_array($bundle['packs'] ?? null) ? $bundle['packs'] : []) as $pack) {
            if (!is_array($pack)) {
                continue;
            }
            $lines[] = '- `' . (string)($pack['key'] ?? '') . '` ' . (string)($pack['title'] ?? '') . ': ' . (string)($pack['summary'] ?? '');
        }

        $lines[] = '';
        $lines[] = '## Sample Items';
        $lines[] = '';

        foreach (array_slice(array_values(is_array($bundle['items'] ?? null) ? $bundle['items'] : []), 0, 120) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $lines[] = '- `' . (string)($item['module_key'] ?? '') . '/' . (string)($item['entity_type'] ?? '') . '` '
                . (string)($item['title'] ?? '')
                . ' [' . (string)($item['status'] ?? '') . ']';
        }

        $hiddenCount = max(0, (int)($bundle['count'] ?? 0) - 120);
        if ($hiddenCount > 0) {
            $lines[] = '';
            $lines[] = '_Additional generated items omitted from markdown: ' . $hiddenCount . '. Inspect the JSON bundle for the full dataset._';
        }

        $lines[] = '';
        return implode(PHP_EOL, $lines);
    }
}
