<?php
namespace App\Support;

use App\Http\Request;

final class DataChangeContext
{
    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    public static function fromRequest(Request $request, array $extra = []): array
    {
        $route = is_array($request->attributes['route'] ?? null) ? $request->attributes['route'] : [];
        $reason = $request->body['change_reason'] ?? $request->body['reason'] ?? $request->query['reason'] ?? null;
        $metadata = is_array($extra['metadata'] ?? null) ? $extra['metadata'] : [];

        return array_merge([
            'change_scope' => 'data',
            'actor_user_id' => $request->user['id'] ?? null,
            'actor_role' => $request->user['role'] ?? null,
            'request_method' => $request->method,
            'request_path' => $request->path,
            'route_path' => $route['path'] ?? null,
            'ip_address' => $request->header('X-Forwarded-For') ?: ($_SERVER['REMOTE_ADDR'] ?? null),
            'user_agent' => $request->header('User-Agent'),
            'reason' => is_scalar($reason) ? trim((string)$reason) : null,
            'metadata' => array_merge([
                'route_name' => $route['name'] ?? null,
                'query' => is_array($request->query) ? $request->query : [],
            ], $metadata),
        ], $extra);
    }
}
