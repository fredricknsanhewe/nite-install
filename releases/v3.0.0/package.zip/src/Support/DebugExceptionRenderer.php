<?php
namespace App\Support;

use App\Http\Request;
use Throwable;

final class DebugExceptionRenderer
{
    public static function render(Throwable $exception, ?Request $request = null): string
    {
        $root = realpath(dirname(__DIR__, 2)) ?: dirname(__DIR__, 2);
        $title = self::basename(get_class($exception));
        $message = trim($exception->getMessage()) !== '' ? $exception->getMessage() : 'Application error';
        $source = self::renderSource($exception->getFile(), $exception->getLine(), $root);
        $trace = self::renderTrace($exception, $root);
        $requestPanel = self::renderRequest($request, $root);

        $html = <<<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Error</title>
    <style>
        :root {
            color-scheme: dark;
            --bg: #0f172a;
            --bg-soft: #111b34;
            --panel: rgba(15, 23, 42, 0.88);
            --panel-strong: rgba(30, 41, 59, 0.96);
            --line: rgba(148, 163, 184, 0.22);
            --line-strong: rgba(248, 113, 113, 0.38);
            --text: #e2e8f0;
            --muted: #94a3b8;
            --danger: #f87171;
            --danger-soft: rgba(248, 113, 113, 0.14);
            --accent: #38bdf8;
            --accent-soft: rgba(56, 189, 248, 0.14);
            --code: #0b1220;
            --code-line: rgba(148, 163, 184, 0.08);
            --shadow: 0 24px 80px rgba(2, 6, 23, 0.48);
            --radius: 18px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Segoe UI Variable Text", "Segoe UI", "Aptos", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at top left, rgba(56, 189, 248, 0.10), transparent 30%),
                radial-gradient(circle at top right, rgba(248, 113, 113, 0.12), transparent 28%),
                linear-gradient(180deg, #0b1120 0%, var(--bg) 100%);
        }

        code,
        pre {
            font-family: "Cascadia Code", Consolas, monospace;
        }

        .shell {
            width: min(1320px, calc(100% - 32px));
            margin: 28px auto 40px;
            display: grid;
            gap: 18px;
        }

        .hero,
        .panel {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--panel);
            box-shadow: var(--shadow);
            backdrop-filter: blur(16px);
        }

        .hero {
            padding: 24px 26px 22px;
            overflow: hidden;
            position: relative;
        }

        .hero::after {
            content: "";
            position: absolute;
            inset: auto -60px -60px auto;
            width: 220px;
            height: 220px;
            border-radius: 999px;
            background: radial-gradient(circle, rgba(248, 113, 113, 0.18), transparent 72%);
            pointer-events: none;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: #fecaca;
            background: var(--danger-soft);
            border: 1px solid var(--line-strong);
        }

        .hero h1 {
            margin: 14px 0 10px;
            font-size: clamp(2rem, 4vw, 3.2rem);
            line-height: 1.02;
            letter-spacing: -0.05em;
        }

        .hero p {
            margin: 0;
            max-width: 80ch;
            color: #cbd5e1;
            font-size: 1rem;
            line-height: 1.6;
        }

        .meta-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
            margin-top: 20px;
        }

        .meta-card {
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 14px 15px;
            background: rgba(15, 23, 42, 0.54);
        }

        .meta-card span {
            display: block;
            color: var(--muted);
            font-size: 0.76rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 7px;
        }

        .meta-card strong,
        .meta-card code {
            display: block;
            font-size: 0.95rem;
            line-height: 1.45;
            word-break: break-word;
        }

        .layout {
            display: grid;
            grid-template-columns: minmax(0, 1.5fr) minmax(320px, 0.85fr);
            gap: 18px;
            align-items: start;
        }

        .stack {
            display: grid;
            gap: 18px;
        }

        .panel {
            padding: 18px;
        }

        .panel h2 {
            margin: 0 0 12px;
            font-size: 1rem;
            letter-spacing: -0.02em;
        }

        .panel .muted {
            color: var(--muted);
            font-size: 0.9rem;
            line-height: 1.55;
        }

        .path {
            display: inline-flex;
            max-width: 100%;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 12px;
            background: var(--accent-soft);
            color: #bae6fd;
            border: 1px solid rgba(56, 189, 248, 0.26);
            margin-bottom: 12px;
            word-break: break-all;
        }

        .code {
            overflow: hidden;
            border-radius: 16px;
            border: 1px solid var(--line);
            background: var(--code);
        }

        .code-header {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            align-items: center;
            padding: 12px 14px;
            border-bottom: 1px solid var(--line);
            color: var(--muted);
            font-size: 0.84rem;
        }

        .code-body {
            overflow: auto;
        }

        .source-line {
            display: grid;
            grid-template-columns: 72px minmax(0, 1fr);
            gap: 0;
            border-bottom: 1px solid rgba(148, 163, 184, 0.06);
            background: transparent;
        }

        .source-line:last-child {
            border-bottom: 0;
        }

        .source-line.active {
            background: linear-gradient(90deg, rgba(248, 113, 113, 0.24), rgba(248, 113, 113, 0.08));
        }

        .line-no,
        .line-code {
            padding: 10px 14px;
            white-space: pre;
        }

        .line-no {
            text-align: right;
            color: var(--muted);
            border-right: 1px solid var(--line);
            background: var(--code-line);
            user-select: none;
        }

        .source-line.active .line-no {
            color: #fecaca;
            background: rgba(248, 113, 113, 0.18);
            border-right-color: rgba(248, 113, 113, 0.30);
        }

        .line-code {
            overflow-x: auto;
        }

        .trace-list,
        .kv-list {
            display: grid;
            gap: 10px;
        }

        .trace-item,
        .kv-item {
            border: 1px solid var(--line);
            border-radius: 14px;
            background: var(--panel-strong);
            padding: 12px 14px;
        }

        .trace-item strong,
        .kv-item strong {
            display: block;
            margin-bottom: 6px;
            font-size: 0.92rem;
            word-break: break-word;
        }

        .trace-item .frame-path,
        .kv-item .value {
            color: var(--muted);
            word-break: break-word;
            line-height: 1.5;
        }

        .trace-index {
            color: var(--danger);
            margin-right: 8px;
        }

        .json {
            margin: 0;
            padding: 14px;
            overflow: auto;
            border-radius: 14px;
            background: var(--code);
            border: 1px solid var(--line);
            color: #dbeafe;
            font-size: 0.87rem;
            line-height: 1.6;
        }

        .empty {
            padding: 14px;
            border-radius: 14px;
            border: 1px dashed var(--line);
            color: var(--muted);
        }

        .footer {
            color: var(--muted);
            font-size: 0.84rem;
            text-align: right;
        }

        @media (max-width: 1080px) {
            .layout {
                grid-template-columns: 1fr;
            }

            .meta-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 720px) {
            .shell {
                width: calc(100% - 16px);
                margin-top: 16px;
            }

            .hero,
            .panel {
                padding: 16px;
            }

            .meta-grid {
                grid-template-columns: 1fr;
            }

            .source-line {
                grid-template-columns: 56px minmax(0, 1fr);
            }

            .line-no,
            .line-code {
                padding: 9px 10px;
            }
        }
    </style>
</head>
<body>
    <main class="shell">
        <section class="hero">
            <span class="eyebrow">APP_DEBUG is enabled</span>
            <h1>__TITLE__</h1>
            <p>__MESSAGE__</p>
            <div class="meta-grid">
                <div class="meta-card">
                    <span>File</span>
                    <code>__FILE__</code>
                </div>
                <div class="meta-card">
                    <span>Line</span>
                    <strong>__LINE__</strong>
                </div>
                <div class="meta-card">
                    <span>Time</span>
                    <strong>__TIME__</strong>
                </div>
                <div class="meta-card">
                    <span>PHP</span>
                    <strong>__PHP__</strong>
                </div>
            </div>
        </section>

        <section class="layout">
            <div class="stack">
                <section class="panel">
                    <h2>Source</h2>
                    <div class="path">__FILE__:__LINE__</div>
                    __SOURCE__
                </section>

                <section class="panel">
                    <h2>Stack Trace</h2>
                    __TRACE__
                </section>
            </div>

            <div class="stack">
                <section class="panel">
                    <h2>Request</h2>
                    __REQUEST__
                </section>
            </div>
        </section>

        <div class="footer">Rendered by Nite debug handler</div>
    </main>
</body>
</html>
HTML;

        return strtr($html, [
            '__TITLE__' => self::escape($title),
            '__MESSAGE__' => self::escape($message),
            '__FILE__' => self::escape(self::shortPath($exception->getFile(), $root)),
            '__LINE__' => (string)$exception->getLine(),
            '__TIME__' => self::escape(gmdate('Y-m-d H:i:s') . ' UTC'),
            '__PHP__' => self::escape(PHP_VERSION),
            '__SOURCE__' => $source,
            '__TRACE__' => $trace,
            '__REQUEST__' => $requestPanel,
        ]);
    }

    private static function renderSource(string $file, int $line, string $root): string
    {
        if ($file === '' || !is_file($file)) {
            return '<div class="empty">Source file is not available.</div>';
        }

        $lines = file($file, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            return '<div class="empty">Source file could not be read.</div>';
        }

        $start = max(1, $line - 8);
        $end = min(count($lines), $line + 8);
        $rows = [];
        for ($current = $start; $current <= $end; $current += 1) {
            $code = $lines[$current - 1] ?? '';
            $class = $current === $line ? 'source-line active' : 'source-line';
            $rows[] = '<div class="' . $class . '">' .
                '<div class="line-no">' . $current . '</div>' .
                '<div class="line-code">' . self::escape(self::normalizeSourceLine($code)) . '</div>' .
            '</div>';
        }

        return '<div class="code">' .
            '<div class="code-header"><span>' . self::escape(self::shortPath($file, $root)) . '</span><span>line ' . $line . '</span></div>' .
            '<div class="code-body">' . implode('', $rows) . '</div>' .
        '</div>';
    }

    private static function renderTrace(Throwable $exception, string $root): string
    {
        $frames = $exception->getTrace();
        if ($frames === []) {
            return '<div class="empty">No stack trace is available.</div>';
        }

        $items = [];
        foreach ($frames as $index => $frame) {
            $function = self::frameFunction($frame);
            $path = isset($frame['file'], $frame['line'])
                ? self::shortPath((string)$frame['file'], $root) . ':' . (int)$frame['line']
                : 'internal frame';

            $items[] = '<div class="trace-item">' .
                '<strong><span class="trace-index">#' . $index . '</span>' . self::escape($function) . '</strong>' .
                '<div class="frame-path">' . self::escape($path) . '</div>' .
            '</div>';
        }

        return '<div class="trace-list">' . implode('', $items) . '</div>';
    }

    private static function renderRequest(?Request $request, string $root): string
    {
        if (!$request instanceof Request) {
            return '<div class="empty">Request context is not available.</div>';
        }

        $items = [
            ['label' => 'Method', 'value' => $request->method],
            ['label' => 'Path', 'value' => $request->path],
            ['label' => 'Query', 'value' => self::pretty(self::sanitize($request->query))],
            ['label' => 'Body', 'value' => self::pretty(self::sanitize($request->body))],
            ['label' => 'Accept', 'value' => (string)$request->header('Accept', '')],
            ['label' => 'Content-Type', 'value' => $request->contentType],
        ];

        $route = is_array($request->attributes['route'] ?? null) ? $request->attributes['route'] : [];
        if ($route !== []) {
            $items[] = [
                'label' => 'Route',
                'value' => self::pretty([
                    'name' => $route['name'] ?? '',
                    'path' => isset($route['path']) ? self::shortPath((string)$route['path'], $root) : '',
                    'allowed_methods' => $route['allowed_methods'] ?? [],
                ]),
            ];
        }

        $rows = [];
        foreach ($items as $item) {
            $value = (string)$item['value'];
            $rows[] = '<div class="kv-item">' .
                '<strong>' . self::escape((string)$item['label']) . '</strong>' .
                '<div class="value">' . self::valueHtml($value) . '</div>' .
            '</div>';
        }

        return '<div class="kv-list">' . implode('', $rows) . '</div>';
    }

    private static function frameFunction(array $frame): string
    {
        $class = isset($frame['class']) ? (string)$frame['class'] : '';
        $type = isset($frame['type']) ? (string)$frame['type'] : '';
        $function = isset($frame['function']) ? (string)$frame['function'] : 'unknown';
        return $class !== '' ? $class . $type . $function . '()' : $function . '()';
    }

    private static function pretty(mixed $value): string
    {
        if ($value === [] || $value === null || $value === '') {
            return 'empty';
        }
        if (is_string($value)) {
            return $value;
        }

        $encoded = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        return is_string($encoded) ? $encoded : 'unrenderable';
    }

    private static function valueHtml(string $value): string
    {
        if (str_contains($value, "\n") || str_starts_with($value, '{') || str_starts_with($value, '[')) {
            return '<pre class="json">' . self::escape($value) . '</pre>';
        }

        return self::escape($value);
    }

    private static function sanitize(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }

        $sanitized = [];
        foreach ($value as $key => $item) {
            $normalized = strtolower((string)$key);
            if (str_contains($normalized, 'password') || str_contains($normalized, 'token') || str_contains($normalized, 'secret')) {
                $sanitized[$key] = '[redacted]';
                continue;
            }

            $sanitized[$key] = is_array($item) ? self::sanitize($item) : $item;
        }

        return $sanitized;
    }

    private static function shortPath(string $path, string $root): string
    {
        $normalized = str_replace('\\', '/', $path);
        $normalizedRoot = rtrim(str_replace('\\', '/', $root), '/');
        if ($normalizedRoot !== '' && str_starts_with($normalized, $normalizedRoot . '/')) {
            return substr($normalized, strlen($normalizedRoot) + 1);
        }

        return $normalized;
    }

    private static function normalizeSourceLine(string $line): string
    {
        return str_replace("\t", '    ', rtrim($line, "\r\n"));
    }

    private static function basename(string $value): string
    {
        $parts = explode('\\', $value);
        return (string)end($parts);
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
