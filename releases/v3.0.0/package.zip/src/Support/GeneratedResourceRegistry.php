<?php
namespace App\Support;

use App\Http\Router;

final class GeneratedResourceRegistry
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public static function manifests(?string $rootPath = null): array
    {
        static $cache = [];

        $basePath = $rootPath ?? dirname(__DIR__, 2);
        if (isset($cache[$basePath])) {
            return $cache[$basePath];
        }

        $directory = self::manifestDirectory($basePath);
        if (!is_dir($directory)) {
            $cache[$basePath] = [];
            return [];
        }

        $files = glob($directory . '/*.php') ?: [];
        sort($files, SORT_STRING);

        $manifests = [];
        foreach ($files as $path) {
            try {
                $loaded = require $path;
            } catch (\Throwable $e) {
                error_log('Failed to load generated resource manifest ' . $path . ': ' . $e->getMessage());
                continue;
            }

            if (!is_array($loaded)) {
                error_log('Generated resource manifest must return an array: ' . $path);
                continue;
            }

            $manifest = self::normalizeManifest($loaded, $path);
            if ($manifest === null) {
                continue;
            }

            $manifests[$manifest['key']] = $manifest;
        }

        $cache[$basePath] = $manifests;
        return $manifests;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function permissionDefinitions(?string $rootPath = null): array
    {
        $definitions = [];

        foreach (self::manifests($rootPath) as $manifest) {
            $rows = is_array($manifest['permissions_catalog'] ?? null) ? $manifest['permissions_catalog'] : [];
            foreach ($rows as $index => $row) {
                if (!is_array($row)) {
                    continue;
                }

                $code = trim((string)($row['code'] ?? ''));
                if ($code === '') {
                    continue;
                }

                $definitions[$code] = self::normalizePermissionDefinition($row, $manifest, $index);
            }
        }

        uasort($definitions, static function (array $left, array $right): int {
            return [(int)($left['sort_order'] ?? 0), (string)($left['code'] ?? '')]
                <=> [(int)($right['sort_order'] ?? 0), (string)($right['code'] ?? '')];
        });

        return array_values($definitions);
    }

    public static function registerRoutes(Router $router, mixed $auth, callable $perm, ?string $rootPath = null): void
    {
        foreach (self::manifests($rootPath) as $manifest) {
            $routes = is_array($manifest['routes'] ?? null) ? $manifest['routes'] : [];
            foreach ($routes as $route) {
                if (!is_array($route)) {
                    continue;
                }

                $method = strtoupper(trim((string)($route['method'] ?? '')));
                $path = self::relativeApiPath((string)($route['path'] ?? ''));
                $controller = trim((string)($route['controller'] ?? ''));
                $action = trim((string)($route['action'] ?? ''));
                if ($method === '' || $path === null || $controller === '' || $action === '') {
                    continue;
                }

                $registered = $router->add($method, $path, [$controller, $action]);
                $name = trim((string)($route['name'] ?? ''));
                if ($name !== '') {
                    $registered->name($name);
                }

                if ((bool)($route['auth_required'] ?? false)) {
                    $registered->middleware($auth);
                }

                $permissions = array_values(array_filter(
                    is_array($route['permissions'] ?? null) ? $route['permissions'] : [],
                    static fn (mixed $value): bool => is_string($value) && trim($value) !== ''
                ));
                if ($permissions !== []) {
                    $registered->middleware($perm($permissions));
                }
            }
        }
    }

    public static function manifestDirectory(?string $rootPath = null): string
    {
        $basePath = $rootPath ?? dirname(__DIR__, 2);
        return $basePath . '/routes/generated';
    }

    /**
     * @param array<string, mixed> $manifest
     * @return array<string, mixed>|null
     */
    private static function normalizeManifest(array $manifest, string $path): ?array
    {
        $key = trim((string)($manifest['key'] ?? ''));
        $routeSegment = trim((string)($manifest['route_segment'] ?? ''));
        $controller = trim((string)($manifest['controller'] ?? ''));
        if ($key === '' || $routeSegment === '' || $controller === '') {
            error_log('Generated resource manifest is missing key, route_segment, or controller: ' . $path);
            return null;
        }

        $defaultDataPath = trim((string)($manifest['default_data_path'] ?? ''));
        if ($defaultDataPath === '') {
            $defaultDataPath = '/api/v1/' . ltrim($routeSegment, '/');
        }

        $label = trim((string)($manifest['label'] ?? ''));
        if ($label === '') {
            $label = ucwords(str_replace('_', ' ', str_replace('-', ' ', $routeSegment)));
        }

        return [
            'key' => $key,
            'label' => $label,
            'group' => trim((string)($manifest['group'] ?? 'generated')) ?: 'generated',
            'item_type' => trim((string)($manifest['item_type'] ?? $label)) ?: $label,
            'table' => trim((string)($manifest['table'] ?? $key)) ?: $key,
            'summary' => trim((string)($manifest['summary'] ?? ('Generated starter resource for ' . $label . '.'))),
            'route_segment' => ltrim($routeSegment, '/'),
            'controller' => $controller,
            'default_data_path' => $defaultDataPath,
            'default_data_auth_required' => (bool)($manifest['default_data_auth_required'] ?? false),
            'fields' => array_values(is_array($manifest['fields'] ?? null) ? $manifest['fields'] : []),
            'create_fields' => array_values(is_array($manifest['create_fields'] ?? null) ? $manifest['create_fields'] : []),
            'update_fields' => array_values(is_array($manifest['update_fields'] ?? null) ? $manifest['update_fields'] : []),
            'query_options' => array_values(is_array($manifest['query_options'] ?? null) ? $manifest['query_options'] : []),
            'routes' => array_values(is_array($manifest['routes'] ?? null) ? $manifest['routes'] : []),
            'permissions_catalog' => array_values(is_array($manifest['permissions_catalog'] ?? null) ? $manifest['permissions_catalog'] : []),
        ];
    }

    /**
     * @param array<string, mixed> $definition
     * @param array<string, mixed> $manifest
     * @return array<string, mixed>
     */
    private static function normalizePermissionDefinition(array $definition, array $manifest, int $index): array
    {
        $code = trim((string)($definition['code'] ?? ''));
        $actionCode = trim((string)($definition['action_code'] ?? 'view'));
        $moduleCode = trim((string)($definition['module_code'] ?? ($manifest['key'] ?? 'generated_resource')));
        $label = trim((string)($manifest['label'] ?? 'Generated Resource'));
        $sectionTitle = trim((string)($definition['section_title'] ?? 'Generated Resources'));
        $moduleTitle = trim((string)($definition['module_title'] ?? $label));
        $actionTitle = trim((string)($definition['action_title'] ?? ucwords(str_replace('_', ' ', $actionCode))));

        return [
            'code' => $code,
            'title' => trim((string)($definition['title'] ?? ($actionTitle . ' ' . $moduleTitle))),
            'description' => trim((string)($definition['description'] ?? ('Generated permission for ' . $moduleTitle . '.'))),
            'section_code' => trim((string)($definition['section_code'] ?? 'generated_resources')) ?: 'generated_resources',
            'section_title' => $sectionTitle === '' ? 'Generated Resources' : $sectionTitle,
            'module_code' => $moduleCode === '' ? 'generated_resource' : $moduleCode,
            'module_title' => $moduleTitle === '' ? $label : $moduleTitle,
            'action_code' => $actionCode === '' ? 'view' : $actionCode,
            'action_title' => $actionTitle === '' ? 'View' : $actionTitle,
            'sort_order' => (int)($definition['sort_order'] ?? (1000 + ($index * 10))),
            'default_roles' => array_values(array_filter(
                array_map('strval', is_array($definition['default_roles'] ?? null) ? $definition['default_roles'] : []),
                static fn (string $value): bool => trim($value) !== ''
            )),
        ];
    }

    private static function relativeApiPath(string $path): ?string
    {
        $normalized = rtrim(trim($path), '/');
        if ($normalized === '') {
            return null;
        }

        if (!str_starts_with($normalized, '/api/v1')) {
            return null;
        }

        $relative = substr($normalized, strlen('/api/v1'));
        return $relative === false ? null : ($relative === '' ? '' : $relative);
    }
}
