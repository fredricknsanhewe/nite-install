<?php
namespace App\Support;

use App\Config\Env;
use App\Models\SiteSettingsModel;

final class EmailTemplate
{
    /**
     * @param array<string, mixed> $options
     * @return array{text_body: string, html_body: string}
     */
    public static function message(array $options): array
    {
        return [
            'text_body' => self::renderText($options),
            'html_body' => self::renderHtml($options),
        ];
    }

    /**
     * @param array<string, mixed> $options
     */
    public static function renderHtml(array $options): string
    {
        $identity = self::identity();
        $siteName = self::string($options['site_name'] ?? $identity['site_name']);
        $shortName = self::string($options['site_short_name'] ?? $identity['site_short_name']);
        $preheader = self::string($options['preheader'] ?? $options['headline'] ?? $siteName);
        $headline = self::string($options['headline'] ?? 'Notification');
        $greeting = self::string($options['greeting'] ?? '');
        $paragraphs = array_merge(
            self::stringList($options['intro'] ?? []),
            self::stringList($options['paragraphs'] ?? [])
        );
        $details = self::normalizeDetails($options['details'] ?? []);
        $notice = self::string($options['notice'] ?? '');
        $signoff = self::string($options['signoff'] ?? $siteName);
        $buttonUrl = self::absoluteUrl(self::string($options['button_url'] ?? ''), $identity['app_url']);
        $buttonLabel = self::string($options['button_label'] ?? 'Open');
        $callout = is_array($options['callout'] ?? null) ? $options['callout'] : [];
        $logoUrl = self::absoluteUrl(self::string($options['logo_url'] ?? $identity['logo_url']), $identity['app_url']);
        $supportEmail = self::string($identity['support_email']);
        $appUrl = self::string($identity['app_url']);

        $brandHtml = $logoUrl !== ''
            ? '<img src="' . self::e($logoUrl) . '" width="88" alt="' . self::e($shortName) . '" style="display:block;max-width:88px;height:auto;border:0;">'
            : '<div style="width:62px;height:62px;border-radius:10px;background:#d4af37;color:#102033;font:700 20px Arial,sans-serif;line-height:62px;text-align:center;">' . self::e($shortName) . '</div>';

        $paragraphHtml = '';
        foreach ($paragraphs as $paragraph) {
            $paragraphHtml .= '<p style="margin:0 0 16px;color:#334155;font:400 15px/1.65 Arial,sans-serif;">' . self::paragraph($paragraph) . '</p>';
        }

        $buttonHtml = '';
        if ($buttonUrl !== '') {
            $buttonHtml = '<table role="presentation" cellspacing="0" cellpadding="0" style="margin:24px 0 18px;"><tr><td style="border-radius:6px;background:#102033;">'
                . '<a href="' . self::e($buttonUrl) . '" target="_blank" style="display:inline-block;padding:13px 22px;color:#ffffff;text-decoration:none;font:700 15px Arial,sans-serif;border-radius:6px;">' . self::e($buttonLabel) . '</a>'
                . '</td></tr></table>'
                . '<p style="margin:0 0 18px;color:#64748b;font:400 13px/1.6 Arial,sans-serif;">If the button does not open, copy this link into your browser:<br>'
                . '<a href="' . self::e($buttonUrl) . '" target="_blank" style="color:#0f766e;word-break:break-all;">' . self::e($buttonUrl) . '</a></p>';
        }

        $detailsHtml = '';
        if ($details !== []) {
            $rows = '';
            foreach ($details as $detail) {
                $rows .= '<tr>'
                    . '<td style="padding:11px 14px;border-top:1px solid #e5e7eb;color:#64748b;font:700 12px/1.5 Arial,sans-serif;text-transform:uppercase;letter-spacing:.04em;width:34%;">' . self::e($detail['label']) . '</td>'
                    . '<td style="padding:11px 14px;border-top:1px solid #e5e7eb;color:#0f172a;font:400 14px/1.55 Arial,sans-serif;word-break:break-word;">' . self::paragraph($detail['value']) . '</td>'
                    . '</tr>';
            }

            $detailsHtml = '<table role="presentation" cellspacing="0" cellpadding="0" width="100%" style="margin:18px 0;border:1px solid #e5e7eb;border-radius:8px;border-collapse:separate;border-spacing:0;background:#ffffff;">'
                . $rows
                . '</table>';
        }

        $calloutHtml = '';
        $calloutBody = self::string($callout['body'] ?? '');
        if ($calloutBody !== '') {
            $calloutTitle = self::string($callout['title'] ?? 'Details');
            $calloutType = self::string($callout['type'] ?? '');
            $calloutBodyHtml = $calloutType === 'code'
                ? '<div style="color:#102033;font:700 24px/1.35 \'Courier New\',monospace;word-break:break-word;">' . self::e($calloutBody) . '</div>'
                : '<div style="color:#334155;font:400 14px/1.65 Arial,sans-serif;">' . self::paragraph($calloutBody) . '</div>';
            $calloutHtml = '<div style="margin:20px 0;padding:16px 18px;border-left:4px solid #d4af37;background:#fff8db;border-radius:6px;">'
                . '<p style="margin:0 0 8px;color:#102033;font:700 14px/1.5 Arial,sans-serif;">' . self::e($calloutTitle) . '</p>'
                . $calloutBodyHtml
                . '</div>';
        }

        $noticeHtml = $notice !== ''
            ? '<div style="margin:22px 0 0;padding:14px 16px;border-radius:8px;background:#f1f5f9;color:#475569;font:400 13px/1.6 Arial,sans-serif;">' . self::paragraph($notice) . '</div>'
            : '';

        $supportHtml = $supportEmail !== ''
            ? ' For support, email <a href="mailto:' . self::e($supportEmail) . '" style="color:#0f766e;text-decoration:none;">' . self::e($supportEmail) . '</a>.'
            : '';

        $siteLinkHtml = $appUrl !== ''
            ? '<a href="' . self::e($appUrl) . '" target="_blank" style="color:#64748b;text-decoration:none;">' . self::e($siteName) . '</a>'
            : self::e($siteName);

        return '<!doctype html>'
            . '<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . self::e($headline) . '</title></head>'
            . '<body style="margin:0;padding:0;background:#f5f7fb;-webkit-text-size-adjust:100%;text-size-adjust:100%;">'
            . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">' . self::e($preheader) . '</div>'
            . '<table role="presentation" cellspacing="0" cellpadding="0" width="100%" style="background:#f5f7fb;margin:0;padding:28px 12px;">'
            . '<tr><td align="center">'
            . '<table role="presentation" cellspacing="0" cellpadding="0" width="100%" style="max-width:640px;border-collapse:separate;border-spacing:0;">'
            . '<tr><td style="padding:0 0 14px;">'
            . '<table role="presentation" cellspacing="0" cellpadding="0" width="100%"><tr>'
            . '<td style="width:96px;vertical-align:middle;">' . $brandHtml . '</td>'
            . '<td style="vertical-align:middle;padding-left:14px;">'
            . '<div style="color:#102033;font:700 18px/1.35 Arial,sans-serif;">' . self::e($siteName) . '</div>'
            . '<div style="margin-top:4px;color:#64748b;font:400 13px/1.45 Arial,sans-serif;">Official system notification</div>'
            . '</td></tr></table>'
            . '</td></tr>'
            . '<tr><td style="background:#ffffff;border:1px solid #dbe3ef;border-radius:10px;box-shadow:0 16px 42px rgba(15,23,42,.08);overflow:hidden;">'
            . '<div style="height:6px;background:#d4af37;line-height:6px;font-size:6px;">&nbsp;</div>'
            . '<div style="padding:32px 30px 28px;">'
            . '<h1 style="margin:0 0 18px;color:#102033;font:700 24px/1.25 Arial,sans-serif;">' . self::e($headline) . '</h1>'
            . ($greeting !== '' ? '<p style="margin:0 0 16px;color:#0f172a;font:700 15px/1.6 Arial,sans-serif;">' . self::paragraph($greeting) . '</p>' : '')
            . $paragraphHtml
            . $buttonHtml
            . $detailsHtml
            . $calloutHtml
            . $noticeHtml
            . '<p style="margin:24px 0 0;color:#334155;font:400 14px/1.65 Arial,sans-serif;">Regards,<br><strong>' . self::e($signoff) . '</strong></p>'
            . '</div>'
            . '</td></tr>'
            . '<tr><td style="padding:18px 6px 0;color:#64748b;font:400 12px/1.6 Arial,sans-serif;text-align:center;">'
            . 'This message was sent by ' . $siteLinkHtml . '.' . $supportHtml
            . '</td></tr>'
            . '</table>'
            . '</td></tr></table>'
            . '</body></html>';
    }

    /**
     * @param array<string, mixed> $options
     */
    public static function renderText(array $options): string
    {
        $identity = self::identity();
        $siteName = self::string($options['site_name'] ?? $identity['site_name']);
        $headline = self::string($options['headline'] ?? 'Notification');
        $greeting = self::string($options['greeting'] ?? '');
        $paragraphs = array_merge(
            self::stringList($options['intro'] ?? []),
            self::stringList($options['paragraphs'] ?? [])
        );
        $details = self::normalizeDetails($options['details'] ?? []);
        $notice = self::string($options['notice'] ?? '');
        $signoff = self::string($options['signoff'] ?? $siteName);
        $buttonUrl = self::absoluteUrl(self::string($options['button_url'] ?? ''), $identity['app_url']);
        $buttonLabel = self::string($options['button_label'] ?? 'Open');
        $callout = is_array($options['callout'] ?? null) ? $options['callout'] : [];

        $lines = [$headline, str_repeat('=', strlen($headline)), ''];

        if ($greeting !== '') {
            $lines[] = $greeting;
            $lines[] = '';
        }

        foreach ($paragraphs as $paragraph) {
            $lines[] = $paragraph;
            $lines[] = '';
        }

        if ($buttonUrl !== '') {
            $lines[] = $buttonLabel . ': ' . $buttonUrl;
            $lines[] = '';
        }

        foreach ($details as $detail) {
            $lines[] = $detail['label'] . ': ' . $detail['value'];
        }
        if ($details !== []) {
            $lines[] = '';
        }

        $calloutBody = self::string($callout['body'] ?? '');
        if ($calloutBody !== '') {
            $calloutTitle = self::string($callout['title'] ?? 'Details');
            $lines[] = $calloutTitle . ':';
            $lines[] = $calloutBody;
            $lines[] = '';
        }

        if ($notice !== '') {
            $lines[] = $notice;
            $lines[] = '';
        }

        $lines[] = 'Regards,';
        $lines[] = $signoff;
        $lines[] = '';
        $lines[] = 'Sent by ' . $siteName . '.';
        if (self::string($identity['support_email']) !== '') {
            $lines[] = 'Support: ' . self::string($identity['support_email']);
        }
        if (self::string($identity['app_url']) !== '') {
            $lines[] = 'Website: ' . self::string($identity['app_url']);
        }

        return trim(implode(PHP_EOL, $lines));
    }

    /**
     * @return array{site_name: string, site_short_name: string, app_url: string, support_email: string, logo_url: string}
     */
    private static function identity(): array
    {
        $appUrl = rtrim(self::string(Env::get('FRONTEND_URL', Env::get('FRONTEND_APP_URL', Env::get('APP_URL', '')))), '/');
        $appName = self::string(Env::get('APP_NAME', 'Nite')) ?: 'Nite';
        $identity = [
            'site_name' => self::string(Env::get('SITE_TITLE', $appName)) ?: $appName,
            'site_short_name' => self::string(Env::get('SITE_SHORT_NAME', $appName)) ?: $appName,
            'app_url' => $appUrl,
            'support_email' => self::firstPublicEmail(Env::get('MAIL_SUPPORT_EMAIL', Env::get('MAIL_REPLY_TO', ''))),
            'logo_url' => self::string(Env::get('MAIL_LOGO_URL', '')),
        ];

        try {
            $record = (new SiteSettingsModel())->get('global');
            $settings = is_array($record['settings'] ?? null) ? $record['settings'] : [];
            foreach ([
                'site_name' => 'site_name',
                'site_short_name' => 'site_short_name',
                'support_email' => 'support_email',
            ] as $source => $target) {
                $value = $source === 'support_email'
                    ? self::firstPublicEmail($settings[$source] ?? '')
                    : self::string($settings[$source] ?? '');
                if ($value !== '') {
                    $identity[$target] = $value;
                }
            }
        } catch (\Throwable) {
            // Email rendering must not fail because optional CMS settings are unavailable.
        }

        return $identity;
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function normalizeDetails(mixed $details): array
    {
        if (!is_array($details)) {
            return [];
        }

        $normalized = [];
        $isList = array_keys($details) === range(0, count($details) - 1);
        if (!$isList) {
            foreach ($details as $label => $value) {
                $labelText = self::string($label);
                $valueText = self::valueToString($value);
                if ($labelText !== '' && $valueText !== '') {
                    $normalized[] = ['label' => $labelText, 'value' => $valueText];
                }
            }
            return $normalized;
        }

        foreach ($details as $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = self::string($item['label'] ?? $item['name'] ?? '');
            $value = self::valueToString($item['value'] ?? '');
            if ($label !== '' && $value !== '') {
                $normalized[] = ['label' => $label, 'value' => $value];
            }
        }

        return $normalized;
    }

    /**
     * @return array<int, string>
     */
    private static function stringList(mixed $value): array
    {
        if (is_string($value) || is_numeric($value)) {
            $text = self::string($value);
            return $text === '' ? [] : [$text];
        }
        if (!is_array($value)) {
            return [];
        }

        $items = [];
        foreach ($value as $item) {
            $text = self::valueToString($item);
            if ($text !== '') {
                $items[] = $text;
            }
        }
        return $items;
    }

    private static function valueToString(mixed $value): string
    {
        if (is_array($value) || is_object($value)) {
            $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            return $encoded === false ? '' : $encoded;
        }

        return self::string($value);
    }

    private static function string(mixed $value): string
    {
        return trim((string)$value);
    }

    private static function firstPublicEmail(mixed $value): string
    {
        $text = self::string($value);
        if ($text === '' || preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $text, $matches) !== 1) {
            return '';
        }

        $email = strtolower((string)$matches[0]);
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return '';
        }

        $domain = substr(strrchr($email, '@') ?: '', 1);
        $suffix = strtolower((string)substr(strrchr($domain, '.') ?: '', 1));
        return in_array($suffix, ['example', 'invalid', 'local', 'test'], true) ? '' : $email;
    }

    private static function paragraph(string $text): string
    {
        return nl2br(self::e($text), false);
    }

    private static function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private static function absoluteUrl(string $url, string $baseUrl): string
    {
        $trimmed = trim($url);
        if ($trimmed === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $trimmed) === 1) {
            return $trimmed;
        }
        if (str_starts_with($trimmed, '//')) {
            return 'https:' . $trimmed;
        }

        $base = rtrim(trim($baseUrl), '/');
        if ($base !== '' && str_starts_with($trimmed, '/')) {
            return $base . $trimmed;
        }

        return $trimmed;
    }
}
