<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class MediaAssetVersionModel extends BaseModel
{
    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = $this->uuidLike((string)($data['id'] ?? '')) ? (string)$data['id'] : UUID::v4();
        $payload['source_version_id'] = $payload['source_version_id'] ?? null;
        $payload['created_by_user_id'] = $this->cleanString($data['created_by_user_id'] ?? $actorUserId);
        $payload['created_at'] = $this->normalizeDateTime($data['created_at'] ?? null) ?: $this->normalizeDateTime(gmdate('c'));

        $this->query(
            <<<SQL
                INSERT INTO media_asset_versions (
                    id, media_asset_id, version_number, original_name, stored_name, mime_type, size_bytes,
                    storage_path, public_url, alt_text, checksum_sha1, change_notes, action, source_version_id,
                    created_by_user_id, created_at
                ) VALUES (
                    :id, :media_asset_id, :version_number, :original_name, :stored_name, :mime_type, :size_bytes,
                    :storage_path, :public_url, :alt_text, :checksum_sha1, :change_notes, :action, :source_version_id,
                    :created_by_user_id, :created_at
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        $row = $this->one('SELECT * FROM media_asset_versions WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findForAsset(string $assetId, string $versionId): ?array
    {
        if (!$this->uuidLike($assetId) || !$this->uuidLike($versionId)) {
            return null;
        }

        $row = $this->one(
            'SELECT * FROM media_asset_versions WHERE media_asset_id = :media_asset_id AND id = :id LIMIT 1',
            [
                ':media_asset_id' => $assetId,
                ':id' => $versionId,
            ]
        );
        return $row ? $this->hydrate($row) : null;
    }

    public function findByAssetAndNumber(string $assetId, int $versionNumber): ?array
    {
        if (!$this->uuidLike($assetId) || $versionNumber <= 0) {
            return null;
        }

        $row = $this->one(
            'SELECT * FROM media_asset_versions WHERE media_asset_id = :media_asset_id AND version_number = :version_number LIMIT 1',
            [
                ':media_asset_id' => $assetId,
                ':version_number' => $versionNumber,
            ]
        );
        return $row ? $this->hydrate($row) : null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listForAsset(string $assetId): array
    {
        if (!$this->uuidLike($assetId)) {
            return [];
        }

        return array_values(array_map(
            fn (array $row): array => $this->hydrate($row),
            $this->many(
                'SELECT * FROM media_asset_versions WHERE media_asset_id = :media_asset_id ORDER BY version_number DESC, created_at DESC',
                [':media_asset_id' => $assetId]
            )
        ));
    }

    public function nextVersionNumber(string $assetId): int
    {
        if (!$this->uuidLike($assetId)) {
            return 1;
        }

        $row = $this->one(
            'SELECT MAX(version_number) AS max_version FROM media_asset_versions WHERE media_asset_id = :media_asset_id',
            [':media_asset_id' => $assetId]
        );

        return max(1, (int)($row['max_version'] ?? 0) + 1);
    }

    public function deleteForAsset(string $assetId): void
    {
        if (!$this->uuidLike($assetId)) {
            return;
        }

        $this->query('DELETE FROM media_asset_versions WHERE media_asset_id = :media_asset_id', [':media_asset_id' => $assetId]);
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];

        foreach ([
            'media_asset_id',
            'original_name',
            'stored_name',
            'mime_type',
            'storage_path',
            'public_url',
            'alt_text',
            'checksum_sha1',
            'change_notes',
            'source_version_id',
        ] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        foreach (['size_bytes', 'version_number'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = max(0, (int)$data[$field]);
            }
        }

        if (array_key_exists('action', $data)) {
            $payload['action'] = $this->normalizeAction($data['action']);
        } elseif ($create) {
            $payload['action'] = 'create';
        }

        if ($create) {
            if (!$this->uuidLike((string)($payload['media_asset_id'] ?? ''))) {
                throw new RuntimeException('A valid media asset identifier is required for the media version.');
            }
            if (($payload['original_name'] ?? '') === '' || ($payload['stored_name'] ?? '') === '' || ($payload['mime_type'] ?? '') === '' || ($payload['storage_path'] ?? '') === '') {
                throw new RuntimeException('Media version file metadata is incomplete.');
            }
            if ((int)($payload['version_number'] ?? 0) <= 0) {
                throw new RuntimeException('A valid media version number is required.');
            }
        }

        if (($payload['source_version_id'] ?? '') !== '' && !$this->uuidLike((string)$payload['source_version_id'])) {
            $payload['source_version_id'] = null;
        }

        return $payload;
    }

    private function normalizeAction(mixed $value): string
    {
        $action = strtolower(trim((string)$value));
        if (!in_array($action, ['create', 'replace', 'restore'], true)) {
            throw new RuntimeException('Invalid media version action supplied.');
        }

        return $action;
    }

    private function hydrate(array $row): array
    {
        $row['size_bytes'] = (int)($row['size_bytes'] ?? 0);
        $row['version_number'] = (int)($row['version_number'] ?? 0);
        return $row;
    }
}
