<?php
namespace App\Models;

final class DataChangeLogModel extends BaseModel
{
    public function create(array $data): array
    {
        $params = [
            ':table_name' => $this->cleanString($data['table_name'] ?? null) ?? 'unknown',
            ':record_id' => $this->cleanString($data['record_id'] ?? null) ?? '',
            ':record_slug' => $this->cleanString($data['record_slug'] ?? null, true),
            ':record_title' => $this->cleanString($data['record_title'] ?? null, true),
            ':action' => $this->normalizeAction($data['action'] ?? 'update'),
            ':change_scope' => $this->cleanString($data['change_scope'] ?? null) ?? 'data',
            ':actor_user_id' => $this->cleanString($data['actor_user_id'] ?? null),
            ':actor_role' => $this->cleanString($data['actor_role'] ?? null, true),
            ':request_method' => $this->cleanString($data['request_method'] ?? null, true),
            ':request_path' => $this->cleanString($data['request_path'] ?? null, true),
            ':route_path' => $this->cleanString($data['route_path'] ?? null, true),
            ':ip_address' => $this->cleanString($data['ip_address'] ?? null, true),
            ':user_agent' => $this->cleanString($data['user_agent'] ?? null, true),
            ':reason' => $this->cleanString($data['reason'] ?? null, true),
            ':before_json' => json_encode(is_array($data['before_json'] ?? null) ? $data['before_json'] : [], JSON_UNESCAPED_SLASHES),
            ':after_json' => json_encode(is_array($data['after_json'] ?? null) ? $data['after_json'] : [], JSON_UNESCAPED_SLASHES),
            ':diff_json' => json_encode(is_array($data['diff_json'] ?? null) ? $data['diff_json'] : [], JSON_UNESCAPED_SLASHES),
            ':metadata_json' => json_encode(is_array($data['metadata_json'] ?? null) ? $data['metadata_json'] : [], JSON_UNESCAPED_SLASHES),
            ':restorable_json' => json_encode(is_array($data['restorable_json'] ?? null) ? $data['restorable_json'] : [], JSON_UNESCAPED_SLASHES),
            ':restored_from_log_id' => isset($data['restored_from_log_id']) ? (int)$data['restored_from_log_id'] : null,
        ];

        if ($this->isMysql()) {
            $this->query(
                <<<SQL
                    INSERT INTO data_change_logs (
                        table_name, record_id, record_slug, record_title, action, change_scope,
                        actor_user_id, actor_role, request_method, request_path, route_path,
                        ip_address, user_agent, reason, before_json, after_json, diff_json,
                        metadata_json, restorable_json, restored_from_log_id
                    ) VALUES (
                        :table_name, :record_id, :record_slug, :record_title, :action, :change_scope,
                        :actor_user_id, :actor_role, :request_method, :request_path, :route_path,
                        :ip_address, :user_agent, :reason, :before_json,
                        :after_json, :diff_json, :metadata_json, :restorable_json, :restored_from_log_id
                    )
                SQL,
                $params
            );

            return (array)$this->findById((int)$this->db->lastInsertId());
        }

        $beforeJsonParam = $this->jsonParam(':before_json');
        $afterJsonParam = $this->jsonParam(':after_json');
        $diffJsonParam = $this->jsonParam(':diff_json');
        $metadataJsonParam = $this->jsonParam(':metadata_json');
        $restorableJsonParam = $this->jsonParam(':restorable_json');
        $row = $this->query(
            <<<SQL
                INSERT INTO data_change_logs (
                    table_name, record_id, record_slug, record_title, action, change_scope,
                    actor_user_id, actor_role, request_method, request_path, route_path,
                    ip_address, user_agent, reason, before_json, after_json, diff_json,
                    metadata_json, restorable_json, restored_from_log_id
                ) VALUES (
                    :table_name, :record_id, :record_slug, :record_title, :action, :change_scope,
                    :actor_user_id, :actor_role, :request_method, :request_path, :route_path,
                    :ip_address, :user_agent, :reason, {$beforeJsonParam},
                    {$afterJsonParam}, {$diffJsonParam},
                    {$metadataJsonParam}, {$restorableJsonParam}, :restored_from_log_id
                )
                RETURNING *
            SQL,
            $params
        )->fetch();

        return $this->hydrate(is_array($row) ? $row : []);
    }

    public function findById(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        $row = $this->one('SELECT * FROM data_change_logs WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];

        $table = trim((string)($filters['table_name'] ?? ''));
        if ($table !== '') {
            $where[] = 'table_name = :table_name';
            $params[':table_name'] = $table;
        }

        $recordId = trim((string)($filters['record_id'] ?? ''));
        if ($recordId !== '') {
            $where[] = 'record_id = :record_id';
            $params[':record_id'] = $recordId;
        }

        $action = trim((string)($filters['action'] ?? ''));
        if ($action !== '') {
            $where[] = 'action = :action';
            $params[':action'] = strtolower($action);
        }

        $actorUserId = trim((string)($filters['actor_user_id'] ?? ''));
        if ($actorUserId !== '') {
            $where[] = 'actor_user_id = :actor_user_id';
            $params[':actor_user_id'] = $actorUserId;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['record_title', 'request_path', 'route_path', 'reason']);
            $params[':q'] = '%' . $q . '%';
        }

        $limit = min(500, max(1, (int)($filters['limit'] ?? 100)));
        $offset = max(0, (int)($filters['offset'] ?? 0));
        $sql = 'SELECT * FROM data_change_logs';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT :limit OFFSET :offset';

        $statement = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $statement->bindValue($key, $value, \PDO::PARAM_STR);
        }
        $statement->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $statement->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $statement->execute();

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $statement->fetchAll()));
    }

    private function hydrate(array $row): array
    {
        if ($row === []) {
            return [];
        }

        $row = $this->normalizeRowForOutput($row);
        $row['before_json'] = $this->decodeJson($row['before_json'] ?? null, []);
        $row['after_json'] = $this->decodeJson($row['after_json'] ?? null, []);
        $row['diff_json'] = $this->decodeJson($row['diff_json'] ?? null, []);
        $row['metadata_json'] = $this->decodeJson($row['metadata_json'] ?? null, []);
        $row['restorable_json'] = $this->decodeJson($row['restorable_json'] ?? null, []);
        return $row;
    }

    private function normalizeAction(mixed $value): string
    {
        $action = strtolower(trim((string)$value));
        return in_array($action, ['create', 'update', 'delete', 'restore'], true) ? $action : 'update';
    }
}
