<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class GalleryModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listAlbums(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];
        if (!$admin) {
            $where[] = "status = 'published'";
        } elseif (trim((string)($filters['status'] ?? '')) !== '') {
            $where[] = 'status = :status';
            $params[':status'] = strtolower(trim((string)$filters['status']));
        }

        $sql = 'SELECT * FROM gallery_albums';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY sort_order ASC, created_at DESC';

        return $this->many($sql, $params);
    }

    public function findAlbum(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one('SELECT * FROM gallery_albums WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    public function createAlbum(array $data, ?string $actorUserId = null): array
    {
        $slug = (string)$this->cleanString($data['slug'] ?? null);
        $title = (string)$this->cleanString($data['title'] ?? null);
        if ($slug === '' || $title === '') {
            throw new RuntimeException('Album slug and title are required.');
        }
        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO gallery_albums (
                    id, slug, title, summary, cover_image_url, status, sort_order, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :title, :summary, :cover_image_url, :status, :sort_order, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':slug' => $slug,
                ':title' => $title,
                ':summary' => $this->cleanString($data['summary'] ?? null, true),
                ':cover_image_url' => $this->cleanString($data['cover_image_url'] ?? null, true),
                ':status' => in_array(($data['status'] ?? 'draft'), ['draft', 'published', 'archived'], true) ? $data['status'] : 'draft',
                ':sort_order' => (int)($data['sort_order'] ?? 0),
                ':created_by_user_id' => $this->cleanString($actorUserId),
                ':updated_by_user_id' => $this->cleanString($actorUserId),
            ]
        );
        return (array)$this->findAlbum($id);
    }

    public function updateAlbum(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findAlbum($id) === null) {
            return null;
        }
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [':id' => $id, ':updated_by_user_id' => $this->cleanString($actorUserId)];
        foreach (['slug', 'title', 'summary', 'cover_image_url', 'status', 'sort_order'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $this->cleanString($data[$field], true);
                if ($field === 'sort_order') {
                    $params[':' . $field] = (int)$data[$field];
                }
            }
        }
        $this->query('UPDATE gallery_albums SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findAlbum($id);
    }

    public function deleteAlbum(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM gallery_albums WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listItems(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];

        if (!$admin) {
            $where[] = "i.status = 'published'";
        } elseif (trim((string)($filters['status'] ?? '')) !== '') {
            $where[] = 'i.status = :status';
            $params[':status'] = strtolower(trim((string)$filters['status']));
        }

        $albumId = trim((string)($filters['album_id'] ?? ''));
        if ($albumId !== '') {
            $where[] = 'i.album_id = :album_id';
            $params[':album_id'] = $albumId;
        }

        $sql = <<<SQL
            SELECT i.*, a.slug AS album_slug, a.title AS album_title
            FROM gallery_items i
            LEFT JOIN gallery_albums a ON a.id = i.album_id
        SQL;
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY i.sort_order ASC, i.created_at DESC';

        return $this->many($sql, $params);
    }

    public function findItem(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        return $this->one('SELECT * FROM gallery_items WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    public function createItem(array $data, ?string $actorUserId = null): array
    {
        $title = (string)$this->cleanString($data['title'] ?? null);
        $mediaUrl = (string)$this->cleanString($data['media_url'] ?? null);
        if ($title === '' || $mediaUrl === '') {
            throw new RuntimeException('Gallery item title and media URL are required.');
        }
        $mediaType = strtolower((string)$this->cleanString($data['media_type'] ?? 'image', true));
        if (!in_array($mediaType, ['image', 'video'], true)) {
            throw new RuntimeException('Invalid gallery media type supplied.');
        }

        $id = UUID::v4();
        $this->query(
            <<<SQL
                INSERT INTO gallery_items (
                    id, album_id, media_asset_id, title, caption, media_type, media_url,
                    thumbnail_url, status, sort_order, captured_at, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :album_id, :media_asset_id, :title, :caption, :media_type, :media_url,
                    :thumbnail_url, :status, :sort_order, :captured_at, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            [
                ':id' => $id,
                ':album_id' => $this->cleanString($data['album_id'] ?? null),
                ':media_asset_id' => $this->cleanString($data['media_asset_id'] ?? null),
                ':title' => $title,
                ':caption' => $this->cleanString($data['caption'] ?? null, true),
                ':media_type' => $mediaType,
                ':media_url' => $mediaUrl,
                ':thumbnail_url' => $this->cleanString($data['thumbnail_url'] ?? null, true),
                ':status' => in_array(($data['status'] ?? 'draft'), ['draft', 'published', 'archived'], true) ? $data['status'] : 'draft',
                ':sort_order' => (int)($data['sort_order'] ?? 0),
                ':captured_at' => $this->normalizeDateTime($data['captured_at'] ?? null),
                ':created_by_user_id' => $this->cleanString($actorUserId),
                ':updated_by_user_id' => $this->cleanString($actorUserId),
            ]
        );
        return (array)$this->findItem($id);
    }

    public function updateItem(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findItem($id) === null) {
            return null;
        }
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [':id' => $id, ':updated_by_user_id' => $this->cleanString($actorUserId)];
        foreach (['album_id', 'media_asset_id', 'title', 'caption', 'media_type', 'media_url', 'thumbnail_url', 'status', 'captured_at'] as $field) {
            if (array_key_exists($field, $data)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $field === 'captured_at'
                    ? $this->normalizeDateTime($data[$field])
                    : $this->cleanString($data[$field], true);
            }
        }
        if (array_key_exists('sort_order', $data)) {
            $assignments[] = 'sort_order = :sort_order';
            $params[':sort_order'] = (int)$data['sort_order'];
        }
        $this->query('UPDATE gallery_items SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findItem($id);
    }

    public function deleteItem(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM gallery_items WHERE id = :id', [':id' => $id]);
        return true;
    }
}
