<?php
namespace App\Models;

use App\Utils\UUID;

final class PasswordResetTokenModel extends BaseModel
{
    /**
     * @return array<string, mixed>
     */
    public function create(string $userId, string $email, string $plainToken, int $ttlMinutes, string $ipAddress = ''): array
    {
        $id = UUID::v4();
        $expiresAt = $this->normalizeDateTime('+' . max(5, $ttlMinutes) . ' minutes');
        $this->query(
            <<<SQL
                INSERT INTO password_reset_tokens (
                    id, user_id, email, token_hash, expires_at, requested_ip
                ) VALUES (
                    :id, :user_id, :email, :token_hash, :expires_at, :requested_ip
                )
            SQL,
            [
                ':id' => $id,
                ':user_id' => $userId,
                ':email' => strtolower(trim($email)),
                ':token_hash' => $this->hashToken($plainToken),
                ':expires_at' => $expiresAt,
                ':requested_ip' => $this->cleanString($ipAddress, true),
            ]
        );

        return (array)$this->findById($id);
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }

        return $this->one('SELECT * FROM password_reset_tokens WHERE id = :id LIMIT 1', [':id' => $id]);
    }

    public function findValid(string $email, string $plainToken): ?array
    {
        $normalizedEmail = strtolower(trim($email));
        $hashes = $this->hashCandidates($plainToken);
        if ($normalizedEmail === '' || $hashes === []) {
            return null;
        }

        $params = [':email' => $normalizedEmail];
        $placeholders = [];
        foreach ($hashes as $index => $hash) {
            $key = ':token_hash_' . $index;
            $placeholders[] = $key;
            $params[$key] = $hash;
        }

        $row = $this->one(
            'SELECT * FROM password_reset_tokens WHERE LOWER(email) = :email AND token_hash IN (' . implode(', ', $placeholders) . ') AND used_at IS NULL AND expires_at > ' . $this->nowExpression() . ' ORDER BY created_at DESC LIMIT 1',
            $params
        );

        return $row ?: null;
    }

    public function markUsed(string $id): void
    {
        if (!$this->uuidLike($id)) {
            return;
        }

        $this->query(
            'UPDATE password_reset_tokens SET used_at = ' . $this->nowExpression() . ' WHERE id = :id AND used_at IS NULL',
            [':id' => $id]
        );
    }

    public function invalidateUserTokens(string $userId): void
    {
        if (!$this->uuidLike($userId)) {
            return;
        }

        $this->query(
            'UPDATE password_reset_tokens SET used_at = ' . $this->nowExpression() . ' WHERE user_id = :user_id AND used_at IS NULL',
            [':user_id' => $userId]
        );
    }

    public function deleteExpired(): int
    {
        $statement = $this->query('DELETE FROM password_reset_tokens WHERE expires_at < ' . $this->nowExpression() . ' OR used_at IS NOT NULL');
        return $statement->rowCount();
    }

    private function hashToken(string $plainToken): string
    {
        $token = trim($plainToken);
        return $token === '' ? '' : hash('sha256', $token);
    }

    /**
     * @return array<int, string>
     */
    private function hashCandidates(string $plainToken): array
    {
        $raw = trim($plainToken);
        $candidates = [];
        if ($raw !== '') {
            $candidates[] = hash('sha256', $raw);
        }

        $normalizedCode = strtoupper((string)(preg_replace('/[^A-Za-z0-9]/', '', $raw) ?? ''));
        if ($normalizedCode !== '') {
            $candidates[] = hash('sha256', $normalizedCode);
        }

        return array_values(array_unique($candidates));
    }
}
