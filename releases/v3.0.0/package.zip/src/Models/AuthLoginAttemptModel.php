<?php
namespace App\Models;

use App\Utils\UUID;

final class AuthLoginAttemptModel extends BaseModel
{
    private const TABLE = 'auth_login_attempts';

    public function findByThrottleKey(string $throttleKey): ?array
    {
        $row = $this->one('SELECT * FROM ' . self::TABLE . ' WHERE throttle_key = :throttle_key LIMIT 1', [
            ':throttle_key' => $throttleKey,
        ]);

        return $row ?: null;
    }

    public function recordFailure(
        string $throttleKey,
        string $email,
        string $ipAddress,
        int $maxAttempts,
        int $decaySeconds,
        int $lockoutSeconds
    ): array {
        $existing = $this->findByThrottleKey($throttleKey);
        $now = time();
        $windowStart = $now - max(60, $decaySeconds);

        if ($existing === null) {
            $attempts = 1;
            $lockedUntil = $attempts >= $maxAttempts ? $this->normalizeDateTime('+' . max(60, $lockoutSeconds) . ' seconds') : null;
            $this->query(
                'INSERT INTO ' . self::TABLE . ' (id, throttle_key, email, ip_address, attempts, first_attempt_at, last_attempt_at, locked_until)'
                . ' VALUES (:id, :throttle_key, :email, :ip_address, :attempts, :first_attempt_at, :last_attempt_at, :locked_until)',
                [
                    ':id' => UUID::v4(),
                    ':throttle_key' => $throttleKey,
                    ':email' => strtolower($email),
                    ':ip_address' => $ipAddress,
                    ':attempts' => $attempts,
                    ':first_attempt_at' => $this->normalizeDateTime('now'),
                    ':last_attempt_at' => $this->normalizeDateTime('now'),
                    ':locked_until' => $lockedUntil,
                ]
            );

            return (array)$this->findByThrottleKey($throttleKey);
        }

        $lastAttempt = strtotime((string)($existing['last_attempt_at'] ?? '')) ?: 0;
        $attempts = $lastAttempt < $windowStart ? 1 : ((int)($existing['attempts'] ?? 0) + 1);
        $firstAttemptAt = $lastAttempt < $windowStart
            ? $this->normalizeDateTime('now')
            : $this->normalizeDateTime((string)($existing['first_attempt_at'] ?? 'now'));
        $lockedUntil = $attempts >= $maxAttempts ? $this->normalizeDateTime('+' . max(60, $lockoutSeconds) . ' seconds') : null;

        $this->query(
            'UPDATE ' . self::TABLE
            . ' SET attempts = :attempts, email = :email, ip_address = :ip_address, first_attempt_at = :first_attempt_at, last_attempt_at = :last_attempt_at, locked_until = :locked_until, updated_at = ' . $this->nowExpression()
            . ' WHERE throttle_key = :throttle_key',
            [
                ':attempts' => $attempts,
                ':email' => strtolower($email),
                ':ip_address' => $ipAddress,
                ':first_attempt_at' => $firstAttemptAt,
                ':last_attempt_at' => $this->normalizeDateTime('now'),
                ':locked_until' => $lockedUntil,
                ':throttle_key' => $throttleKey,
            ]
        );

        return (array)$this->findByThrottleKey($throttleKey);
    }

    public function clear(string $throttleKey): void
    {
        $this->query('DELETE FROM ' . self::TABLE . ' WHERE throttle_key = :throttle_key', [
            ':throttle_key' => $throttleKey,
        ]);
    }

    public function deleteExpired(int $decaySeconds): int
    {
        $threshold = $this->normalizeDateTime('-' . max(60, $decaySeconds) . ' seconds') ?? $this->normalizeDateTime('now');
        $statement = $this->query(
            'DELETE FROM ' . self::TABLE . ' WHERE last_attempt_at < :threshold AND (locked_until IS NULL OR locked_until < :now)',
            [
                ':threshold' => $threshold,
                ':now' => $this->normalizeDateTime('now'),
            ]
        );

        return $statement->rowCount();
    }
}
