<?php
namespace App\Models;

use App\Utils\UUID;
use RuntimeException;

final class NewsPostModel extends BaseModel
{
    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = [], bool $admin = false): array
    {
        $where = [];
        $params = [];
        if (!$admin) {
            $where[] = "status = 'published'";
        } elseif (trim((string)($filters['status'] ?? '')) !== '') {
            $where[] = 'status = :status';
            $params[':status'] = strtolower(trim((string)$filters['status']));
        }

        $type = strtolower(trim((string)($filters['post_type'] ?? $filters['type'] ?? '')));
        if ($type !== '') {
            $where[] = 'post_type = :post_type';
            $params[':post_type'] = $type;
        }

        if (array_key_exists('featured', $filters)) {
            $where[] = 'is_featured = :is_featured';
            $params[':is_featured'] = $this->boolValue($filters['featured']) ? 1 : 0;
        }

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['title', 'summary', 'body']);
            $params[':q'] = '%' . $q . '%';
        }

        $sql = 'SELECT * FROM news_posts';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY ' . $this->orderByNullsLast('published_at', 'DESC') . ', created_at DESC';

        if (isset($filters['limit'])) {
            $sql .= ' LIMIT ' . max(1, min(100, (int)$filters['limit']));
        }

        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $this->many($sql, $params)));
    }

    public function findById(string $id): ?array
    {
        if (!$this->uuidLike($id)) {
            return null;
        }
        $row = $this->one('SELECT * FROM news_posts WHERE id = :id LIMIT 1', [':id' => $id]);
        return $row ? $this->hydrate($row) : null;
    }

    public function findBySlug(string $slug, bool $admin = false): ?array
    {
        $sql = 'SELECT * FROM news_posts WHERE slug = :slug';
        if (!$admin) {
            $sql .= " AND status = 'published'";
        }
        $sql .= ' LIMIT 1';
        $row = $this->one($sql, [':slug' => trim($slug)]);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(array $data, ?string $actorUserId = null): array
    {
        $payload = $this->normalizePayload($data, true);
        $payload['id'] = UUID::v4();
        $payload['created_by_user_id'] = $this->cleanString($actorUserId);
        $payload['updated_by_user_id'] = $this->cleanString($actorUserId);
        $metaJsonParam = $this->jsonParam(':meta_json');

        $this->query(
            <<<SQL
                INSERT INTO news_posts (
                    id, slug, post_type, title, summary, body, featured_image_url,
                    status, is_featured, published_at, meta_json, created_by_user_id, updated_by_user_id
                ) VALUES (
                    :id, :slug, :post_type, :title, :summary, :body, :featured_image_url,
                    :status, :is_featured, :published_at, {$metaJsonParam}, :created_by_user_id, :updated_by_user_id
                )
            SQL,
            $payload
        );

        return (array)$this->findById($payload['id']);
    }

    public function update(string $id, array $data, ?string $actorUserId = null): ?array
    {
        if ($this->findById($id) === null) {
            return null;
        }

        $payload = $this->normalizePayload($data, false);
        $assignments = ['updated_at = NOW()', 'updated_by_user_id = :updated_by_user_id'];
        $params = [
            ':id' => $id,
            ':updated_by_user_id' => $this->cleanString($actorUserId),
        ];

        foreach (['slug', 'post_type', 'title', 'summary', 'body', 'featured_image_url', 'status', 'published_at'] as $field) {
            if (array_key_exists($field, $payload)) {
                $assignments[] = $field . ' = :' . $field;
                $params[':' . $field] = $payload[$field];
            }
        }
        if (array_key_exists('is_featured', $payload)) {
            $assignments[] = 'is_featured = :is_featured';
            $params[':is_featured'] = $payload['is_featured'];
        }
        if (array_key_exists('meta_json', $payload)) {
            $assignments[] = 'meta_json = ' . $this->jsonParam(':meta_json');
            $params[':meta_json'] = $payload['meta_json'];
        }

        $this->query('UPDATE news_posts SET ' . implode(', ', $assignments) . ' WHERE id = :id', $params);
        return $this->findById($id);
    }

    public function delete(string $id): bool
    {
        if (!$this->uuidLike($id)) {
            return false;
        }
        $this->query('DELETE FROM news_posts WHERE id = :id', [':id' => $id]);
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizePayload(array $data, bool $create): array
    {
        $payload = [];
        foreach (['slug', 'title', 'summary', 'body', 'featured_image_url'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $this->cleanString($data[$field], true);
            }
        }

        if ($create && (($payload['slug'] ?? '') === '' || ($payload['title'] ?? '') === '')) {
            throw new RuntimeException('News slug and title are required.');
        }

        if (array_key_exists('post_type', $data)) {
            $type = strtolower((string)$this->cleanString($data['post_type'], true));
            if (!in_array($type, ['news', 'announcement', 'notice'], true)) {
                throw new RuntimeException('Invalid news post type supplied.');
            }
            $payload['post_type'] = $type;
        } elseif ($create) {
            $payload['post_type'] = 'news';
        }

        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$this->cleanString($data['status'], true));
            if (!in_array($status, ['draft', 'published', 'archived'], true)) {
                throw new RuntimeException('Invalid news status supplied.');
            }
            $payload['status'] = $status;
        } elseif ($create) {
            $payload['status'] = 'draft';
        }

        if (array_key_exists('is_featured', $data)) {
            $payload['is_featured'] = $this->boolValue($data['is_featured']) ? 1 : 0;
        } elseif ($create) {
            $payload['is_featured'] = 0;
        }

        if (array_key_exists('published_at', $data)) {
            $payload['published_at'] = $this->normalizeDateTime($data['published_at']);
        } elseif ($create) {
            $payload['published_at'] = null;
        }

        if (array_key_exists('meta', $data) || array_key_exists('meta_json', $data)) {
            $payload['meta_json'] = json_encode(
                is_array($data['meta'] ?? null) ? $data['meta'] : (is_array($data['meta_json'] ?? null) ? $data['meta_json'] : []),
                JSON_UNESCAPED_SLASHES
            );
        } elseif ($create) {
            $payload['meta_json'] = '{}';
        }

        if ($create) {
            foreach (['summary', 'featured_image_url'] as $field) {
                if (!array_key_exists($field, $payload)) {
                    $payload[$field] = null;
                }
            }
            if (!array_key_exists('body', $payload)) {
                $payload['body'] = '';
            }
        }

        return $payload;
    }

    private function hydrate(array $row): array
    {
        $row['meta'] = $this->decodeJson($row['meta_json'] ?? null, []);
        unset($row['meta_json']);
        return $row;
    }
}
