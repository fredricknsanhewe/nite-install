<?php
namespace App\Models;

final class SystemAuditLogModel extends BaseModel
{
    public function create(array $data): void
    {
        $requiredPermissionsParam = $this->jsonParam(':required_permissions');
        $requestPayloadParam = $this->jsonParam(':request_payload');
        $responsePayloadParam = $this->jsonParam(':response_payload');
        $this->query(
            <<<SQL
                INSERT INTO system_audit_logs (
                    scope, actor_user_id, actor_role, method, path, route_path,
                    required_permissions, success, http_status, duration_ms,
                    ip_address, user_agent, request_payload, response_payload, error_message
                ) VALUES (
                    :scope, :actor_user_id, :actor_role, :method, :path, :route_path,
                    {$requiredPermissionsParam}, :success, :http_status, :duration_ms,
                    :ip_address, :user_agent, {$requestPayloadParam}, {$responsePayloadParam}, :error_message
                )
            SQL,
            [
                ':scope' => (string)($data['scope'] ?? 'api'),
                ':actor_user_id' => $this->cleanString($data['actor_user_id'] ?? null),
                ':actor_role' => $this->cleanString($data['actor_role'] ?? null),
                ':method' => strtoupper((string)($data['method'] ?? 'GET')),
                ':path' => (string)($data['path'] ?? '/'),
                ':route_path' => $this->cleanString($data['route_path'] ?? null),
                ':required_permissions' => json_encode(is_array($data['required_permissions'] ?? null) ? $data['required_permissions'] : [], JSON_UNESCAPED_SLASHES),
                ':success' => $this->boolValue($data['success'] ?? true) ? 1 : 0,
                ':http_status' => (int)($data['http_status'] ?? 200),
                ':duration_ms' => max(0, (int)($data['duration_ms'] ?? 0)),
                ':ip_address' => $this->cleanString($data['ip_address'] ?? null),
                ':user_agent' => $this->cleanString($data['user_agent'] ?? null),
                ':request_payload' => json_encode(is_array($data['request_payload'] ?? null) ? $data['request_payload'] : [], JSON_UNESCAPED_SLASHES),
                ':response_payload' => json_encode(is_array($data['response_payload'] ?? null) ? $data['response_payload'] : [], JSON_UNESCAPED_SLASHES),
                ':error_message' => $this->cleanString($data['error_message'] ?? null),
            ]
        );
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = $this->likeAny(['path', 'route_path', 'error_message']);
            $params[':q'] = '%' . $q . '%';
        }

        $scope = trim((string)($filters['scope'] ?? ''));
        if ($scope !== '') {
            $where[] = 'scope = :scope';
            $params[':scope'] = $scope;
        }

        $actorUserId = trim((string)($filters['actor_user_id'] ?? ''));
        if ($actorUserId !== '') {
            $where[] = 'actor_user_id = :actor_user_id';
            $params[':actor_user_id'] = $actorUserId;
        }

        $limit = min(500, max(1, (int)($filters['limit'] ?? 100)));
        $offset = max(0, (int)($filters['offset'] ?? 0));
        $sql = 'SELECT * FROM system_audit_logs';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC LIMIT :limit OFFSET :offset';
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;

        $statement = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $type = is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR;
            $statement->bindValue($key, $value, $type);
        }
        $statement->execute();

        $rows = $statement->fetchAll();
        return array_values(array_map(fn (array $row): array => $this->hydrate($row), $rows));
    }

    private function hydrate(array $row): array
    {
        $row = $this->normalizeRowForOutput($row);
        $row['required_permissions'] = $this->decodeJson($row['required_permissions'] ?? null, []);
        $row['request_payload'] = $this->decodeJson($row['request_payload'] ?? null, []);
        $row['response_payload'] = $this->decodeJson($row['response_payload'] ?? null, []);
        return $row;
    }
}
