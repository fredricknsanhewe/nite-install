<?php
namespace App\Models;

final class SiteSettingsModel extends BaseModel
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public function all(?string $visibility = null): array
    {
        $sql = 'SELECT * FROM site_settings';
        $params = [];
        if ($visibility !== null && $visibility !== '') {
            $sql .= ' WHERE visibility = :visibility';
            $params[':visibility'] = $visibility;
        }
        $sql .= ' ORDER BY config_key ASC';

        $rows = $this->many($sql, $params);
        $result = [];
        foreach ($rows as $row) {
            $result[(string)$row['config_key']] = [
                'config_key' => (string)$row['config_key'],
                'visibility' => (string)$row['visibility'],
                'settings' => $this->decodeJson($row['settings'] ?? null, []),
                'updated_at' => $row['updated_at'] ?? null,
                'updated_by_user_id' => $row['updated_by_user_id'] ?? null,
            ];
        }
        return $result;
    }

    public function get(string $key): ?array
    {
        $row = $this->one('SELECT * FROM site_settings WHERE config_key = :config_key LIMIT 1', [
            ':config_key' => $key,
        ]);
        if ($row === null) {
            return null;
        }
        return [
            'config_key' => (string)$row['config_key'],
            'visibility' => (string)$row['visibility'],
            'settings' => $this->decodeJson($row['settings'] ?? null, []),
            'updated_at' => $row['updated_at'] ?? null,
            'updated_by_user_id' => $row['updated_by_user_id'] ?? null,
        ];
    }

    public function upsert(string $key, string $visibility, array $settings, ?string $actorUserId = null): array
    {
        $normalizedVisibility = in_array($visibility, ['public', 'admin'], true) ? $visibility : 'admin';
        $params = [
            ':config_key' => $key,
            ':visibility' => $normalizedVisibility,
            ':settings' => json_encode($settings, JSON_UNESCAPED_SLASHES),
            ':updated_by_user_id' => $this->cleanString($actorUserId),
        ];

        if ($this->isMysql()) {
            $this->query(
                <<<SQL
                    INSERT INTO site_settings (config_key, visibility, settings, updated_by_user_id, updated_at)
                    VALUES (:config_key, :visibility, :settings, :updated_by_user_id, NOW())
                    ON DUPLICATE KEY UPDATE
                        visibility = VALUES(visibility),
                        settings = VALUES(settings),
                        updated_by_user_id = VALUES(updated_by_user_id),
                        updated_at = NOW()
                SQL,
                $params
            );
        } else {
            $settingsJsonParam = $this->jsonParam(':settings');
            $this->query(
                <<<SQL
                    INSERT INTO site_settings (config_key, visibility, settings, updated_by_user_id, updated_at)
                    VALUES (:config_key, :visibility, {$settingsJsonParam}, :updated_by_user_id, NOW())
                    ON CONFLICT (config_key) DO UPDATE
                    SET visibility = EXCLUDED.visibility,
                        settings = EXCLUDED.settings,
                        updated_by_user_id = EXCLUDED.updated_by_user_id,
                        updated_at = NOW()
                SQL,
                $params
            );
        }

        return (array)$this->get($key);
    }
}
