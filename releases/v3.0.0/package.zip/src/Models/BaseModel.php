<?php
namespace App\Models;

use App\Config\Database;
use App\Config\Env;
use App\Support\QueryBuilder;
use DateTimeImmutable;
use DateTimeZone;
use PDO;
use PDOException;
use PDOStatement;

abstract class BaseModel
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    protected function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $statement = $this->db->prepare($sql);
            $statement->execute($params);
            return $statement;
        } catch (PDOException $e) {
            if (!$this->debugEnabled()) {
                throw $e;
            }

            $message = $e->getMessage() . ' SQL: ' . $sql;
            if ($params !== []) {
                $message .= ' Params: ' . implode(', ', array_keys($params));
            }

            throw new PDOException($message, (int)$e->getCode(), $e);
        }
    }

    protected function one(string $sql, array $params = []): ?array
    {
        $row = $this->query($sql, $params)->fetch();
        return $row ? $this->normalizeRowForOutput($row) : null;
    }

    protected function many(string $sql, array $params = []): array
    {
        return array_map(
            fn (array $row): array => $this->normalizeRowForOutput($row),
            $this->query($sql, $params)->fetchAll()
        );
    }

    protected function table(string $table): QueryBuilder
    {
        return new QueryBuilder($this->db, $table, $this->databaseDriver());
    }

    protected function decodeJson(mixed $value, mixed $fallback = []): mixed
    {
        if (is_array($value)) {
            return $value;
        }
        if (!is_string($value) || trim($value) === '') {
            return $fallback;
        }

        $decoded = json_decode($value, true);
        return $decoded === null && json_last_error() !== JSON_ERROR_NONE ? $fallback : $decoded;
    }

    protected function boolValue(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int)$value !== 0;
        }
        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }

        return !empty($value);
    }

    protected function cleanString(mixed $value, bool $allowEmpty = false): ?string
    {
        if ($value === null) {
            return null;
        }

        $text = trim((string)$value);
        if ($text === '' && !$allowEmpty) {
            return null;
        }

        return $text;
    }

    protected function uuidLike(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1;
    }

    protected function databaseDriver(): string
    {
        return Database::driver();
    }

    protected function isMysql(): bool
    {
        return $this->databaseDriver() === 'mysql';
    }

    protected function isPgsql(): bool
    {
        return $this->databaseDriver() === 'pgsql';
    }

    protected function jsonParam(string $parameterName): string
    {
        return $this->isPgsql() ? 'CAST(' . $parameterName . ' AS JSONB)' : $parameterName;
    }

    /**
     * @param array<int, string> $columns
     */
    protected function likeAny(array $columns, string $parameterName = ':q'): string
    {
        $clauses = [];
        foreach ($columns as $column) {
            $clauses[] = $this->isPgsql()
                ? $column . ' ILIKE ' . $parameterName
                : 'LOWER(' . $column . ') LIKE LOWER(' . $parameterName . ')';
        }

        return '(' . implode(' OR ', $clauses) . ')';
    }

    protected function orderByNullsLast(string $column, string $direction = 'DESC'): string
    {
        $normalizedDirection = strtoupper(trim($direction)) === 'ASC' ? 'ASC' : 'DESC';
        if ($this->isPgsql()) {
            return $column . ' ' . $normalizedDirection . ' NULLS LAST';
        }

        return '(' . $column . ' IS NULL) ASC, ' . $column . ' ' . $normalizedDirection;
    }

    protected function normalizeDateTime(mixed $value): ?string
    {
        $text = $this->cleanString($value, true);
        if ($text === null || $text === '') {
            return null;
        }

        $date = $this->parseDateTime($text, $this->userTimezone());
        if ($date === null) {
            return $text;
        }

        $utc = $date->setTimezone(new DateTimeZone('UTC'));
        return $this->isMysql()
            ? $utc->format('Y-m-d H:i:s')
            : $utc->format('c');
    }

    protected function nowExpression(): string
    {
        return $this->isPgsql() ? 'NOW()' : 'CURRENT_TIMESTAMP';
    }

    private function debugEnabled(): bool
    {
        $value = getenv('APP_DEBUG');
        if ($value === false) {
            return false;
        }

        return in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    protected function normalizeRowForOutput(array $row): array
    {
        foreach ($row as $key => $value) {
            if (!is_string($value) || !$this->isTemporalColumn((string)$key)) {
                continue;
            }
            $normalized = $this->normalizeOutputDateTime($value);
            if ($normalized !== null) {
                $row[$key] = $normalized;
            }
        }

        return $row;
    }

    private function isTemporalColumn(string $name): bool
    {
        return (bool)preg_match('/(_at|_until|_deadline)$/i', $name);
    }

    private function normalizeOutputDateTime(string $value): ?string
    {
        $text = trim($value);
        if ($text === '' || preg_match('/\d{1,2}:\d{2}/', $text) !== 1) {
            return null;
        }

        $date = $this->parseDateTime($text, $this->storageTimezone());
        if (!$date) {
            return null;
        }

        $timezone = $this->userTimezone();
        $localized = $date->setTimezone($timezone);
        return $timezone->getName() === 'UTC'
            ? $localized->format('Y-m-d\TH:i:s\Z')
            : $localized->format('Y-m-d\TH:i:sP');
    }

    private function parseDateTime(string $value, DateTimeZone $timezone): ?DateTimeImmutable
    {
        try {
            return new DateTimeImmutable($value, $timezone);
        } catch (\Throwable) {
            return null;
        }
    }

    private function userTimezone(): DateTimeZone
    {
        $timezone = trim((string)($_SERVER['HTTP_X_USER_TIMEZONE'] ?? ''));
        if ($timezone === '') {
            $timezone = 'UTC';
        }

        try {
            return new DateTimeZone($timezone);
        } catch (\Throwable) {
            return new DateTimeZone('UTC');
        }
    }

    private function storageTimezone(): DateTimeZone
    {
        $timezone = trim((string)(Env::get('APP_STORAGE_TIMEZONE', Env::get('APP_TIMEZONE', 'UTC')) ?? 'UTC'));
        if ($timezone === '') {
            $timezone = 'UTC';
        }

        try {
            return new DateTimeZone($timezone);
        } catch (\Throwable) {
            return new DateTimeZone('UTC');
        }
    }
}
