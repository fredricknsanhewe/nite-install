<?php
namespace App\Console;

final class ConsoleSupport
{
    public static function rootPath(): string
    {
        return dirname(__DIR__, 2);
    }

    public static function studly(string $value): string
    {
        $normalized = preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', trim($value)) ?? trim($value);
        $parts = preg_split('/[^a-zA-Z0-9]+/', $normalized) ?: [];
        $parts = array_values(array_filter(array_map('trim', $parts), static fn (string $part): bool => $part !== ''));

        return implode('', array_map(static function (string $part): string {
            return ucfirst(strtolower($part));
        }, $parts));
    }

    public static function snake(string $value): string
    {
        $normalized = preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', trim($value)) ?? trim($value);
        $normalized = strtolower($normalized);
        $normalized = preg_replace('/[^a-z0-9]+/', '_', $normalized) ?? $normalized;
        return trim($normalized, '_');
    }

    public static function kebab(string $value): string
    {
        return str_replace('_', '-', self::snake($value));
    }

    public static function pluralize(string $value): string
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return '';
        }

        $lower = strtolower($trimmed);
        if (in_array($lower, ['news', 'series', 'species'], true)) {
            return $trimmed;
        }
        if (preg_match('/[^aeiou]y$/i', $trimmed) === 1) {
            return substr($trimmed, 0, -1) . 'ies';
        }
        if (preg_match('/(s|x|z|ch|sh)$/i', $trimmed) === 1) {
            return $trimmed . 'es';
        }
        if (str_ends_with(strtolower($trimmed), 'people')) {
            return $trimmed;
        }
        return $trimmed . 's';
    }

    public static function singularize(string $value): string
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return '';
        }

        $lower = strtolower($trimmed);
        if (in_array($lower, ['news', 'series', 'species'], true) || str_ends_with($lower, 'us')) {
            return $trimmed;
        }
        if (preg_match('/ies$/i', $trimmed) === 1) {
            return substr($trimmed, 0, -3) . 'y';
        }
        if (preg_match('/(sses|xes|zes|ches|shes)$/i', $trimmed) === 1) {
            return substr($trimmed, 0, -2);
        }
        if (preg_match('/s$/i', $trimmed) === 1 && preg_match('/ss$/i', $trimmed) !== 1) {
            return substr($trimmed, 0, -1);
        }
        return $trimmed;
    }

    /**
     * @param array<string, string> $replacements
     */
    public static function renderTemplate(string $template, array $replacements): string
    {
        return strtr($template, $replacements);
    }

    public static function ensureDirectory(string $path): void
    {
        if (is_dir($path)) {
            return;
        }

        if (!@mkdir($path, 0777, true) && !is_dir($path)) {
            throw new \RuntimeException('Failed to create directory: ' . $path);
        }
    }

    public static function timestamp(): string
    {
        return gmdate('Ymd_His');
    }
}
