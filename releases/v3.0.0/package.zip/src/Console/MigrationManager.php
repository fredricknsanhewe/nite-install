<?php
namespace App\Console;

use App\Config\App;
use App\Config\Database;
use App\Support\DatabaseSchemaRunner;
use PDO;
use RuntimeException;

final class MigrationManager
{
    private const TABLE = 'app_console_migrations';

    private string $rootPath;

    public function __construct(?string $rootPath = null)
    {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
    }

    /**
     * @return array<string, mixed>
     */
    public function migrate(bool $applyBaseSchema = true): array
    {
        $connection = Database::connection();
        $transactional = $this->supportsTransactionalMigrations();
        if ($applyBaseSchema) {
            DatabaseSchemaRunner::apply($connection);
        }

        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $pending = $this->pendingMigrations($connection);
        $applied = [];
        $batch = $this->nextBatch($connection);

        foreach ($pending as $migration) {
            if ($transactional) {
                $connection->beginTransaction();
            }
            try {
                foreach ($this->statementsFor($migration, 'up') as $statement) {
                    $connection->exec($statement);
                }

                $insert = $connection->prepare(
                    'INSERT INTO ' . self::TABLE . ' (id, name, version, batch, applied_at) VALUES (:id, :name, :version, :batch, ' . $this->nowExpression() . ')'
                );
                $insert->execute([
                    ':id' => $migration['id'],
                    ':name' => $migration['name'],
                    ':version' => $migration['version'],
                    ':batch' => $batch,
                ]);

                if ($transactional && $connection->inTransaction()) {
                    $connection->commit();
                }
                $applied[] = $migration;
            } catch (\Throwable $e) {
                if ($transactional && $connection->inTransaction()) {
                    $connection->rollBack();
                }
                throw new RuntimeException('Failed to apply migration ' . $migration['id'] . ': ' . $e->getMessage(), 0, $e);
            }
        }

        return [
            'schema_path' => Database::schemaPath(),
            'driver' => Database::driver(),
            'applied' => $applied,
            'pending_count' => count($pending) - count($applied),
            'applied_count' => count($applied),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function rollback(int $steps = 1): array
    {
        $connection = Database::connection();
        $transactional = $this->supportsTransactionalMigrations();
        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $rows = $this->appliedRows($connection, max(1, $steps));
        $discovered = $this->discoverMigrationsById();
        $rolledBack = [];

        foreach ($rows as $row) {
            $migration = $discovered[(string)$row['id']] ?? null;
            if ($migration === null) {
                throw new RuntimeException('Migration file is missing for applied migration: ' . (string)$row['id']);
            }

            if ($transactional) {
                $connection->beginTransaction();
            }
            try {
                foreach ($this->statementsFor($migration, 'down') as $statement) {
                    $connection->exec($statement);
                }

                $delete = $connection->prepare('DELETE FROM ' . self::TABLE . ' WHERE id = :id');
                $delete->execute([':id' => $migration['id']]);

                if ($transactional && $connection->inTransaction()) {
                    $connection->commit();
                }
                $rolledBack[] = $migration;
            } catch (\Throwable $e) {
                if ($transactional && $connection->inTransaction()) {
                    $connection->rollBack();
                }
                throw new RuntimeException('Failed to roll back migration ' . $migration['id'] . ': ' . $e->getMessage(), 0, $e);
            }
        }

        return [
            'driver' => Database::driver(),
            'rolled_back' => $rolledBack,
            'requested_steps' => max(1, $steps),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function rollbackToVersion(string $targetVersion): array
    {
        $connection = Database::connection();
        $transactional = $this->supportsTransactionalMigrations();
        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $rows = $this->allAppliedRows($connection);
        $matching = array_values(array_filter($rows, static function (array $row) use ($targetVersion): bool {
            return version_compare((string)($row['version'] ?? '0.0.0'), $targetVersion, '>');
        }));

        if ($matching === []) {
            return [
                'driver' => Database::driver(),
                'target_version' => $targetVersion,
                'rolled_back' => [],
            ];
        }

        $discovered = $this->discoverMigrationsById();
        $rolledBack = [];
        foreach ($matching as $row) {
            $migration = $discovered[(string)$row['id']] ?? null;
            if ($migration === null) {
                throw new RuntimeException('Migration file is missing for applied migration: ' . (string)$row['id']);
            }

            if ($transactional) {
                $connection->beginTransaction();
            }
            try {
                foreach ($this->statementsFor($migration, 'down') as $statement) {
                    $connection->exec($statement);
                }

                $delete = $connection->prepare('DELETE FROM ' . self::TABLE . ' WHERE id = :id');
                $delete->execute([':id' => $migration['id']]);

                if ($transactional && $connection->inTransaction()) {
                    $connection->commit();
                }
                $rolledBack[] = $migration;
            } catch (\Throwable $e) {
                if ($transactional && $connection->inTransaction()) {
                    $connection->rollBack();
                }
                throw new RuntimeException('Failed to roll back migration ' . $migration['id'] . ': ' . $e->getMessage(), 0, $e);
            }
        }

        return [
            'driver' => Database::driver(),
            'target_version' => $targetVersion,
            'rolled_back' => $rolledBack,
        ];
    }

    /**
     * @param array<int, string> $ids
     * @return array<string, mixed>
     */
    public function rollbackIds(array $ids): array
    {
        $requestedIds = array_values(array_unique(array_filter(array_map('strval', $ids), static fn (string $value): bool => trim($value) !== '')));
        if ($requestedIds === []) {
            return [
                'driver' => Database::driver(),
                'requested_ids' => [],
                'rolled_back' => [],
            ];
        }

        $connection = Database::connection();
        $transactional = $this->supportsTransactionalMigrations();
        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $lookup = array_fill_keys($requestedIds, true);
        $rows = array_values(array_filter($this->allAppliedRows($connection), static function (array $row) use ($lookup): bool {
            return isset($lookup[(string)($row['id'] ?? '')]);
        }));

        $discovered = $this->discoverMigrationsById();
        $rolledBack = [];
        foreach ($rows as $row) {
            $migration = $discovered[(string)$row['id']] ?? null;
            if ($migration === null) {
                throw new RuntimeException('Migration file is missing for applied migration: ' . (string)$row['id']);
            }

            if ($transactional) {
                $connection->beginTransaction();
            }
            try {
                foreach ($this->statementsFor($migration, 'down') as $statement) {
                    $connection->exec($statement);
                }

                $delete = $connection->prepare('DELETE FROM ' . self::TABLE . ' WHERE id = :id');
                $delete->execute([':id' => $migration['id']]);

                if ($transactional && $connection->inTransaction()) {
                    $connection->commit();
                }
                $rolledBack[] = $migration;
            } catch (\Throwable $e) {
                if ($transactional && $connection->inTransaction()) {
                    $connection->rollBack();
                }
                throw new RuntimeException('Failed to roll back migration ' . $migration['id'] . ': ' . $e->getMessage(), 0, $e);
            }
        }

        return [
            'driver' => Database::driver(),
            'requested_ids' => $requestedIds,
            'rolled_back' => $rolledBack,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function refresh(bool $seed = false): array
    {
        $connection = Database::connection();
        $this->dropAllTables($connection);
        $result = $this->migrate(true);
        if ($seed) {
            $this->runScript($this->rootPath . '/scripts/seed.php');
        }

        return $result + ['seeded' => $seed];
    }

    /**
     * @return array<string, mixed>
     */
    public function seed(bool $applyBaseSchema = true): array
    {
        $result = $applyBaseSchema
            ? $this->migrate(true)
            : [
                'schema_path' => Database::schemaPath(),
                'driver' => Database::driver(),
                'applied' => [],
                'pending_count' => 0,
                'applied_count' => 0,
            ];
        $this->runScript($this->rootPath . '/scripts/seed.php');
        return $result + ['seeded' => true];
    }

    /**
     * @return array<string, mixed>
     */
    public function wipe(): array
    {
        $connection = Database::connection();
        $this->dropAllTables($connection);

        return [
            'driver' => Database::driver(),
            'schema_path' => Database::schemaPath(),
            'wiped' => true,
        ];
    }

    /**
     * @param array<int, string> $ids
     * @return array<int, string>
     */
    public function appliedMigrationIds(array $ids = []): array
    {
        $connection = Database::connection();
        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $applied = array_values(array_map(
            static fn (array $row): string => (string)($row['id'] ?? ''),
            $this->allAppliedRows($connection)
        ));
        if ($ids === []) {
            return $applied;
        }

        $lookup = array_fill_keys(array_values(array_unique(array_map('strval', $ids))), true);
        return array_values(array_filter($applied, static fn (string $id): bool => isset($lookup[$id])));
    }

    /**
     * @return array<string, mixed>
     */
    public function status(): array
    {
        $connection = Database::connection();
        $this->ensureMigrationDirectory();
        $this->ensureRepository($connection);

        $discovered = $this->discoverMigrations();
        $appliedMap = $this->appliedMap($connection);
        $pending = [];
        $applied = [];

        foreach ($discovered as $migration) {
            if (isset($appliedMap[$migration['id']])) {
                $applied[] = array_merge($migration, $appliedMap[$migration['id']]);
                continue;
            }
            $pending[] = $migration;
        }

        return [
            'driver' => Database::driver(),
            'schema_path' => Database::schemaPath(),
            'migration_directory' => $this->migrationDirectory(),
            'applied' => $applied,
            'pending' => $pending,
            'conflicts' => $this->migrationConflicts(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function migrationConflicts(): array
    {
        $this->ensureMigrationDirectory();
        $ids = [];
        $names = [];
        $duplicateIds = [];
        $duplicateNames = [];

        foreach ($this->migrationFiles() as $path) {
            $definition = $this->loadMigration($path);
            $id = (string)$definition['id'];
            $name = (string)$definition['name'];

            if (isset($ids[$id])) {
                $duplicateIds[$id] = array_values(array_unique(array_merge($duplicateIds[$id] ?? [$ids[$id]], [$path])));
            } else {
                $ids[$id] = $path;
            }

            if (isset($names[$name])) {
                $duplicateNames[$name] = array_values(array_unique(array_merge($duplicateNames[$name] ?? [$names[$name]], [$path])));
            } else {
                $names[$name] = $path;
            }
        }

        return [
            'duplicate_ids' => $duplicateIds,
            'duplicate_names' => $duplicateNames,
        ];
    }

    /**
     * @return array<int, string>
     */
    public function statementsFor(array $migration, string $direction): array
    {
        $section = $migration[$direction] ?? [];
        return $this->normalizeStatements($section, Database::driver());
    }

    private function ensureMigrationDirectory(): void
    {
        ConsoleSupport::ensureDirectory($this->migrationDirectory());
    }

    private function migrationDirectory(): string
    {
        return $this->rootPath . '/database/migrations';
    }

    /**
     * @return array<int, string>
     */
    private function migrationFiles(): array
    {
        $files = glob($this->migrationDirectory() . '/*.php') ?: [];
        sort($files, SORT_STRING);
        return array_values($files);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function discoverMigrations(): array
    {
        $migrations = [];
        foreach ($this->migrationFiles() as $path) {
            $migrations[] = $this->loadMigration($path);
        }

        usort($migrations, static function (array $left, array $right): int {
            return strcmp((string)$left['id'], (string)$right['id']);
        });

        return $migrations;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function discoverMigrationsById(): array
    {
        $map = [];
        foreach ($this->discoverMigrations() as $migration) {
            $map[(string)$migration['id']] = $migration;
        }
        return $map;
    }

    /**
     * @return array<string, mixed>
     */
    private function loadMigration(string $path): array
    {
        $loaded = require $path;
        if (!is_array($loaded)) {
            throw new RuntimeException('Migration file must return an array: ' . $path);
        }

        $id = pathinfo($path, PATHINFO_FILENAME);
        $name = trim((string)($loaded['name'] ?? $id));
        $version = trim((string)($loaded['version'] ?? App::VERSION));
        if ($name === '') {
            throw new RuntimeException('Migration name is required: ' . $path);
        }

        return [
            'id' => $id,
            'name' => $name,
            'version' => $version === '' ? App::VERSION : $version,
            'path' => $path,
            'up' => $loaded['up'] ?? [],
            'down' => $loaded['down'] ?? [],
        ];
    }

    /**
     * @param mixed $section
     * @return array<int, string>
     */
    private function normalizeStatements(mixed $section, string $driver): array
    {
        if (is_string($section)) {
            $trimmed = trim($section);
            return $trimmed === '' ? [] : [$trimmed];
        }

        if (!is_array($section)) {
            return [];
        }

        if (isset($section[$driver])) {
            return $this->normalizeStatements($section[$driver], $driver);
        }
        if (isset($section['*'])) {
            return $this->normalizeStatements($section['*'], $driver);
        }

        $statements = [];
        foreach ($section as $statement) {
            if (!is_string($statement)) {
                continue;
            }
            $trimmed = trim($statement);
            if ($trimmed !== '') {
                $statements[] = $trimmed;
            }
        }

        return $statements;
    }

    private function ensureRepository(PDO $connection): void
    {
        $defaultVersion = App::VERSION;
        if (Database::driver() === 'pgsql') {
            $connection->exec(
                <<<SQL
                CREATE TABLE IF NOT EXISTS app_console_migrations (
                    id VARCHAR(80) PRIMARY KEY,
                    name VARCHAR(180) NOT NULL,
                    version VARCHAR(40) NOT NULL DEFAULT '{$defaultVersion}',
                    batch INTEGER NOT NULL DEFAULT 1,
                    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                SQL
            );
            return;
        }

        $connection->exec(
            <<<SQL
            CREATE TABLE IF NOT EXISTS app_console_migrations (
                id VARCHAR(80) PRIMARY KEY,
                name VARCHAR(180) NOT NULL,
                version VARCHAR(40) NOT NULL DEFAULT '{$defaultVersion}',
                batch INT NOT NULL DEFAULT 1,
                applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL
        );
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function appliedMap(PDO $connection): array
    {
        $statement = $connection->query('SELECT id, name, version, batch, applied_at FROM ' . self::TABLE);
        $rows = $statement ? $statement->fetchAll() : [];
        $map = [];
        foreach ($rows as $row) {
            $map[(string)$row['id']] = $row;
        }
        return $map;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function pendingMigrations(PDO $connection): array
    {
        $applied = $this->appliedMap($connection);
        return array_values(array_filter($this->discoverMigrations(), static function (array $migration) use ($applied): bool {
            return !isset($applied[(string)$migration['id']]);
        }));
    }

    private function nextBatch(PDO $connection): int
    {
        $statement = $connection->query('SELECT MAX(batch) AS batch FROM ' . self::TABLE);
        $row = $statement ? $statement->fetch() : null;
        return max(1, (int)($row['batch'] ?? 0) + 1);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function appliedRows(PDO $connection, int $limit): array
    {
        $statement = $connection->query(
            'SELECT id, name, version, batch, applied_at FROM ' . self::TABLE . ' ORDER BY batch DESC, applied_at DESC, id DESC'
        );
        $rows = $statement ? $statement->fetchAll() : [];
        return array_slice($rows, 0, $limit);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function allAppliedRows(PDO $connection): array
    {
        $statement = $connection->query(
            'SELECT id, name, version, batch, applied_at FROM ' . self::TABLE . ' ORDER BY batch DESC, applied_at DESC, id DESC'
        );
        return $statement ? $statement->fetchAll() : [];
    }

    private function nowExpression(): string
    {
        return Database::driver() === 'pgsql' ? 'NOW()' : 'CURRENT_TIMESTAMP';
    }

    private function supportsTransactionalMigrations(): bool
    {
        return Database::driver() !== 'mysql';
    }

    private function dropAllTables(PDO $connection): void
    {
        if (Database::driver() === 'pgsql') {
            $statement = $connection->query("SELECT tablename FROM pg_tables WHERE schemaname = current_schema()");
            $tables = $statement ? $statement->fetchAll(PDO::FETCH_COLUMN) : [];
            foreach ($tables as $table) {
                $quoted = '"' . str_replace('"', '""', (string)$table) . '"';
                $connection->exec('DROP TABLE IF EXISTS ' . $quoted . ' CASCADE');
            }
            return;
        }

        $connection->exec('SET FOREIGN_KEY_CHECKS = 0');
        try {
            $statement = $connection->query('SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE()');
            $tables = $statement ? $statement->fetchAll(PDO::FETCH_COLUMN) : [];
            foreach ($tables as $table) {
                $quoted = '`' . str_replace('`', '``', (string)$table) . '`';
                $connection->exec('DROP TABLE IF EXISTS ' . $quoted);
            }
        } finally {
            $connection->exec('SET FOREIGN_KEY_CHECKS = 1');
        }
    }

    private function runScript(string $path): void
    {
        if (!is_file($path)) {
            throw new RuntimeException('Script not found: ' . $path);
        }

        require $path;
    }
}
