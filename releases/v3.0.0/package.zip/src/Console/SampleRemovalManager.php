<?php
namespace App\Console;

use App\Config\Database;
use RuntimeException;

/**
 * Conservative Nite 2.x sample cleanup. A filename never authorises deletion:
 * every file must match an original published SHA-256 fingerprint.
 */
final class SampleRemovalManager
{
    /** @var array<string, string> v2.2.0 public-package file hashes */
    private const FILE_HASHES = [
        'src/Controllers/SampleRecordsController.php' => '0462e778e87fde1dab295cea725256643f0d76a00359543b3a9e8bfac7878334',
        'src/Services/SampleRecordService.php' => '9fffcd3187a2e1dbe73cc9d0853935cc6a13311b8e3edab41cf4ff91aed243b9',
        'src/Models/SampleRecordModel.php' => 'bdda1f6e2a6177b701bc6adf2edd98f7bec83d590044fd44532a136e99f037e6',
        'src/Controllers/CustomerAccountController.php' => '60bcf2d2bea5163575e26fdfc26d30216f237d38c293355d8b83fcbaf71b7e2c',
        'src/Services/CustomerAccountService.php' => 'eb3c2553106556129ade742425d27fba67ecc3ded4faf3246a2da25e5348761a',
        'src/Models/CustomerAccountModel.php' => '6076eabab30fecddfac8b511213a81b9ea72d05ae55e568ed5a3611c744839e7',
        'src/Controllers/ProjectBoardController.php' => '5f66f35b8b6a2a2f014e40ea2d071c11a53fe96f837690d4ec03f8b55889d930',
        'src/Services/ProjectBoardService.php' => 'd5474491dc0f6936062ffec4304254aec4f3f0ebeda8e4d87216d8593477070d',
        'src/Models/ProjectBoardModel.php' => '5f4ae40fa85d41e447e79764c0d387f505f4f4e80388f6e1b890e36ac11874c3',
        'src/Controllers/SupportTicketController.php' => '807fdea6c7e5ddb67c5c1d894af1578e86f1628a9c6edbfde94243bbffa60ce8',
        'src/Services/SupportTicketService.php' => '31d7d987ac7028c13bbc56229da415f848c8dfee6022d374c59d193e146c0a12',
        'src/Models/SupportTicketModel.php' => '55be4ef8be823c766ff4bcbe989e1e3773cabee28115ff8dd83c46ad12c9bb2b',
        'src/Controllers/TaskItemController.php' => '6a0ecc1cb64f98d82f50697baea2a5a179d78c907cfd55a644b9a18dd4269e1d',
        'src/Services/TaskItemService.php' => '9e945fc603deede05af77a8d3c5fbc6b168bc730d18d440502c6945a62d7da9b',
        'src/Models/TaskItemModel.php' => '93f8752245170297fd55f3c770063c073b1352da4ec9bb68443b8317600e8a2c',
    ];

    /** @var array<int, string> */
    private const SAMPLE_TABLES = ['sample_records', 'customer_accounts', 'project_boards', 'support_tickets', 'task_items'];

    public function __construct(private readonly string $rootPath, private readonly ConsoleIO $io)
    {
    }

    /** @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function remove(array $options = []): array
    {
        $dryRun = $this->boolOption($options, 'dry-run', false);
        $backupDir = $dryRun || !$this->boolOption($options, 'backup', true) ? null : $this->rootPath . '/storage/backups/samples-clean-' . gmdate('Ymd_His');
        return [
            'dry_run' => $dryRun,
            'backup_dir' => $backupDir,
            'files' => $this->cleanFiles($dryRun, $backupDir),
            'database' => $this->cleanTables($dryRun),
        ];
    }

    /** @return array<string, array<int, string>> */
    private function cleanFiles(bool $dryRun, ?string $backupDir): array
    {
        $deleted = []; $preserved = []; $missing = []; $warnings = [];
        foreach (self::FILE_HASHES as $relative => $expected) {
            $path = $this->rootPath . '/' . $relative;
            if (!is_file($path)) { $missing[] = $relative; continue; }
            $actual = hash_file('sha256', $path);
            if (!is_string($actual) || !hash_equals($expected, strtolower($actual))) {
                $preserved[] = $relative;
                continue;
            }
            if ($dryRun) { $deleted[] = $relative; continue; }
            $this->backup($relative, $backupDir);
            if (!@unlink($path)) { $warnings[] = 'Could not remove ' . $relative . '.'; continue; }
            $deleted[] = $relative;
        }
        return ['deleted' => $deleted, 'preserved_modified' => $preserved, 'missing' => $missing, 'warnings' => $warnings];
    }

    /** @return array<string, mixed> */
    private function cleanTables(bool $dryRun): array
    {
        try { $connection = Database::connection(); } catch (\Throwable $error) { return ['status' => 'skipped', 'detail' => 'Database cleanup skipped: ' . $error->getMessage(), 'removed' => [], 'preserved' => []]; }
        $removed = []; $preserved = [];
        foreach (self::SAMPLE_TABLES as $table) {
            if (!$this->tableExists($connection, $table)) { continue; }
            $rows = (int) $connection->query('SELECT COUNT(*) FROM ' . $this->identifier($table))->fetchColumn();
            $foreignKeys = $this->externalForeignKeys($connection, $table);
            if ($rows > 0 || $foreignKeys > 0) {
                $preserved[$table] = $rows > 0 ? 'contains data' : 'has external foreign-key dependencies';
                continue;
            }
            if ($dryRun) { $removed[] = $table; continue; }
            $connection->exec('DROP TABLE ' . $this->identifier($table));
            $removed[] = $table;
        }
        return ['status' => 'completed', 'detail' => $dryRun ? 'No tables were changed (dry run).' : 'Only empty, dependency-free sample tables were removed.', 'removed' => $removed, 'preserved' => $preserved];
    }

    private function tableExists(\PDO $connection, string $table): bool
    {
        if (Database::driver() === 'pgsql') { $statement = $connection->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = ?'); }
        else { $statement = $connection->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?'); }
        $statement->execute([$table]); return $statement->fetchColumn() !== false;
    }

    private function externalForeignKeys(\PDO $connection, string $table): int
    {
        if (Database::driver() === 'pgsql') {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.table_constraints tc JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name AND tc.table_schema = ccu.table_schema WHERE tc.constraint_type = ? AND ccu.table_name = ? AND tc.table_name <> ?');
        } else {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE WHERE REFERENCED_TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME = ? AND TABLE_NAME <> ?');
        }
        $statement->execute(Database::driver() === 'pgsql' ? ['FOREIGN KEY', $table, $table] : [$table, $table]);
        return (int) $statement->fetchColumn();
    }

    private function identifier(string $name): string { return Database::driver() === 'pgsql' ? '"' . $name . '"' : '`' . $name . '`'; }
    private function backup(string $relative, ?string $backupDir): void { if ($backupDir === null) return; $target = $backupDir . '/' . $relative; ConsoleSupport::ensureDirectory(dirname($target)); if (!@copy($this->rootPath . '/' . $relative, $target)) throw new RuntimeException('Failed to back up sample file: ' . $relative); }
    /** @param array<string, mixed> $options */
    private function boolOption(array $options, string $key, bool $default): bool { return array_key_exists($key, $options) ? (bool) $options[$key] : $default; }
}
