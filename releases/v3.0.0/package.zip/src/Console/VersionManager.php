<?php
namespace App\Console;

use App\Config\App;
use RuntimeException;

final class VersionManager
{
    private string $rootPath;

    public function __construct(?string $rootPath = null)
    {
        $this->rootPath = $rootPath ?? ConsoleSupport::rootPath();
    }

    /**
     * @return array<string, mixed>
     */
    public function info(): array
    {
        $data = $this->read();
        return [
            'application' => App::NAME,
            'code_version' => App::VERSION,
            'installed_version' => (string)($data['current_version'] ?? App::VERSION),
            'repository' => is_array($data['repository'] ?? null) ? $data['repository'] : [
                'slug' => App::publicRepository(),
                'url' => App::publicRepositoryUrl(),
                'api' => App::publicRepositoryApi(),
            ],
            'installed_tag' => (string)($data['installed_tag'] ?? ''),
            'installed_files_count' => count($this->installedFiles()),
            'compatibility_acceptances' => array_values(is_array($data['compatibility_acceptances'] ?? null) ? $data['compatibility_acceptances'] : []),
            'history' => array_values(is_array($data['history'] ?? null) ? $data['history'] : []),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function markInstalled(bool $seeded = false, ?string $version = null, array $meta = []): array
    {
        return $this->writeVersion($version ?? App::VERSION, 'install', array_merge([
            'seeded' => $seeded,
        ], $meta));
    }

    /**
     * @return array<string, mixed>
     */
    public function markUpdated(?string $version = null, array $meta = []): array
    {
        return $this->writeVersion($version ?? App::VERSION, 'update', $meta);
    }

    /**
     * @return array<string, mixed>
     */
    public function acceptCompatibility(string $version): array
    {
        $data = $this->read();
        $items = array_values(is_array($data['compatibility_acceptances'] ?? null) ? $data['compatibility_acceptances'] : []);
        $filtered = array_values(array_filter($items, static function (array $item) use ($version): bool {
            return (string)($item['version'] ?? '') !== $version;
        }));
        $filtered[] = [
            'version' => $version,
            'accepted_at' => gmdate('c'),
        ];

        $data['compatibility_acceptances'] = $filtered;
        $this->write($data);

        return $data;
    }

    public function currentVersion(): string
    {
        $data = $this->read();
        return (string)($data['current_version'] ?? App::VERSION);
    }

    /**
     * @return array<int, string>
     */
    public function installedFiles(): array
    {
        $data = $this->read();
        return array_values(array_filter(
            array_map('strval', is_array($data['installed_files'] ?? null) ? $data['installed_files'] : []),
            static fn (string $value): bool => trim($value) !== ''
        ));
    }

    public function assertCanUpgrade(string $targetVersion, bool $acceptCompatibility = false): void
    {
        $data = $this->read();
        $current = (string)($data['current_version'] ?? App::VERSION);
        if (version_compare($targetVersion, $current, '<=')) {
            throw new RuntimeException('Upgrade target must be greater than the installed version.');
        }

        if (
            $this->requiresCompatibilityAcceptance($current, $targetVersion)
            && !$acceptCompatibility
            && !$this->isCompatibilityAccepted($data, $targetVersion)
        ) {
            throw new RuntimeException('Compatibility acceptance is required before a major-version upgrade.');
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function upgrade(string $targetVersion, bool $acceptCompatibility = false, array $meta = []): array
    {
        $data = $this->read();
        $current = (string)($data['current_version'] ?? App::VERSION);
        $this->assertCanUpgrade($targetVersion, $acceptCompatibility);

        if ($this->requiresCompatibilityAcceptance($current, $targetVersion)) {
            if ($acceptCompatibility) {
                $data = $this->acceptCompatibility($targetVersion);
            } elseif (!$this->isCompatibilityAccepted($data, $targetVersion)) {
                throw new RuntimeException('Compatibility acceptance is required before a major-version upgrade.');
            }
        }

        return $this->writeVersion($targetVersion, 'upgrade', array_merge([
            'accepted_compatibility' => $this->isCompatibilityAccepted($this->read(), $targetVersion),
        ], $meta));
    }

    /**
     * @return array<string, mixed>
     */
    public function downgrade(string $targetVersion, array $meta = []): array
    {
        $data = $this->read();
        $current = (string)($data['current_version'] ?? App::VERSION);
        if (version_compare($targetVersion, $current, '>=')) {
            throw new RuntimeException('Downgrade target must be lower than the installed version.');
        }

        return $this->writeVersion($targetVersion, 'downgrade', $meta);
    }

    public function clear(): void
    {
        $path = $this->manifestPath();
        if (!is_file($path)) {
            return;
        }

        if (!@unlink($path)) {
            throw new RuntimeException('Failed to remove version manifest.');
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function read(): array
    {
        $path = $this->manifestPath();
        if (!is_file($path)) {
            return $this->defaultManifest();
        }

        $json = file_get_contents($path);
        if (!is_string($json) || trim($json) === '') {
            return $this->defaultManifest();
        }

        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : $this->defaultManifest();
    }

    /**
     * @param array<string, mixed> $data
     */
    private function write(array $data): void
    {
        ConsoleSupport::ensureDirectory(dirname($this->manifestPath()));
        $encoded = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($encoded)) {
            throw new RuntimeException('Failed to encode version manifest.');
        }

        file_put_contents($this->manifestPath(), $encoded . PHP_EOL);
    }

    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    private function writeVersion(string $version, string $action, array $extra = []): array
    {
        $data = $this->read();
        $from = (string)($data['current_version'] ?? App::VERSION);
        $history = array_values(is_array($data['history'] ?? null) ? $data['history'] : []);
        $history[] = [
            'action' => $action,
            'from' => $from,
            'to' => $version,
            'at' => gmdate('c'),
            'meta' => $extra,
        ];

        $data['application'] = App::NAME;
        $data['current_version'] = $version;
        if (isset($extra['installed_tag'])) {
            $data['installed_tag'] = (string)$extra['installed_tag'];
        }
        if (isset($extra['repository']) && is_array($extra['repository'])) {
            $data['repository'] = $extra['repository'];
        }
        if (isset($extra['installed_files']) && is_array($extra['installed_files'])) {
            $data['installed_files'] = array_values(array_map('strval', $extra['installed_files']));
        }
        if (isset($extra['release']) && is_array($extra['release'])) {
            $data['release'] = $extra['release'];
        }
        $data['history'] = $history;
        $data['updated_at'] = gmdate('c');

        $this->write($data);
        return $data;
    }

    private function manifestPath(): string
    {
        return $this->rootPath . '/storage/console/version.json';
    }

    /**
     * @return array<string, mixed>
     */
    private function defaultManifest(): array
    {
        return [
            'application' => App::NAME,
            'current_version' => App::VERSION,
            'installed_tag' => 'v' . App::VERSION,
            'repository' => [
                'slug' => App::publicRepository(),
                'url' => App::publicRepositoryUrl(),
                'api' => App::publicRepositoryApi(),
            ],
            'installed_files' => [],
            'compatibility_acceptances' => [],
            'history' => [],
            'updated_at' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $data
     */
    private function isCompatibilityAccepted(array $data, string $targetVersion): bool
    {
        foreach (array_values(is_array($data['compatibility_acceptances'] ?? null) ? $data['compatibility_acceptances'] : []) as $item) {
            if ((string)($item['version'] ?? '') === $targetVersion) {
                return true;
            }
        }

        return false;
    }

    private function requiresCompatibilityAcceptance(string $fromVersion, string $toVersion): bool
    {
        $fromMajor = (int)explode('.', $fromVersion)[0];
        $toMajor = (int)explode('.', $toVersion)[0];
        return $toMajor > $fromMajor;
    }
}
