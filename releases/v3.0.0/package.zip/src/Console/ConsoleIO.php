<?php
namespace App\Console;

final class ConsoleIO
{
    public function line(string $message = ''): void
    {
        fwrite(STDOUT, $message . PHP_EOL);
    }

    public function info(string $message): void
    {
        $this->line('[info] ' . $message);
    }

    public function success(string $message): void
    {
        $this->line('[ok] ' . $message);
    }

    public function warn(string $message): void
    {
        $this->line('[warn] ' . $message);
    }

    public function error(string $message): void
    {
        fwrite(STDERR, '[error] ' . $message . PHP_EOL);
    }

    /**
     * @param array<int, string> $headers
     * @param array<int, array<int, string>> $rows
     */
    public function table(array $headers, array $rows): void
    {
        if ($headers === []) {
            return;
        }

        $widths = array_map('strlen', $headers);
        foreach ($rows as $row) {
            foreach ($headers as $index => $_header) {
                $value = (string)($row[$index] ?? '');
                $widths[$index] = max($widths[$index], strlen($value));
            }
        }

        $separator = '+';
        foreach ($widths as $width) {
            $separator .= str_repeat('-', $width + 2) . '+';
        }

        $this->line($separator);
        $this->line($this->tableRow($headers, $widths));
        $this->line($separator);
        foreach ($rows as $row) {
            $this->line($this->tableRow($row, $widths));
        }
        $this->line($separator);
    }

    public function isInteractive(): bool
    {
        if (!defined('STDIN')) {
            return false;
        }

        if (function_exists('stream_isatty')) {
            return stream_isatty(STDIN);
        }

        return true;
    }

    public function confirm(string $prompt, bool $default = false): bool
    {
        if (!$this->isInteractive()) {
            return $default;
        }

        $suffix = $default ? ' [Y/n] ' : ' [y/N] ';
        fwrite(STDOUT, $prompt . $suffix);
        $answer = fgets(STDIN);
        if ($answer === false) {
            return $default;
        }

        $normalized = strtolower(trim($answer));
        if ($normalized === '') {
            return $default;
        }

        return in_array($normalized, ['y', 'yes'], true);
    }

    /**
     * @param array<int, string> $cells
     * @param array<int, int> $widths
     */
    private function tableRow(array $cells, array $widths): string
    {
        $parts = [];
        foreach ($widths as $index => $width) {
            $parts[] = ' ' . str_pad((string)($cells[$index] ?? ''), $width) . ' ';
        }

        return '|' . implode('|', $parts) . '|';
    }
}
