<?php
namespace App\Console;

use App\Config\App;
use App\Support\EnvFileEditor;
use RuntimeException;

/** Builds the shipped Angular client without ever replacing a known-good build until validation succeeds. */
final class AdminBuildManager
{
    public function __construct(private readonly string $rootPath)
    {
    }

    /** @return array<string, mixed> */
    public function status(): array
    {
        $source = $this->sourcePath();
        $build = $this->buildPath();
        $metadata = $this->readMetadata($build . '/nite-admin-build.json');
        $sourceChecksum = is_dir($source) ? $this->treeChecksum([$source, $this->customPath()]) : null;
        $compiledChecksum = is_dir($build) ? $this->assetManifestChecksum($build) : null;
        $isValid = false;
        $error = null;
        try {
            $this->validateBuild($build);
            $isValid = true;
        } catch (RuntimeException $exception) {
            $error = $exception->getMessage();
        }

        return [
            'source_available' => is_file($source . '/angular.json') && is_file($source . '/package.json'),
            'lockfile_available' => is_file($source . '/package-lock.json'),
            'dependencies_installed' => is_dir($source . '/node_modules'),
            'compiled_build_available' => is_dir($build) && is_file($build . '/index.html'),
            'compiled_build_valid' => $isValid,
            'compiled_build_error' => $error,
            'compiled_build_version' => $metadata['admin_version'] ?? null,
            'framework_version' => App::VERSION,
            'source_checksum' => $sourceChecksum,
            'compiled_build_checksum' => $compiledChecksum,
            'compiled_build_stale' => $metadata === [] || !hash_equals((string) ($metadata['source_checksum'] ?? ''), (string) $sourceChecksum),
            'node' => $this->binaryVersion('node', '--version'),
            'npm' => $this->binaryVersion('npm', '--version'),
        ];
    }

    /** @return array<string, mixed> */
    public function install(bool $verbose = false): array
    {
        $this->assertSourceWorkspace();
        $this->assertNodeTools();
        $command = is_file($this->sourcePath() . '/package-lock.json') ? ['npm', 'ci'] : ['npm', 'install'];
        $result = $this->run($command, $this->sourcePath(), $verbose);
        return [
            'command' => implode(' ', $command),
            'duration_seconds' => $result['duration_seconds'],
            'output' => $result['output'],
        ];
    }

    /** @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function build(array $options = []): array
    {
        $started = microtime(true);
        $this->assertSourceWorkspace();
        $this->assertNodeTools();
        if (!$this->boolOption($options, 'no-install', false) && !is_dir($this->sourcePath() . '/node_modules')) {
            $this->install($this->boolOption($options, 'verbose', false));
        }
        if (!is_dir($this->sourcePath() . '/node_modules')) {
            throw new RuntimeException('Nite Admin dependencies are missing. Run `php nite admin:install` first.');
        }

        $configuration = trim((string) ($options['configuration'] ?? 'production')) ?: 'production';
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $configuration)) {
            throw new RuntimeException('Invalid Angular build configuration.');
        }
        $theme = trim((string) ($options['theme'] ?? ''));
        if ($theme !== '') {
            $this->setDefaultTheme($theme);
        }

        $temporary = $this->rootPath . '/storage/console/tmp/nite-admin-' . bin2hex(random_bytes(6));
        ConsoleSupport::ensureDirectory(dirname($temporary));
        try {
            $command = ['npx', 'ng', 'build', '--configuration=' . $configuration, '--output-path=' . $temporary, '--base-href=' . $this->adminBasePath() . '/'];
            $process = $this->run($command, $this->sourcePath(), $this->boolOption($options, 'verbose', false));
            $output = is_dir($temporary . '/browser') ? $temporary . '/browser' : $temporary;
            $this->validateAngularOutput($output);
            $metadata = $this->writeMetadata($output, $configuration);
            $this->validateBuild($output);
            $assetCount = $this->fileCount($output);
            $this->replaceBuildAtomically($output);
            return [
                'status' => 'built',
                'configuration' => $configuration,
                'output_directory' => 'public/nite-admin',
                'asset_count' => $assetCount,
                'duration_seconds' => round(microtime(true) - $started, 3),
                'build_output' => $process['output'],
                'metadata' => $metadata,
            ];
        } catch (\Throwable $exception) {
            $this->removeDirectory($temporary);
            throw $exception;
        }
    }

    /** @return array<string, mixed> */
    public function syncSource(): array
    {
        $this->assertSourceWorkspace();
        $manifestPath = $this->customPath() . '/upstream-hashes.json';
        $current = $this->sourceHashMap();
        $previous = $this->readMetadata($manifestPath);
        $previousFiles = is_array($previous['files'] ?? null) ? $previous['files'] : [];
        $modified = [];
        foreach ($previousFiles as $path => $hash) {
            if (isset($current[$path]) && !hash_equals((string) $hash, $current[$path])) {
                $modified[] = $path;
            }
        }
        ConsoleSupport::ensureDirectory(dirname($manifestPath));
        $payload = ['generated_at' => gmdate('c'), 'framework_version' => App::VERSION, 'files' => $current];
        $encoded = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if (!is_string($encoded) || file_put_contents($manifestPath, $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write the Nite Admin source synchronisation report.');
        }
        return [
            'status' => $previousFiles === [] ? 'baseline_recorded' : ($modified === [] ? 'up_to_date' : 'conflicts_detected'),
            'report' => $this->relativePath($manifestPath),
            'modified_upstream_files' => $modified,
            'customisation_directory' => $this->relativePath($this->customPath()),
        ];
    }

    /** @return array<int, array<string, string>> */
    public function themes(): array
    {
        return [
            ['key' => 'nite', 'name' => 'Nite Default'], ['key' => 'light', 'name' => 'Light'],
            ['key' => 'dark', 'name' => 'Dark'], ['key' => 'ocean', 'name' => 'Ocean Blue'],
            ['key' => 'emerald', 'name' => 'Emerald'], ['key' => 'purple', 'name' => 'Royal Purple'],
            ['key' => 'amber', 'name' => 'Amber'], ['key' => 'slate', 'name' => 'Slate'],
            ['key' => 'high-contrast', 'name' => 'High Contrast'],
        ];
    }

    public function setDefaultTheme(string $theme): void
    {
        $available = array_column($this->themes(), 'key');
        if (!in_array($theme, $available, true)) {
            throw new RuntimeException('Unknown Nite Admin theme: ' . $theme);
        }
        EnvFileEditor::upsert($this->rootPath . '/.env', ['NITE_ADMIN_DEFAULT_THEME' => $theme]);
    }

    public function serve(bool $watch, bool $verbose = false): int
    {
        $this->assertSourceWorkspace();
        $this->assertNodeTools();
        $command = $watch
            ? ['npx', 'ng', 'build', '--watch', '--configuration=development']
            : ['npx', 'ng', 'serve', '--proxy-config', 'proxy.conf.json'];
        $this->run($command, $this->sourcePath(), $verbose, true);
        return 0;
    }

    /** @return array<string, mixed> */
    public function qualityChecks(bool $verbose = false): array
    {
        $this->assertSourceWorkspace();
        $this->assertNodeTools();
        if (!is_dir($this->sourcePath() . '/node_modules')) {
            $this->install($verbose);
        }
        return [
            'test' => $this->run(['npm', 'run', 'test'], $this->sourcePath(), $verbose),
            'lint' => $this->run(['npm', 'run', 'lint'], $this->sourcePath(), $verbose),
        ];
    }

    /** @return array<string, mixed> */
    public function validateBuild(string $path): array
    {
        $metadata = $this->readMetadata($path . '/nite-admin-build.json');
        if (!is_file($path . '/index.html') || $metadata === []) {
            throw new RuntimeException('Compiled Nite Admin build or metadata is missing.');
        }
        if ((string) ($metadata['framework_version'] ?? '') !== App::VERSION || (string) ($metadata['admin_version'] ?? '') !== App::VERSION) {
            throw new RuntimeException('Compiled Nite Admin version does not match Nite ' . App::VERSION . '.');
        }
        if (trim((string) ($metadata['source_checksum'] ?? '')) === '' || trim((string) ($metadata['asset_manifest_checksum'] ?? '')) === '') {
            throw new RuntimeException('Compiled Nite Admin metadata is incomplete.');
        }
        if (!hash_equals((string) $metadata['asset_manifest_checksum'], $this->assetManifestChecksum($path, ['nite-admin-build.json']))) {
            throw new RuntimeException('Compiled Nite Admin asset checksum is invalid.');
        }
        $this->validateAngularOutput($path);
        return $metadata;
    }

    private function assertSourceWorkspace(): void
    {
        foreach (['angular.json', 'package.json', 'tsconfig.json'] as $file) {
            if (!is_file($this->sourcePath() . '/' . $file)) {
                throw new RuntimeException('Nite Admin Angular source is incomplete: missing ' . $file . '.');
            }
        }
    }

    private function assertNodeTools(): void
    {
        foreach ([['node', '--version'], ['npm', '--version']] as [$binary, $arg]) {
            if ($this->binaryVersion($binary, $arg) === null) {
                throw new RuntimeException('Nite Admin requires ' . $binary . ' when building from source. Install Node.js and retry.');
            }
        }
    }

    /** @return array<string, mixed> */
    private function writeMetadata(string $output, string $configuration): array
    {
        $metadata = [
            'application' => 'Nite Admin', 'framework_version' => App::VERSION, 'admin_version' => App::VERSION,
            'build_configuration' => $configuration, 'built_at' => gmdate('c'),
            'source_checksum' => $this->treeChecksum([$this->sourcePath(), $this->customPath()]),
            'asset_manifest_checksum' => '',
        ];
        $metadata['asset_manifest_checksum'] = $this->assetManifestChecksum($output, ['nite-admin-build.json']);
        $encoded = json_encode($metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if (!is_string($encoded) || file_put_contents($output . '/nite-admin-build.json', $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Failed to write Nite Admin build metadata.');
        }
        return $metadata;
    }

    private function validateAngularOutput(string $path): void
    {
        if (!is_file($path . '/index.html')) {
            throw new RuntimeException('Angular did not generate index.html.');
        }
        $index = (string) file_get_contents($path . '/index.html');
        if (!preg_match('/(?:src|href)="[^"]+\.(?:js|css)/i', $index)) {
            throw new RuntimeException('Angular did not generate required JavaScript or CSS bundles.');
        }
        foreach (['<app-root', '<base'] as $required) {
            if (!str_contains($index, $required)) {
                throw new RuntimeException('Angular index.html is invalid: missing ' . $required . '.');
            }
        }
    }

    private function replaceBuildAtomically(string $output): void
    {
        $target = $this->buildPath();
        $backup = $target . '.previous-' . bin2hex(random_bytes(4));
        if (is_dir($target) && !@rename($target, $backup)) {
            throw new RuntimeException('Could not preserve the previous Nite Admin build.');
        }
        if (!@rename($output, $target)) {
            if (is_dir($backup)) {
                @rename($backup, $target);
            }
            throw new RuntimeException('Could not activate the validated Nite Admin build.');
        }
        $this->removeDirectory($backup);
    }

    /** @param array<int, string> $exclude */
    private function assetManifestChecksum(string $path, array $exclude = []): string
    {
        $entries = [];
        if (!is_dir($path)) {
            return '';
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $item) {
            if (!$item->isFile()) { continue; }
            $relative = str_replace('\\', '/', substr($item->getPathname(), strlen($path) + 1));
            if (in_array($relative, $exclude, true)) { continue; }
            $hash = hash_file('sha256', $item->getPathname());
            if (is_string($hash)) { $entries[$relative] = $hash; }
        }
        ksort($entries);
        return hash('sha256', json_encode($entries, JSON_UNESCAPED_SLASHES) ?: '');
    }

    /** @param array<int, string> $roots */
    private function treeChecksum(array $roots): string
    {
        $entries = [];
        foreach ($roots as $root) {
            if (!is_dir($root)) { continue; }
            $iterator = new \RecursiveIteratorIterator($this->filteredIterator($root));
            foreach ($iterator as $item) {
                if (!$item->isFile()) { continue; }
                $relative = $this->relativePath($item->getPathname());
                $hash = hash_file('sha256', $item->getPathname());
                if (is_string($hash)) { $entries[$relative] = $hash; }
            }
        }
        ksort($entries);
        return hash('sha256', json_encode($entries, JSON_UNESCAPED_SLASHES) ?: '');
    }

    /** @return array<string, string> */
    private function sourceHashMap(): array
    {
        $map = [];
        $root = $this->sourcePath();
        $iterator = new \RecursiveIteratorIterator($this->filteredIterator($root));
        foreach ($iterator as $item) {
            if (!$item->isFile()) { continue; }
            $hash = hash_file('sha256', $item->getPathname());
            if (is_string($hash)) { $map[str_replace('\\', '/', substr($item->getPathname(), strlen($root) + 1))] = $hash; }
        }
        ksort($map);
        return $map;
    }

    /** @return array<string, mixed> */
    private function run(array $command, string $cwd, bool $verbose, bool $inherit = false): array
    {
        $command[0] = $this->executable((string) ($command[0] ?? ''));
        $line = implode(' ', array_map('escapeshellarg', $command));
        $descriptor = $inherit
            ? [0 => STDIN, 1 => STDOUT, 2 => STDERR]
            : [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $started = microtime(true);
        $process = proc_open($line, $descriptor, $pipes, $cwd);
        if (!is_resource($process)) { throw new RuntimeException('Could not start: ' . implode(' ', $command)); }
        $output = '';
        if (!$inherit) {
            fclose($pipes[0]);
            $output = (string) stream_get_contents($pipes[1]) . (string) stream_get_contents($pipes[2]);
            fclose($pipes[1]); fclose($pipes[2]);
            if ($verbose && $output !== '') { fwrite(STDOUT, $output); }
        }
        $status = proc_close($process);
        if ($status !== 0) { throw new RuntimeException('Nite Admin command failed (' . $status . '): ' . trim($output)); }
        return ['duration_seconds' => round(microtime(true) - $started, 3), 'output' => $output];
    }

    private function binaryVersion(string $binary, string $argument): ?string
    {
        $binary = $this->executable($binary);
        $process = @proc_open(escapeshellarg($binary) . ' ' . escapeshellarg($argument), [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (!is_resource($process)) { return null; }
        $output = trim((string) stream_get_contents($pipes[1]) . (string) stream_get_contents($pipes[2]));
        fclose($pipes[1]); fclose($pipes[2]);
        return proc_close($process) === 0 && $output !== '' ? $output : null;
    }

    private function sourcePath(): string { return $this->rootPath . '/resources/nite-admin/source'; }
    private function customPath(): string { return $this->rootPath . '/resources/nite-admin/custom'; }
    private function buildPath(): string { return $this->rootPath . '/public/nite-admin'; }
    private function adminBasePath(): string { return '/' . trim((string) getenv('NITE_ADMIN_BASE_PATH') ?: '/admin', '/'); }
    private function relativePath(string $path): string { return str_replace('\\', '/', substr(str_replace('\\', '/', $path), strlen(str_replace('\\', '/', $this->rootPath)) + 1)); }
    private function fileCount(string $path): int { return iterator_count(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS))); }
    /** @return array<string, mixed> */
    private function readMetadata(string $path): array { $raw = is_file($path) ? file_get_contents($path) : false; $data = is_string($raw) ? json_decode($raw, true) : null; return is_array($data) ? $data : []; }
    /** @param array<string, mixed> $options */
    private function boolOption(array $options, string $key, bool $default): bool { return array_key_exists($key, $options) ? (bool) $options[$key] : $default; }
    private function removeDirectory(string $path): void { if (!is_dir($path)) { return; } $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST); foreach ($it as $item) { $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname()); } @rmdir($path); }
    private function filteredIterator(string $root): \RecursiveCallbackFilterIterator { return new \RecursiveCallbackFilterIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS), static fn (\SplFileInfo $item): bool => !$item->isDir() || !in_array($item->getFilename(), ['node_modules', '.angular', 'coverage'], true)); }
    private function executable(string $binary): string { if (PHP_OS_FAMILY !== 'Windows' || !in_array($binary, ['npm', 'npx'], true)) return $binary; $candidate = rtrim((string) getenv('ProgramFiles'), '\\/') . '\\nodejs\\' . $binary . '.cmd'; return is_file($candidate) ? $candidate : $binary . '.cmd'; }
}
