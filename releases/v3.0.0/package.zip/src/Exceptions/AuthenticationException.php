<?php
namespace App\Exceptions;

use RuntimeException;

final class AuthenticationException extends RuntimeException
{
    public function __construct(string $message = 'Unauthorized')
    {
        parent::__construct($message, 401);
    }
}
