<?php
namespace App\Exceptions;

use RuntimeException;

final class ThrottleException extends RuntimeException
{
    public function __construct(
        private readonly int $retryAfterSeconds,
        string $message = 'Too many authentication attempts. Please try again later.'
    ) {
        parent::__construct($message, 429);
    }

    public function retryAfterSeconds(): int
    {
        return $this->retryAfterSeconds;
    }
}
