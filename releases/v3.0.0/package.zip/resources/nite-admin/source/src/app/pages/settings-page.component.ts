import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ThemeService } from '../core/theme.service';
import { RuntimeConfigService } from '../core/runtime-config.service';
import { AuthService } from '../core/auth.service';

@Component({
  standalone: true, imports: [CommonModule, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<section class="page"><div class="page-heading"><div><p class="eyebrow">Personal preferences</p><h1>Appearance & settings</h1><p>Theme selection is stored locally before sign-in and can be synchronised to a user profile by enabled backend extensions.</p></div></div><div class="settings-layout"><article class="panel"><header><div><h2>Colour theme</h2><p>Token-based themes keep components free of hard-coded colours.</p></div></header><div class="theme-grid"><button *ngFor="let theme of themes.themes()" type="button" [class.active]="theme.key === themes.active()" (click)="themes.select(theme.key)"><i [style.background]="theme.tokens['primary']"></i><span>{{ theme.name }}</span><small>{{ theme.key === themes.active() ? 'Selected' : 'Use theme' }}</small></button></div></article><aside class="panel profile-card"><h2>{{ auth.user()?.name || 'Nite user' }}</h2><p>{{ auth.user()?.email }}</p><dl><div><dt>Role</dt><dd>{{ auth.user()?.role }}</dd></div><div><dt>Framework</dt><dd>{{ runtime.config().framework_version }}</dd></div><div><dt>Admin client</dt><dd>{{ runtime.config().admin_version }}</dd></div></dl><a routerLink="/roles">Review access controls</a></aside></div></section>`,
  styleUrl: './page.css'
})
export class SettingsPageComponent { readonly themes = inject(ThemeService); readonly runtime = inject(RuntimeConfigService); readonly auth = inject(AuthService); }
