import { Injectable, signal } from '@angular/core';

export interface RuntimeConfiguration {
  application_name: string;
  framework_version: string;
  admin_version: string;
  admin_base_path: string;
  api_base_path: string;
  default_theme: string;
  authentication_mode: 'bearer';
  enabled_features: string[];
  branding: { title: string; favicon_url: string };
}

const fallback: RuntimeConfiguration = {
  application_name: 'Nite', framework_version: '3.0.0', admin_version: '3.0.0', admin_base_path: '/admin', api_base_path: '/api/v1',
  default_theme: 'nite', authentication_mode: 'bearer', enabled_features: [], branding: { title: 'Nite Administration', favicon_url: '' }
};

@Injectable({ providedIn: 'root' })
export class RuntimeConfigService {
  readonly config = signal<RuntimeConfiguration>(fallback);

  async load(): Promise<void> {
    const inline = (window as Window & { __NITE_ADMIN_CONFIG__?: Partial<RuntimeConfiguration> }).__NITE_ADMIN_CONFIG__;
    const base = document.querySelector('base')?.href ?? window.location.origin + '/admin/';
    try {
      const response = await fetch(new URL('runtime-config.json', base), { cache: 'no-store', credentials: 'same-origin' });
      if (response.ok) {
        const loaded = await response.json() as Partial<RuntimeConfiguration>;
        this.config.set({ ...fallback, ...loaded, branding: { ...fallback.branding, ...(loaded.branding ?? {}) } });
        return;
      }
    } catch { /* The PHP renderer injects the safe fallback for offline diagnostics. */ }
    this.config.set({ ...fallback, ...inline, branding: { ...fallback.branding, ...(inline?.branding ?? {}) } });
  }

  apiUrl(path: string): string {
    return this.config().api_base_path.replace(/\/$/, '') + '/' + path.replace(/^\//, '');
  }
}
