import { RuntimeConfigService } from './runtime-config.service';
import { ThemeService } from './theme.service';

describe('ThemeService', () => {
  beforeEach(() => localStorage.clear());

  it('selects and persists a supplied built-in theme', () => {
    const service = new ThemeService(new RuntimeConfigService());
    service.select('dark');

    expect(service.active()).toBe('dark');
    expect(document.documentElement.dataset['niteTheme']).toBe('dark');
    expect(JSON.parse(localStorage.getItem('nite.admin.theme') || '{}').name).toBe('dark');
  });

  it('falls back to the Nite default for an unknown theme', () => {
    const service = new ThemeService(new RuntimeConfigService());
    service.select('does-not-exist');

    expect(service.active()).toBe('nite');
  });
});
