import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RuntimeConfigService } from '../core/runtime-config.service';

interface Dashboard { counts?: Record<string, number>; module_examples?: Record<string, number>; recent_news?: Array<Record<string, unknown>>; upcoming_events?: Array<Record<string, unknown>>; recent_contacts?: Array<Record<string, unknown>>; }
interface Envelope<T> { data: T; }

@Component({
  standalone: true, imports: [CommonModule, DecimalPipe], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<section class="page"><div class="page-heading"><div><p class="eyebrow">Framework operations</p><h1>System overview</h1><p>Live framework information, not seeded demonstration data.</p></div><span class="status" [class.warning]="error()">{{ error() ? 'Limited data' : 'Operational' }}</span></div><div class="metric-grid" *ngIf="data() as dashboard; else loading"><article class="metric" *ngFor="let item of metrics(dashboard)"><span>{{ item.label }}</span><strong>{{ item.value | number }}</strong><small>{{ item.detail }}</small></article></div><ng-template #loading><div class="loading-grid"><i></i><i></i><i></i><i></i></div></ng-template><p class="notice" *ngIf="error()">{{ error() }} Dashboard cards remain available when a service is temporarily unavailable.</p><div class="dashboard-grid" *ngIf="data() as dashboard"><article class="panel chart-panel"><header><div><h2>Registered example activity</h2><p>Counts exposed by configured modules</p></div></header><div class="bar-list" *ngIf="pairs(dashboard.module_examples).length; else empty"><div *ngFor="let pair of pairs(dashboard.module_examples)"><span>{{ pair[0] }}</span><i><b [style.width.%]="barWidth(pair[1], dashboard.module_examples)"></b></i><strong>{{ pair[1] }}</strong></div></div><ng-template #empty><div class="empty">No module activity has been registered.</div></ng-template></article><article class="panel"><header><div><h2>Recent contacts</h2><p>From the current application database</p></div></header><div class="feed" *ngIf="dashboard.recent_contacts?.length; else noContacts"><div *ngFor="let row of dashboard.recent_contacts | slice:0:5"><b>{{ text(row, 'name', 'Contact') }}</b><span>{{ text(row, 'email', 'No email') }}</span></div></div><ng-template #noContacts><div class="empty">No recent contact activity.</div></ng-template></article></div></section>`,
  styleUrl: './page.css'
})
export class DashboardPageComponent {
  private readonly http = inject(HttpClient); private readonly runtime = inject(RuntimeConfigService);
  readonly data = signal<Dashboard | null>(null); readonly error = signal('');
  constructor() { this.http.get<Envelope<Dashboard>>(this.runtime.apiUrl('/admin/dashboard')).subscribe({ next: response => this.data.set(response.data), error: () => { this.error.set('Dashboard data could not be loaded.'); this.data.set({ counts: {}, module_examples: {} }); } }); }
  metrics(data: Dashboard): Array<{ label: string; value: number; detail: string }> { const counts = data.counts ?? {}; return [{ label: 'Users', value: counts['users'] ?? 0, detail: 'registered accounts' }, { label: 'Open contacts', value: counts['open_contacts'] ?? 0, detail: 'requires attention' }, { label: 'Published events', value: counts['published_events'] ?? 0, detail: 'current content' }, { label: 'Course enrollments', value: counts['course_enrollments'] ?? 0, detail: 'live progress' }]; }
  pairs(source?: Record<string, number>): Array<[string, number]> { return Object.entries(source ?? {}).slice(0, 6); }
  barWidth(value: number, source?: Record<string, number>): number { const max = Math.max(...Object.values(source ?? { max: 1 }), 1); return Math.max(4, (value / max) * 100); }
  text(row: Record<string, unknown>, key: string, fallback: string): string { return typeof row[key] === 'string' && row[key] ? row[key] : fallback; }
}
