import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { RuntimeConfigService } from '../core/runtime-config.service';
import { AuthService } from '../core/auth.service';

type Row = Record<string, unknown>;
interface Envelope<T> { data: T; }

@Component({
  standalone: true, imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<section class="page"><div class="page-heading"><div><p class="eyebrow">Administration</p><h1>{{ title }}</h1><p>{{ description }}</p></div><button type="button" class="secondary" (click)="reload()" [disabled]="loading()">Refresh</button></div><div class="toolbar"><label class="search"><span aria-hidden="true">⌕</span><input [(ngModel)]="query" placeholder="Filter results" aria-label="Filter results"></label><span>{{ filtered().length }} visible</span></div><article class="panel table-panel" *ngIf="!loading(); else loadingState"><p class="notice" *ngIf="error()" role="alert">{{ error() }}</p><div class="table-scroll" *ngIf="filtered().length; else empty"><table><thead><tr><th *ngFor="let key of columns()">{{ label(key) }}</th></tr></thead><tbody><tr *ngFor="let row of filtered()"><td *ngFor="let key of columns()">{{ value(row[key]) }}</td></tr></tbody></table></div><ng-template #empty><div class="empty">No {{ title.toLowerCase() }} match the current filter.</div></ng-template></article><ng-template #loadingState><div class="loading-grid"><i></i><i></i><i></i></div></ng-template></section>`,
  styleUrl: './page.css'
})
export class ResourcePageComponent {
  private readonly http = inject(HttpClient); private readonly runtime = inject(RuntimeConfigService); private readonly route = inject(ActivatedRoute); private readonly auth = inject(AuthService);
  readonly rows = signal<Row[]>([]); readonly loading = signal(true); readonly error = signal(''); query = '';
  readonly title = String(this.route.snapshot.data['title'] ?? 'Resource'); readonly endpoint = String(this.route.snapshot.data['endpoint'] ?? ''); readonly permission = String(this.route.snapshot.data['permission'] ?? '');
  readonly description = this.endpoint.includes('meta/routes') ? 'Documented PHP API routes and their live metadata.' : 'Data is requested from the existing Nite API and remains permission controlled.';
  readonly filtered = computed(() => { const needle = this.query.toLowerCase().trim(); return needle ? this.rows().filter(row => JSON.stringify(row).toLowerCase().includes(needle)) : this.rows(); });
  readonly columns = computed(() => { const first = this.filtered()[0] ?? this.rows()[0]; return first ? Object.keys(first).slice(0, 6) : []; });
  constructor() { this.reload(); }
  reload(): void { if (this.permission && !this.auth.can(this.permission)) { this.error.set('You do not have permission to view this resource.'); this.rows.set([]); this.loading.set(false); return; } this.loading.set(true); this.error.set(''); this.http.get<Envelope<Row[] | Row>>(this.runtime.apiUrl(this.endpoint)).subscribe({ next: response => { this.rows.set(Array.isArray(response.data) ? response.data : this.objectRows(response.data)); this.loading.set(false); }, error: () => { this.rows.set([]); this.error.set('The API request failed. Your session and server permissions were not bypassed.'); this.loading.set(false); } }); }
  value(value: unknown): string { if (value === null || value === undefined) return '—'; if (typeof value === 'object') return JSON.stringify(value).slice(0, 90); return String(value); }
  label(value: string): string { return value.replace(/[_-]/g, ' ').replace(/\b\w/g, letter => letter.toUpperCase()); }
  private objectRows(data: Row): Row[] { return Object.entries(data).map(([key, value]) => ({ key, value })); }
}
