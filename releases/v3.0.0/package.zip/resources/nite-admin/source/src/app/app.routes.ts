import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';
import { LoginPageComponent } from './pages/login-page.component';
import { DashboardPageComponent } from './pages/dashboard-page.component';
import { ResourcePageComponent } from './pages/resource-page.component';
import { SettingsPageComponent } from './pages/settings-page.component';

export const routes: Routes = [
  { path: 'login', component: LoginPageComponent },
  { path: 'dashboard', component: DashboardPageComponent, canActivate: [authGuard] },
  { path: 'users', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'Users', endpoint: '/admin/users', permission: 'admin.users.view' } },
  { path: 'roles', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'Roles & permissions', endpoint: '/admin/rbac/roles', permission: 'admin.rbac.view' } },
  { path: 'resources', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'Resources', endpoint: '/admin/resources', permission: 'admin.resources.view' } },
  { path: 'routes', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'API explorer', endpoint: '/meta/routes' } },
  { path: 'audit', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'Audit logs', endpoint: '/admin/audit-logs', permission: 'admin.audit_logs.view' } },
  { path: 'media', component: ResourcePageComponent, canActivate: [authGuard], data: { title: 'Media', endpoint: '/admin/media', permission: 'admin.media.view' } },
  { path: 'settings', component: SettingsPageComponent, canActivate: [authGuard] },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: '**', redirectTo: 'dashboard' }
];
