describe('Nite Admin', () => {
  it('starts its test suite', () => {
    expect(true).toBeTrue();
  });
});
