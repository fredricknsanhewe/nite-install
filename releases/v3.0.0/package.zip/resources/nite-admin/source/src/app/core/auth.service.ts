import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { RuntimeConfigService } from './runtime-config.service';

export interface NiteUser { id: string; email: string; name: string; role: string; permissions?: string[]; profile?: Record<string, unknown>; }
interface ApiEnvelope<T> { data: T; }
interface LoginResult { token: string; user: NiteUser; expires_in: number; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly user = signal<NiteUser | null>(null);
  readonly loading = signal(false);
  constructor(private readonly http: HttpClient, private readonly runtime: RuntimeConfigService) {}
  token(): string | null { try { return sessionStorage.getItem('nite.admin.token'); } catch { return null; } }
  authenticated(): boolean { return !!this.token(); }
  can(permission?: string): boolean { return !permission || (this.user()?.permissions ?? []).includes(permission) || this.user()?.role === 'admin'; }
  async login(email: string, password: string): Promise<void> {
    this.loading.set(true);
    try {
      const result = await firstValueFrom(this.http.post<ApiEnvelope<LoginResult>>(this.runtime.apiUrl('/auth/login'), { email, password }));
      sessionStorage.setItem('nite.admin.token', result.data.token); this.user.set(result.data.user);
    } finally { this.loading.set(false); }
  }
  async restore(): Promise<boolean> {
    if (!this.token()) return false;
    try { const result = await firstValueFrom(this.http.get<ApiEnvelope<NiteUser>>(this.runtime.apiUrl('/me'))); this.user.set(result.data); return true; }
    catch { this.logout(); return false; }
  }
  logout(): void { try { sessionStorage.removeItem('nite.admin.token'); } catch { /* unavailable storage */ } this.user.set(null); }
}
