import { Injectable, signal } from '@angular/core';
import { RuntimeConfigService } from './runtime-config.service';

export interface NiteTheme { key: string; name: string; tokens: Record<string, string>; }

const baseThemes: NiteTheme[] = [
  { key: 'nite', name: 'Nite Default', tokens: { primary: '#5b3cc4', secondary: '#372780', accent: '#f06d7b', background: '#f7f7fb', surface: '#ffffff', elevated: '#ffffff', sidebar: '#17142b', header: '#ffffff', text: '#19162b', muted: '#6f6b86', border: '#e3e0ee', success: '#09835b', warning: '#a25b00', danger: '#c8384e', info: '#3656c8', focus: '#5b3cc4', hover: '#f0edff', selected: '#e8e1ff', chart1: '#5b3cc4', chart2: '#f06d7b', chart3: '#188a99', chart4: '#e49a26' } },
  { key: 'light', name: 'Light', tokens: { primary: '#2563eb', secondary: '#1e3a8a', accent: '#d97706', background: '#f8fafc', surface: '#ffffff', elevated: '#ffffff', sidebar: '#eff6ff', header: '#ffffff', text: '#172033', muted: '#64748b', border: '#dbe3ef', success: '#15803d', warning: '#a16207', danger: '#be123c', info: '#2563eb', focus: '#1d4ed8', hover: '#eff6ff', selected: '#dbeafe', chart1: '#2563eb', chart2: '#db2777', chart3: '#059669', chart4: '#d97706' } },
  { key: 'dark', name: 'Dark', tokens: { primary: '#a78bfa', secondary: '#7c3aed', accent: '#fb7185', background: '#10101a', surface: '#1b1a28', elevated: '#242236', sidebar: '#151421', header: '#1b1a28', text: '#f5f3ff', muted: '#b6b1ca', border: '#36334d', success: '#4ade80', warning: '#fbbf24', danger: '#fb7185', info: '#60a5fa', focus: '#c4b5fd', hover: '#2d2944', selected: '#3c3561', chart1: '#a78bfa', chart2: '#fb7185', chart3: '#2dd4bf', chart4: '#fbbf24' } },
  { key: 'ocean', name: 'Ocean Blue', tokens: { primary: '#0369a1', secondary: '#0c4a6e', accent: '#06b6d4', background: '#f0f9ff', surface: '#ffffff', elevated: '#ffffff', sidebar: '#082f49', header: '#ffffff', text: '#0c2434', muted: '#547082', border: '#cce6f1', success: '#047857', warning: '#b45309', danger: '#be123c', info: '#0284c7', focus: '#06b6d4', hover: '#e0f2fe', selected: '#bae6fd', chart1: '#0369a1', chart2: '#06b6d4', chart3: '#14b8a6', chart4: '#f59e0b' } },
  { key: 'emerald', name: 'Emerald', tokens: { primary: '#047857', secondary: '#064e3b', accent: '#65a30d', background: '#f4fbf7', surface: '#ffffff', elevated: '#ffffff', sidebar: '#052e26', header: '#ffffff', text: '#12332b', muted: '#5c756d', border: '#cfe9dc', success: '#15803d', warning: '#a16207', danger: '#be123c', info: '#0f766e', focus: '#059669', hover: '#e4f7ed', selected: '#c9f2dc', chart1: '#047857', chart2: '#65a30d', chart3: '#0891b2', chart4: '#d97706' } },
  { key: 'purple', name: 'Royal Purple', tokens: { primary: '#6d28d9', secondary: '#3b0764', accent: '#d946ef', background: '#faf7ff', surface: '#ffffff', elevated: '#ffffff', sidebar: '#28113f', header: '#ffffff', text: '#2a1741', muted: '#746683', border: '#e7dcf2', success: '#15803d', warning: '#a16207', danger: '#be123c', info: '#4f46e5', focus: '#7c3aed', hover: '#f3e8ff', selected: '#e9d5ff', chart1: '#6d28d9', chart2: '#d946ef', chart3: '#0f766e', chart4: '#ca8a04' } },
  { key: 'amber', name: 'Amber', tokens: { primary: '#b45309', secondary: '#78350f', accent: '#dc2626', background: '#fffbeb', surface: '#ffffff', elevated: '#ffffff', sidebar: '#3e240d', header: '#ffffff', text: '#35240f', muted: '#7b6a4a', border: '#f0dfb9', success: '#15803d', warning: '#b45309', danger: '#b91c1c', info: '#0369a1', focus: '#d97706', hover: '#fef3c7', selected: '#fde68a', chart1: '#b45309', chart2: '#dc2626', chart3: '#0f766e', chart4: '#7c3aed' } },
  { key: 'slate', name: 'Slate', tokens: { primary: '#475569', secondary: '#1e293b', accent: '#0284c7', background: '#f8fafc', surface: '#ffffff', elevated: '#ffffff', sidebar: '#1e293b', header: '#ffffff', text: '#172033', muted: '#64748b', border: '#d8e0ea', success: '#15803d', warning: '#a16207', danger: '#be123c', info: '#0284c7', focus: '#475569', hover: '#e9eef5', selected: '#dbe4ef', chart1: '#475569', chart2: '#0284c7', chart3: '#0f766e', chart4: '#a16207' } },
  { key: 'high-contrast', name: 'High Contrast', tokens: { primary: '#ffff00', secondary: '#ffffff', accent: '#00ffff', background: '#000000', surface: '#000000', elevated: '#111111', sidebar: '#000000', header: '#000000', text: '#ffffff', muted: '#ffffff', border: '#ffffff', success: '#00ff00', warning: '#ffff00', danger: '#ff5c5c', info: '#00ffff', focus: '#ffff00', hover: '#222222', selected: '#333333', chart1: '#ffff00', chart2: '#00ffff', chart3: '#00ff00', chart4: '#ff5c5c' } }
];

@Injectable({ providedIn: 'root' })
export class ThemeService {
  readonly themes = signal<NiteTheme[]>(baseThemes);
  readonly active = signal('nite');
  constructor(private readonly runtime: RuntimeConfigService) {}

  async initialize(): Promise<void> {
    const base = document.querySelector('base')?.href ?? window.location.origin + '/admin/';
    try {
      const response = await fetch(new URL('assets/custom-themes/themes.json', base));
      const custom = response.ok ? await response.json() as unknown : [];
      if (Array.isArray(custom)) this.themes.set([...baseThemes, ...custom.filter(this.isTheme)]);
    } catch { /* optional developer overlay */ }
    let selected = this.runtime.config().default_theme;
    try { selected = JSON.parse(localStorage.getItem('nite.admin.theme') || 'null')?.name || selected; } catch { /* unavailable storage */ }
    this.select(selected, false);
  }

  select(key: string, persist = true): void {
    const theme = this.themes().find(item => item.key === key) ?? this.themes()[0];
    document.documentElement.dataset['niteTheme'] = theme.key;
    Object.entries(theme.tokens).forEach(([token, value]) => document.documentElement.style.setProperty('--nite-' + token, value));
    this.active.set(theme.key);
    if (persist) try { localStorage.setItem('nite.admin.theme', JSON.stringify({ name: theme.key })); } catch { /* storage fallback is deliberately best effort */ }
  }

  private isTheme(value: unknown): value is NiteTheme {
    return !!value && typeof value === 'object' && typeof (value as NiteTheme).key === 'string' && typeof (value as NiteTheme).name === 'string' && typeof (value as NiteTheme).tokens === 'object';
  }
}
