import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const token = inject(AuthService).token();
  return next(token && request.url.includes('/api/') ? request.clone({ setHeaders: { Authorization: `Bearer ${token}`, 'Cache-Control': 'no-store' } }) : request);
};
