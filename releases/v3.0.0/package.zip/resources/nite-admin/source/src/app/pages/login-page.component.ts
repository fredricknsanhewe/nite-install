import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RuntimeConfigService } from '../core/runtime-config.service';
import { AuthService } from '../core/auth.service';

@Component({
  standalone: true, imports: [FormsModule, NgIf], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<section class="login-shell"><form (ngSubmit)="submit()" #form="ngForm" class="login-card"><div class="login-brand"><span>N</span><div><small>{{ runtime.config().application_name }}</small><h1>Administration</h1></div></div><p>Sign in with your existing Nite account. Your permissions remain enforced by the PHP application.</p><label>Email<input name="email" type="email" autocomplete="username" required [(ngModel)]="email"></label><label>Password<input name="password" type="password" autocomplete="current-password" required [(ngModel)]="password"></label><p class="form-error" *ngIf="error()" role="alert">{{ error() }}</p><button type="submit" [disabled]="!form.valid || auth.loading()">{{ auth.loading() ? 'Signing in…' : 'Sign in' }}</button><small class="hint">Nite {{ runtime.config().framework_version }} · Secure bearer-token session</small></form></section>`,
  styleUrl: './login-page.component.css'
})
export class LoginPageComponent {
  readonly runtime = inject(RuntimeConfigService); readonly auth = inject(AuthService); private readonly router = inject(Router);
  email = ''; password = ''; readonly error = signal('');
  async submit(): Promise<void> { this.error.set(''); try { await this.auth.login(this.email, this.password); await this.router.navigateByUrl('/dashboard'); } catch (error: unknown) { this.error.set(this.errorMessage(error)); } }
  private errorMessage(error: unknown): string { const value = error as { error?: { message?: string } }; return value?.error?.message || 'Unable to sign in. Check your email and password.'; }
}
