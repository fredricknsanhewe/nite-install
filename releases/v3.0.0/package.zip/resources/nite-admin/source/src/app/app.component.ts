import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { AuthService } from './core/auth.service';
import { RuntimeConfigService } from './core/runtime-config.service';
import { ThemeService } from './core/theme.service';

interface NavigationItem { label: string; route: string; icon: string; permission?: string; }

@Component({
  selector: 'app-root', standalone: true, imports: [RouterOutlet, RouterLink, RouterLinkActive, NgFor, NgIf],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <main class="app-frame" [class.signed-out]="!auth.authenticated()">
      <aside class="sidebar" *ngIf="auth.authenticated()" [class.open]="mobileOpen()">
        <a class="brand" routerLink="/dashboard" (click)="mobileOpen.set(false)"><span class="brand-mark">N</span><span>{{ runtime.config().application_name }}</span></a>
        <nav aria-label="Administration navigation">
          <a *ngFor="let item of visibleNavigation()" [routerLink]="item.route" routerLinkActive="active" (click)="mobileOpen.set(false)"><span aria-hidden="true">{{ item.icon }}</span>{{ item.label }}</a>
        </nav>
        <div class="sidebar-foot"><small>Nite {{ runtime.config().framework_version }}</small><a routerLink="/settings">Appearance & settings</a></div>
      </aside>
      <section class="work-area">
        <header class="topbar" *ngIf="auth.authenticated()">
          <button class="icon-button menu" type="button" (click)="mobileOpen.set(!mobileOpen())" aria-label="Toggle navigation">☰</button>
          <div class="crumb"><span>Administration</span><strong>{{ pageTitle() }}</strong></div>
          <div class="top-actions">
            <label class="sr-only" for="quick-theme">Theme</label>
            <select id="quick-theme" [value]="themes.active()" (change)="themes.select(themeValue($event))" aria-label="Select colour theme"><option *ngFor="let theme of themes.themes()" [value]="theme.key">{{ theme.name }}</option></select>
            <button class="profile" type="button" (click)="profileOpen.set(!profileOpen())" [attr.aria-expanded]="profileOpen()"><span>{{ initials() }}</span><b>{{ auth.user()?.name || 'Administrator' }}</b></button>
            <div class="profile-menu" *ngIf="profileOpen()"><a routerLink="/settings" (click)="profileOpen.set(false)">Settings</a><button type="button" (click)="logout()">Sign out</button></div>
          </div>
        </header>
        <router-outlet />
      </section>
    </main>
  `,
  styleUrl: './app.component.css'
})
export class AppComponent {
  readonly auth = inject(AuthService); readonly runtime = inject(RuntimeConfigService); readonly themes = inject(ThemeService); private readonly router = inject(Router);
  readonly mobileOpen = signal(false); readonly profileOpen = signal(false);
  readonly navigation: NavigationItem[] = [
    { label: 'Overview', route: '/dashboard', icon: '◈' }, { label: 'Users', route: '/users', icon: '◉', permission: 'admin.users.view' },
    { label: 'Roles & access', route: '/roles', icon: '◇', permission: 'admin.rbac.view' }, { label: 'Resources', route: '/resources', icon: '▦', permission: 'admin.resources.view' },
    { label: 'API explorer', route: '/routes', icon: '⌘' }, { label: 'Audit logs', route: '/audit', icon: '◌', permission: 'admin.audit_logs.view' },
    { label: 'Media', route: '/media', icon: '▧', permission: 'admin.media.view' }, { label: 'Settings', route: '/settings', icon: '⚙' }
  ];
  readonly visibleNavigation = computed(() => this.navigation.filter(item => this.auth.can(item.permission)));
  pageTitle = computed(() => this.router.url.split('/').filter(Boolean).map(part => part.replace(/-/g, ' ').replace(/\b\w/g, char => char.toUpperCase())).at(-1) || 'Overview');
  initials(): string { return (this.auth.user()?.name || 'Nite').split(/\s+/).map(part => part[0]).join('').slice(0, 2).toUpperCase(); }
  themeValue(event: Event): string { return (event.target as HTMLSelectElement).value; }
  logout(): void { this.auth.logout(); this.profileOpen.set(false); void this.router.navigateByUrl('/login'); }
}
