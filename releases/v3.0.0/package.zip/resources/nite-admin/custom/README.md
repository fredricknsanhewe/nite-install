# Nite Admin customisation overlay

Keep developer-owned changes here. Add a `themes/themes.json` file containing an array of `{ "key", "name", "tokens" }` objects; the build publishes it at `assets/custom-themes/themes.json` and the administrator loads it at runtime. Do not edit the framework source for token-only changes.

Run `php nite admin:sync-source` before an upgrade to record or inspect source changes, and `php nite admin:build` after changing this directory.
