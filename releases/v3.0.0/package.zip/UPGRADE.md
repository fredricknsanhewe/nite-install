# Upgrade guide

## Upgrading 2.2.0 to 3.0.0

1. Run the normal backup-enabled upgrade and accept the major-version compatibility prompt.
2. No Node.js installation or rebuild is required: the release includes `public/nite-admin`.
3. Open the existing `/admin` URL. The default is `NITE_ADMIN_DRIVER=angular`; `legacy` remains available for recovery.
4. Run `php nite samples:clean --dry-run`, then `php nite samples:clean` only after reviewing preserved modified files and tables.
5. If Angular source was changed, use `php nite admin:sync-source` and keep reusable token changes under `resources/nite-admin/custom`.

Existing APIs, JWT authentication, permission identifiers, users, configuration, uploads, storage, generated resources, and application code are preserved. Legacy admin support remains through 3.0.x and is planned for retirement in 3.1.0 only when compatibility permits.

## Supported upgrade path

Nite 2.2.0 supports upgrades from every published release, including the earliest `v0.1.0` tag. Upgrade from one release package at a time; do not copy framework files over an installation manually.

```bash
php nite app:doctor
php nite app:update --accept-compatibility
```

The compatibility acknowledgement is required only when crossing the v0/v1-to-v2 major-version boundary.

The updater preserves `.env`, `.env.docker`, `storage/`, `public/uploads/`, and generated routes. It creates a backup under `storage/console/backups/` by default. Commit or back up custom source changes before using `--accept-conflicts` or `--force`.

## Compatibility defaults

- Existing `.env` files without `NITE_PASSWORD_POLICY_PROFILE` use the legacy-compatible password policy: minimum eight characters and no new composition requirements.
- New applications set `NITE_PASSWORD_POLICY_PROFILE=modern` and use the stronger v2.2 defaults.
- To opt an upgraded application into the stronger rules, add:

```dotenv
NITE_PASSWORD_POLICY_PROFILE=modern
```

- The RBAC matrix remains automatic by default. Use `NITE_RBAC_MATRIX_FORMAT=legacy` for v0-v1 response data or `NITE_RBAC_MATRIX_FORMAT=groups` for the v2 group response.

## Legacy RBAC API

The following v0-v1 endpoints remain available through Nite 2.x:

- `GET /api/v1/admin/rbac/roles`
- `PUT /api/v1/admin/rbac/roles/{role}/permissions`
- `PATCH /api/v1/admin/rbac/roles/{role}/permissions`

They send a `Deprecation: true` response header. Move to `/api/v1/admin/rbac/groups` and `/api/v1/admin/rbac/groups/{id}/permissions` before Nite 3.0.

## Database migrations

Run `php nite db:migrate` after every package sync. The 2.2.0 migration corrects historical migration-ledger versions only. It does not delete or modify application records. This lets downgrade planning identify the correct `v1.1.0` and `v2.1.0` boundaries.

Before a production upgrade, test a database copy and verify:

- an existing user can sign in;
- existing role permissions still work;
- custom generated routes and uploads remain present;
- your integration accepts the selected RBAC matrix format.
